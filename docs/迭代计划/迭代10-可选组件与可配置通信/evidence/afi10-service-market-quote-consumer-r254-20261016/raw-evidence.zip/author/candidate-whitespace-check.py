import json
from pathlib import Path
paths = [Path(item) for item in __import__('sys').argv[1:]]
issues = []
for path in paths:
    raw = path.read_bytes()
    if not raw.endswith(b'\n'):
        issues.append({'path': str(path), 'issue': 'missing_final_lf'})
    for number, line in enumerate(raw.splitlines(), 1):
        if line.endswith((b' ', b'\t')):
            issues.append({'path': str(path), 'line': number, 'issue': 'trailing_whitespace'})
        if b'\x00' in line:
            issues.append({'path': str(path), 'line': number, 'issue': 'nul_byte'})
result = {'files': [str(path) for path in paths], 'issues': issues, 'passed': not issues}
print(json.dumps(result, indent=2))
raise SystemExit(0 if not issues else 1)
