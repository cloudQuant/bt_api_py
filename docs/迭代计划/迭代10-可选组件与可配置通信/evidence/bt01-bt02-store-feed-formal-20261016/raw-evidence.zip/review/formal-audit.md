# BT01 / BT02 正式条款静态裁定（2026-10-16）

本记录只汇总已接受证据并裁定正式条款；未运行测试、Host、provider 或旧入口，也未改 tracker/progress。结合本轮 Store/Feed 正常链，建议 Root 将 **BT01、BT02 均翻为正式 PASS**，总数从既有 35/68 增至 37/68。正式条款要求的是具体正常数据、策略账簿语义、恢复与关闭行为，并未要求真实交易所账户；BT01 还明确允许替换最末端 provider。保留范围披露：当前为本机合成末端行情/撮合 provider，不能代表交易所或真实账户；回调以持久待交付/ACK状态追踪，失败可重放，属于 at-least-once 语义，不承诺任意用户副作用跨进程 exactly-once。

## 本轮正常 Store/Feed 链

原只读诊断 `.codex-tmp/iteration10_bt01_bt02_wiring_readonly_r1_20261016.md` 定位的具体缺口是：此前已接受的 fresh-process 恢复链用测试专用 Pandas feed，没有从 `BtApiStore.getdata()` 走生产 `BtApiFeed`，并把行情 quote/bar 与 V2 持久 fill 绑定起来。该缺口现已由 Root r3 关闭。

Root 结果 `D:/temp/iteration10-bt01-bt02-store-feed-binding-root-20261016-r3/result.json` 记为 pytest exit 0、819 个 source pin 和五个仓库 HEAD 前后不变；`junit.xml` 为 1 passed、13.764 秒。只有一条既有 Quandl deprecation warning，见同目录 `stdout.log`。证据级别为 `PRODUCTION_TICK_QUOTE_ALIGNMENT_AND_REAL_LOCAL_STORE_FEED_BROKER_V2_HOST_SYNTHETIC_PROVIDER`。被执行节点与冻结源 pin 见 r3 `spec.json`，测试为 `D:/source_code/backtrader/tests/integration/test_managed_paper_v2_store_feed_binding.py`。

该节点真实调用 `BtApiStore.getdata()` 并断言产物是 `BtApiFeed`；同一 data 上按序收到 cursor 1、2。填单上下文把 quote source/generation/cursor/instrument/as-of 与 data name、bar index、datetime 对齐；来自 Host 持久 V2 projection 的成交量价为 1.25 / 10.02，撮合时间不早于 quote as-of，策略收到一个 trade callback，Host 只派发一次。Session/runtime、runner 与 Host 正常关闭，exit 0、无强制回收，两对 Pipe 均闭合（测试约第 297–384、390–495、561–590 行）。r2 中已接受的独立 tick-to-bar 单测通过，r3 spec 明确标记该 unit 已接受且未重复运行；不把 r2 同轮集成失败改写为通过。

失败记录均原样保留：r1 `D:/temp/iteration10-bt01-bt02-store-feed-binding-root-20261016-r1/` 的单节点失败为 `service execution recovery projection unavailable`，促成 `_drain_live_ticks` 在产生新可交付 line bar 后停止排空的窄生产修复；r2 `...-r2/` 中 unit 节点通过，集成节点因把一条 intent 错当一个 event receipt 而拒绝实际四个生命周期 receipts。r2 的 JUnit/stdout/result 未覆盖或重写；r3 按 intent 唯一、receipt 四事件的真实合同修正后通过。R1/R2 是保留的修复过程证据，不抵销 r3 正向验收。

## 正式条款逐项对照

**BT01 — 正式 PASS。** 正常数据推进、成交通知、内置 Store feed 与 V2 Broker/Host 的可信 quote/bar/fill 绑定及本轮全关闭由上述 r3 Root 集成证明。策略资金/持仓与共享 Broker 读语义由已接受的 Backtrader R82、R107、R120 补齐：R82 显式 strategy account book、持仓/费用且缺少 cash/value 时不回退到全账户值或 Risk 预算（`D:/temp/iteration10-backtrader-strategy-account-book-20261015-r1/`；父进度 `docs/迭代计划/迭代10-可选组件与可配置通信/开发与验收进度.md:2461-2489`）；R107 证明两个绑定策略的 owner view 隔离、共享 Broker 保持账户 getter 语义及正常关闭（`docs/迭代计划/迭代10-可选组件与可配置通信/evidence/bt02-multi-strategy-20261016/root-adjudication.md`，进度 `:3121-3134`）；R120 证明双策略真实 Cerebro/ServiceHost/SQLite 的现金、持仓数量/成本、费用在同一 RunID 正常重开后保持且不重复派发/入账（`docs/迭代计划/迭代10-可选组件与可配置通信/evidence/backtrader-strategy-financial-service-20261016/root-adjudication.md`，进度 `:3267-3285`）。恢复与重连后的 Broker 恢复见下列 R184；正常退出/关闭亦由 R120、R122、R184 与 r3 分别覆盖。计划 §10 BT01 只要求末端 provider 可替换，不要求真实账户。

**BT02 — 正式 PASS。** 策略与 Broker 的显式绑定、共享 Broker 账户级读语义、预算不冒充 cash 见 R82/R107。重复回报/投影的去重见 R122：同一受认证 projection revision 再次进入 Broker 更新后，持仓、成交量、均价、手续费与回调次数不继续增长，持久 dispatch/reserve/settle 各一次，Session/runtime/Host 正常关闭（`docs/迭代计划/迭代10-可选组件与可配置通信/evidence/backtrader-execution-callbacks-20261016/root-adjudication.md`，进度 `:3291-3299`）。快照/事件/cursor 恢复及 callback 崩溃窗口由已接受 R184 fresh-process V2 链覆盖：测试 `D:/source_code/backtrader/tests/integration/test_managed_paper_v2_fresh_process_recovery.py:1491-1700` 在 Trade checkpoint 后、callback ACK 前让第一策略进程崩溃；同一 logical run/journal 的第二进程只水合一笔原 Trade、重放并 ACK pending callback，`submit_calls=0`，receipt 数不增，Host `dispatch_attempts=1`。R184 接受记录为父进度 `docs/迭代计划/迭代10-可选组件与可配置通信/开发与验收进度.md:3880-3886`，其中记录 Backtrader commit `be07a50ed`、独立复核 GO、1 passed / 169.31 秒及恰一次派发/ACK；真实 local SDK/ServiceHost/CURVE/SQLite/Cerebro 链，provider 为合成叶子。callback 的重放属于合同允许的 at-least-once，不是新成交或重复交易意图。计划 §8 与 BT02 明确不要求任意用户回调 exactly-once。

BT01/BT02 可以按跨轮已接受证据合并裁定，不要求把资金账、重复 projection、fresh-process crash 和正常 Store feed 全塞进同一节点，也不要求重跑已接受 R82/R107/R120/R122/R184 或 unit。正式条款摘录见 `docs/迭代计划/迭代10-可选组件与可配置通信/正式迭代计划.md:696-697,765-766`。本记录是裁定支持材料；正式状态表由 Root 更新。
