# MIG04 R211 candidate raw bundle

This contains only the new certlib consumer closure evidence: consumer R1 logs and result, exact successful R9 runner/child/result, and selected raw R1–R8 failure outputs. The accepted R161 and R197 evidence remains at its original repository paths and is referenced by exact hashes in the outer manifest and adjudication; no old wheel or sdist is duplicated.

The consumer venv and 121-wheel wheelhouse remain at the original D:\temp location and are not copied. No environment file, account data, credential or install/build tree is included.