# Execution recoverable-page static review — 2026-10-16

**Verdict:** `GO_STATIC_STORE_API_ONLY`; `HOLD` for claiming the DIM09 owner scan has been bounded. Static review only: no QA or tests were run.

Frozen candidates on `D:\bt_api_py\bt_api\bt_api_execution` dev `f5c030644dea06ce91afbaacf94e11e353538186`:

- `src/bt_api_execution/group_store.py` — 45,592 bytes, SHA-256 `66b4d99df7056f6f24042d342ab5b336197edfb140ee43e5706feeca1d85e1d4`.
- `tests/test_group_store_recoverable_page.py` — 5,928 bytes, SHA-256 `2371f6d7c2fe21afe6e4ad04b8f71ae2abca91340def037f9360bf992be68ed9`.

The additive API is statically sound. It validates an exact integer page size in `[1, 256]` (excluding bool), and an exact three-item cursor with positive SQLite-int-range timestamp and refs matching the existing ASCII reference grammar. It binds all values, uses the exclusive lexicographic keyset `(created_at_ns, portfolio_ref, group_id)`, orders by that same key, and appends a real SQL `LIMIT`. Creation time is retained by `update`; the new row-value predicate and index key order therefore remain stable across revisions. The read acquires the store's `RLock`, performs no transaction/write, and is compatible with the existing connection: it can observe same-connection uncommitted state under an active transaction, while other local store methods serialize on the lock. SQLite errors follow the existing `DurableStoreError` convention. The old `list_recoverable()` remains unchanged.

The schema adds `order_group_snapshots_recovery_page(created_at_ns, portfolio_ref, group_id, state)`, matching the keyset/order prefix and making `state` available to filter during the ordered scan. It is created idempotently alongside existing schema objects; no column or data migration is needed. This costs one additional index entry per snapshot and index maintenance when state changes. Static source shows the index can support ordered keyset traversal; the new test checks emitted `LIMIT` SQL but does not assert an SQLite query plan or measure rows visited.

The test meaningfully covers equal creation timestamps, group-id tie order, two-item keyset pages, a row becoming terminal between pages, a later row becoming `RECOVERY_REQUIRED`, empty tail, maximum limit, legacy API output, and invalid limit/cursor types and bounds. It does not cover portfolio-ref tie ordering or wrap-around.

One caller condition must be explicit before production adoption. Each page evaluates current state, but the cursor only advances. `_TERMINAL_STATES` excludes `PAIRED`, while the transition table permits `PAIRED -> UNWINDING`; if a scan passes that key while it is PAIRED, then it becomes UNWINDING, the current pass misses it. A caller retaining cursors across owner ticks must reset to `after=None` after exhausting a pass (and repeat bounded passes as needed); the method docstring currently invites retaining the cursor between ticks without stating this wrap condition. Also, production `GroupCoordinator.recover_interrupted_groups()` still calls unbounded `list_recoverable()`. Thus this API-only round does not yet make DIM09 owner recovery bounded.

The only implementation caveat found is the caller integration/wrap contract above; no defect was found in the candidate SQL, cursor validation, or transaction use.