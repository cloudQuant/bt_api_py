from pathlib import Path
import hashlib
import json
import os
import sys
import time

root = Path('D:/bt_api_py')
folder = root / '.codex-tmp/load01-lazy-reply-budget-20261021'
os.environ['BT_API_PY_LIGHT_IMPORT'] = '1'
os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD'] = '1'
sys.path[:0] = [str(root), *(str(p) for p in sorted((root/'bt_api').glob('bt_api_*/src')))]
applied = json.loads((folder/'applied.json').read_text(encoding='utf-8'))
pins = {name: hashlib.sha256((root/name).read_bytes()).hexdigest() for name in applied['scope']}
assert all(pin == applied['scope'][name]['after_sha256'] for name, pin in pins.items())
out = folder/'source-qa-result.json'
assert not out.exists()
config = folder/'pytest.ini'
config.write_text('[pytest]\naddopts = --import-mode=importlib --strict-markers\nmarkers =\n    integration: Local integration\n    unit: Local unit\n    slow: Slow local tests\n', encoding='utf-8')
import pytest
import bt_api_py.service_host as host
import bt_api_py.service_registry as registry
import bt_api_gateway.market_hub as hub
import bt_api_transport_zmq.service_v2 as transport
origins = {
    'bt_api_py.service_host': 'bt_api_py/service_host.py',
    'bt_api_py.service_registry': 'bt_api_py/service_registry.py',
    'bt_api_gateway.market_hub': 'bt_api/bt_api_gateway/src/bt_api_gateway/market_hub.py',
    'bt_api_transport_zmq.service_v2': 'bt_api/bt_api_transport_zmq/src/bt_api_transport_zmq/service_v2.py',
}
for name, relative in origins.items():
    assert Path(sys.modules[name].__file__).resolve() == (root/relative).resolve()
selected = [
    'tests/unit/test_service_market_bounded_reply_integration.py',
    'tests/unit/test_service_registry.py::test_handler_exceptions_are_finite_and_registry_bounds_are_enforced',
]
start = time.monotonic()
code = pytest.main(['-q', '-c', str(config), '--noconftest', '-p', 'no:cacheprovider',
                    '--junitxml='+str(folder/'focused.xml'), *(str(root/p) for p in selected)])
after = {name: hashlib.sha256((root/name).read_bytes()).hexdigest() for name in pins}
assert after == pins
ctp_loaded = any(n.startswith(('bt_api_ctp','openctp','ctpwrapper','vnpy_ctp')) for n in sys.modules)
assert not ctp_loaded
result = {'evidence': 'LOCAL_SYNTHETIC_HOST_REGISTRY_REPLY_BUDGET_ONLY',
          'pytest_exit': int(code), 'selected': selected, 'elapsed_seconds': time.monotonic()-start,
          'pins': pins, 'pins_unchanged': True, 'origins': origins,
          'ctp_modules_loaded': ctp_loaded, 'account_action': False,
          'retained_r7_runtime_used': False}
out.write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
print(json.dumps({'pytest_exit': int(code), 'result': str(out)}))
raise SystemExit(code)
