from __future__ import annotations

import ast
import hashlib
import json
import re
import shutil
import subprocess
import tomllib
from pathlib import Path

BT = Path(r"D:\source_code\backtrader")
SDK = Path(r"D:\bt_api_py")
R14 = Path(r"D:\temp\iteration10-bt-p5a-group-source-20261016-r25")
OUT = Path(r"D:\temp\iteration10-bt-p5a-group-source-20261016-r26")
BASE_SPEC = Path(r"D:\bt_api_py\.codex-tmp\iteration10_bt_p5a_group_cerebro_root_focused_qa_r25_20261016.json")
SPEC_OUT = SDK / ".codex-tmp" / "iteration10_bt_p5a_group_cerebro_root_focused_qa_r26_20261016.json"
MATERIALIZER = Path(r"D:\temp\materialize_iteration10_bt_p5a_r26.py")
TEST = BT / "tests" / "integration" / "test_btapi_execution_group_cerebro_v3_host.py"
ACCEPTED_ROOT = "77b86e2139708455722a3f11955cce18b14647fe"
PLUGIN_REPOS = (
    "bt_api_binance", "bt_api_bitget", "bt_api_bybit", "bt_api_coinbase",
    "bt_api_ctp", "bt_api_dydx", "bt_api_gateio", "bt_api_htx",
    "bt_api_hyperliquid", "bt_api_ib_web", "bt_api_kraken", "bt_api_mexc",
    "bt_api_mt5", "bt_api_okx",
)
TEXT_SUFFIXES = {".py", ".pyi", ".yaml", ".yml", ".json", ".toml", ".txt", ".ini", ".cfg", ".xml", ".csv"}
NATIVE_SUFFIXES = {".dll", ".pyd", ".so", ".dylib", ".lib", ".a", ".exe", ".bin"}

if OUT.exists():
    raise SystemExit(f"refusing to overwrite existing export: {OUT}")
if not R14.is_dir() or not TEST.is_file() or not BASE_SPEC.is_file():
    raise SystemExit("R14 export, candidate test, or base spec is missing")
shutil.copytree(R14, OUT)


def run_git(repo: Path, *args: str, raw: bool = False):
    result = subprocess.run(
        ["git", "-C", str(repo), *args], check=True,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
    )
    return result.stdout if raw else result.stdout.decode("utf-8").strip()


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def gitlink(path: str) -> str:
    row = run_git(SDK, "ls-tree", ACCEPTED_ROOT, path)
    fields = row.split()
    if len(fields) != 4 or fields[1] != "commit":
        raise SystemExit(f"expected accepted gitlink at {path}: {row!r}")
    return fields[2]


def metadata_files(project: dict, target_name: str) -> list[Path]:
    project_table = project.get("project")
    if not isinstance(project_table, dict):
        raise SystemExit(f"project table missing in {target_name}")
    name = project_table.get("name")
    version = project_table.get("version")
    if type(name) is not str or type(version) is not str:
        raise SystemExit(f"static project name/version missing in {target_name}")
    normalized = re.sub(r"[-_.]+", "-", name).lower()
    dist = OUT / f"{normalized}-{version}.dist-info"
    dist.mkdir(parents=True, exist_ok=True)
    (dist / "METADATA").write_text(
        f"Metadata-Version: 2.1\nName: {name}\nVersion: {version}\n\n",
        encoding="utf-8", newline="\n",
    )
    ep_group = project_table.get("entry-points", {}).get("bt_api.plugins", {})
    if ep_group:
        if not isinstance(ep_group, dict):
            raise SystemExit(f"invalid bt_api.plugins entry points in {target_name}")
        lines = ["[bt_api.plugins]"]
        lines.extend(f"{key} = {value}" for key, value in sorted(ep_group.items()))
        (dist / "entry_points.txt").write_text(
            "\n".join(lines) + "\n", encoding="utf-8", newline="\n"
        )
    (dist / "top_level.txt").write_text(name.replace("-", "_") + "\n", encoding="utf-8", newline="\n")
    return [dist / "METADATA", *([dist / "entry_points.txt"] if ep_group else []), dist / "top_level.txt"]


# Give importlib.metadata the exact package versions for the already-exported
# accepted SDK source, so system-site .dist-info cannot supply an R227 version.
core_sources = (
    (SDK, ACCEPTED_ROOT, "pyproject.toml", "sdk-root/pyproject.toml"),
    (SDK / "bt_api" / "bt_api_base", "b4aabd1e17b9c7252fa7b4d266932087d99b5517", "pyproject.toml", "sdk-base/pyproject.toml"),
    (SDK / "bt_api" / "bt_api_execution", "cb66b480b5cc9a2d56ab5c27f9cc6c9f87a81a2e", "pyproject.toml", "sdk-execution/pyproject.toml"),
    (SDK / "bt_api" / "bt_api_risk", "ede55dec5e8e7ad1c5376969eb54e9933ebf9e85", "pyproject.toml", "sdk-risk/pyproject.toml"),
    (SDK / "bt_api" / "bt_api_monitor", "536a4f04747182749fabdac5e28624f80465bc53", "pyproject.toml", "sdk-monitor/pyproject.toml"),
    (SDK / "bt_api" / "bt_api_transport_zmq", "a397fdb460d2deb22e67ceb4963992ef63dbbb0e", "pyproject.toml", "sdk-transport/pyproject.toml"),
)
core_project_provenance = []
for repo, commit, source_path, export_rel in core_sources:
    rel = "pyproject.toml" if repo == SDK else source_path
    data = run_git(repo, "show", f"{commit}:{rel}", raw=True)
    target = OUT / export_rel
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    project = tomllib.loads(data.decode("utf-8"))
    dist_files = metadata_files(project, export_rel)
    core_project_provenance.append({
        "repository": str(repo), "accepted_commit": commit, "git_path": rel,
        "export_path": str(target), "pyproject_sha256": sha(target),
        "pyproject_bytes": target.stat().st_size,
        "generated_dist_info": [str(p) for p in dist_files],
    })

plugin_rows = []
plugin_pythonpaths = []
for repo_name in PLUGIN_REPOS:
    repo = SDK / "bt_api" / repo_name
    gitlink_path = f"bt_api/{repo_name}"
    commit = gitlink(gitlink_path)
    run_git(repo, "cat-file", "-e", f"{commit}^{{commit}}")
    project_bytes = run_git(repo, "show", f"{commit}:pyproject.toml", raw=True)
    project = tomllib.loads(project_bytes.decode("utf-8"))
    name = project.get("project", {}).get("name")
    version = project.get("project", {}).get("version")
    if type(name) is not str or type(version) is not str:
        raise SystemExit(f"pinned plugin metadata is incomplete: {repo_name}")
    entry_points = project.get("project", {}).get("entry-points", {}).get("bt_api.plugins", {})
    if not isinstance(entry_points, dict) or len(entry_points) != 1:
        raise SystemExit(f"expected exactly one bt_api.plugins entrypoint: {repo_name}")

    pyproject_target = OUT / "sdk-plugins" / repo_name / "pyproject.toml"
    pyproject_target.parent.mkdir(parents=True, exist_ok=True)
    pyproject_target.write_bytes(project_bytes)
    src_root = OUT / "sdk-plugins" / repo_name / "src"
    src_root.mkdir(parents=True, exist_ok=True)
    listing = run_git(repo, "ls-tree", "-r", "-l", commit, "--", "src")
    exported = []
    excluded_native = []
    for line in listing.splitlines():
        if "\t" not in line:
            continue
        header, git_path = line.split("\t", 1)
        suffix = Path(git_path).suffix.lower()
        if suffix in NATIVE_SUFFIXES:
            excluded_native.append(git_path)
            continue
        if suffix not in TEXT_SUFFIXES:
            continue
        if not git_path.startswith("src/"):
            raise SystemExit(f"unexpected non-src tree path: {git_path}")
        payload = run_git(repo, "show", f"{commit}:{git_path}", raw=True)
        target = src_root / Path(git_path).relative_to("src")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(payload)
        exported.append({
            "git_path": git_path, "export_path": str(target),
            "sha256": hashlib.sha256(payload).hexdigest(), "bytes": len(payload),
        })

    metadata_paths = metadata_files(project, str(pyproject_target))
    plugin_pythonpaths.append(str(src_root))
    plugin_rows.append({
        "repository": str(repo), "gitlink_path": gitlink_path, "accepted_commit": commit,
        "distribution": name, "version": version,
        "entry_points": entry_points,
        "pyproject_export": str(pyproject_target),
        "pyproject_sha256": sha(pyproject_target),
        "source_root": str(src_root), "source_files": exported,
        "source_file_count": len(exported),
        "source_bytes": sum(item["bytes"] for item in exported),
        "excluded_native_paths": excluded_native,
        "generated_dist_info": [str(p) for p in metadata_paths],
    })

# Use the fixed export plus only the exact BT adapter and host-node overlays.
export_test = OUT / "tests" / "integration" / TEST.name
adapter = BT / "backtrader" / "stores" / "service_execution_group.py"
export_adapter = OUT / "backtrader" / "stores" / "service_execution_group.py"
shutil.copyfile(TEST, export_test)
shutil.copyfile(adapter, export_adapter)
if ast.parse(TEST.read_text(encoding="utf-8")) is None:
    raise SystemExit("test source did not parse")
if ast.parse(adapter.read_text(encoding="utf-8")) is None:
    raise SystemExit("adapter source did not parse")

# Build a source manifest from every byte present in the fixed export, with no
# current checkout/plugin working-tree bytes except the explicit BT overlays.
files = {}
for path in sorted(item for item in OUT.rglob("*") if item.is_file() and item.name != "source-manifest.json"):
    files[str(path)] = {"sha256": sha(path), "bytes": path.stat().st_size}

old_manifest = json.loads((R14 / "source-manifest.json").read_text(encoding="utf-8"))
new_candidate_overlays = []
for row in old_manifest["candidate_overlays"]:
    checkout_path = Path(row["checkout_path"])
    target = OUT / row["path"]
    if row["path"] == "backtrader/stores/service_execution_group.py":
        checkout_path = adapter
        target = export_adapter
    elif row["path"] == "tests/integration/test_btapi_execution_group_cerebro_v3_host.py":
        checkout_path = TEST
        target = export_test
    new_candidate_overlays.append({
        "path": row["path"], "checkout_path": str(checkout_path),
        "export_path": str(target), "sha256": sha(target), "bytes": target.stat().st_size,
    })

accepted_links = dict(old_manifest["accepted_sdk_gitlinks"])
for row in plugin_rows:
    accepted_links[row["gitlink_path"]] = row["accepted_commit"]

archives = []
for row in old_manifest["archives"]:
    row = dict(row)
    for field in ("archive", "extract_root"):
        value = row.get(field)
        if isinstance(value, str) and value.startswith(str(R14)):
            row[field] = str(OUT / Path(value).relative_to(R14))
    archives.append(row)

manifest = {
    "purpose": "R14_FAILED_CEREBRO_HOST_NODE_FOLLOWUP_WITH_PINNED_FULL_PLUGIN_IMPORT_CLOSURE",
    "evidence_level": "BT_ADAPTER_CEREBRO_LOCAL_SERVICEHOST_CURVE_SYNTHETIC_PROVIDER",
    "export_root": str(OUT), "non_git_directory": True,
    "dirty_worktree_bytes_included": False,
    "source_parent": {"accepted_sdk_parent_commit": ACCEPTED_ROOT, "inherited_export": str(R14)},
    "runtime_source_selection": old_manifest["runtime_source_selection"],
    "repositories": old_manifest["repositories"],
    "accepted_sdk_gitlinks": accepted_links,
    "archives": archives,
    "fixed_core_distribution_metadata": core_project_provenance,
    "fixed_plugin_import_closure": plugin_rows,
    "candidate_overlays": new_candidate_overlays,
    "exported_files": files,
    "test_support": {
        **old_manifest["test_support"],
        "sdk_host_fixture_root": str(OUT / "tests"),
        "fixed_plugin_source_roots": plugin_pythonpaths,
        "fixed_sdk_metadata_isolation": "generated minimal .dist-info from exact accepted pyproject.toml; placed at export root ahead of system site-packages",
    },
    "excluded": [
        "SDK working-tree-only source and dirty recovery-proof files",
        "Backtrader docs/evidence/history trees and unrelated checkout WIP",
        "current bt_api_base checkout bytes newer than accepted parent gitlink",
        "native plugin binaries and external credential/account inputs",
        "real exchange provider calls; test continues to use the pinned SQLite synthetic leaf",
        "adapter-passing node (not selected again in this followup)",
    ],
    "validation": {
        "method": "copy of fixed R14 export plus accepted-parent gitlink source imports and exact test overlay",
        "file_count_excluding_manifest": len(files),
        "byte_count_excluding_manifest": sum(x["bytes"] for x in files.values()),
        "plugin_source_file_count": sum(row["source_file_count"] for row in plugin_rows),
        "plugin_source_byte_count": sum(row["source_bytes"] for row in plugin_rows),
        "native_plugin_binaries_exported": 0,
        "test_ast_parse_only": True,
        "qa_executed": False, "collection_executed": False, "host_started": False,
    },
}
manifest_path = OUT / "source-manifest.json"
manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")

# Bind a single fresh Root run to the failed Host node only. The prior adapter
# node's R14 PASS remains accepted and is explicitly not selected here.
base_spec = json.loads(BASE_SPEC.read_text(encoding="utf-8"))
spec = base_spec
spec.update({
    "status": "UNEXECUTED_PENDING_INDEPENDENT_STATIC_REVIEW",
    "purpose": "One previously failed normal Cerebro v3 C/P/F Host node with accepted SDK quantity-unit metadata (`contracts`) and finite account-owner callback diagnostics; no previously accepted node is selected.",
    "cwd": str(OUT),
    "output": r"D:\temp\iteration10-bt-p5a-group-cerebro-author-20261016-r26",
    "nodes": ["tests/integration/test_btapi_execution_group_cerebro_v3_host.py::test_v3_cerebro_paired_three_leg_snapshot_over_real_curve_hosts"],
})
spec["environment"]["BT_API_PY_TESTS_ROOT"] = str(OUT / "tests")
base_paths = [
    str(OUT), str(OUT / "sdk-root"), str(OUT / "sdk-base" / "src"),
    str(OUT / "sdk-execution" / "src"), str(OUT / "sdk-risk" / "src"),
    str(OUT / "sdk-monitor" / "src"), str(OUT / "sdk-transport" / "src"),
]
spec["environment"]["PYTHONPATH"] = ";".join(base_paths + plugin_pythonpaths)

binding = spec["accepted_source_binding"]
binding["candidate_overlays"] = new_candidate_overlays
binding["backtrader_head"] = spec["repositories"][str(BT)]
binding["source_manifest"] = str(manifest_path)
binding["source_manifest_sha256"] = sha(manifest_path)
binding["materializer"] = str(MATERIALIZER)
binding["materializer_sha256"] = sha(MATERIALIZER)
binding["fixed_plugin_gitlinks"] = {row["gitlink_path"]: row["accepted_commit"] for row in plugin_rows}
binding["fixed_plugin_entrypoints"] = {
    row["distribution"]: row["entry_points"] for row in plugin_rows
}
binding["sdk_gitlinks"].update({row["gitlink_path"]: row["accepted_commit"] for row in plugin_rows})

spec["candidate_source_delta"] = [
    "The BT adapter validates the accepted SDK GroupOrderCoordinatorService {ok, code, result} business envelope before decoding the nested typed snapshot; malformed submit replies remain unknown outcome and a valid explicit business rejection remains definitive.",
    "The integration fixture initializes its empty SQLite schema before Host startup and supplies DurableOutbox(read_only=True) to MonitorReadService.",
    "The synthetic adapter reply fixture now uses the accepted SDK success-envelope shape; the selected Cerebro node exercises submit/query through actual local ZMQ/CURVE ServiceClientRuntime and ServiceHosts.",
    "Transparent test-only wrappers record bounded coordinator submit facts and account-owner _submit exception type/code/context-function facts before the SDK converts the original failure to GROUP_ORDER_OUTCOME_UNPROVEN; both rethrow unchanged and preserve normal control/shutdown behavior.",
    "The Monitor handler returns its read page directly after transport unwrapping, so Monitor response parsing remains unchanged.",
    "The fixed export carries accepted SDK venue-plugin source trees and generated distribution metadata from pinned parent/gitlinks; no dirty plugin source bytes are exported.",
    "No native CTP plugin binaries, exchange calls, credentials, real accounts, or remote services are included; the SQLite provider remains the only order leaf.",
]
spec["accepted_previous_qa_not_repeated"] = [
    "The historical R14 adapter-node PASS remains preserved and is not repeated; this round exercises the changed adapter only through the actual Host node.",
    "The R14/R17 actual Host failures and R18-R21 author diagnostics remain preserved; R23-R25 separately failed the three-leg snapshot PAIRED assertion and remain unchanged; R25 traced the fixture metadata unit mismatch to the accepted SDK allowlist.",
    "Previously accepted ownership and cursor nodes are not rerun.",
]
spec["scope"]["runtime_path"] = "Cerebro -> Strategy-bound BT group adapter with strict SDK group-envelope decoding -> authenticated ZMQ/CURVE SDK ClientRuntime -> local accepted SDK Account/GroupCoordinator/Monitor ServiceHosts -> SQLite synthetic provider leaf."
spec["scope"]["excluded"] = list(spec["scope"].get("excluded", [])) + [
    "No live exchange plugin/provider request is made; fixed plugin modules are imported only for ordinary registry initialization.",
    "No monitor.read_after RPC is invoked in this slice.",
    "R14 adapter PASS is not repeated.",
]

# Every exported file and exact checkout overlay is a byte pin. Add the finite
# runner/config/materializer dependencies, but do not carry R14 output artifacts.
pins = {path: row["sha256"] for path, row in files.items()}
pins[str(manifest_path)] = sha(manifest_path)
pins[str(TEST)] = sha(TEST)
adapter = BT / "backtrader" / "stores" / "service_execution_group.py"
pins[str(adapter)] = sha(adapter)
runner = SDK / ".codex-tmp" / "iteration10-focused-qa.py"
pytest_ini = SDK / ".codex-tmp" / "iteration10-resume-sync-pytest.ini"
for path in (runner, pytest_ini, MATERIALIZER):
    if not path.is_file():
        raise SystemExit(f"required fixed runner dependency missing: {path}")
    pins[str(path)] = sha(path)
spec["source_sha256"] = dict(sorted(pins.items()))

# Hold and bind all seven monitored repositories to their current metadata-only
# guards. Accepted runtime bytes remain the fixed parent/gitlink exports above.
repo_paths = list(spec["repositories"])
for repo in repo_paths:
    head = run_git(Path(repo), "rev-parse", "HEAD")
    spec["repositories"][repo] = head
spec["accepted_source_binding"]["current_sdk_root_head_used_only_as_repository_guard"] = spec["repositories"][str(SDK)]

SPEC_OUT.parent.mkdir(parents=True, exist_ok=True)
SPEC_OUT.write_text(json.dumps(spec, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")

# Verify the generated byte pins and that each imported plugin registrar in the
# accepted source declares the fixed loader's two-argument contract, via AST only.
for path_text, expected in spec["source_sha256"].items():
    path = Path(path_text)
    if not path.is_file() or sha(path) != expected:
        raise SystemExit(f"source pin mismatch: {path_text}")
for row in plugin_rows:
    module = next((Path(item["export_path"]) for item in row["source_files"] if item["git_path"].endswith("/plugin.py")), None)
    if module is None:
        raise SystemExit(f"pinned plugin entry module absent: {row['distribution']}")
    tree = ast.parse(module.read_text(encoding="utf-8"))
    registration = next((node for node in tree.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == "register_plugin"), None)
    if registration is None or len(registration.args.args) < 2:
        raise SystemExit(f"accepted plugin registrar does not meet fixed Base contract: {row['distribution']}")

print(json.dumps({
    "export": str(OUT), "manifest": str(manifest_path), "manifest_sha256": sha(manifest_path),
    "spec": str(SPEC_OUT), "spec_sha256": sha(SPEC_OUT), "spec_bytes": SPEC_OUT.stat().st_size,
    "source_pin_count": len(spec["source_sha256"]), "exported_file_count": len(files),
    "plugin_source_file_count": sum(row["source_file_count"] for row in plugin_rows),
    "plugin_source_byte_count": sum(row["source_bytes"] for row in plugin_rows),
    "plugin_distributions": [{"name": row["distribution"], "commit": row["accepted_commit"], "entry_points": row["entry_points"]} for row in plugin_rows],
    "selected_nodes": spec["nodes"], "adapter_sha256": sha(adapter), "test_sha256": sha(TEST),
    "qa_executed": False, "collection_executed": False, "host_started": False,
}, ensure_ascii=False, indent=2))

