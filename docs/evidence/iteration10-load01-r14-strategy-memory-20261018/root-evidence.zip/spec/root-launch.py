from pathlib import Path
import hashlib
import json
import psutil
import subprocess
import sys
import time

repository = Path('D:/bt_api_py')
prepared = repository / '.codex-tmp/iteration10-load01-pilot-spec-r14-current-dev-20261018.json'
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
assert len(sys.argv) == 2 and sha(prepared) == sys.argv[1]
document = json.loads(prepared.read_text(encoding='utf-8'))
source = document['current_source']
export = source['export']
execution = document['execution']
root = Path(execution['working_directory'])
output = Path(execution['output_root'])
assert not output.exists(), 'Do not reuse consumed pilot output'
assert Path(execution['python']).resolve() == Path('C:/Anaconda3/python.exe').resolve()
assert document['workload'] == {
    'pilot_seconds': 120, 'full_seconds': 1800, 'strategies': 100,
    'accounts': 10, 'strategies_per_account': 10, 'topics': 20,
    'upstream_messages_per_second': 200,
    'order_lifecycle_cycles_per_account_per_second': 2,
    'strategy_children': 100, 'account_execution_owner_children': 10,
    'market_children': 1, 'monitor_children': 1, 'total_children': 112,
    'pytest_controller': 1, 'total_processes_including_controller': 113,
}
assert document['resource_gate']['minimum_available_physical_bytes'] == 10603200512
preflight_path = Path(export['preflight_path'])
assert sha(preflight_path) == export['preflight_sha256']
preflight = json.loads(preflight_path.read_text(encoding='utf-8'))
assert preflight['resource_helper_parent_zip_member_verified']
assert preflight['resource_helper_runtime_manifest_binding_verified']
assert not any(preflight[k] for k in ('pilot_started', 'full_started', 'host_started', 'pytest_collected_or_run'))
manifest_path = Path(export['source_manifest_path'])
assert sha(manifest_path) == preflight['source_manifest_sha256']
manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
assert manifest['parent_commit'] == source['parent_commit']
assert manifest['files']['tests/unit/_load01_resource_diagnostics.py'] == '9ad5f172f9d7714a4f4a732586ccd4369885a41bbd2b535e73453c7b528eaddc'
pins = {str(root / path): digest for path, digest in manifest['files'].items()}
for name, metadata in export['archive_hashes'].items():
    path = Path(export['root']) / name
    assert path.stat().st_size == metadata['bytes'] and sha(path) == metadata['sha256']
    pins[str(path)] = metadata['sha256']
assert sha(export['source_export_pins']) == export['source_export_pins_sha256']
runner = repository / '.codex-tmp/iteration10-focused-qa.py'
assert sha(runner) == '8b7f470be77270adeb9d72a83776b827c4653004b39835eeca0f43bf63cf24ed'
for path in (prepared, runner, manifest_path, preflight_path, Path(export['source_export_pins'])):
    pins[str(path)] = sha(path)
assert all(sha(path) == digest for path, digest in pins.items())
git = lambda *args: subprocess.check_output(['git', '-C', str(repository), *args]).decode().strip()
head = git('rev-parse', 'HEAD')
assert head == source['parent_commit'] == 'd9719ce55dfc350385d6dc3574bc80a148cca7cf'
assert git('branch', '--show-current') == 'dev'
assert not git('diff', '--cached', '--name-only')
heads = {str(repository): head}
heads.update({str(repository / path): commit for path, commit in source['package_gitlinks'].items()})
environment = dict(execution['environment'])
environment.pop('BT_API_LOAD01_SOURCE_MANIFEST', None)
runner_overlay_sha = source['runner_provenance_overlay']['candidate_raw_sha256']
assert runner_overlay_sha == preflight['runner_overlay_sha256']
assert sha(root / 'tests/unit/test_load01_hundred_strategy_30min.py') == runner_overlay_sha
environment.update(BT_API_LOAD01_MODE='pilot', BT_API_LOAD01_OUTPUT=execution['pilot_output'],
                   PYTHONPYCACHEPREFIX=str(output / 'pilot-python-cache'),
                   BT_API_LOAD01_RUNNER_OVERLAY_SHA256=runner_overlay_sha)
assert all(isinstance(key, str) and isinstance(value, str) for key, value in environment.items())
spec = {
    'schema_version': 1, 'label': 'LOAD01_R14_112_PROCESS_120_SECOND_PILOT',
    'python': execution['python'], 'cwd': str(root), 'output': str(output),
    'environment': environment, 'unset_environment': ['BT_API_LOAD01_SOURCE_MANIFEST'],
    'nodes': [execution['node']], 'pytest_options': execution['pytest_arguments'],
    'repositories': heads, 'source_sha256': pins,
    'evidence_level': 'LOCAL_SYNTHETIC_LOAD01_112_PROCESS_120_SECOND_PILOT_ONLY',
    'source_parent': head,
    'preparation_adjustments': 'Prepared environment had a null runner overlay placeholder; this execution binds it to the verified exact exported runner hash. Historical execution-order notice wording is superseded by user authorization and the fresh memory gate below.',
    'authorization': 'User authorized memory reclamation and continuation. App working sets reclaimed; Qoder and retained sessions untouched. No trimming during the run.',
}
path = repository / '.codex-tmp/iteration10-load01-r14-pilot-root-execution-20261018.json'
assert not path.exists()
path.write_text(json.dumps(spec, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
samples = []
for index in range(3):
    samples.append({'time': time.time(), 'available': psutil.virtual_memory().available})
    if index < 2:
        time.sleep(5)
receipt = {
    'spec': str(path), 'spec_sha256': sha(path), 'samples': samples,
    'threshold': 10603200512,
    'ready': all(row['available'] >= 10603200512 for row in samples),
    'source_count': len(pins), 'execution_head': head,
}
memory_path = repository / '.codex-tmp/iteration10-memory-pre-load01-r14-pilot-20261018.json'
assert not memory_path.exists()
memory_path.write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps(receipt), flush=True)
assert receipt['ready'], 'Memory gate not met; pilot not started'
raise SystemExit(subprocess.call([execution['python'], '-X', 'utf8', str(runner), str(path)]))
