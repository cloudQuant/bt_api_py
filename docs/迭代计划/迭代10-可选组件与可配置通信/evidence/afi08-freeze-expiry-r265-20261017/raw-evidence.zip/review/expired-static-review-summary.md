Independent static review summary (no reviewer test runs)

Two reviewers independently returned GO for the AFI08 EXPIRED projection and directed test. The Monitor durable ledger expires only unclaimed PENDING commands; claimed commands remain UNKNOWN and keep reconciliation required. EXPIRED is terminal no-effect: owner_final remains false, outcome/effect reference/effect result are null, and reconciliation_required is false. AFI persists exact owner_status=expired and clears the issuer unresolved lock only after reading that persisted status. The HTTP status endpoint does not label EXPIRED as APPLIED or UNKNOWN.

The directed author test pauses the synthetic Monitor owner executor before expiry, advances the SQLite DurableControlLedger clock past the signed command TTL, restores the owner method, and queries through the HTTP status route. It checks EXPIRED in the actual Monitor ledger, no RiskGate freeze/no effect from the expired command, AFI owner_status=expired with owner_final=0, then a higher issuer sequence whose command is applied by the actual DurableRiskGate on the local ServiceHost owner thread.

Review level: GO_STATIC / source-contract review only. Reviewers did not run tests. Author local synthetic QA is not Root QA, provider/account proof, process-restart proof, or formal Iteration10 acceptance. DRAIN and CLOSE remain unsupported.
