"""
Configuration management - Load configuration from environment variables.
"""

import os
import re
from pathlib import Path
from typing import Any, Literal

from pydantic import Field, SecretStr, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from app.ai_provider_registry import get_default_provider_registry
from app.config_parsing import parse_ai_providers, parse_strategy_score_weights
from app.services.market_data.openbb_runtime import SUPPORTED_OPENBB_RUNNER_PROVIDERS

_DEFAULT_SECRETS = frozenset(
    {
        "your-secret-key-change-in-production",
        "your-jwt-secret-change-in-production",
        # Public Docker/repository example values are equally predictable and
        # must never satisfy a server-owned provenance or production-secret
        # check merely because their wording happens to exceed 32 characters.
        "replace-with-a-random-secret-key-at-least-32-chars",
        "replace-with-a-random-jwt-secret-at-least-32-chars",
    }
)

_DEFAULT_PASSWORDS = frozenset({"admin123", "password", "12345678"})
_MARKET_DATA_PROVIDER_TOKEN_PATTERN = re.compile(r"^[a-z0-9][a-z0-9._-]{0,127}$")
_REPO_ROOT = Path(__file__).resolve().parents[3]
_DEFAULT_SQLITE_DATABASE_URL = (
    f"sqlite+aiosqlite:///{(_REPO_ROOT / 'data' / 'dev' / 'backtrader.db').as_posix()}"
)


def _coerce_bool(value: object) -> bool | None:
    """Coerce common boolean-like values from settings inputs or env vars."""
    if isinstance(value, bool):
        return value
    if isinstance(value, int) and value in (0, 1):
        return bool(value)
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"true", "1", "yes", "on"}:
            return True
        if normalized in {"false", "0", "no", "off"}:
            return False
    return None


def _is_production(debug: object | None = None, *, debug_was_explicit: bool = False) -> bool:
    """Check if the application should apply production-only safeguards."""
    normalized_debug = _coerce_bool(debug)
    if debug_was_explicit and normalized_debug is not None:
        return not normalized_debug
    env_debug = _coerce_bool(os.environ.get("DEBUG"))
    if env_debug is not None:
        return not env_debug
    return False


def production_security_mode(settings: "Settings") -> bool:
    """Return whether production-only runtime security guards apply."""
    return _is_production(
        settings.DEBUG,
        debug_was_explicit="DEBUG" in settings.model_fields_set,
    )


class Settings(BaseSettings):
    """Application settings.

    Attributes:
        APP_NAME: Application name.
        DEBUG: Debug mode flag.
        SECRET_KEY: Secret key for encryption.
        DATABASE_TYPE: Database type (postgresql, mysql, mongodb, sqlite).
        DATABASE_URL: Database connection URL.
        DOCUMENT_DB_TYPE: Optional document database type.
        DOCUMENT_DB_URL: Optional document database URL.
        TIMESERIES_DB_TYPE: Optional timeseries database type.
        TIMESERIES_DB_URL: Optional timeseries database URL.
        REDIS_URL: Optional Redis cache URL.
        JWT_SECRET_KEY: JWT secret key.
        JWT_ALGORITHM: JWT encryption algorithm.
        JWT_EXPIRE_MINUTES: JWT token expiration time in minutes.
        HOST: Server host address.
        PORT: Server port.
        BACKTEST_TIMEOUT: Backtest subprocess timeout in seconds.
        CORS_ORIGINS: Comma-separated list of allowed CORS origins.
        SQL_ECHO: Whether to echo SQL statements.
        ADMIN_USERNAME: Default admin username.
        ADMIN_PASSWORD: Default admin password.
        ADMIN_EMAIL: Default admin email.
    """

    # App settings
    APP_NAME: str = "ai-for-investor"
    DEBUG: bool = Field(default=False, description="Debug mode (must remain False in production)")
    SECRET_KEY: str = Field(
        default="your-secret-key-change-in-production",
        description="Secret key for encryption (CHANGE IN PRODUCTION)",
    )

    # Database settings
    DATABASE_TYPE: str = Field(
        default="sqlite", description="Database type: postgresql, mysql, mongodb, sqlite"
    )
    DATABASE_URL: str = Field(
        default=_DEFAULT_SQLITE_DATABASE_URL, description="Database connection URL"
    )
    AKSHARE_DATA_DATABASE_URL: str = Field(
        default="", description="Akshare data warehouse database connection URL"
    )
    MARKET_DATA_QUERY_V2_ENABLED: bool = Field(
        default=False,
        description="Expose the Iteration 197 normalized market-data query API",
    )
    MARKET_DATA_ONLINE_FETCH_ENABLED: bool = Field(
        default=False,
        description="Allow the normalized market-data query API to invoke approved providers",
    )
    MARKET_DATA_RESEARCH_CACHE_FILL_ENABLED: bool = Field(
        default=False,
        description=(
            "Allow an explicitly requested strategy-data cache fill with research source authorization"
        ),
    )
    MARKET_DATA_RESEARCH_BACKTEST_BRIDGE_ENABLED: bool = Field(
        default=False,
        description=(
            "Bind AI strategy research backtests to strict local-only Iteration 197 data artifacts"
        ),
    )
    MARKET_DATA_RESEARCH_ARTIFACT_ROOT: str = Field(
        default=str((_REPO_ROOT / "data" / "market_data_research").resolve()),
        description=("Server-owned root for immutable market-data research/backtest artifacts"),
    )
    MARKET_DATA_RESEARCH_ARTIFACT_SIGNING_KEY: str = Field(
        default="",
        repr=False,
        description=(
            "Operator-managed HMAC key used to verify server-issued research data bindings"
        ),
    )
    MARKET_DATA_CURSOR_SIGNING_KEY: str = Field(
        default="",
        repr=False,
        description=(
            "Operator-managed HMAC key for normalized market-data pagination cursors; "
            "required when the v2 query API is enabled"
        ),
    )
    MARKET_DATA_OPENBB_PROVIDER: str = Field(
        default="yfinance",
        description="Approved OpenBB provider identifier used by the isolated runner",
    )
    MARKET_DATA_OPENBB_ALLOWED_MARKETS: str = Field(
        default="",
        description=(
            "Comma-separated master-data venues that may narrow an explicit OpenBB permit; "
            "they cannot enable a route on their own"
        ),
    )
    MARKET_DATA_THS_ENABLED: bool = Field(
        default=False,
        description=(
            "叠加 kill-switch for the Iteration 198 THS provider routes. THS routing is "
            "fail-closed by default and additionally requires a durable capability ledger "
            "attestation, an active provider registry row, and a source authorization grant; "
            "this flag only removes THS routes from the assembled policy."
        ),
    )
    MARKET_DATA_OPENDATA_ENABLED: bool = Field(
        default=False,
        description=(
            "叠加 kill-switch for the opendata (self-hosted data platform) provider route. "
            "opendata routing is fail-closed by default and additionally requires a durable "
            "capability ledger attestation, an active provider registry row, and a source "
            "authorization grant; this flag only removes the route from the assembled policy."
        ),
    )
    MARKET_DATA_THS_SCHEDULER_ENABLED: bool = Field(
        default=False,
        description=(
            "Enable the Iteration 199 daily THS history collection job (APScheduler). "
            "Requires THS_API_KEY; disabled by default."
        ),
    )
    MARKET_DATA_THS_SCHEDULER_HOUR: int = Field(
        default=18, description="Hour (Asia/Shanghai) for the daily THS collection job"
    )
    MARKET_DATA_THS_SCHEDULER_MINUTE: int = Field(
        default=0, description="Minute for the daily THS collection job"
    )
    MARKET_DATA_THS_SCHEDULER_TIMEZONE: str = Field(
        default="Asia/Shanghai", description="Timezone name for the daily THS collection job"
    )
    LEGACY_SQLITE_DATABASE_URL: str = Field(
        default="", description="Legacy SQLite database connection URL used during migration"
    )
    LEGACY_AKSHARE_DATABASE_URL: str = Field(
        default="", description="Legacy akshare_web database connection URL used during migration"
    )
    AKSHARE_SCHEDULER_TIMEZONE: str = Field(
        default="Asia/Shanghai", description="Scheduler timezone for akshare tasks"
    )
    AKSHARE_SCHEDULER_MAX_CONCURRENT_TASKS: int = Field(
        default=1,
        ge=1,
        description="Maximum concurrent akshare scheduler-triggered tasks",
    )
    AKSHARE_SCRIPT_ROOT: str = Field(
        default="app/data_fetch/scripts", description="Root directory for akshare scripts"
    )
    AKSHARE_INTERFACE_BOOTSTRAP_MODE: str = Field(
        default="manual", description="Akshare interface bootstrap mode: manual or refresh"
    )
    STOCK_SIGNAL_SCHEDULE_ENABLED: bool = Field(
        default=False,
        description="Enable the after-close auditable SSE50 signal scheduler",
    )
    STOCK_SIGNAL_SCHEDULE_TIMEZONE: str = Field(
        default="Asia/Shanghai", description="Timezone for the stock signal scheduler"
    )
    STOCK_SIGNAL_SCHEDULE_CRON: str = Field(
        default="10 19 * * 1-5", description="Five-field cron expression for stock signals"
    )
    STOCK_SIGNAL_UNIVERSE: str = Field(
        default="sse50", description="Versioned universe identifier for nightly stock signals"
    )
    STOCK_SIGNAL_MAX_CONCURRENCY: int = Field(
        default=4, ge=1, le=10, description="Maximum simultaneous symbol collections"
    )
    STOCK_SIGNAL_MIN_HISTORY_BARS: int = Field(
        default=60, ge=20, le=500, description="Minimum daily bars required for an eligible signal"
    )
    STOCK_SIGNAL_MAX_FINANCIAL_AGE_DAYS: int = Field(
        default=210, ge=30, le=730, description="Maximum financial report age before degradation"
    )
    STOCK_SIGNAL_MAX_NEWS_AGE_DAYS: int = Field(
        default=7, ge=1, le=90, description="Maximum news age before degradation"
    )
    STOCK_SIGNAL_ROUND_TRIP_COST_BPS: float | None = Field(
        default=None,
        ge=0,
        le=1000,
        description="Approved round-trip cost for scheduled evaluations",
    )
    STOCK_SIGNAL_BUY_SUCCESS_THRESHOLD_BPS: float | None = Field(
        default=None,
        ge=0,
        le=5000,
        description="Approved buy-success threshold for scheduled evaluation",
    )
    STOCK_SIGNAL_SELL_SUCCESS_THRESHOLD_BPS: float | None = Field(
        default=None,
        ge=0,
        le=5000,
        description="Approved sell-success threshold for scheduled evaluation",
    )
    ASSET_RESEARCH_SCHEDULE_ENABLED: bool = Field(
        default=False,
        description="Enable the database-backed multi-asset shadow-schedule worker",
    )
    ASSET_RESEARCH_TASK_RUNNER_ENABLED: bool = Field(
        default=True,
        description="Enable the database-backed interactive multi-asset task worker",
    )
    AI_RESEARCH_PROTOCOL_V2_ENABLED: bool = Field(
        default=False,
        description="Enable new trusted AI-research v2 write operations for an approved scope",
    )
    AI_RESEARCH_PROTOCOL_V2_WORKFLOW_VERSION: Literal["generation-v1", "discovery-v1"] = Field(
        default="generation-v1",
        description=(
            "Server-owned protocol-v2 workflow selected for newly submitted research runs; "
            "clients cannot override it"
        ),
    )
    AI_RESEARCH_PROTOCOL_V2_WORKER_ENABLED: bool = Field(
        default=False,
        description="Enable the separately deployed trusted-research Explorer worker",
    )
    AI_RESEARCH_PROTOCOL_V2_WORKER_FACTORY: str = Field(
        default="",
        max_length=512,
        description=(
            "Reviewed app.research_deployments factory reference used only by the Explorer worker"
        ),
    )
    AI_RESEARCH_PROTOCOL_V2_WORKER_POLL_SECONDS: float = Field(
        default=10.0,
        ge=0.1,
        le=3600,
        description="Polling cadence for the separately deployed trusted-research Explorer worker",
    )
    AI_RESEARCH_PROTOCOL_V2_HOLDOUT_WORKER_ENABLED: bool = Field(
        default=False,
        description="Enable the separately deployed sealed-holdout evaluator worker",
    )
    AI_RESEARCH_PROTOCOL_V2_HOLDOUT_WORKER_FACTORY: str = Field(
        default="",
        max_length=512,
        description="Reviewed app.research_deployments factory for the holdout worker process",
    )
    AI_RESEARCH_PROTOCOL_V2_HOLDOUT_WORKER_POLL_SECONDS: float = Field(
        default=10.0,
        ge=0.1,
        le=3600,
        description="Polling cadence for the separately deployed sealed-holdout worker",
    )
    AI_RESEARCH_PROTOCOL_V2_HOLDOUT_ENDPOINT_URL: str = Field(
        default="",
        max_length=2048,
        description="Pinned HTTPS /v1/holdout-executions evaluator endpoint",
    )
    AI_RESEARCH_PROTOCOL_V2_HOLDOUT_BEARER_TOKEN: SecretStr = Field(
        default_factory=lambda: SecretStr(""),
        repr=False,
        description="Deployment-only credential for the sealed evaluator endpoint",
    )
    AI_RESEARCH_PROTOCOL_V2_HOLDOUT_WORKER_IDENTITY: str = Field(
        default="",
        max_length=512,
        description="Service identity recorded for holdout claim and recovery operations",
    )
    AI_RESEARCH_PROTOCOL_V2_HOLDOUT_EVALUATOR_IDENTITY: str = Field(
        default="",
        max_length=512,
        description="Pinned independent evaluator identity expected in holdout receipts",
    )
    AI_RESEARCH_PROTOCOL_V2_HOLDOUT_EVALUATOR_IMAGE_DIGEST: str = Field(
        default="",
        max_length=128,
        description="Pinned sha256 evaluator image digest expected in holdout receipts",
    )
    AI_RESEARCH_PROTOCOL_V2_HOLDOUT_HTTP_TIMEOUT_SECONDS: float = Field(
        default=60.0,
        gt=0,
        le=3600,
        description="Whole HTTP deadline for sealed holdout execute and inspect calls",
    )
    AI_RESEARCH_PROTOCOL_V2_HOLDOUT_MAX_RESPONSE_BYTES: int = Field(
        default=10_000_000,
        ge=1,
        le=10_000_000,
        description="Maximum accepted sealed evaluator response bytes",
    )
    AI_RESEARCH_PROTOCOL_V2_HOLDOUT_LEASE_SECONDS: int = Field(
        default=300,
        ge=1,
        le=7200,
        description="Database lease duration for one holdout command claim",
    )
    AI_RESEARCH_PROTOCOL_V2_HOLDOUT_HEARTBEAT_SECONDS: float = Field(
        default=30.0,
        gt=0,
        le=2400,
        description="Heartbeat cadence while a sealed evaluator request is active",
    )
    AI_RESEARCH_PROTOCOL_V2_DATASET_OBJECT_RESOLVER_TYPE: str = Field(
        default="",
        max_length=32,
        description="Exact deployment-owned protocol-v2 dataset resolver type; empty disables it",
    )
    AI_RESEARCH_PROTOCOL_V2_DATASET_FILESYSTEM_ROOT: str = Field(
        default="",
        max_length=2048,
        description="Absolute controlled object root for the reviewed filesystem dataset resolver",
    )
    AI_RESEARCH_PROTOCOL_V2_DATASET_RECEIPT_STORE: str = Field(
        default="",
        max_length=2048,
        description="Separate absolute receipt store for the reviewed filesystem dataset resolver",
    )
    AI_RESEARCH_PROTOCOL_V2_DATASET_MAX_BYTES: int = Field(
        default=0,
        ge=0,
        le=10 * 1024 * 1024 * 1024,
        description="Maximum byte size for a filesystem dataset object; zero keeps resolver disabled",
    )
    # The real GENERATE deployment remains opt-in behind the two protocol/worker
    # flags above.  These static settings are intentionally separate from the
    # user-facing AI provider registry: a worker image chooses one reviewed
    # route, prompt, quota policy, and materialization manifest at startup.
    AI_RESEARCH_PROTOCOL_V2_GENERATION_PROVIDER_ID: str = Field(
        default="",
        max_length=256,
        description="Reviewed provider route identity for the opt-in v2 generation worker",
    )
    AI_RESEARCH_PROTOCOL_V2_GENERATION_ENDPOINT_URL: str = Field(
        default="",
        max_length=2048,
        description="Pinned HTTPS chat-completions endpoint for the v2 generation worker",
    )
    AI_RESEARCH_PROTOCOL_V2_GENERATION_MODEL_ALIAS: str = Field(
        default="",
        max_length=256,
        description="Server-owned model alias requested by the v2 generation executor",
    )
    AI_RESEARCH_PROTOCOL_V2_GENERATION_MODEL_ID: str = Field(
        default="",
        max_length=256,
        description="Pinned provider model identity resolved from the generation alias",
    )
    AI_RESEARCH_PROTOCOL_V2_GENERATION_API_KEY: SecretStr = Field(
        default_factory=lambda: SecretStr(""),
        repr=False,
        description="Deployment-only credential for the pinned v2 generation provider route",
    )
    AI_RESEARCH_PROTOCOL_V2_GENERATION_TIMEOUT_SECONDS: float = Field(
        default=60.0,
        gt=0,
        le=600,
        description="Total provider request timeout for the v2 generation worker",
    )
    AI_RESEARCH_PROTOCOL_V2_GENERATION_MAX_OUTPUT_TOKENS: int = Field(
        default=1024,
        ge=1,
        le=131_072,
        description="Fixed maximum generated tokens; deployment verifies it fits the quota reserve",
    )
    AI_RESEARCH_PROTOCOL_V2_GENERATION_MAX_RESPONSE_BYTES: int = Field(
        default=2 * 1024 * 1024,
        ge=1,
        le=16 * 1024 * 1024,
        description="Maximum accepted provider response bytes for v2 generation",
    )
    AI_RESEARCH_PROTOCOL_V2_GENERATION_MAX_REQUEST_BYTES: int = Field(
        default=512 * 1024,
        ge=1,
        le=1024 * 1024,
        description="Maximum serialized provider request bytes for v2 generation",
    )
    AI_RESEARCH_PROTOCOL_V2_GENERATION_PROMPT_TEMPLATE_VERSION: str = Field(
        default="",
        max_length=128,
        description="Immutable deployment prompt-template version for v2 generation",
    )
    AI_RESEARCH_PROTOCOL_V2_GENERATION_PROMPT_CONTENT: str = Field(
        default="",
        max_length=256 * 1024,
        description="Fixed deployment prompt content for v2 generation; never selected by a browser",
    )
    AI_RESEARCH_PROTOCOL_V2_GENERATION_PROMPT_CONTENT_HASH: str = Field(
        default="",
        max_length=128,
        description="Canonical hash of the fixed deployment generation prompt",
    )
    AI_RESEARCH_PROTOCOL_V2_GENERATION_SAMPLING_PARAMS_JSON: str = Field(
        default="{}",
        max_length=64 * 1024,
        description="Static JSON object of approved sampling parameters for v2 generation",
    )
    AI_RESEARCH_PROTOCOL_V2_GENERATION_QUOTA_POLICY_VERSION: str = Field(
        default="",
        max_length=128,
        description="Server-owned quota policy version for v2 generation reservations",
    )
    AI_RESEARCH_PROTOCOL_V2_GENERATION_ACCOUNTING_POLICY_JSON: str = Field(
        default="",
        max_length=16 * 1024,
        description="Reviewed all-inclusive provider accounting contract; empty denies real generation",
    )
    AI_RESEARCH_PROTOCOL_V2_GENERATION_ACCOUNTING_POLICY_HASH: str = Field(
        default="",
        max_length=64,
        description="Deployment-reviewed canonical hash of the accounting contract, not provider proof",
    )
    AI_RESEARCH_PROTOCOL_V2_GENERATION_RESERVED_TOKENS: int = Field(
        default=0,
        ge=0,
        le=1_000_000,
        description="Total input-plus-output token ceiling per v2 call; zero denies deployment",
    )
    AI_RESEARCH_PROTOCOL_V2_GENERATION_QUOTA_LEASE_SECONDS: int = Field(
        default=900,
        ge=1,
        le=24 * 60 * 60,
        description="Lease duration for the fixed v2 generation quota reservation",
    )
    AI_RESEARCH_PROTOCOL_V2_GENERATION_MATERIALIZATION_POLICY_VERSION: str = Field(
        default="",
        max_length=128,
        description="Immutable deployment materialization-policy version for v2 generation",
    )
    AI_RESEARCH_PROTOCOL_V2_GENERATION_ENVIRONMENT_MANIFEST_JSON: str = Field(
        default="{}",
        max_length=64 * 1024,
        description="Static nonempty JSON environment manifest for v2 candidate materialization",
    )
    # Discovery executes only through a separately deployed, pinned HTTPS
    # runner. Defaults are deliberately incomplete so enabling either rollout
    # flag alone cannot create a usable remote-execution path.
    AI_RESEARCH_PROTOCOL_V2_DISCOVERY_ENDPOINT_URL: str = Field(
        default="",
        max_length=2048,
        description="Pinned HTTPS /v1/discovery-executions endpoint for the v2 discovery runner",
    )
    AI_RESEARCH_PROTOCOL_V2_DISCOVERY_BEARER_TOKEN: SecretStr = Field(
        default_factory=lambda: SecretStr(""),
        repr=False,
        description="Deployment-only credential for the pinned v2 discovery runner",
    )
    AI_RESEARCH_PROTOCOL_V2_DISCOVERY_RUNNER_IDENTITY: str = Field(
        default="",
        max_length=512,
        description="Pinned service identity expected in discovery-runner evidence",
    )
    AI_RESEARCH_PROTOCOL_V2_DISCOVERY_HTTP_TIMEOUT_SECONDS: float = Field(
        default=0.0,
        ge=0,
        le=3660,
        description="Whole HTTP deadline for discovery execution; deployment validates policy margin",
    )
    AI_RESEARCH_PROTOCOL_V2_DISCOVERY_SANDBOX_POLICY_VERSION: str = Field(
        default="",
        max_length=128,
        description="Immutable server-owned sandbox policy version for discovery",
    )
    AI_RESEARCH_PROTOCOL_V2_DISCOVERY_SANDBOX_IMAGE_DIGEST: str = Field(
        default="",
        max_length=128,
        description="Pinned sha256 image digest accepted from the discovery runner",
    )
    AI_RESEARCH_PROTOCOL_V2_DISCOVERY_SANDBOX_NETWORK_MODE: str = Field(
        default="",
        max_length=32,
        description="Pinned sandbox network mode; discovery policy requires none",
    )
    AI_RESEARCH_PROTOCOL_V2_DISCOVERY_SANDBOX_INPUT_READ_ONLY: bool = Field(
        default=False,
        description="Require read-only discovery sandbox inputs",
    )
    AI_RESEARCH_PROTOCOL_V2_DISCOVERY_SANDBOX_OUTPUT_PATH: str = Field(
        default="",
        max_length=2048,
        description="Pinned sandbox-owned output path for discovery evidence",
    )
    AI_RESEARCH_PROTOCOL_V2_DISCOVERY_SANDBOX_CPU_LIMIT: int = Field(
        default=0,
        ge=0,
        le=1024,
        description="Discovery sandbox CPU limit; zero leaves deployment fail-closed",
    )
    AI_RESEARCH_PROTOCOL_V2_DISCOVERY_SANDBOX_MEMORY_LIMIT_MB: int = Field(
        default=0,
        ge=0,
        le=16 * 1024 * 1024,
        description="Discovery sandbox memory limit in MiB; zero leaves deployment fail-closed",
    )
    AI_RESEARCH_PROTOCOL_V2_DISCOVERY_SANDBOX_PID_LIMIT: int = Field(
        default=0,
        ge=0,
        le=1_000_000,
        description="Discovery sandbox process limit; zero leaves deployment fail-closed",
    )
    AI_RESEARCH_PROTOCOL_V2_DISCOVERY_SANDBOX_WALL_TIMEOUT_SECONDS: int = Field(
        default=0,
        ge=0,
        le=3600,
        description="Discovery sandbox wall-clock timeout; zero leaves deployment fail-closed",
    )
    AI_RESEARCH_PROTOCOL_V2_DISCOVERY_SANDBOX_OUTPUT_LIMIT_BYTES: int = Field(
        default=0,
        ge=0,
        le=100 * 1024 * 1024,
        description="Maximum retained discovery sandbox output bytes; zero leaves deployment fail-closed",
    )
    AI_RESEARCH_PROTOCOL_V2_DISCOVERY_QUOTA_POLICY_VERSION: str = Field(
        default="",
        max_length=128,
        description="Server-owned discovery sandbox-seconds quota policy version",
    )
    AI_RESEARCH_PROTOCOL_V2_DISCOVERY_QUOTA_LEASE_SECONDS: int = Field(
        default=0,
        ge=0,
        le=24 * 60 * 60,
        description="Discovery quota lease; deployment validates the required wall-time margin",
    )
    AI_RESEARCH_PROTOCOL_V2_GOVERNANCE_POLICY_VERSION: str = Field(
        default="governance-v1",
        min_length=1,
        max_length=128,
        description="Server-owned version for trusted-research governance deviations",
    )
    AI_RESEARCH_PROTOCOL_V2_WAIVABLE_TARGETS: str = Field(
        default="",
        description="Comma-separated server allowlist of waivable trusted-research performance targets",
    )
    ASSET_RESEARCH_TASK_POLL_SECONDS: int = Field(
        default=10,
        ge=1,
        le=3600,
        description="Polling cadence for queued interactive multi-asset research tasks",
    )
    ASSET_RESEARCH_TASK_LEASE_SECONDS: int = Field(
        default=900,
        ge=60,
        le=7200,
        description="Durable lease duration for one interactive multi-asset task",
    )
    ASSET_RESEARCH_TASK_MAX_BATCH: int = Field(
        default=20,
        ge=1,
        le=100,
        description="Maximum queued interactive research tasks claimed in one worker cycle",
    )
    ASSET_RESEARCH_TASK_WORKER_CONCURRENCY: int = Field(
        default=4,
        ge=1,
        le=32,
        description="Maximum in-process interactive research task executions per cycle",
    )
    ASSET_RESEARCH_OPERATOR_JURISDICTION: str = Field(
        default="CN",
        min_length=2,
        max_length=32,
        description="Server-owned operating jurisdiction for asset-research publication policy",
    )
    ASSET_RESEARCH_DIRECTIONAL_FX_CRYPTO_ENABLED: bool = Field(
        default=False,
        description="Allow public FX/crypto directions outside mainland China after approvals",
    )
    ASSET_RESEARCH_SCHEDULE_POLL_SECONDS: int = Field(
        default=60,
        ge=10,
        le=3600,
        description="Polling cadence for due multi-asset shadow schedules",
    )
    ASSET_RESEARCH_SCHEDULE_LEASE_SECONDS: int = Field(
        default=900,
        ge=60,
        le=7200,
        description="Durable lease duration for one multi-asset schedule fire",
    )
    ASSET_RESEARCH_SCHEDULE_MAX_RETRIES: int = Field(
        default=3,
        ge=0,
        le=10,
        description="Maximum immutable retries for one failed schedule fire",
    )
    ASSET_RESEARCH_SCHEDULE_MISFIRE_GRACE_SECONDS: int = Field(
        default=300,
        ge=0,
        le=86400,
        description="Lateness tolerated before a schedule misfire policy is applied",
    )
    ASSET_RESEARCH_SCHEDULE_RETRY_BASE_SECONDS: int = Field(
        default=300,
        ge=10,
        le=86400,
        description="Initial exponential-backoff delay for asset schedule retries",
    )
    ASSET_RESEARCH_SCHEDULE_RETRY_MAX_SECONDS: int = Field(
        default=3600,
        ge=10,
        le=86400,
        description="Maximum exponential-backoff delay for asset schedule retries",
    )
    ASSET_RESEARCH_SCHEDULE_MAX_BATCH: int = Field(
        default=100,
        ge=1,
        le=100,
        description="Maximum due multi-asset schedules claimed in one approved capacity cycle",
    )
    ASSET_RESEARCH_SCHEDULE_WORKER_CONCURRENCY: int = Field(
        default=4,
        ge=1,
        le=32,
        description="Maximum in-process multi-asset schedule executions per poll",
    )
    ASSET_RESEARCH_SOURCE_MAX_CONCURRENCY: int = Field(
        default=2,
        ge=1,
        le=16,
        description="Maximum in-process collection attempts per declared asset-data source",
    )
    ASSET_RESEARCH_AKSHARE_PROVIDER_ENABLED: bool = Field(
        default=False,
        description="Enable approved AkShare-backed futures/bond providers for asset research",
    )
    ASSET_RESEARCH_OUTCOME_EVALUATOR_ENABLED: bool = Field(
        default=False,
        description="Enable the database-backed multi-asset outcome evaluator worker",
    )
    ASSET_RESEARCH_OUTCOME_EVALUATOR_POLL_SECONDS: int = Field(
        default=300,
        ge=30,
        le=86400,
        description="Polling cadence for mature multi-asset outcome evaluation",
    )
    ASSET_RESEARCH_OUTCOME_EVALUATOR_LEASE_SECONDS: int = Field(
        default=900,
        ge=60,
        le=7200,
        description="Durable lease duration for one multi-asset outcome evaluation",
    )
    ASSET_RESEARCH_OUTCOME_EVALUATOR_MAX_BATCH: int = Field(
        default=100,
        ge=1,
        le=1000,
        description="Maximum mature predictions claimed in one outcome evaluator poll",
    )
    ASSET_RESEARCH_LLM_REPORT_ENABLED: bool = Field(
        default=False,
        description="Enable optional LLM-generated multi-asset report sections",
    )
    ASSET_RESEARCH_LLM_MODEL: str = Field(
        default="",
        description="Model name for optional asset-research report generation",
    )
    ASSET_RESEARCH_LLM_PROVIDER: str = Field(
        default="",
        description="Provider key from the AI provider registry for asset-research LLM",
    )
    ASSET_RESEARCH_LLM_BASE_URL: str | None = Field(
        default=None,
        description="Optional OpenAI-compatible base URL for asset-research LLM",
    )
    ASSET_RESEARCH_LLM_API_KEY_ENV: str | None = Field(
        default=None,
        description="Environment variable name containing the asset-research LLM API key",
    )
    ASSET_RESEARCH_LLM_MAX_TOKENS: int = Field(
        default=6000,
        ge=256,
        le=32768,
        description="Maximum output tokens requested for one asset-research report",
    )
    ASSET_RESEARCH_LLM_PER_TASK_TOKENS: int = Field(
        default=30000,
        ge=1000,
        le=200000,
        description="Per-task LLM token budget for asset-research reports",
    )
    ASSET_RESEARCH_LLM_DAILY_TOKENS: int = Field(
        default=100000,
        ge=1000,
        le=5000000,
        description="Daily LLM token budget for asset-research reports",
    )
    ASSET_RESEARCH_LLM_MONTHLY_TOKENS: int = Field(
        default=1000000,
        ge=1000,
        le=50000000,
        description="Monthly LLM token budget for asset-research reports",
    )
    ASSET_RESEARCH_LLM_PER_TASK_COST_USD: float = Field(
        default=0.1,
        ge=0,
        le=100,
        description="Per-task LLM cost budget in USD for asset-research reports",
    )
    ASSET_RESEARCH_LLM_DAILY_COST_USD: float = Field(
        default=1.0,
        ge=0,
        le=10000,
        description="Daily LLM cost budget in USD for asset-research reports",
    )
    ASSET_RESEARCH_LLM_MONTHLY_COST_USD: float = Field(
        default=10.0,
        ge=0,
        le=100000,
        description="Monthly LLM cost budget in USD for asset-research reports",
    )
    DB_AUTO_CREATE_SCHEMA: bool = Field(default=False)
    DB_AUTO_CREATE_DEFAULT_ADMIN: bool = Field(default=False)

    # Optional: Document database
    DOCUMENT_DB_TYPE: str | None = Field(default=None, description="Document database type")
    DOCUMENT_DB_URL: str | None = Field(default=None, description="Document database URL")

    # Optional: Timeseries database
    TIMESERIES_DB_TYPE: str | None = Field(default=None, description="Timeseries database type")
    TIMESERIES_DB_URL: str | None = Field(default=None, description="Timeseries database URL")

    # Optional: Redis cache
    REDIS_URL: str | None = Field(default=None, description="Redis cache URL")
    HTTP_PROXY: str = Field(default="", description="HTTP proxy URL")
    HTTPS_PROXY: str = Field(default="", description="HTTPS proxy URL")
    SOCKS_PROXY: str = Field(default="", description="SOCKS proxy URL")
    PROXY_HOST: str = Field(default="", description="Proxy host with optional scheme")
    NO_PROXY: str = Field(default="", description="No proxy hosts")

    # JWT settings
    JWT_SECRET_KEY: str = Field(
        default="your-jwt-secret-change-in-production",
        description="JWT secret key (CHANGE IN PRODUCTION)",
    )
    JWT_ALGORITHM: str = Field(default="HS256", description="JWT encryption algorithm")
    JWT_EXPIRE_MINUTES: int = Field(
        default=60, description="JWT token expiration in minutes (default 1 hour)"
    )

    # Rate limiting (slowapi limit strings). E2E environments can raise these
    # quotas explicitly without weakening production brute-force protection.
    RATE_LIMIT_REGISTER: str = Field(
        default="5/hour", description="Rate limit for POST /auth/register (slowapi string)"
    )
    RATE_LIMIT_LOGIN: str = Field(
        default="10/minute", description="Rate limit for POST /auth/login (slowapi string)"
    )
    RATE_LIMIT_AUTH_ME: str = Field(
        default="60/minute", description="Rate limit for GET /auth/me (slowapi string)"
    )

    # Service settings
    # NOTE: defaults to 127.0.0.1 (loopback) for safety. Production / docker
    # deployments should override via HOST=0.0.0.0 in their env files.
    HOST: str = Field(
        default="127.0.0.1",
        description="Server host address (override to 0.0.0.0 in containers/production)",
    )
    PORT: int = Field(default=8000, description="Server port")
    AI_CHAT_ENABLED: bool = Field(
        default=False, description="Enable generated AI responses for knowledge-base chat"
    )
    AI_CHAT_BASE_URL: str = Field(
        default="", description="Base URL for an OpenAI-compatible chat completions endpoint"
    )
    AI_CHAT_API_KEY: str = Field(default="", description="API key for AI chat provider")
    AI_CHAT_MODEL: str = Field(default="", description="Model name for AI chat provider")
    AI_CHAT_TIMEOUT: float = Field(
        default=120.0, description="Timeout for AI chat provider requests in seconds"
    )
    AI_CHAT_TEMPERATURE: float = Field(
        default=0.2, description="Sampling temperature for AI chat provider requests"
    )
    AI_CHAT_MAX_TOKENS: int = Field(
        default=4096,
        ge=512,
        le=32768,
        description="Maximum tokens requested from the AI chat provider",
    )
    RAG_VECTOR_ENABLED: bool = Field(
        default=True,
        description="Enable local vector retrieval for knowledge-base chat",
    )
    RAG_EMBEDDING_MODEL: str = Field(
        default="BAAI/bge-small-zh-v1.5",
        description="Sentence Transformers model used for local RAG embeddings",
    )
    RAG_VECTOR_COLLECTION: str = Field(
        default="knowledge_base_documents_v3",
        description="Local Chroma collection name for knowledge-base document vectors",
    )
    RAG_VECTOR_UPSERT_BATCH_SIZE: int = Field(
        default=128,
        ge=16,
        le=512,
        description="Document vectors processed in one local Chroma upsert batch",
    )
    RAG_LLM_RERANK_TIMEOUT: float = Field(
        default=30.0,
        ge=5.0,
        le=120.0,
        description="Maximum seconds for the short knowledge-base rerank call",
    )
    AI_BUDGET_DAILY_USD: float | None = Field(
        default=None, description="Default daily AI cost budget in USD. None means unlimited"
    )
    AI_BUDGET_MODE: str = Field(default="soft", description="AI budget mode: soft or hard")
    AI_PROVIDERS: dict[str, dict[str, Any]] = Field(
        default_factory=get_default_provider_registry,
        description="AI provider registry keyed by provider name",
    )
    STRATEGY_SCORE_MODEL_VERSION: str = Field(
        default="v1", description="Model version for strategy score outputs"
    )
    STRATEGY_SCORE_WEIGHTS: dict[str, float] = Field(
        default_factory=lambda: {
            "profitability": 0.2,
            "risk_control": 0.2,
            "stability": 0.2,
            "overfitting_risk": 0.15,
            "executability": 0.15,
            "benchmark_comparison": 0.1,
        },
        description="Strategy score dimension weights",
    )

    # Graceful shutdown timeout (seconds)
    SHUTDOWN_TIMEOUT: int = Field(
        default=30,
        description="Graceful shutdown timeout in seconds (range 1-300)",
    )

    # Optional, deployment-owned read-only service-client composition. This
    # value contains client authentication material and is never exposed by
    # settings reprs or ordinary model dumps. Empty keeps the integration off.
    SERVICE_READ_DEPLOYMENT_JSON: SecretStr = Field(
        default=SecretStr(""),
        repr=False,
        exclude=True,
        description=(
            "Secret deployment JSON for explicitly authorized read-only service clients; "
            "leave blank to keep service reads unconfigured"
        ),
    )

    # Backtest subprocess timeout (seconds)
    BACKTEST_TIMEOUT: int = Field(default=300, description="Backtest subprocess timeout in seconds")
    AI_STRATEGY_SANDBOX_USE_DOCKER: bool = Field(
        default=True,
        description="Require Docker isolation for AI strategy draft validation in production",
    )
    AI_STRATEGY_SANDBOX_DOCKER_IMAGE: str = Field(
        default="backtrader-sandbox:latest",
        description="Docker image used for AI strategy draft validation",
    )

    # Monitoring check intervals (seconds)
    MONITORING_SYSTEM_INTERVAL: int = Field(
        default=300, description="System alert check interval in seconds"
    )
    MONITORING_ACCOUNT_INTERVAL: int = Field(
        default=30, description="Account/Position alert check interval in seconds"
    )
    MONITORING_STRATEGY_INTERVAL: int = Field(
        default=60, description="Strategy alert check interval in seconds"
    )
    MONITORING_DEFAULT_INTERVAL: int = Field(
        default=60, description="Default alert check interval in seconds"
    )

    # CORS allowed origins (comma-separated)
    CORS_ORIGINS: str = Field(
        default="http://localhost:3000", description="Comma-separated list of allowed CORS origins"
    )

    # Logging format: "json" for structured JSON, "text" for plain text.
    # If unset, falls back to DEBUG-based default (DEBUG=true → colored text, DEBUG=false → JSON).
    LOG_FORMAT: str = Field(
        default="",
        description="Log output format: 'json' for structured JSON, 'text' for plain text, "
        "empty for auto-detection based on DEBUG flag",
    )

    # Log level override: when set, overrides the DEBUG-based default level.
    # Valid values: DEBUG, INFO, WARNING, ERROR, CRITICAL (case-insensitive).
    LOG_LEVEL: str = Field(
        default="",
        description="Explicit log level override. Empty = auto (DEBUG→DEBUG, prod→WARNING/INFO)",
    )

    # Log output directory
    LOG_DIR: str = Field(default="./logs", description="Log output directory path")

    # Log retention periods per category (days)
    LOG_RETENTION_APP_DAYS: int = Field(default=30, description="Application log retention in days")
    LOG_RETENTION_ERROR_DAYS: int = Field(default=90, description="Error log retention in days")
    LOG_RETENTION_AUDIT_DAYS: int = Field(default=365, description="Audit log retention in days")
    LOG_ROTATION_MAX_MB: int = Field(
        default=100,
        description="Maximum size in MB for each dated log file before rotation; 0 disables size cap",
    )

    # Audit settings
    AUDIT_RETENTION_DAYS: int = Field(
        default=90, description="Database audit record retention in days (7-365)"
    )
    AUDIT_CLEANUP_HOUR: int = Field(
        default=2, description="Hour of day to run audit cleanup (0-23)"
    )
    AUDIT_EVENT_MAX_SIZE_KB: int = Field(
        default=10, description="Maximum size of a single audit event_data in KB (1-100)"
    )

    # Airflow integration settings
    AIRFLOW_API_BASE_URL: str = Field(
        default="", description="Airflow REST API base URL (e.g. http://localhost:8080/api/v1)"
    )
    AIRFLOW_USERNAME: str = Field(default="admin", description="Airflow API username")
    AIRFLOW_PASSWORD: str = Field(default="", description="Airflow API password")
    ORCHESTRATION_BACKEND: str = Field(
        default="auto",
        description="Orchestration backend: airflow, apscheduler, auto (auto-detect)",
    )
    AIRFLOW_DAG_OUTPUT_DIR: str = Field(
        default="./dags", description="Directory for generated Airflow DAG files"
    )
    AIRFLOW_CALLBACK_BASE_URL: str = Field(
        default="http://localhost:8000",
        description="Base URL for Airflow task callbacks to ai-for-investor",
    )

    # SQL logging (independent of DEBUG to avoid too much noise)
    SQL_ECHO: bool = Field(default=False, description="Enable SQLAlchemy query logging")

    # Default admin account
    ADMIN_USERNAME: str = Field(default="admin", description="Default admin username")
    ADMIN_PASSWORD: str = Field(
        default="admin123", description="Default admin password (CHANGE IN PRODUCTION)"
    )
    ADMIN_EMAIL: str = Field(default="admin@example.com", description="Default admin email")

    SYNC_LOCAL_MYSQL_HOST: str = Field(
        default="127.0.0.1", description="Local MySQL host for data sync"
    )
    SYNC_LOCAL_MYSQL_PORT: int = Field(default=3306, description="Local MySQL port for data sync")
    SYNC_LOCAL_MYSQL_USER: str = Field(default="root", description="Local MySQL user for data sync")
    SYNC_LOCAL_MYSQL_PASSWORD: str = Field(
        default="", description="Local MySQL password for data sync"
    )

    # CTP credentials (read from .env for form pre-fill)
    CTP_BROKER_ID: str = Field(default="", description="CTP broker ID")
    CTP_USER_ID: str = Field(default="", description="CTP user/investor ID")
    CTP_INVESTOR_ID: str = Field(default="", description="CTP investor ID")
    CTP_PASSWORD: str = Field(default="", description="CTP password")
    CTP_APP_ID: str = Field(default="simnow_client_test", description="CTP app ID")
    CTP_AUTH_CODE: str = Field(default="0000000000000000", description="CTP auth code")

    # MT5 credentials
    MT5_LOGIN: str = Field(default="", description="MT5 login")
    MT5_PASSWORD: str = Field(default="", description="MT5 password")
    MT5_SERVER: str = Field(default="", description="MT5 server name")
    MT5_WS_URI: str = Field(default="", description="MT5 WebSocket URI")
    MT5_DEMO_LOGIN: str = Field(default="", description="MT5 demo login")
    MT5_DEMO_PASSWORD: str = Field(default="", description="MT5 demo password")
    MT5_DEMO_SERVER: str = Field(default="", description="MT5 demo server name")
    MT5_DEMO_WS_URI: str = Field(default="", description="MT5 demo WebSocket URI")
    MT5_LIVE_LOGIN: str = Field(default="", description="MT5 live login")
    MT5_LIVE_PASSWORD: str = Field(default="", description="MT5 live password")
    MT5_LIVE_SERVER: str = Field(default="", description="MT5 live server name")
    MT5_LIVE_WS_URI: str = Field(default="", description="MT5 live WebSocket URI")
    MT5_SYMBOL_SUFFIX: str = Field(default="", description="MT5 symbol suffix")
    MT5_TIMEOUT: float = Field(default=60.0, description="MT5 request timeout in seconds")

    # IB Web credentials
    IB_ACCOUNT_ID: str = Field(default="", description="IB account ID")
    IB_ASSET_TYPE: str = Field(default="STK", description="IB asset type")
    IB_BASE_URL: str = Field(default="https://localhost:5000", description="IB Web base URL")
    IB_ACCESS_TOKEN: str = Field(default="", description="IB access token")
    IB_VERIFY_SSL: bool = Field(default=True, description="IB Web verify SSL")
    IB_TIMEOUT: float = Field(default=10.0, description="IB Web request timeout in seconds")
    IB_COOKIE_SOURCE: str = Field(default="", description="IB Web cookie source")
    IB_COOKIE_BROWSER: str = Field(default="chrome", description="IB Web cookie browser")
    IB_COOKIE_PATH: str = Field(default="/sso", description="IB Web cookie path")
    IB_USERNAME: str = Field(default="", description="IB Web username")
    IB_PASSWORD: str = Field(default="", description="IB Web password")
    IB_LOGIN_BROWSER: str = Field(default="chrome", description="IB Web login browser")
    IB_LOGIN_HEADLESS: bool = Field(default=False, description="IB Web login headless")
    IB_LOGIN_TIMEOUT: int = Field(default=180, description="IB Web login timeout in seconds")
    IB_COOKIE_OUTPUT: str = Field(default="", description="IB Web cookie output path")
    IB_WEB_ACCOUNT_ID: str = Field(default="", description="IB Web account ID")
    IB_WEB_ASSET_TYPE: str = Field(default="", description="IB Web asset type")
    IB_WEB_BASE_URL: str = Field(default="", description="IB Web base URL override")
    IB_WEB_ACCESS_TOKEN: str = Field(default="", description="IB Web access token override")
    IB_WEB_VERIFY_SSL: bool = Field(default=True, description="IB Web verify SSL override")
    IB_WEB_TIMEOUT: float = Field(default=0.0, description="IB Web request timeout override")
    IB_WEB_COOKIE_SOURCE: str = Field(default="", description="IB Web cookie source override")
    IB_WEB_COOKIE_BROWSER: str = Field(default="", description="IB Web cookie browser override")
    IB_WEB_COOKIE_PATH: str = Field(default="", description="IB Web cookie path override")
    IB_WEB_USERNAME: str = Field(default="", description="IB Web username override")
    IB_WEB_PASSWORD: str = Field(default="", description="IB Web password override")
    IB_WEB_LOGIN_MODE: str = Field(default="", description="IB Web login mode override")
    IB_WEB_LOGIN_BROWSER: str = Field(default="", description="IB Web login browser override")
    IB_WEB_LOGIN_HEADLESS: bool = Field(default=False, description="IB Web login headless override")
    IB_WEB_LOGIN_TIMEOUT: int = Field(default=0, description="IB Web login timeout override")
    IB_WEB_COOKIE_OUTPUT: str = Field(default="", description="IB Web cookie output override")
    IB_PAPER_ACCOUNT_ID: str = Field(default="", description="IB paper account ID")
    IB_PAPER_ASSET_TYPE: str = Field(default="", description="IB paper asset type")
    IB_PAPER_BASE_URL: str = Field(default="", description="IB paper base URL")
    IB_PAPER_ACCESS_TOKEN: str = Field(default="", description="IB paper access token")
    IB_PAPER_VERIFY_SSL: bool = Field(default=True, description="IB paper verify SSL")
    IB_PAPER_TIMEOUT: float = Field(default=0.0, description="IB paper request timeout in seconds")
    IB_PAPER_COOKIE_SOURCE: str = Field(default="", description="IB paper cookie source")
    IB_PAPER_COOKIE_BROWSER: str = Field(default="", description="IB paper cookie browser")
    IB_PAPER_COOKIE_PATH: str = Field(default="", description="IB paper cookie path")
    IB_LIVE_ACCOUNT_ID: str = Field(default="", description="IB live account ID")
    IB_LIVE_ASSET_TYPE: str = Field(default="", description="IB live asset type")
    IB_LIVE_BASE_URL: str = Field(default="", description="IB live base URL")
    IB_LIVE_ACCESS_TOKEN: str = Field(default="", description="IB live access token")
    IB_LIVE_VERIFY_SSL: bool = Field(default=True, description="IB live verify SSL")
    IB_LIVE_TIMEOUT: float = Field(default=0.0, description="IB live request timeout in seconds")
    IB_LIVE_COOKIE_SOURCE: str = Field(default="", description="IB live cookie source")
    IB_LIVE_COOKIE_BROWSER: str = Field(default="", description="IB live cookie browser")
    IB_LIVE_COOKIE_PATH: str = Field(default="", description="IB live cookie path")

    # Binance credentials
    BINANCE_ACCOUNT_ID: str = Field(default="", description="Binance account identifier")
    BINANCE_ASSET_TYPE: str = Field(default="SWAP", description="Binance asset type")
    BINANCE_API_KEY: str = Field(default="", description="Binance API key")
    BINANCE_SECRET_KEY: str = Field(default="", description="Binance secret key")
    BINANCE_TESTNET: bool = Field(default=False, description="Binance testnet flag")
    BINANCE_BASE_URL: str = Field(default="", description="Binance REST base URL")

    # OKX credentials
    OKX_ACCOUNT_ID: str = Field(default="", description="OKX account identifier")
    OKX_ASSET_TYPE: str = Field(default="SWAP", description="OKX asset type")
    OKX_API_KEY: str = Field(default="", description="OKX API key")
    OKX_SECRET_KEY: str = Field(default="", description="OKX secret key")
    OKX_PASSPHRASE: str = Field(default="", description="OKX passphrase")
    OKX_TESTNET: bool = Field(default=False, description="OKX testnet flag")
    OKX_BASE_URL: str = Field(default="", description="OKX REST base URL")

    model_config = SettingsConfigDict(
        env_file=(
            ".env",
            str(Path(__file__).resolve().parents[3] / ".env"),
        ),
        env_file_encoding="utf-8",
        extra="ignore",
    )

    @model_validator(mode="after")
    def validate_runtime_security_guards(self) -> "Settings":
        """Validate production-only secret and admin-password guards."""
        if self.MARKET_DATA_QUERY_V2_ENABLED and not self.MARKET_DATA_CURSOR_SIGNING_KEY:
            raise ValueError(
                "MARKET_DATA_CURSOR_SIGNING_KEY is required when MARKET_DATA_QUERY_V2_ENABLED=true"
            )
        if self.MARKET_DATA_RESEARCH_BACKTEST_BRIDGE_ENABLED:
            if not self.MARKET_DATA_QUERY_V2_ENABLED:
                raise ValueError(
                    "MARKET_DATA_QUERY_V2_ENABLED is required when "
                    "MARKET_DATA_RESEARCH_BACKTEST_BRIDGE_ENABLED=true"
                )
            if len(self.MARKET_DATA_RESEARCH_ARTIFACT_SIGNING_KEY.encode("utf-8")) < 32:
                raise ValueError(
                    "MARKET_DATA_RESEARCH_ARTIFACT_SIGNING_KEY must be at least 32 bytes when "
                    "MARKET_DATA_RESEARCH_BACKTEST_BRIDGE_ENABLED=true"
                )
            artifact_root = Path(self.MARKET_DATA_RESEARCH_ARTIFACT_ROOT).expanduser()
            if not artifact_root.is_absolute():
                raise ValueError(
                    "MARKET_DATA_RESEARCH_ARTIFACT_ROOT must be an absolute path when "
                    "MARKET_DATA_RESEARCH_BACKTEST_BRIDGE_ENABLED=true"
                )
        if production_security_mode(self):
            cors_origins = {
                origin.strip() for origin in self.CORS_ORIGINS.split(",") if origin.strip()
            }
            if "*" in cors_origins:
                raise ValueError(
                    "Wildcard CORS origin is not allowed in production when credentials are enabled. "
                    "Set CORS_ORIGINS to explicit http:// or https:// origins."
                )
            for field_name in ("SECRET_KEY", "JWT_SECRET_KEY"):
                if getattr(self, field_name) in _DEFAULT_SECRETS:
                    raise ValueError(
                        f"Default secret key detected (ENV: {field_name}). "
                        "Please set a secure random key via environment variable in production."
                    )
            if self.ADMIN_PASSWORD.lower() in _DEFAULT_PASSWORDS:
                raise ValueError(
                    "Default admin password detected. Set ADMIN_PASSWORD to a secure password in production."
                )
            for field_name in (
                "IB_VERIFY_SSL",
                "IB_WEB_VERIFY_SSL",
                "IB_PAPER_VERIFY_SSL",
                "IB_LIVE_VERIFY_SSL",
            ):
                if not getattr(self, field_name):
                    raise ValueError(
                        f"{field_name}=False is not allowed in production. "
                        "Install the gateway CA certificate and enable TLS verification."
                    )
            if not self.AI_STRATEGY_SANDBOX_USE_DOCKER:
                raise ValueError(
                    "AI_STRATEGY_SANDBOX_USE_DOCKER must be enabled in production. "
                    "AI-generated strategy code cannot run in the application process."
                )
        return self

    @field_validator("SECRET_KEY", "JWT_SECRET_KEY")
    @classmethod
    def validate_secrets_length(cls, v: str, info) -> str:
        """Validate that secret keys have sufficient length."""
        min_length = 32
        if len(v) < min_length:
            raise ValueError(
                f"{info.field_name} must be at least {min_length} characters long "
                f"for security. Current length: {len(v)}"
            )
        return v

    @field_validator("DATABASE_TYPE")
    @classmethod
    def validate_database_type(cls, v: str) -> str:
        """Validate that database type is supported."""
        supported_databases = {"sqlite", "postgresql", "mysql"}
        if v.lower() not in supported_databases:
            raise ValueError(
                f"Unsupported DATABASE_TYPE: {v}. Supported types: {', '.join(supported_databases)}"
            )
        return v.lower()

    @field_validator("PORT")
    @classmethod
    def validate_port_range(cls, v: int) -> int:
        """Validate that port is in valid range."""
        if not (1 <= v <= 65535):
            raise ValueError(f"PORT must be between 1 and 65535, got: {v}")
        return v

    @field_validator("SHUTDOWN_TIMEOUT")
    @classmethod
    def validate_shutdown_timeout(cls, v: int) -> int:
        """Validate that shutdown timeout is in valid range (1-300)."""
        if not (1 <= v <= 300):
            import logging

            logging.getLogger(__name__).warning(
                "SHUTDOWN_TIMEOUT=%d is out of range (1-300), using default 30s", v
            )
            return 30
        return v

    @field_validator("AKSHARE_INTERFACE_BOOTSTRAP_MODE")
    @classmethod
    def validate_akshare_interface_bootstrap_mode(cls, v: str) -> str:
        """Validate akshare interface bootstrap mode."""
        normalized = v.strip().lower()
        supported_modes = {"manual", "refresh"}
        if normalized not in supported_modes:
            raise ValueError(
                "AKSHARE_INTERFACE_BOOTSTRAP_MODE must be one of: "
                f"{', '.join(sorted(supported_modes))}"
            )
        return normalized

    @field_validator("MARKET_DATA_OPENBB_PROVIDER")
    @classmethod
    def validate_market_data_openbb_provider(cls, v: str) -> str:
        """Accept only runner providers with a reviewed static contract."""
        normalized = str(v or "").strip().lower()
        if not _MARKET_DATA_PROVIDER_TOKEN_PATTERN.fullmatch(normalized):
            raise ValueError(
                "MARKET_DATA_OPENBB_PROVIDER must be a lowercase provider token up to 128 chars"
            )
        if normalized not in SUPPORTED_OPENBB_RUNNER_PROVIDERS:
            raise ValueError(
                "MARKET_DATA_OPENBB_PROVIDER must be one of: "
                f"{', '.join(sorted(SUPPORTED_OPENBB_RUNNER_PROVIDERS))}"
            )
        return normalized

    @field_validator("MARKET_DATA_OPENBB_ALLOWED_MARKETS")
    @classmethod
    def validate_market_data_openbb_allowed_markets(cls, v: str) -> str:
        """Normalize an operator-reviewed OpenBB venue allow-list without defaults."""
        values = [item.strip() for item in str(v or "").split(",") if item.strip()]
        if any(len(item) > 128 for item in values):
            raise ValueError("MARKET_DATA_OPENBB_ALLOWED_MARKETS values must be at most 128 chars")
        return ",".join(dict.fromkeys(values))

    @field_validator("MARKET_DATA_CURSOR_SIGNING_KEY")
    @classmethod
    def validate_market_data_cursor_signing_key(cls, v: str) -> str:
        """Accept a blank disabled-state value or a high-entropy HMAC secret."""
        normalized = str(v or "").strip()
        if normalized and len(normalized.encode("utf-8")) < 32:
            raise ValueError("MARKET_DATA_CURSOR_SIGNING_KEY must be at least 32 bytes")
        return normalized

    @field_validator("SERVICE_READ_DEPLOYMENT_JSON")
    @classmethod
    def validate_service_read_deployment_size(cls, value: SecretStr) -> SecretStr:
        """Keep the secret deployment document bounded before JSON parsing."""
        if len(value.get_secret_value().encode("utf-8")) > 262_144:
            raise ValueError("SERVICE_READ_DEPLOYMENT_JSON exceeds the 256 KiB limit")
        return value

    @field_validator("AI_BUDGET_MODE")
    @classmethod
    def validate_ai_budget_mode(cls, v: str) -> str:
        normalized = str(v or "soft").strip().lower()
        supported_modes = {"soft", "hard"}
        if normalized not in supported_modes:
            raise ValueError(f"AI_BUDGET_MODE must be one of: {', '.join(sorted(supported_modes))}")
        return normalized

    @field_validator("AI_PROVIDERS", mode="before")
    @classmethod
    def validate_ai_providers(cls, v: object) -> dict[str, dict[str, Any]]:
        return parse_ai_providers(v)

    @field_validator("JWT_EXPIRE_MINUTES")
    @classmethod
    def validate_jwt_expiration(cls, v: int) -> int:
        """Validate that JWT expiration is reasonable."""
        if not (5 <= v <= 10080):  # 5 minutes to 7 days
            raise ValueError(
                f"JWT_EXPIRE_MINUTES must be between 5 and 10080 (5 min to 7 days), got: {v}"
            )
        return v

    @field_validator("CORS_ORIGINS")
    @classmethod
    def validate_cors_origins(cls, v: str) -> str:
        """Validate that CORS origins are properly formatted."""
        if not v:
            raise ValueError("CORS_ORIGINS cannot be empty")

        origins = [o.strip() for o in v.split(",") if o.strip()]
        for origin in origins:
            if origin == "*":
                continue  # Wildcard is acceptable
            if not origin.startswith(("http://", "https://")):
                raise ValueError(
                    f"Invalid CORS origin: '{origin}'. Origins must start with http:// or https://"
                )

        return v

    @field_validator("STRATEGY_SCORE_WEIGHTS", mode="before")
    @classmethod
    def validate_strategy_score_weights(cls, v: object) -> dict[str, float]:
        """Validate strategy score weights from dict or JSON string."""
        return parse_strategy_score_weights(v)


# Use simple cache to avoid lru_cache issues in pydantic-settings v2
_settings: Settings | None = None


def get_settings() -> Settings:
    """Get the configuration singleton.

    Returns:
        The Settings instance.
    """
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings
