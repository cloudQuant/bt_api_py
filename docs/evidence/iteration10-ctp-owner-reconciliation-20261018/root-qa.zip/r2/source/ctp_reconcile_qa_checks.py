"""Root-only source origin and no-provider guards for the focused component QA."""
import importlib.abc
from pathlib import Path
import sys
import platform
platform.node()  # Preload Windows metadata before candidate subprocess denial.
ROOT = Path(__file__).resolve().parent
class NoCtpProvider(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname == "bt_api_ctp" or fullname.startswith("bt_api_ctp."):
            raise RuntimeError("provider import forbidden in callback component QA")
        return None
sys.meta_path.insert(0, NoCtpProvider())
def no_external_calls(event, args):
    if event in {"socket.connect", "socket.bind", "subprocess.Popen", "os.system", "os.exec", "os.posix_spawn"}:
        raise RuntimeError("external operation forbidden in callback component QA")
sys.addaudithook(no_external_calls)
def pytest_sessionfinish(session, exitstatus):
    expected = {
        "bt_api_py.ctp_service_execution": ROOT / "bt_api_py/ctp_service_execution.py",
        "bt_api_execution.store": ROOT / "execution/src/bt_api_execution/store.py",
        "bt_api_execution.ctp_callback_session": ROOT / "execution/src/bt_api_execution/ctp_callback_session.py",
        "bt_api_base": ROOT / "base/src/bt_api_base/__init__.py",
    }
    for name, source in expected.items():
        module = sys.modules.get(name)
        assert module is not None and Path(module.__file__).resolve() == source.resolve(), name
    assert not any(name == "bt_api_ctp" or name.startswith("bt_api_ctp.") for name in sys.modules)
