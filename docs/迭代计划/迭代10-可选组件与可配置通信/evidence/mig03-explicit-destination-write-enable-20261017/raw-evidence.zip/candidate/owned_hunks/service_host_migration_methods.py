# Extracted exact MIG03 methods only; rest of shared service_host.py excluded.

    def migration_consumer_inventory(self) -> tuple[object, ...]:
        """Return the parsed-config and trusted-authority consumer snapshot.

        The snapshot is available only from a started Host so configured
        outbound bindings use the same trusted scope/peer resolvers and
        requested-operation policy that the production runtime uses. It is a
        preflight input for MIG03, not evidence that the consumers have stopped.
        """

        self._check_owner_thread()
        if self._state != "started":
            raise ServiceHostError("HOST_NOT_STARTED")
        bundle = self._trusted_clients
        if self._config.clients and bundle is None:
            raise ServiceHostError("TRUSTED_CLIENTS_REQUIRED")
        try:
            from .service_migration_boundary import derive_service_consumer_inventory

            return derive_service_consumer_inventory(
                self._config,
                self._authority.grants,
                authority=self._authority,
                requested_operations=(
                    None if bundle is None else bundle.requested_operations
                ),
                scope_resolver=None if bundle is None else bundle.scope_resolver,
                peer_resolver=None if bundle is None else bundle.peer_resolver,
            )
        except Exception as exc:
            if isinstance(exc, ServiceHostError):
                raise
            raise ServiceHostError("MIGRATION_CONSUMER_INVENTORY_UNAVAILABLE") from None

    def enable_migration_writes(
        self,
        *,
        migration_id: str,
        readiness_sha256: str,
    ) -> None:
        """Explicitly enable a ready destination after operator readback.

        The caller must first verify destination-side reads/projections and
        policy against the source inventory. The Registry then checks the
        durable cutover identity and its own readiness before releasing the
        local writer latch.
        """

        self._check_owner_thread()
        registry = self._registry
        if self._state != "started" or registry is None:
            raise ServiceHostError("HOST_NOT_STARTED")
        if not self.healthy or not registry.ready:
            raise ServiceHostError("COMPONENT_NOT_READY")
        try:
            registry.enable_migration_writes(
                migration_id=migration_id,
                deployment_epoch=self._migration_deployment_epoch,
                readiness_sha256=readiness_sha256,
            )
        except MigrationGateError as exc:
            raise ServiceHostError(exc.code) from None
