# ARB04 R279 selected source scope (2026-10-17)

No test or Host was run for the source correction. Relative to the R3 fixed-source execution, only the final read-only oracle in `test_arb04_unknown_late_fill_explicit_query_resolves_original_hold_once` changed: the provider database has no `provider_cancel_dispatches` table, and the coordinator wire ledger above already asserts no cancel RPC ran. The R3 execution used the original invalid oracle and remains a failed pytest result.

The selected HEAD-based candidate patch contains exactly three test/fixture paths at captured HEAD `394eacc58e2c61769e0c9b807284f6468137c8af`:

- `tests/integration/test_arb04_group_cancel_reply_loss_service.py` (`bbf718f8de2e9a23c541721bf0b764a860c6d588`): adds the duplicate-fill and positive late-fill focused nodes; R3-to-candidate delta is only the final oracle correction. R3 source `56829` bytes / `B250E5C99E2BEC61CEA7B2028FAA8A987568E4FEC042153A5C23EE7FAEC710AC`; candidate `56885` bytes / `25560B99246B2FBA539153C777A0AEA0D3640C9A9934F8026BDF273F5FBDDC55`.
- `tests/integration/_arb04_group_reply_loss_support.py` (`ee56be944aa875d29e88a646572c64263c3ee848`): bounded socket-disconnect fault, wire/source stats and test-owned child lifecycle evidence. R3 and candidate are byte-identical, `59890` bytes / `D64EACE191EF103688FD3099F7D53D222E3DA7DE0B84AE40631D594C7AA63F94`.
- `tests/integration/test_arb03_dim05_group_partial_fill_service.py` (`ca3af195cd45f2ffdc75666a78eface1184a465c`): opt-in test-only synthetic plugin discovery and bounded startup/close facts; default legacy fixture behavior remains. R3 and candidate are byte-identical, `107998` bytes / `55872460AAB594970D198ADA57234CA5AD0A522B742B09D695FC7F78FEB4BB70`.

No production module or threshold changes are included. HEAD-based patch: `D:\bt_api_py\.codex-tmp\arb04-r279-selected-source.patch` (`77294` bytes / `699BBABC4897339FCD5757EC7EF315517EECA37BF2FAF46EF88FFFF3830DEEA5`). Exact R3-to-candidate correction: `D:\bt_api_py\.codex-tmp\arb04-r279-r3-oracle-correction.patch` (`751` bytes / `E23AB134AF5521BD7CEDF681B8784DF679BAC0217EE83D16492239540D5F502B`). Source pins: `D:\bt_api_py\.codex-tmp\arb04-r279-source-manifest-20261017.json`. The files are not staged.

R3's original failure and raw output stay unchanged. R2 duplicate-fill and R8 socket-disconnect pytest results also remain failures; read-only SQLite sidecars supplement only the persisted facts they actually observe. This preparation does not edit the formal tracker or index.
