from __future__ import annotations

import builtins
import contextlib
import hashlib
import importlib
import importlib.util
import io
import json
import os
import platform
import sys
from pathlib import Path


QA_ROOT = Path(__file__).resolve().parent
EXECUTION_ROOT = QA_ROOT / "execution"
BASE_ROOT = QA_ROOT / "base"
TEST_FILE = EXECUTION_ROOT / "tests" / "test_ctp_callback_session_router.py"
TEST_NODES = (
    f"{TEST_FILE}::test_store_reads_scoped_durable_ctp_trade_facts_without_mutation",
    f"{TEST_FILE}::test_store_rejects_inconsistent_durable_ctp_trade_readback",
)
EXECUTION_HEAD = "456eb3ce9a49fa8924a6f908d1a4e336e7120ce8"
BASE_HEAD = "fb47f3dd733613494aa1d86cfd94b2d6fe70314d"
RUN_ID = "r4"


def _candidate_pins() -> list[dict[str, object]]:
    pins = []
    for relative in (
        Path("src/bt_api_execution/store.py"),
        Path("src/bt_api_execution/__init__.py"),
        Path("tests/test_ctp_callback_session_router.py"),
    ):
        source_path = EXECUTION_ROOT / relative
        data = source_path.read_bytes()
        pins.append(
            {
                "path": str(source_path),
                "bytes": len(data),
                "sha256": hashlib.sha256(data).hexdigest(),
            }
        )
    return pins


def _module_is_forbidden(name: str) -> bool:
    root = name.split(".", 1)[0]
    return root in {"bt_api_ctp", "socket", "subprocess"}


def main() -> int:
    os.environ["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"
    node_name = platform.node()

    # Import the test runner before guarding candidate imports. It is harness
    # setup; all candidate/test imports occur only after the guards below.
    import pytest

    candidate_inputs_before = _candidate_pins()
    sys.path[:0] = [
        str(EXECUTION_ROOT / "src"),
        str(BASE_ROOT / "src"),
    ]
    original_import = builtins.__import__
    original_import_module = importlib.import_module
    blocked_attempts: list[str] = []

    def guarded_import(name, globals=None, locals=None, fromlist=(), level=0):
        effective_name = name
        if level and globals and globals.get("__package__"):
            try:
                effective_name = importlib.util.resolve_name(
                    "." * level + name,
                    globals["__package__"],
                )
            except (ImportError, ValueError):
                effective_name = name
        if _module_is_forbidden(effective_name):
            blocked_attempts.append(effective_name)
            raise AssertionError(f"guarded import rejected: {effective_name}")
        return original_import(name, globals, locals, fromlist, level)

    def guarded_import_module(name, package=None):
        effective_name = name
        if name.startswith(".") and package:
            effective_name = importlib.util.resolve_name(name, package)
        if _module_is_forbidden(effective_name):
            blocked_attempts.append(effective_name)
            raise AssertionError(f"guarded import_module rejected: {effective_name}")
        return original_import_module(name, package)

    builtins.__import__ = guarded_import
    importlib.import_module = guarded_import_module
    output = io.StringIO()
    pytest_exit = 2
    module_origins: dict[str, str | None] = {}
    try:
        with contextlib.redirect_stdout(output), contextlib.redirect_stderr(output):
            pytest_exit = int(
                pytest.main(
                    [
                        "-q",
                        "-s",
                        "-c",
                        str(QA_ROOT / "pytest.ini"),
                        "-p",
                        "no:debugging",
                        "-p",
                        "no:cacheprovider",
                        *TEST_NODES,
                    ]
                )
            )
    finally:
        builtins.__import__ = original_import
        importlib.import_module = original_import_module

    for name in (
        "bt_api_execution",
        "bt_api_execution.store",
        "bt_api_execution.service_order_entry",
    ):
        module = sys.modules.get(name)
        module_origins[name] = getattr(module, "__file__", None)

    candidate_inputs_after = _candidate_pins()

    test_output = output.getvalue()
    raw_output_path = QA_ROOT / f"{RUN_ID}_raw_output.txt"
    raw_output_path.write_text(test_output, encoding="utf-8")
    result = {
        "status": "PASS_FOCUSED_DURABLE_CTP_TRADE_FACT_READBACK"
        if pytest_exit == 0
        and not blocked_attempts
        and candidate_inputs_before == candidate_inputs_after
        else "FAIL_FOCUSED_DURABLE_CTP_TRADE_FACT_READBACK",
        "python_executable": sys.executable,
        "platform_node_pre_guard": node_name,
        "execution_head": EXECUTION_HEAD,
        "base_head": BASE_HEAD,
        "pytest_nodes": [str(node) for node in TEST_NODES],
        "pytest_args": [
            "-q",
            "-s",
            "-c",
            str(QA_ROOT / "pytest.ini"),
            "-p",
            "no:debugging",
            "-p",
            "no:cacheprovider",
            *TEST_NODES,
        ],
        "candidate_input_pins_before": candidate_inputs_before,
        "candidate_input_pins_after": candidate_inputs_after,
        "module_origins": module_origins,
        "guarded_import_attempts": blocked_attempts,
        "pytest_exit_code": pytest_exit,
        "raw_output_path": str(raw_output_path),
        "evidence_scope": "committed_execution_and_base_export_plus_three_candidate_overlays",
    }
    (QA_ROOT / f"{RUN_ID}_result.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(result, sort_keys=True))
    return 0 if result["status"].startswith("PASS_") else 1


if __name__ == "__main__":
    raise SystemExit(main())
