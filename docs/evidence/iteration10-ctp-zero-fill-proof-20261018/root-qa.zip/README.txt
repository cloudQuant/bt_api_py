Iteration 10 CTP zero-fill reader evidence package

This package contains the raw public metadata for the single R1 and single R3 Root test invocations, their source/export recipes, and the selected source delta. It intentionally excludes pytest-tmp SQLite databases and all private inputs. R1's reader run had one failing selector; R3 reran that selector and added the monotonic-clock-domain regression. The three journal cases in R1 are historical support already accepted and committed separately; they are not counted as new work here.

Evidence level: LOCAL_SYNTHETIC_CTP_QUERY_AND_ZERO_FILL_CUTOVER_ONLY. No native CTP extension, live SimNow session, account operation, or formal acceptance is established. The expected fixed-source CTP extension fallback warning is retained in both stdout logs. No timing/cause conclusion is asserted.
