﻿# 迭代10开发与验收进度

更新日期：2026-10-16。工作范围以[正式迭代计划](正式迭代计划.md)为准；文档审查完成不代表运行验收通过。

## 当前状态

已提交公共合同、本机认证通信、注册表和客户端代理，并完成共享行情、账户读取、受管订单与撤单、Monitor 日志及 Backtrader/AFI 的部分真实本机服务集成。截止第241轮，当前正式通过40/68；DIM06 本地合同/故障验收、MIG04 固定 Binance 发行组合均已正式通过，MIG03 写尝试屏障及 map importer 已完成本机组件验收；完整名单及当前证据见[验收状态汇总](迭代10验收状态汇总.md)。DIST01、DIST02 与 ARB05 的真实双机场景按既定范围暂缓，其余仍按正式条款验收；以下历史轮次保留当时范围和结论。

## 第01轮：公共配置和中立通信合同

范围：在现有 `dev` 工作区交付 base 中立 wire v2 DTO/codec/transport Protocol，SDK 纯配置解析、显式有界 YAML 加载与离线命令、五份示例，以及默认 import 对旧 ZMQ 导出的延迟加载。策略配置不创建四个领域组件。

| 仓库 / 分支 | 交付 | 提交 |
|---|---|---|
| bt_api_base / dev | service_protocol.py、对应13项契约测试 | `822db9337bbe9b03bd6ee22981b0b421dbe23000` |
| bt_api_py / dev | SDK配置/CLI/示例/测试、上述gitlink、计划角色登记和本进度 | 随本记录提交；以本文件的 Git 提交历史查询实际 SHA |

SDK 接口为 `parse_client_config`、`parse_service_config`、`load_client_config`、`load_service_config`。结果只可通过解析器构造，内部映射递归冻结，对外返回独立字典及规范化指纹。配置值和未知字段名不进入错误文本。角色、挂载槽、组件端口、配置版本、引用语法、可选只读与必需写能力、账户槽与跨挂载账户一致性、内部组件引用、当前服务自连接、等价 IP bind 冲突均做离线校验。

```text
python -m bt_api_py.service_config_io --role client examples/services/unconfigured-client.yaml
python -m bt_api_py.service_config_io --role service examples/services/account-service.yaml
```

命令成功只返回 `activated: false` 的校验摘要。示例里的身份、政策和服务引用仍需部署时验证；本轮不会解析私密材料、连接账户或启动服务。`{}` 和 `clients: {}` 可保持零能力配置。

Wire v2 使用有界严格 JSON，拒绝重复键、非有限数和非法结构，递归冻结 payload。身份和 scope 始终是待认证的声明；reply 绑定 request 的 correlation、operation、scope 和 owner epoch，可额外绑定可信 peer。事件包含 stream/epoch/sequence。此模块没有导入领域组件或 ZMQ；现有 v1 协议保持独立。

### 已完成检查与证据边界

| 检查 | 结果 | 能证明什么 |
|---|---|---|
| base focused pytest | 13 passed | DTO/codec/消息绑定、错误合同、中立依赖边界的源代码行为 |
| SDK parser + YAML/CLI focused pytest | 70 passed | 52项纯解析回归、18项文件/CLI/冷启动导入检查 |
| 原有 light-import 回归 | 2 passed | 受影响的现有轻导入与延迟导出行为保持 |
| 原有公开 ForwardingClient/GatewayClient 导出检查 | passed | 显式请求旧导出仍解析为原类；不等于旧模块退役 |
| Ruff check / format | passed | 本轮新增或修改的 Python 文件 |
| 独立源代码审查 | 四项配置问题修复后复核 | 不代替运行时或真实账户验收 |

测试使用当前 Python 3.11.5，针对同步测试运行 `pytest -p no:asyncio`。安装的 pytest 8.0.0 与 pytest-asyncio 0.23.0 在启用插件时有 collection 兼容故障；禁用插件后每次 focused 运行仍保留一条已知 `asyncio_default_fixture_loop_scope` 未识别配置警告。不声称 async 测试环境或全仓测试通过。

第一次 YAML 集成检查恰逢作者修改配置对象构造器，得到 6 failed / 12 passed；该中间态未验收。作者完成并固定代码后，最终 70 项组合检查全部通过。已有通过的 base 13 项、light-import 2 项不为交付重复运行。

本轮的 CLI 与 import 检查确实创建了本地 Python 子进程，但没有运行服务 socket、跨机链路或 provider。冷导入检查禁止尝试加载四个领域包及 ZMQ；这不是干净环境 wheel 安装验收，MIG04 仍待依赖拆分和真实安装验证。

### 第01轮后的待办（进展见后续轮次）

1. 以当前合同建立 SDK 服务装配/客户端代理，四包仅在服务端按需加载；增加完整部署图校验，拒绝跨服务 A→B→A，校验作用域引用与远端就绪。当前单文件解析只识别自身回环。
2. 接通 ZMQ v2 的身份认证、注册/租约、动作授权和可信 principal 绑定，不能用配置解析对象或 wire 声明当授权。实际 bind 冲突还需在启动资源获取时清理失败项，离线 IP 规范化不做 DNS 解析。
3. 可靠事件恢复连接既有 journal/outbox 与游标/ACK 合同。当前 `EventSubscriber` 明确无持久 ACK；transport message_id 不代替业务幂等键。
4. 补充 wire 深度64/65边界测试，在对应代码有变更时继续验证；当前已实现64层限制，不以未覆盖边界声称完整极限验收。
5. 再按计划完成四包角色、Backtrader v6 映射、AFI接入、旧转发退役、隔离安装、负载、真实双机及授权 venue 验收。现有受约束入口和历史证据保持原有含义。

## AFI 工作区恢复记录

用户确认新 clone 不应有大量暂存删除，并授权与远程对比修复、保留新增功能。实时远程 HEAD/master/dev 与本地 HEAD 均为 `0203154fa7cb831f45b5213fa3666a3983198e7d`。实际问题是 `.git/index` 缺失；3个未检出的远程文档路径达到260/261字符，Git 报 Filename too long。这支持 Windows checkout 长路径失败的解释，但不能据此归因给某个代理。

Root 记录修复前文件摘要和 Git 元数据，从 HEAD 重建索引，设置本仓库 `core.longpaths=true`，只恢复3个缺失的远程文档，创建并切到跟踪 origin/dev 的本地 dev（HEAD不变）。修复前所有现存相关文件逐字节校验保持一致；新增的 Windows 启停控制器及文档保留为6项修改和3个新增，暂存区为空。

恢复记录、差异补丁与9个本地改动文件的 ZIP 备份位于 AFI 的 `.git/codex-recovery/20261013T144240Z/`。未启动或停止 AFI 服务，未提交这9个未验收改动。只读审查发现旧 PID 文件的进程归属校验不足，后续启停功能验收须先修复，避免误停其他 checkout 的后端；此问题与本轮 Git 索引恢复分别记录。

## 第02轮：认证通信、注册表和 SDK 代理

本轮在现有 dev 中接通“解析配置 → 部署图检查 → CURVE 认证 → 服务注册 → 受权 RPC → 续租/注销”。领域组件的真实装配是下一轮；本轮集成使用实际子进程、socket、ZAP、SQLite 和合成账户读取处理器。

### 交付内容

- `service_deployment.validate_deployment`：离线检查跨服务依赖环、目标实例/端口、账户写入口冲突和 RPC/行情双端点匹配，输出冻结的启动顺序。market 配置现在同时需要 RPC 控制端点与行情端点。
- `service_registry.ServiceRegistry`：可信 principal 与 wire 身份逐项匹配、scope/动作授权、SQLite 幂等注册、租约、重启 epoch、数据库进程持有锁、同一策略/账户的单活写会话。注销和租约结束只处理登记，不修改交易账本。多账户声明先整体检查后整体写入。
- `service_runtime.ServiceClientRuntime`：按配置选择代码登记的代理动作，查询远端能力、申请注册、精确选择账户、显式续租和关闭。必需依赖失败回收本轮登记，可选遥测/监控控制失败报告降级；监控查询能力可以继续使用。回执校验失败也回收已取得的注册句柄，注销回执不完整会计入清理失败。
- `ZmqServiceClient/Server`：所有 TCP（含 loopback）强制 CURVE/ZAP，授权身份取自认证帧的 User-Id。回复用该认证客户端公钥进行 libsodium SealedBox 加密，防止断线后不同密钥复用 ROUTER ID 读取原回复；版本前缀和 48 字节加密开销计入帧限额，不接受明文降级。
- 消息接收限制帧数并分批丢弃多余帧；断线目标、队列满和无法容纳的错误回复不会导致重复业务派发。已发送请求超时或回复失配返回 UNKNOWN，退役该连接；连接内最多记录4096个请求 ID，拒绝重复 ID。确定未排队的请求返回 NOT_SENT，允许调用者显式再次请求；传输层均不自动重试。

处理器异常或非可信错误回执不证明业务没有副作用，SDK 对此返回 BUSINESS_OUTCOME_UNKNOWN。业务作用域和 transport ID 分开：未知订单结果仍需使用业务订单/幂等键向领域服务核对，不能仅换一个 message_id 再下单。注册成功也不代表策略恢复完数据基线或可以交易。

### 检查结果

| 检查 | 最终结果 | 边界 |
|---|---|---|
| SDK 配置、部署图、YAML/CLI | 90 passed | 包括三类 market 配置同时要求 RPC/行情端点 |
| 注册表 | 13 passed | 持久注册、重启、竞争写会话、角色与作用域拒绝 |
| SDK 代理 | 14 passed | 包含真实 spawn 子进程 CURVE 注册/读取/续租/注销，服务端拒绝伪造身份/错账户/未授予动作 |
| transport 完整包 | 30 passed | 包括旧 v1 回归、真实 CURVE ACL、生产服务路由复用尝试与接收者隔离、帧限额和 UNKNOWN/NOT_SENT |
| Ruff check / format | passed | 本轮 Python 源码与测试 |
| 独立源码审查 | 已修复具体问题 | 不代替真实账户、跨机器或完整计划验收 |

SDK pytest 保留一条已有的未知 asyncio 配置警告；transport 在 Windows 上使用 pyzmq/Tornado 的 selector 辅助线程，保留17条 Proactor 兼容警告。未更改机器全局事件循环策略。初次运行发现 transport 包未安装，修正测试进程的明确源码搜索路径后执行以上检查；这证明本地组件集成，不证明 wheel 干净安装。

### 第02轮结束时尚未完成的合同（后续进展见第03轮）

1. 服务端代码登记的四包工厂、纯参数校验、启动/停止顺序和真实领域处理器接入；当前不把合成 account.snapshot 称为真实 Gateway 读取。
2. 行情发布/订阅与可靠私有事件 journal/read_after/ACK/重放；当前市场端点只被校验，尚未被客户端代理用于流式订阅。
3. 领域订单账本、risk reservation、最终派发的 owner fencing 和业务幂等；当前注册锁仅管本数据库实例。service 角色的 portfolio 写、application/service 伪装策略写明确拒绝，待受信协调代际/委托路径落地后再开放，REG04 仍未完成。
4. 客户端当前显式 renew；后续服务宿主/Backtrader 生命周期须接管心跳、失联冻结、恢复与数据基线。
5. 四包角色深化、Backtrader/AFI 接入、旧转发退役、发行安装、100策略负载、真正双机和各 venue 指定验收仍按正式计划完成。完整68项用例尚未增加 PASS，不能用本轮单元数量替代。

本轮没有启动交易所连接、发单、读取私密账户输入或操作历史保留进程。AFI 原有9个新增功能文件再次与恢复备份逐字节核对一致，仍在 dev、暂存区为空。

| 仓库 / 分支 | 本轮提交 |
|---|---|
| bt_api_transport_zmq / dev | `3834c511ee66ab841e0957b6a0e75104cd8f0df9` |
| bt_api_py / dev | 随本记录提交；以本文件 Git 历史查询 SHA |

## 第03轮：真实领域读取与服务宿主

本轮把现有持久化领域接口接到固定服务工厂。策略和应用进程使用 SDK 代理，四个领域包只在服务端被选中时导入。服务清单不能指定 Python 模块或工厂；部署方通过可信代码提供身份、CURVE 密钥、ACL、作用域及资源对象。

### 已提交的领域接口

| 子包 / dev 提交 | 实际能力 | 证据与限制 |
|---|---|---|
| gateway / `d59bccc615797a1306a7e5339939cd8590e60a9e` | `account.read_after`、`account.snapshot`、`account.head` 使用现有 GatewayEventJournal 与 GatewayPrincipal ACL | 24项组件检查通过；持久策略流读取，不代表 provider 共享会话或行情已接通 |
| execution / `d2b51f4895b99b0a9b180d0d33aeedd02d67c55f` | `orders.query` 按明确 WireScope 到 ExecutionScope 的映射查询现有订单 | 24项新组件检查通过；保留 UNKNOWN；没有开放提交、撤单或订单组 |
| risk / `a5c45a3c5f77453eab022965462d1da2fdaa4157` | `risk.snapshot` 读取现有 DurableRiskGate 的预留/冻结/政策快照 | 24项组件检查通过；snapshot 按既有接口可能更新过期预留，不是物理数据库只读，也不是组合估值或完整账户风险 |
| monitor / `eee98cc546c2f180dbdc2d4b90ceb4b3b37890e8` | `monitor.query`、`monitor.read_after` 使用只读 DurableOutbox 的有序多类型分页 | 13项组件检查通过；返回 requested_cursor/next_cursor/has_more，不把当前页末尾冒充全局 head，不修改消费者 checkpoint |

以上适配器借用资源，显式授权映射之外的账户、策略、执行域或组合不会被猜测、扩展或聚合。具有明确 strategy 的模板可接受该策略不同 run_id；Gateway 仍读取同一持久策略流，不能据此声称日志按 run 隔离。账户范围读取需要显式目标，当前各适配器的组合/人工 book 支持范围不同，尚不代表 AFI 全部视图可用。

Monitor 包改为延迟加载公开导出；原有95个名字及其定义模块逐项与提交前比较一致。冷导入组件校验器不启动采集、线程或日志输出。Gateway/Execution/Risk/Monitor 的 pure options 校验与 SDK schema 对齐，但接受某个角色的配置不代表该角色的全部动作已经实现。宿主只发布实际 handler 能力，未实现的公开端口拒绝启动。

### 宿主装配与本轮验收状态

SDK 的 `ServiceHost` / `TrustedServiceAuthority` 与 `ComponentResources` 已接通。宿主构造不打开文件或连接；启动先完成引用、所有选中组件、ACL/capability 关系及 ZMQ endpoint/CURVE keypair 的纯校验，再按依赖获取资源、创建未就绪注册表、登记处理器并绑定认证监听，最后声明就绪。端口只声明实际实现的动作；Risk 的操作集从其实际类属性读取，不依赖不存在的模块常量。

就绪状态在等待请求前和实际派发前重新检查，未就绪时拒绝业务调用及新增/续期登记，仍允许发现和注销。清理先停止对外就绪和监听，再逆序释放本宿主拥有的组件，最后关闭注册表；借用资源保持调用方所有。关闭失败保留资源和 `close_failed` 状态，后续显式 close 只重试未完成项。owned 资源的关闭回调必须可安全重试。

Transport 服务端按 authenticator → socket → context 关闭，依赖资源关闭失败时不继续阻塞式 context.term；部分关闭后禁止继续请求或服务。服务端构造失败且清理失败用 `ServiceTransportStartupCleanupError.transport` 将部分实例交给宿主，包含启动期间中断的清理分支。注册表的对应异常携带 `.registry`；数据库和锁文件关闭成功后才清引用，锁文件已关闭后抛错也可完成下一次清理。正常启动异常在清理成功后仍传播，不伪装启动成功。

出站服务 clients 暂时只做完整部署图检查，然后明确拒绝未接通的运行装配；不会忽略配置。可信资源提供器仍由部署方代码实现，本轮没有提供通用私密配置加载器或部署 CLI。现有 account-service.yaml 是完整目标配置的离线样例，其中的交易写端口尚不能由本轮读取宿主启动。

### 最终检查和交付

| 检查 | 结果 | 证据边界 |
|---|---|---|
| 四包新增读取适配器 | gateway 24、execution 24、risk 24、monitor 13 项通过 | 真实本地 SQLite 与合成数据；并非 provider/账户验收 |
| SDK 宿主 + 注册表 + 跨进程集成 | 31 passed | 15项宿主、15项注册表及1项真实 Windows spawn/CURVE 集成；覆盖启动/关闭失败接管与重试 |
| Transport 本轮定向回归 | 9 passed；随后启动中断两参数 2 passed，含1个重叠用例 | 覆盖纯校验、阶段关闭失败、线程所有权、真实 CURVE、UNKNOWN/连接退役；没有重跑或宣称整包通过 |
| Ruff check / format | passed | 本轮源码和测试；集成测试的最终格式整理保持 AST 不变 |
| 独立只读审查 | 所发现的具体装配、预检和关闭问题已修复 | 最后关闭边界由 Root 检查修复代码并执行上述故障回归；不声称额外独立测试 |

跨进程用例实际启动独立服务进程，经 SDK strategy/application 代理注册后分别读取 Gateway 持久事件、Risk 预留快照、Execution 已有订单和 Monitor 事件，验证错账户与未授予发单动作被拒绝。Gateway/Monitor/Execution 业务行前后保持一致，Risk 的已存在预留快照一致；客户端注销、服务资源关闭和子进程正常退出均有断言。测试进程安装了源码路径并加载领域包准备合成数据，因此这不是 CFG04/MIG04 的无四包客户端安装证据，也不是跨机器证据。

SDK 最终批次保留5条既有环境警告（1条 pytest 配置、4条 Windows Proactor/selector）；transport 定向批次保留5条同类 Windows 警告，启动异常增补无警告。没有修改全局事件循环策略、运行交易所连接、读取真实账户或操作历史保留进程。初次跨包组合遇到的 Risk 能力查找错误已修复，失败的中间结果不计通过。

AFI 恢复后再次独立只读复核：远程 HEAD/master/dev 与本地提交一致，7437个跟踪文件无删除，9个现有功能文件与恢复ZIP逐字节一致，暂存区为空；AFI 这9项既有功能尚未进行运行验收或提交。

| 仓库 / 分支 | 本轮后续提交 |
|---|---|
| bt_api_transport_zmq / dev | `7cd77fa5339f60ec141e748499c63a7f6093de3c` |
| bt_api_py / dev | 宿主、注册表修复、测试、五个gitlink与本进度随本记录提交；以本文件 Git 历史查询 SHA |

下一轮继续服务出站代理/生命周期与共享读取生产者的正常路径，再按正式计划接入 Backtrader/AFI。当前不把只读适配器称为四包全部功能完成，也不恢复 Optional16。68项完整计划用例尚未新增正式 PASS。

## 第04轮：服务间代理和租约生命周期

本轮延续 P1/P2 的真实使用路径：服务清单的 `clients` 由 SDK 宿主装配，服务以自己的可信身份注册上游，领域资源提供器通过 `host.upstream` 使用代理。部署图、服务身份、组件和传输参数仍先校验；YAML 不提供模块名或工厂代码。没有 clients 的服务不创建上游代理。

客户端在 socket 所属线程维护租约，提供 `maintain()`、`next_maintenance_delay()`、`healthy` 和显式 `recover()`；宿主在服务循环中维护并限制轮询等待时间。必要上游失败撤回业务就绪，可选遥测或监控控制失败保留降级信息。显式恢复申请新的登记会话，保留策略 run 和业务 ID；不自动重发业务请求，不切换 direct，不把重新登记当作账户或行情基线已经恢复。

租约回执新增 `lease_remaining_seconds`，重复登记返回真实剩余时间。客户端以请求开始时的本地单调时间保守计算可用期限，不拿远端 `expires_at` 与本机 UTC 直接比较；旧服务缺少该字段时明确拒绝。续期必须核对原登记、服务 epoch、能力及政策版本，过晚回复不能恢复已过期的本地租约。服务端目前仍使用自身时钟执行租约过期；本轮不声称已经验证服务端壁钟跳变，订单持久期限和账户 writer fencing 也不是登记租约的替代物。

远端登记结果未知、本地连接关闭、远端注销确认分别记录。丢失登记或续期回复时，不用请求超时推算远端已经释放；可保留未知计数供后续处理。关闭失败保留本地 transport，显式 close 只重试尚未释放的资源。宿主先停止监听，再释放依赖上游的组件，最后关闭上游代理和注册表。

### 通信子包已接受的小提交

`bt_api_transport_zmq/dev` 提交 `251df83907af70f12b33d1e4fd363d501d7c3279`：client 构造和 socket 初始化在获取资源后立即保存所有权，启动失败或中断时按 socket、context 顺序清理。清理失败通过既有 `ServiceTransportStartupCleanupError.transport` 返回原部分实例；成功清理后仍传播原启动异常。未完成清理的实例不能继续请求。

Root 的6项定向检查通过：部分启动清理、关闭重试、线程归属、真实 CURVE 请求、确定未发送后显式调用，以及未知超时后的连接退役。保留3条既有 Windows Proactor/selector 警告；Ruff check/format 和 diff 检查通过。该提交只含 transport 源码及其定向测试，没有重跑整包或 provider 验收。

### 最终检查和交付

Root 对冻结源码运行 SDK runtime、registry、host、既有四包读取集成和新增双服务集成，结果为 **73 passed、9 warnings、48.09秒**。其中 runtime/registry 合计50项、host 21项、真实 spawn 集成2项。警告为1条已有 pytest 配置警告和8条 Windows Proactor/selector 兼容警告；没有改变全局事件循环策略。

双服务集成实际执行：Gateway SQLite 事件经上游 ServiceHost、CURVE RPC 和下游 `host.upstream` 进入 Monitor 的 DurableOutbox，再由 application 代理读取。跨过默认30秒租期后仍可使用，上游退出时下游撤回就绪并停止生产，显式重启/重新登记后按原事件 ID 补读，所有新建进程正常退出。该用例用时40.23秒。

独立源码审查指出的未知登记、关闭中断及恢复空会话仍显示健康问题已修复。Root 还核对续期回执的登记/epoch/权限/政策绑定、旧本地期限、畸形拒绝/注销回执，以及明确 NOT_SENT 与 UNKNOWN 的区分；对应回归包含在上述73项。ZMQ 工厂只在显式激活时导入后端，将精确的未发送异常转换为 SDK 中性异常，不按异常文本猜测状态。

Ruff lint 和最终格式检查通过。Root 最终格式检查发现 runtime 及其测试的两处文件仍需整理，随后只做格式修改并逐文件确认 AST 不变；没有为格式交付重复已通过的功能测试。diff 检查通过，本文继续使用 UTF-8 BOM/LF，未出现替换字符或乱码。

| 仓库 / 分支 | 本轮提交 |
|---|---|
| bt_api_transport_zmq / dev | `251df83907af70f12b33d1e4fd363d501d7c3279`，仅源码和定向测试2文件 |
| bt_api_py / dev | 宿主、runtime、registry、4份测试、transport gitlink及本记录随本轮提交；以本文件 Git 历史查询 SHA |

本轮没有运行交易所/provider、读取真实账户输入或操作历史保留进程。四个领域子包、Backtrader 和 AFI 未修改。全部正式68项仍按完整行为逐项验收，不以本轮73项检查数量替代。

该合成生产者只用于验证宿主和代理装配：源 cursor 暂保存在进程内，事件去重由既有 outbox 完成，没有实现生产者崩溃后的事务化 cursor/ACK、完整账户基线恢复或正式监控规则。因此不能把这个用例记作 GW03、MON01、REG03 全项通过，也不能由本机两个进程推导 DIST01 双机通过。业务基线就绪仍由资源提供器的 readiness 决定，登记健康只是其中一个条件。

### 下一条功能链路

Gateway 的现有 journal 和读取 adapter 还不生产 provider 数据，新的行情发布/接收端也尚未接通。后续优先完成公共行情 hub 的订阅去重、首订阅建立/末订阅释放、权限域隔离及有界 PUB/SUB，再接账户 session worker 和快照增量。复用现有 journal，不建立第二套订单归属账本。

Backtrader 的最小正常接入点是 `BtApiStore(api=...)` 的 provider 接口，经 Store 供 Broker/Feed 使用；须先补齐余额/持仓与行情合同。不要把 `orders.query` 当作账户快照，也不要仅为接入而从策略入口导入四包。`provider="btapi"` 且代理暴露 `poll_event` 会进入现有 SDK event 模式，适配时必须遵循其完整合同。默认无服务配置路径继续保留。


## 第05轮：共享行情生产与接收

本轮接通 P2/P3 的公共行情路径：完整合约/订阅键、Gateway 上游引用管理与有界重放、认证 PUB/SUB、SDK 行情客户端及宿主装配。RPC 控制与广播数据各自使用已配置的端点；策略不导入 Gateway 包。账户私有事实仍走逐请求鉴权读取，不能放入这个公共广播端点。

### 已接受的基础合同

`bt_api_base/dev` 提交 `801dabf6a50c1c0a6466774b1af1ce0b608cec7d`，版本 `0.15.6`。`MarketInstrumentKey` 记录 provider、venue、环境、产品类型、规范合约 ID 和原生 symbol；`MarketSubscriptionKey` 加上源、权限集合、频道、深度和周期，生成稳定 stream_id。严格 JSON 形状、不可变性、各维度不混淆、独立进程身份一致和冷导入边界共23项通过；保留1条已有 pytest 配置警告。Ruff lint/format 与 diff 检查通过。该提交仅包含新模块、测试与两处版本声明。

注册表新增 owner 侧 `active_registration_ids(instance_id=...)`，宿主可在没有客户端请求时按权威租约清理订阅引用。续期和注销立即反映在该集合中；临时 unready 不自行撤销登记，读取失败不伪装成空集合；到期不会删除交易 writer 的持久归属。本轮3项定向回归通过。最初关闭后异常类型断言与既有 SQLite 事务 API 不符，已修正为其实际的 ProgrammingError；未修改既有关闭语义。

### 行情合同边界

同一个 PUB 端点只接纳被可信部署授权读取该端点全部行情的 principal，不能依赖 topic 过滤来防止越权。广播数据权限与登记租约分开：租约管理上游引用；撤销数据权限需要受控关闭旧发布端、按新准入表重建连接。新组件以 Gateway 的可信 key universe 检查广播内容和受众。

PUB 的本地发送返回不是接收确认；慢订阅者可能丢数据，详见 [libzmq PUB/SUB 语义](https://libzmq.readthedocs.io/en/latest/zmq_socket.html)。SDK 需要通过 sequence、epoch、RPC head 与有界 read_after 检查和补读；超出窗口明确要求重同步。Gateway 当前 `snapshot_kind=latest_event, complete=false`，不代表完整盘口。首次加入新流与已有流断线恢复是不同操作，不能用最后一条数据掩盖中间缺口。

各层的实际检查及交付结果见下文；单项源码检查不替代完整计划用例。


### 已接受的行情通信实现

`bt_api_transport_zmq/dev` 提交 `2419d24c7fc507ca77e323d6ed2d13f65e8a1907`，仅新增 `market_v2.py`、对应测试并把 base 下限提升到0.15.6。`ZmqMarketPublisher` 与 `ZmqMarketSubscriber` 实现中立 EventPublisher/EventSubscriber 端口，保持 owner 线程的创建、调用、关闭与失败清理；显式 ZMQ 工厂负责选择实现。发布者仅接受公共 service scope 和严格的 market event，接收者绑定可信 peer、scope、完整订阅键和 stream_id。

Root 的14项新模块检查通过（6条既有 Windows Proactor/selector 警告），覆盖真实 loopback CURVE 收发、未授权 key 不收数据、关闭后按新受众表在原端点重建并拒绝旧 key、畸形/超长/多帧输入，以及启动/关闭失败的资源保留。Ruff lint/format 与 diff 检查通过。独立源码检查未发现资源清理阻塞项；受众授权按上节的整个端点合同由可信 Gateway/宿主校验，不能仅凭传输类证明跨订阅键权限或数据连续性。

### 已接受的 Gateway 共享订阅

`bt_api_gateway/dev` 提交 `6f2960114c27378674b27e6a069bd04f0e0c837c`，仅新增 `market_hub.py`、定向测试与 base 版本下限。上游按完整订阅键计数，首登记建立、末登记释放；引用来自注册表确认的 registration_id，不由业务 payload 声明。释放返回 False 或抛错时保留句柄供幂等重试，不能把结果未知的旧句柄继续当作有效数据源。

每次实际获取上游时传入新的 source generation，provider 回调必须带回该 token；旧 token 在序号递增、重放缓存和 PUB 之前被拒绝。正常释放后再次订阅会更新 wire epoch 并清除旧缓存。仍持有同一上游时显式 `reset_stream_epoch` 只切换 wire epoch；provider 必须先排空、标记或丢弃重连前的原生队列事件，不能把该 API 当作原生队列清理。

Root 对最终修复运行14项定向检查，全部通过、无警告；独立只读审查未发现阻塞项。测试覆盖首末订阅、失败后释放重试、旧 token 拒绝、显式换代、范围授权、窗口缺口和重放容量界限。Ruff lint/format、diff 检查通过；未为提交重复整包检查。

### SDK 和宿主使用方式

服务端选择 `gateway` 的 `market_hub` 角色，监听 profile 同时配置 `rpc_bind` 与 `market_bind`。可信资源提供器返回 `ComponentResources(values={"hub": hub}, ...)`；宿主在创建监听 socket 前校验 hub 身份、公共作用域、完整 key universe 及端点全部受众权限，并接管发布端和 hub 生命周期。部署配置只引用受控资源，不加载 YAML 指定的任意代码。

策略端配置 `store.market` 绑定和对应 profile 的 `rpc_connect`、`market_connect`。先启动 `ServiceClientRuntime`，再用 `ServiceMarketClient` 及 `ZmqMarketTransportFactory` 建立行情订阅；省略这些配置时不启动该功能。订阅前先建立 SUB，再经 RPC 获取最新事件和 cursor。`poll()` 在同一线程维护租约、检测 head 和补读缺口；应用需持续轮询，不能阻塞 owner 线程超过租期。关闭时先 `market.close()`，再 `runtime.close()`。

PUB 或本地队列缺口通过有界重放恢复；队列同时限制条数与字节。若已缓冲连续前缀，应先排空再显式 `recover()`。同一登记恢复只重建本地 SUB，不释放仍有效的上游引用；登记改变时保留旧注销结果未知。超出重放窗口或权威 stream epoch 改变会要求重同步；应用处理自身状态后显式确认数据损失，仍不声称获得完整盘口基线。

Root 宿主定向检查26项通过，保留11条既有环境警告（1条 pytest 配置、10条 Windows Proactor/selector）。包括无流量租约清理、完整受众预检、发布端关闭失败保留 hub 及显式清理重试；这是本机组件证据。

### 最终检查和交付

| 检查 | 结果 | 证据边界 |
|---|---|---|
| SDK market facade | 8 passed | 实际 SDK runtime/registry 与合成控制和接收叶子；覆盖重放、字节/条数界限、UNKNOWN/NOT_SENT、失败关闭，以及确认新代后忽略旧代迟到帧 |
| 十策略进程共享行情 | passed，37.77秒 | 真实 Windows spawn、CURVE RPC/PUB 和可计数合成 provider；不是交易所数据 |
| 单策略真实进程换代恢复 | passed，2.37秒 | 显式恢复保持上游引用，权威换代保留旧 cursor；未确认前不健康，确认后接收新代 sequence 1 |
| Ruff lint / format / diff | passed | 本轮九份 SDK 源码和测试；子包分别在提交前检查 |

十策略用例建立十个独立登记，全部订阅同一完整 key，观测到上游 starts=1。十方收到相同 epoch/sequence/key/payload；未授权完整 key 不增加上游连接，未列入 CURVE 受众的原始 SUB 收不到广播。一方正常退出后剩余九方继续；另一个本测试新建客户端按预期以23退出、不发注销，经过真实30秒租期只清除它的引用，剩余八方续租并继续收数。最后退出后 stops=1、活动引用/上游归零。其余测试进程正常退出，本轮没有使用 terminate/kill 清理兜底，也没有操作历史保留进程。

首次组合运行得到9项通过、1项失败：8项 SDK 检查和十策略用例通过；换代用例把 PipeConnection 错传给需要 process/pipe record 的测试辅助函数，是测试调用错误。修复该用例所有同类调用后，仅重跑换代用例并通过。没有把失败批次描述成10项全部通过，也没有重跑已通过的十策略测试。

两个实际批次各保留1条已有 pytest 配置警告；子进程使用当前 Windows ZMQ 环境，未改变全局事件循环策略。源码路径安装包含准备服务端合成数据所需的领域包，因此不构成 MIG04 干净 wheel 安装或无四包客户端安装验收。公共行情合同不携带账户身份；同账户策略映射、账户私有会话及正常 Backtrader 策略入口尚未接入，GW01 记录为共享广播与生命周期部分证据，不标完整 PASS。没有进行真实双机、全量盘口或交易所/provider 验收。

| 仓库 / 分支 | 本轮提交 |
|---|---|
| bt_api_base / dev | `801dabf6a50c1c0a6466774b1af1ce0b608cec7d`，4文件 |
| bt_api_transport_zmq / dev | `2419d24c7fc507ca77e323d6ed2d13f65e8a1907`，3文件 |
| bt_api_gateway / dev | `6f2960114c27378674b27e6a069bd04f0e0c837c`，3文件 |
| bt_api_py / dev | 5份源码、4份测试、3个 gitlink、base 依赖下限和本进度，共14路径；以本文件 Git 历史查询本轮 SHA |

ai-for-investor 本轮再次实时比对远程：本地 HEAD、远程 master/dev 同为 `0203154fa7cb831f45b5213fa3666a3983198e7d`，7437个跟踪文件无删除、暂存区为空，恢复前的6项修改和3项新增仍完整保留。没有改动或提交其应用代码。

下一轮按同一链路补账户 session worker 与余额/持仓读取生产者，复用既有 journal 和账户隔离；再接最小正常 Backtrader Store 路径。账户 writer fencing、可靠 ACK、组执行与风险、AFI 正常入口、发行/负载/双机等继续按原计划推进，不能由公共行情用例推导完成。

## 第06轮：共享账户会话与余额、持仓基线

本轮接通 Gateway 账户读取生产者、宿主生命周期和 SDK 账户 facade。服务持有账户会话，多个策略读取同一份原生账户事实；策略注销不关闭会话，服务关闭时才释放。一个策略可以显式登记两个账户，另一个策略共享其中一个。原生账户余额和持仓不代表策略虚拟账、可平量预留或组合预算。

### 已接受的账户数据合同和持久化原语

`bt_api_base/dev` 提交 `962c0f5bc18f86547cf0319f15cd919ed5f8291f`，版本 `0.15.7`，仅包含新账户合同、测试和两处版本声明。`AccountKey` 按 provider、venue、环境和实际账户/子账户确定连接归属，产品和保证金池另以 `AccountResourceKey` 表示。余额、持仓与 provider 估值保留十进制字符串、单位、币种及观察时间；未知值保留 None，不能转换成零。完整观察明确 coverage、余额/持仓完整标志、查询起止时间和 provider_atomic/multi_query 一致性等级。合约身份与账户环境绑定，重复行、缺覆盖、非有限数和超限负载均拒绝。

Root 对账户合同35项检查通过，保留1条既有 pytest 配置警告；Ruff lint/format 与 diff 检查通过。没有为提交重复已通过的检查。

`bt_api_gateway/dev` 提交 `0a144afe200e1efe73590b23d14891da6e164377`，仅含 journal 修改和新状态流测试。`replace_state_snapshot` 在同一 SQLite 事务内核对 expected_cursor、递增 cursor 并替换基线；状态流不写事件或幂等历史表，防止把周期全量读取变成无界历史。状态流与既有事件流互斥，混用时明确拒绝。当前保留的快照支持相同 ID、内容和原 expected_cursor 的准确重试；被覆盖的历史 ID 不保留，不能声称全历史去重。

Root 的14项 journal 检查通过，无警告；Ruff lint/format 与 diff 检查通过。这个状态替换原语不是 G3 的订单增量、消费 ACK 或审计历史。

### 已接受的本机会话归属保护

`bt_api_gateway/dev` 提交 `2d791e63556f6eafe4f1d36089b54a1151d4640d`，仅新增 `LocalAccountSessionGuard` 和测试。相同账户必须使用同一受信目录；固定文件通过 Windows 字节锁或 POSIX flock 排除本机竞争者，代次、owner 和 active/closed 记录持久化。异常退出留下 active 记录时，即使 OS 锁已释放也要求人工或后续受控流程对账，不按时间自动接管。锁文件不删除，路径替换和错误线程/进程拒绝；关闭失败保留资源供同 owner 重试。

同一 guard 对象还永久绑定一个消费对象，避免可信装配误把同一对象交给两个 worker。恢复沿用同一 worker；新 worker 使用新的 guard 对象并重新遵守持久归属检查。只有 provider 关闭已经确认，worker 才能释放保护。

Root 首次检查9项通过、1项跳过（当前 Windows 无创建 symlink 的权限）；增加消费对象绑定后仅补跑新增用例，1项通过。Ruff lint/format 与 diff 检查通过。这是本机排他保护，不是分布式 fencing、交易 writer 选主或 provider 端强制代次。跨机首版继续使用静态唯一 owner，失联不自动启用第二连接。

后续 `5409fdc253ea0879a499391a246f413467fe349c` 仅增加只读 account_key_digest 和定向测试，使 worker 能在构造时拒绝账户与 guard 错配。Root 只补跑该新增用例，1项通过；没有重复此前已接受的 guard 检查。

### Gateway 生产者与授权读取

`bt_api_gateway/dev` 提交 `bca930562928ddc216559d243c82f3c1fd97af7f`，仅含账户 worker、其测试、读取 adapter 和 base 依赖下限，共4文件。可信资源提供器传入未启动的 provider、journal、guard、实际账户及所需 coverage。worker 在所属线程获取归属后连接一次，启动时和定时维护时执行有界完整读取；策略 RPC 只读 journal，不触发额外登录或 provider 查询。provider adapter 必须遵守 timeout；同步 worker 会拒绝超时返回，但不能强制中断一个不返回的 adapter。

完整快照使用 `sdk.account.state` 负载，带 session_generation 和 AccountObservation；cursor 与状态替换同事务提交。缺覆盖、完整标志为假、陈旧/迟到/旧代次、观察时间回退等情况使基线不可用，保留旧状态供诊断。provider 关闭失败时不释放 guard；明确恢复先确认旧连接关闭，再获取新代次。构造时核对 guard 的账户身份并绑定唯一消费对象，provider 调用之后和状态写入之前再次核验归属。

重启只把旧持久快照用作 cursor、完成时间及所保留行的时间下限；新代次仍须取得新的完整观察才能就绪。旧的完整空持仓快照不能覆盖更晚的持久持仓。新鲜度绑定本地单调时钟期限；相同观察重读不延长期限，UTC 回退也不能靠更换 observation_id 使旧字段重新变新。检测到时间回退会拒绝准入，不能按重启自动豁免。

`GatewayReadService` 必须借用 worker 的同一个 journal 对象，核对账户和共享状态流。原来的策略私有流映射仍保持唯一；只有显式授权的 shared_fact_strategy_refs 才能读取全账户事实。回复的 state_status 只有在实际返回流、cursor、代次和负载匹配当前 worker 基线时才会标为 ready。借用旧 journal 的普通读取 adapter 不会凭空获得该就绪声明。

Root 首轮 worker/adapter 检查44项通过；独立只读审查发现重启后的时间下限未从持久快照恢复，修复后补跑4项新建或受影响检查，全部通过，其中1项为受修复影响的既有重启用例。两批均无警告。最终只读复核未发现剩余阻塞项；Ruff lint/format 和 diff 检查通过。最后一次格式整理只改变一个 worker 文件的排版，已核对所有相关 AST 不变。

### SDK 与宿主接入

服务清单选择 gateway 的 `account_session_worker`，可信资源提供器返回 `ComponentResources(values={"journal": journal, "accounts": accounts, "principals": principals}, internal_ports={"service.provider_session": worker}, close=worker.close, ...)`。宿主先登记资源所有权，再完成 adapter 的账户/状态流绑定校验，之后才启动 worker。就绪同时要求资源和 worker 可用；轮询维护不依赖活跃策略数，策略注销或租约清除不会关闭账户。journal 自己按每次事务关闭 SQLite 连接，没有额外的长期连接要由 worker 关闭。

策略端先启动 `ServiceClientRuntime`，然后创建 `ServiceAccountClient(runtime, "store.account", account_ref=..., expected_account=..., required_coverage=...)`，显式 `refresh()` 后通过 `snapshot()` 读取仍新鲜的缓存。身份、挂载和覆盖要求创建后只读；一个 runtime 可以为多个账户创建不同 facade。关闭 facade 只清它自己的缓存，不关闭共享 runtime。

客户端检查完整基线、预期账户和 coverage、代次/cursor、来源与服务就绪。有效期从 RPC 开始时的本机单调时间计算，通信和解析耗时都消耗期限。读取失败立即撤销当前缓存，旧 view 仅供诊断；相同 epoch、代次和 cursor 的不同内容被拒绝。该接口保留原生币种和数量单位，不跨币种加总、不计算策略现金或虚拟持仓，不生成消费 ACK。

Root 的 SDK facade 12项检查通过（1条既有 pytest 配置警告）；宿主新增/受影响5项检查通过（1条配置、3条 Windows Proactor/selector 警告），包含错配在连接之前拒绝、启动失败清理、关闭失败保留并重试、陈旧状态撤回就绪及共享读取。没有重跑未受影响的第05轮行情测试。

### 真实进程集成与交付边界

Root 单独执行 `tests/unit/test_service_account_integration.py`，最终 **1 passed，调用用时4.66秒**。用例启动两个独立账户 ServiceHost 和两个独立策略进程，使用真实 Windows spawn、CURVE RPC、SQLite 与可计数合成 provider。策略一绑定 A+B，策略二只绑定 A；A 的两个读取者获得同一 snapshot_id、cursor、代次和内容，A/B 的账户数据没有混入。

每个账户 connect=1，客户端读取不增加 provider 查询数。服务端刷新 A 后，余额变更和完整空持仓以新 cursor 原子替换，两策略得到同一新基线；B 保持原状态。错账户路由被拒绝；对 B 没有授予身份能力的客户端在 discover 阶段返回 DENIED；未知 CURVE key 的握手失败使 IMMEDIATE socket 无法入队，SDK 明确返回 REQUEST_NOT_SENT。任一策略及最后一个策略退出后，账户会话仍由服务持有；最后关闭服务，A/B 各 close=1，四个子进程正常退出，未使用 terminate/kill 兜底。

前两次组合运行均因测试错误预期拒绝码而失败：先把 discovery 的 DENIED 写成 SCOPE_DENIED，后把握手前未发送写成 REQUIRED_REGISTRATION_FAILED。Root 核对实际 registry、ZMQ IMMEDIATE 和 SDK 异常转换后只修正这两处断言，保留精确有限错误码；未改动权限逻辑或放宽为任意异常。第一次批次的5项宿主检查已通过，之后只重跑未通过的集成用例。最终批次保留1条既有 pytest 配置警告，子进程沿用当前 Windows ZMQ 环境。

| 仓库 / 分支 | 本轮提交 |
|---|---|
| bt_api_base / dev | `962c0f5bc18f86547cf0319f15cd919ed5f8291f`，账户合同与版本，共4文件 |
| bt_api_gateway / dev | `0a144afe200e1efe73590b23d14891da6e164377`、`2d791e63556f6eafe4f1d36089b54a1151d4640d`、`5409fdc253ea0879a499391a246f413467fe349c`、`bca930562928ddc216559d243c82f3c1fd97af7f`，按已接受的小范围顺序提交 |
| bt_api_py / dev | 3份源码、3份测试、2个 gitlink、base 依赖下限与本记录，共10路径；以本文件 Git 历史查询本轮 SHA |

本轮是 GW02/ARB01 的多账户读取与共享会话部分证据，不标完整用例 PASS。没有执行真实 provider、读取账户凭据、验证百策略/十账户负载、双机或无四包 wheel 安装，也未触及历史保留进程。Backtrader 和 AFI 应用代码本轮未修改。完整68项计划继续按原行为验收，不能把本轮单测数量或四进程合成结果换算成正式完成数量。

下一步补齐正常 Backtrader 读取所需的 SDK provider 适配、历史 bar/实时数据衔接和实际 open-orders 读取合同；缺失订单事实不能返回伪造空列表。随后继续账户增量/ACK、共享限流、订单与风险、AFI 接入和原有发行/负载/双机要求。当前账户 worker 不宣称交易 writer fencing、完整 G3/G7/G8 或任何交易所账户验收。

## 第07轮 A：历史 K 线和原生未成交订单读取（2026-10-14）

第06轮父仓交付为 `66765c3ecd51c3b99c6fc49db231ca0525557156`，10路径；提交后检查确认 dev、父提交、精确范围、两个 gitlink、干净工作区和 UTF-8 BOM/LF。首次提交后的范围检查误把 Git 的末尾 NUL 当成额外路径，提交本身成功；修正只读检查后通过，没有重复提交或重复功能测试。

本轮补齐普通 Backtrader 读取的两项基础合同，应用适配与完整 Cerebro 链路另行验收：

- `AccountOpenOrder` 表示账户原生开放订单，包含产品/保证金池、合约、provider order/client ID、买卖方向、持仓方向、订单类型、数量/已成交量、单位、可选价格/币种和时间。正数量且仍有剩余量；open 与 partially_filled 的成交量必须一致。价格允许有限负数以支持相关期货语义。它不赋予策略归属，不代替 Execution 的意图、分配和订单账本。
- `AccountObservation.open_orders=None` 仍表示未取得订单事实，序列化保留原来的精确 v1 字段形状；有订单集合时使用新的两字段形状。完整空集合与未知状态明确区分。Gateway 状态外层 v1 对应字段缺失，v2 对应字段存在；客户端和重启读取拒绝版本/字段错配。
- worker 与 SDK facade 均可显式要求 `require_open_orders=True`，缺失或不完整时拒绝就绪/读取。订单观察时间参与陈旧判断、相同观察去重及重启后的时间下限，完整空订单可按新版本替换旧集合。
- `MarketHistoryRequest` 明确完整订阅 key、包含起点/不包含终点的 UTC 时间窗和 1–1000 条页上限；只支持明确固定时长的 bar 周期。`MarketBar` 保留十进制 OHLCV、可选持仓量和开闭时间。页面有大小上限，行有序、唯一、不重叠且周期吻合；不完整页的续读时间必须恰好等于末条收盘时间，不能跳过未返回区间。complete 表示 provider 已读尽指定区间，不保证无交易时段也产生 bar；未来区间不能标为已观察。
- Gateway 的 `market.history` 由可信 `history_provider` 和显式超时启用，注册身份、公共 scope 和 key ACL 先于一次 provider 查询。无自动重试或缓存；同步 provider 必须遵守超时，宿主能拒绝迟到结果但不能抢占永久阻塞的函数。latest-event snapshot 和 replay 继续保留原来的含义。
- SDK `ServiceMarketClient.history(request)` 要求健康、已启动且有明确历史读取权限；核验回复合同、精确请求和前后服务 epoch/绑定，不推进或清空实时游标、队列。服务宿主先校验潜在能力，资源构造后仅允许按实际 provider 省略可选的 history；其他能力不变。实际能力与授权再次校验，未配置 provider 的 history 授权无法启动。

### 本轮验收与提交

Root 账户/历史合同检查 **101 passed**，1条既有 pytest 配置警告；SDK 账户 facade **18 passed**，1条同类警告。Gateway 首批 **43 passed / 6 failed**，六项失败均来自新测试夹具把非零成交量标为 open；修正为 partially_filled 后仅重跑这六项，**6 passed**，无警告。生产校验未放宽。

Root SDK 历史 facade 与真实 ServiceHost/registry 检查 **10 passed**，包含配置/未配置的能力声明、实际历史分发、错 scope 零额外查询、错误授权启动清理，以及客户端无权限、错误回复、epoch 变化和失去回复不重试。保留1条配置警告和3条 Windows Proactor/selector 警告。此处宿主测试经过实际组件构造和 registry 分发，尚不是跨进程 Cerebro 验收。修改文件的 Ruff lint/format 与 Git diff 检查通过。

| 仓库 / 分支 | 已验收交付 |
|---|---|
| bt_api_base / dev | `aac1f0e57a1e1741d91c089f67499f30f988b339`，两项合同及测试、版本声明，共6路径，版本0.15.8 |
| bt_api_gateway / dev | `f20fccbab223cd9b77c50b8e937efd1e13a090bf`，账户 worker、历史服务及测试、base依赖下限，共5路径 |
| bt_api_py / dev | 五份源码、三份测试、两个 gitlink、依赖下限和本记录，共12路径；本记录的 Git 历史给出提交 SHA |

子包先提交再更新父仓；没有为交付重复通过的功能检查。父仓与 Gateway 的 base 下限同步提高至0.15.8，避免使用不含新合同的0.15.7。没有构建或发布 wheel，因此不是隔离安装/发行验收。Backtrader 的只读代理、历史实时衔接和跨进程正常 Cerebro 测试仍在本轮 B 中进行；BT01/BT02、GW03 和完整68项没有因上述单测而标为 PASS。未使用真实交易所、账户凭据或历史保留进程。

## 第07轮 A 补修：账户读取适配器的 v2 就绪检查（2026-10-14）

第07轮 A 父仓提交为 `f0fd871a2bd23e66d8fee6b6ed22e9ad0024786b`。随后 Backtrader 的首次双服务/Cerebro 集成在 Broker 启动时被 `ACCOUNT_SESSION_NOT_READY` 拒绝。源码诊断确认：worker 已生成含开放订单的 v2 观察，但 Gateway 读取适配器的快照一致性检查仍硬编码 v1。这是我们的生产适配遗漏，不是 provider、网络或账户问题。

适配器现在解析 worker 的精确 `AccountObservation`，缺失订单字段只对应 v1，存在订单字段（包括完整空集合）只对应 v2；拒绝错误类型、形状和版本错配。原有账户、游标、scope、generation 和快照一致性检查保留。

Root 首次新增3项回归因夹具未创建受信 guard 目录而在构造期失败；补齐夹具目录后这3项全部通过（0.53秒，无警告）。覆盖真实 worker+journal+adapter 的 v2 非空→完整空替换、v1 兼容读取、错误版本拒绝。Ruff lint/format、Git diff 检查通过；未重复第07轮 A 已通过的合同/SDK 套件。

Gateway dev 提交 `619cb94e31f2e88f73d74fd4c8c7023e54e9ff4a`，精确两路径：`service_component.py` 与其测试。父仓本次仅更新该 gitlink 和本记录，提交 SHA 见本文件 Git 历史。本修复仍是本机合成源组件验收，双服务/Cerebro 的完整成功和正常清理待第07轮 B 实测；首次失败没有建立成功链路或正常退出证据。

## 第07轮 B 前置补修：账户时钟与 Cerebro 收尾（2026-10-14）

双服务进程集成暴露了两个需要先独立修复的生产问题。Backtrader 原来在关闭 Broker/Store 后才生成 writer 最终报告；服务代理关闭后拒绝查询，因此最终净值读取失败，并可能遮蔽原始运行异常。`Backtrader/dev` 已以 `f8f82ae41d09e2ddbbc87d0470b7d3a49193d447` 提交三路径修复：在资源关闭前生成最终报告、即使报告失败也尝试关闭所有 writer、保留原始策略运行异常。Root 的4项正常 Cerebro 定向检查通过，保留1条既有 pytest 配置警告；未改动其他未接受的运行路径。详细约束见 Backtrader 的 `docs/source/developer-guide/writer-lifecycle.md`。

随后账户 worker 把独立 UTC/monotonic 采样误差当作墙钟回退，服务刷新失败。Root 当前 Windows 时钟实测中，99个间隔比较有15个 UTC 增量比 monotonic 增量小，最小差约 -0.014秒；两个时钟报告分辨率均为0.015625秒。这是本地时钟校验缺陷，不是账户或交易所失败。

`bt_api_gateway/dev` 提交 `341c359e93937d0a673ba17b0115a922a36a9227`，仅修改账户 worker 和其测试。默认时钟仅按自身报告分辨率计算比较误差预算，注入时钟默认预算为零或由可信装配显式提供。monotonic 前后读数包住 UTC 采样，把逻辑时间保守推进到采样末端；新鲜度使用不后退的逻辑时间及单调期限，预算不延长 provider 事实有效期。持久快照仍写原始 UTC，并保留严格的持久时间下限、完整观察和代次要求。

独立复核另外发现重启加载使用未包围的两次采样，可能漏计调度暂停；现已共用相同采样逻辑。旧持久状态仍只供诊断与时间下限使用，必须取得新代次完整观察才能 ready。跨进程停机期间缺少持续单调时间证据的场景没有在本轮被宣称解决。

Root 第一批7项定向检查通过（0.84秒），覆盖25次默认时钟刷新、量化误差、真实回退、重复与更换 ID 的旧事实及持久重启下限；复核修复后再运行新增重启暂停回归和受影响的既有重启节点，2项通过（0.45秒）。合计8个不同节点通过，其中1个因后续修复再次验证，均无警告。独立只读复核关闭阻塞项，Ruff lint/format 与 diff 检查通过；未重复无关已接受套件。

父仓本次仅更新 Gateway gitlink 与本记录，以本文件 Git 历史查询提交 SHA。这两个前置修复不代表完整双服务/Cerebro 集成已通过；后续仍须验证历史实时衔接、最终报告、读取与正常进程收尾。此前失败均保留为失败，不增加正式计划 PASS。

## 第07轮 B：正常 Backtrader 只读策略接入（2026-10-14）

`Backtrader/dev` 提交 `5e961ee3210b61370695c1a784f3b1c35e6288d3`，直接父提交为收尾修复 `f8f82ae41d09e2ddbbc87d0470b7d3a49193d447`。精确8路径：新 `ServiceReadProxy`、Store/Broker/Feed 接线、两份测试、使用说明和 AGENTS 事实说明；其他已有修改及删除保持不变，提交后暂存区为空。前置时钟修复的 SDK 父仓提交为 `f85407730606fae93f6c29e4f7b37a99b5b5d76e`。

使用方先启动 SDK runtime，创建明确账户与行情绑定的 facade，再显式注入 `BtApiStore(api=proxy)`；Broker 使用 `market_data_only=True`。代理只借用中立合同和客户端，不在策略内嵌四个领域服务；未配置/未注入仍走已有路径。账户必须有完整原生开放订单事实，数量单位、币种和持仓模式显式确定。现金/净值取指定币种的 provider 估值，持仓不代表策略分配份额；所有写入口明确拒绝。

Feed 先订阅再读取有界历史，历史/实时相同闭合 K 线去重；冲突、乱序、失去完整性和未收盘数据报错。仅支持固定时长 UTC bar，不接受缺少日历锚点的周/月/年线。服务不可用不会退回 direct 或旧账户缓存。成功关闭是终态，新的运行要新建 facade/代理；共享 runtime 由调用者最后关闭。最终账户值在策略 stop 或最终 writer 报告中读取，不能在 Cerebro 关闭 Broker 后把旧值当作新读取。

| Root 检查 | 结果 |
|---|---|
| 代理定向行为 | 20个不同节点通过；包括账户事实/映射、历史衔接、去重、生命周期和写路径拒绝 |
| 原有接入兼容 | 8项通过；Store/Broker/Feed 及既有 writer 路径 |
| 双服务进程正常 Cerebro | 1 passed，调用9.76秒、总13.32秒 |
| Ruff / diff | 六份源码和测试 lint、新增三份 Python 文件格式、精确提交范围与空白检查通过 |

完整集成使用两个真实 Windows spawn 服务、CURVE RPC/PUB/SUB、实际账户 worker/journal/guard、market hub/history、SDK runtime/facade 和 Cerebro。只有 provider 数据源与测试密钥为合成输入。初始一项开放订单被显式刷新为完整空集合；历史两根 bar 与实时一根新 bar 按序进入策略，重叠 bar 只输出一次。三次读取现金80、净值105、持仓2.5，实际 writer 输出 `End: 105.0`。

每个服务连接对应源一次；账户只在启动及显式刷新各查询一次，客户端读取不另开连接。行情上游启动/关闭各一次，账户在服务关闭时 close=1；SDK 清理失败与注销不确定计数为零。两个子进程退出码均为零，没有使用 terminate/kill 兜底，也未操作历史保留进程。

每个检查批次保留1条已知 pytest 配置警告；当前 Windows ZMQ 的 Proactor/selector 兼容处理未改。最后一次失败来自测试把整数清理计数错写为空元组，核对 SDK API 后只把两处断言改为等于零，并只重跑未通过的集成用例。此前三个生产缺陷及两个测试夹具缺陷已修复，已通过的定向/兼容检查没有为交付重复运行。

详细装配示例和约束在 Backtrader 的 `docs/source/developer-guide/optional-service-read-proxy.md`。本轮是 BT01 的只读接入部分证据；策略虚拟资金/持仓、重连完整生命周期、交易执行、跨账户组、真实 provider、AFI、干净 wheel、负载及双机验收仍未完成。完整 BT01/BT02 和68项计划均不因本轮而标为 PASS。下一轮继续复用已有服务路径补账户可靠事件/消费恢复及必要领域操作，不扩大平行验收框架。

## 第08轮：账户流服务端持久消费进度（2026-10-14）

`bt_api_gateway/dev` 提交 `031ce0fffa42192d5c9773f2773e6f0a3fe0dbb0`，直接父提交为 `341c359e93937d0a673ba17b0115a922a36a9227`。精确6路径：journal、服务适配器、公开 DTO 导出、两份测试和 README。父仓本轮接通 SDK 能力/身份透传、旧默认兼容和真实进程检查；两份源码、两份既有测试、一份新集成测试、Gateway gitlink 与本记录，共7路径，以本文件 Git 历史查询交付 SHA。

### 行为和使用合同

Gateway 的 `read_for_consumer` 在同一 SQLite 事务内读取快照/事件和持久化本次可返回范围。进度按 principal、可信 consumer_ref、账户和视图隔离，包含持久的 `stream_epoch`、`offered_cursor` 和 `acknowledged_cursor`。流代次在同一库重开后保持，与服务进程代次和 provider session generation 分开；重建流不得沿用旧代次重置序号。

`offered_cursor` 表示已准备返回的数据范围，不证明网络实际送达。正游标续读必须提供匹配代次，且不能跳过此前未向该消费者提供的范围；从零读取或显式 `cursor=None` 基线读取可启动消费。保留期内可重放；已压缩部分返回新快照及后续事件，接收方必须先应用基线。服务端只保存有界消费者/流记录（各最多8192）；上限只拒绝新增，不阻止已有消费者继续。

ACK 只能确认该消费者已提供范围以内的游标；重复或更早 ACK 返回当前进度，不回退。错误代次、未来游标和未授权范围拒绝，失败事务不留下新进度。ACK 只改变消费元数据，不删除源事件、快照或去重记录，不确认交易所订单、不释放风险、不提升账户就绪。进度查询不隐式创建消费者。

服务端从 registry 的已认证 WireIdentity 与授权视图派生 consumer_ref，包含角色/principal/actor/delegate 和执行域/账户/策略，不含 run_id 或 registration_id。同一逻辑消费者的新运行可以续用，不同 actor、委托、角色或策略保持隔离；客户端不能提交任意 consumer ID。直接 Python 调用该适配器仍须由调用方提供可信上下文，它本身不是认证层。

SDK 仍通过既有 `ServiceClientRuntime.call` 使用账户端口：

- 显式申请并授权 `account.read_after`、`account.ack` 和 `account.progress`。
- 首读 `account.read_after` 使用 `track_delivery: true`、`cursor: 0` 和有界 limit；回复附 `consumer_progress`。
- 接收方本地业务投影和游标同事务落盘后，才用回复中的 stream_epoch 与已保存 cursor 调 `account.ack`。
- 后续以本地恢复点和对应 stream_epoch 续读；`account.progress` 仅供核对，不能替代接收方自己的事务恢复点。

旧客户端未显式申请新操作时仍只登记原来的 snapshot/head/read_after，避免服务升级后自动申请新的 ACK 权限。未跟踪 read_after 保持原响应形状，不写消费者状态；普通 snapshot/head 不变。ACK 是自己的消费记录写入，不成为交易 writer 能力，操作依旧需要明确 grant。领域错误沿用现有 registry 的 HANDLER_FAILED 封装，Python 直调保留有限错误码；可操作的跨组件错误合同仍需后续补齐。

### 检查及边界

Root 对 journal、既有事件读取及 Gateway 适配器运行 **54项，全部通过，无警告，2.07秒**。覆盖数据库重开、身份/视图隔离、越界与错误代次、ACK 不删除事件、压缩基线恢复、失败事务回滚及容量。独立只读审查未发现阻塞项；发现的孤立进度行错误分类差异不允许重置或写入，保留为诊断改进项。

SDK 新增3项操作登记/授权检查和1项受影响的真实宿主适配检查全部通过。真实进程集成 **1 passed，调用2.74秒**：两个独立 actor 共用一个已认证 principal 和账户事实视图，分别获得事件1；A ACK1、B 保持0。错误代次、未读事件2的 ACK 及伪造策略范围被拒绝且进度不动。正常关闭服务并重启同一 journal 后，service_epoch 改变、流 epoch/ACK 保留；同一 actor 使用新 run_id 续读事件2并 ACK2，B 仍独立。ACK 前后源事件均可读取。两个服务进程先后正常退出，四个 runtime 正常注销关闭，未使用 terminate/kill 兜底。

首次 SDK 检查因 Root PYTHONPATH 漏掉现有宿主测试导入的 Monitor 源目录而在 collection 阶段停止；补齐现有源码目录后得到4 passed/1 failed。唯一失败为测试把冻结后的 operations 元组写成列表。Root 修正时一度缩进错误导致该节点 collection 失败，立即修复，随后只补跑这个节点，1 passed（0.54秒）。未重跑已通过的进程集成或54项 Gateway 检查。SDK 批次保留既有 pytest 配置警告，宿主批次另有 Windows Proactor/selector 兼容警告；源码和测试的 Ruff lint/format、精确范围和 diff 检查通过。

本轮只证明服务端进度与真实本机通信/重启，没有真实 provider，也未实现 SDK 接收端业务投影与游标的原子提交、提交后 ACK 前崩溃去重、provider 规范流到权限视图的事务生成或完整账户增量生产。GW03 和68项计划尚不能因此标为完整 PASS。下一步沿同一账户消费路径补接收端持久投影/恢复，再接 Monitor 与领域订单事实；不新建平行验收拓扑。

## 第09轮：SDK 账户视图的持久消费与崩溃恢复（2026-10-14）

第08轮父仓提交为 `e4b7494d8a9b01d11f7eaf777bb1048671dafb07`。本轮直接在同一 dev 补接收端，不修改 Gateway 已接受的服务端进度，也不重复其验收。精确交付为两份新 SDK 源码、三份新测试和本记录，共6路径，提交 SHA 见本文件 Git 历史。

接收端保存的是一份授权账户视图的本地读模型，不成为 Execution 的订单/策略归属账本、Risk 的准入状态或新鲜账户余额的权威。应用显式提供纯本地的快照和事件投影函数；SDK 不内嵌四个领域组件，不默认创建线程、连接或本地库。投影函数中的外部调用不在 SQLite 事务内，不能宣称发送订单、通知等外部副作用恰好执行一次。

本地投影、流代次、消费游标及待 ACK 标记在同一 SQLite 事务中保存；只有提交成功后才发 ACK。重启发现待 ACK 时先确认这个持久游标，再取后续事件，不重复应用已保存的页面。ACK 回复丢失时保留待确认状态；恢复注册后由调用方再次轮询，同一确认可以重发。服务端 ACK 只作确认核验，不能替代本地恢复点；本地库不存在时从完整基线重新读取，即使服务端已经记录了更高 ACK。

持久库绑定可信身份、服务/实例、挂载、授权范围、明确的 journal 视图及投影版本，不绑定一次运行或服务进程代次。不同账户、actor 或投影版本不能复用同一库。流 epoch 变化、缺口、冲突重复及损坏状态不自动重置；落后于压缩边界且取得合法快照时，快照与尾部事件一起原子替换本地视图。只保留有界的最近一页重投递校验信息，不建立无限增长的事件副本。

### 使用与边界

使用方先启动并维护 `ServiceClientRuntime`，显式申请 `account.read_after`、`account.ack`、`account.progress`，再从 `bt_api_py.service_account_consumer` 导入 `ServiceAccountConsumer`。构造参数包括 runtime、挂载、account_ref、本地 path、projection_version、initial_state、可信装配提供的 expected_account_scope/expected_strategy_scope，以及 snapshot_reducer/event_reducer。快照函数接收初始状态和快照，事件函数接收当前状态和事件，返回新的 JSON mapping；输入递归只读，数量单位和业务字段解析由应用明确负责。

`poll()` 最多读取一页，默认100条、最多1000条；同一页精确重投递不会再调用投影函数，重复空轮询正常返回。ACK 不确定时没有自动重试，调用方恢复 runtime 后再次显式 poll。`checkpoint()` 是无需远端可用的历史持久诊断，不能冒充新鲜账户观察。`close()` 只关闭接收器，借用的 runtime 仍由调用方维护和关闭。获授权的 strategy/application/service 身份可使用这条客户端路径；是否获得权限仍由 registry 决定。服务端 account.progress 不会主动驱动本地游标。

存储使用真实 SQLite、FULL synchronous 和短事务连接，同一事务保存投影与恢复元数据；不接受内存库。库路径固定为绝对路径，其他数据库 schema、版本/绑定冲突和损坏结构拒绝复用。JSON 页面和输出默认上限1 MiB，另有限定深度、节点数、字段、事件数及整数范围；超限在投影执行前拒绝。两句柄在事务内读取当前状态，旧请求不能覆盖新进度；回调重入使本次事务回滚。上述保证仅针对 SQLite 本地状态及明确的纯函数合同，不构成通用外部副作用事务。

### 检查与交付

Root 首批工具 `678c41` 得到2 passed / 21 failed。共同生产缺陷是把 `sqlite3.Row` 的成员检查误当作键检查，导致合法新库被报告 STORE_CORRUPT；修复为显式检查 row.keys()。五项客户端测试另有夹具 scope_ref 与注册 grant 不一致，生产 ACL 正确拒绝；仅修正夹具，未放宽授权。首次集成的消费子进程因此退出1，未达到预定崩溃点，不记成功。

Root 随后只补跑失败的21项，工具 `91ee15`：**21 passed / 2 deselected**，2.98秒。合计23个不同节点通过，包括17项持久存储检查、5项客户端检查及1项真实进程集成。保留既有 pytest 配置警告；首次失败集成还输出了既有 Windows Proactor/selector 兼容警告。Ruff lint/format 与精确范围 diff 检查通过，独立只读复核关闭本轮接收端阻塞项。

真实进程集成调用1.95秒，复用第08轮 ServiceHost/CURVE/journal 装配：新建消费子进程在实际 SQLite apply 提交后、发送 ACK 前调用测试专用 os._exit(73)。同一服务仍运行；重开的本地库保留 cursor=1、pending_ack=true，而服务端 offered=1/ACK=0。新 run_id、同逻辑 actor 的 SDK 先发 ACK1，再以 cursor1 读取事件2，最后 ACK2；两个事件各应用一次，本地 pending 清空、服务端 ACK2，源事件仍保留。预期崩溃子进程退出码73，服务进程正常退出0，恢复 runtime 正常注销关闭，未使用 terminate/kill 清理兜底；未触及任何历史保留进程。

**下一项具体阻塞：账户回复大小合同。** 独立源码复核发现 Gateway journal 尚不限制单事件/快照大小，而 registry 在处理器返回后才检查900 KiB上限，部署的 wire profile 还可能更小。过大的单条事实或整页可能在 offered 已持久化后被拒绝发送，客户端保留旧投影但无法取得该页；offered 本来就不证明送达，这不会授权 SDK 跳过数据。下一轮需要把生产端、页面和传输的字节上限接通，不能仅靠调用方缩小 limit 或宣称重试可恢复。

本轮接受 SDK 接收端组件与真实本机提交后崩溃恢复，不接受所有账户流集成。过大回复、规范流到权限过滤视图的事务生成、完整 provider 增量、真实账户、干净安装、跨机器与负载要求仍待后续完成，GW03 和完整68项均未标为 PASS。没有新依赖、包发布、四领域包变更、Backtrader 或 AFI 应用变更。

## 第10轮：账户连续分页与完整回复字节上限（2026-10-14）

第09轮父仓提交为 `a31e5fdf1e91b24afa522073580373532ac92c12`。本轮修复其记录的过大回复阻塞，直接使用既有 journal、ServiceHost 和 SDK 消费器。Transport/dev 已提交 `39b34c4cf5b1d6ba9bac9b8c66ad4115c16043c9`（精确2路径），Gateway/dev 已提交 `3ebc790464b93580e7efc6168b663fe5d0c283dd`（精确4路径）；父仓随后只提交本轮10份源码/测试、两个 gitlink 和本记录，提交 SHA 见本文件 Git 历史。

### 行为与兼容边界

Transport 的纯函数 `service_reply_fits` 用实际回复构造和序列化检查完整字节数，包括 WireEnvelope、SDK 的 ok/code/result 包装、UTF-8、协议前缀和 sealed-box 开销。ServiceHost 取监听端与请求声明上限中较小的值；客户端声明只能缩小服务端上限，不改变授权。SDK 对跟踪的 account.read_after 自动声明所绑定 profile 的实际限制，显式参数也被夹到该限制以内。普通旧请求不自动增加字段；旧原始客户端没有声明时，服务端只能保证自身配置上限，不能推断远端较小的接收限制。

Gateway 在消费进度事务内使用完整结果的大小检查，选取能放下的最大连续事件前缀，再写 offered。检查采用有界二分，不逐条重新序列化所有可能页面；账户状态元数据在本次选页内采样一次，最终返回检查过的同一结果。必要快照能放下而尾部事件放不下时，可以先提交快照基线；SDK 接受这类快照页，随后从其游标续读。没有快照的空页仍不能掩盖未读取事件或游标缺口。

单条首事件或必要快照也放不下时，事务抛出有限大小错误，已有 offered/ACK 不变，也不创建新的消费者/流记录。SDK 把这一已回滚的跟踪读取失败暴露为 `REPLY_TOO_LARGE`；调用方需要修正生产事实大小或部署配置，不能靠跳过事件或重置消费进度恢复。本轮没有给历史 journal 强行追加统一的写入大小限制：不同部署的 wire 上限不同，已有超大行也必须可诊断、不能静默删除。

复核发现并修复了写操作结果语义回退：处理器执行后才发现回复过大，操作可能已经生效，仍返回 HANDLER_FAILED，由 runtime 保持 BUSINESS_OUTCOME_UNKNOWN，不自动重试。确定的 REPLY_TOO_LARGE 仅允许精确 SDK 错误类型、非写的 service.account_read/account.read_after 路径；同码任意异常、子类、其他读取和写入不会被误判为确定未执行。

### 检查与交付

| Root 定向检查 | 结果 |
|---|---|
| Transport 完整帧大小与边界 | 14 passed，0.24秒，无警告；工具 `0338cd` |
| Gateway 连续分页、快照、回滚与完整结果 | 14个不同节点通过；首批 `a9ba13` 为12 passed/2 failed，夹具修正后 `5366f1` 只补验两项，2 passed/0.36秒，无警告 |
| SDK 快照单页投影 | 新增1 passed，0.36秒；工具 `a34dc5` |
| SDK 大小声明、授权与写结果未知 | 6 passed，0.65秒；工具 `608736` |
| 受新 RPC 字段影响的既有消费器 | 5 passed；工具 `06c676` |
| 真实 CURVE 非对称上限 | 2 passed；客户端更小调用1.51秒、服务端更小调用1.43秒；工具 `06c676` |

Gateway 两项失败都是测试先追加第三条事件、再以 cursor=2 创建快照，生产代码正确拒绝过期快照。修正为先在当前 cursor=2 建快照，再追加第三条；未放松快照并发检查。SDK 首批六项新测试失败分别来自不支持的 client alias 和认证 principal 与 grant 不一致；只修正夹具，未改变 ACL。已通过的14项 Transport、12项 Gateway 和两项真实通信检查均未为交付重复执行；消费器5项因新增 wire 字段而验证兼容性。SDK 批次保留既有 pytest 配置警告。

真实检查使用 Windows spawn、实际 ServiceHost/journal/SQLite、CURVE RPC、SDK runtime 和持久消费器，只有事实与密钥为合成数据。64 KiB 服务端/12 KiB 客户端和反向配置均把三条各约7 KB的事件按连续三页提交并 ACK 到3。再加入80 KiB的第四条事件后返回 REPLY_TOO_LARGE，客户端投影与 cursor3、服务端 offered3/ACK3 均保持；服务仍存活。两个服务分别正常退出0，runtime 正常注销关闭，未用强制终止兜底，也未触及历史保留进程。

独立只读复核确认写结果未知语义和选页事务边界；Ruff lint/format 与精确提交范围检查通过。本轮接受本机组件及上述真实通信证据，未增加正式68项 PASS。下一个具体缺口仍是 provider 规范账户事实到权限过滤视图的原子生成：目前 worker 更新单一完整账户快照，scope 路由本身不筛选 payload。应在单库事务内生成受可信策略限制的视图、独立连续游标和删除事实，保留完整性语义，不能把过滤后的事实当作策略持仓归属。完整 provider、AFI、干净 wheel、跨机和负载验收仍待完成。

## 第11轮：权限账户视图原子生产及双策略恢复（2026-10-14）

第10轮父仓提交为 `fd6fdb619c0fa29e8fe6fc7cecf456c43384155d`。本轮 Gateway/dev 提交 `08222008250f6d4e1c8ef5e832f10987f0a19c50`，直接父提交 `3ebc790464b93580e7efc6168b663fe5d0c283dd`，精确9路径：四份源码、四份测试和 README。父仓随后只提交真实进程集成测试、Gateway gitlink 和本记录，共3路径；提交 SHA 见本文件 Git 历史。其余子包、Backtrader 和 AFI 没有改动。

### 行为与使用边界

可信服务端装配通过 `GatewayAccountSessionWorker(view_policies=...)` 声明资源、事实种类和可选账户估值权限。未配置时保持原单账户快照路径。客户端不能自选 policy、资源或投影函数；服务端再通过精确 strategy_scope_map 和 grant 暴露所需视图子集。允许一个账户向多个策略提供不同资源范围，资源权限不代表策略订单归属、虚拟持仓或分配资金。

worker 的完整 canonical observation、各权限视图及私有源绑定在同一个 SQLite 事务内更新。初始 `sdk.account.view` v1 基线从 cursor1 开始；后续 `account.view_delta` 携带明确 upsert/delete。每份视图独立连续编号，隐藏事实变化不增加可见事件、游标、快照 ID 或已发布时间。公开 payload 不含源账户身份、源 observation ID、源修订号或 policy digest；保留获授权行自己的事实时间，保守声明 multi_query，不冒充跨查询原子观察。

缺失所需 coverage、不完整 balances/positions/open_orders、请求订单却没有订单事实、请求估值却缺少估值，均拒绝整个更新。不能由不完整输入推断删除。后来某视图写入失败时，canonical snapshot 和前面已处理的视图一起回滚。保留事件有数量和总字节界限，压缩先生成上一投影的完整基线，再追加连续增量；旧消费者沿既有快照恢复合同接续。

首次发布固定源账户身份和政策集，重启先校验再连接 provider。漏配、改配、scope 冲突和手工写入受管视图均拒绝；给已使用的旧源增加政策或修改权限，要显式迁移到新流身份，不能静默重置。受管读取验证基线、指纹及有界连续尾部；缺失私有绑定时由保留基线的 reserved schema/ID 检测并拒绝，不把损坏视图当作旧流返回。这是明确的持久化损坏检测，不是任意多表和 payload 协同篡改的通用防护。

过滤视图只有到达当前可见 head、私有绑定与 worker 新鲜观察一致时才 ready；重启留下的旧库仅供诊断，必须取得新代次完整观察。完整账户 facade 仍要求完整账户 schema，不能把过滤视图塞给 Backtrader 当自己的持仓。SDK generic consumer 用纯本地 reducer 解析视图信封和 delta，策略端不嵌入 Gateway 或 provider SDK。

### 验收和已修复问题

Root 共接受 **36个不同节点**：纯投影12项、journal9项、worker4项、服务适配6项、受影响旧路径4项、真实进程集成1项。未为交付重复通过的套件；后续源码修正仅复验受影响节点。

- 纯投影初次工具 `78c9fa` 为11 passed/1 failed，失败夹具的行资源与缩小后的 coverage 不一致；只修夹具后 `8b56a2` 补验1 passed，0.23秒。
- journal/worker/服务与旧路径首批 `aa827f` 为20 passed/2 failed。两个预期错误分别是 cursor 等于基线时仍期待同一快照，以及把事件上限2的压缩点3误写成4；修正测试合同，没有放松生产检查。
- 独立只读复核促成读取前完整性校验、缺失单个及成对私有元数据的拒绝检查。修后 `0e9f8e` 为6 passed/1 failed；新损坏测试第二次写入漏传同一政策集，生产代码正确拒绝。补齐夹具后只重跑该节点，`7936fe` 为1 passed，0.30秒，无警告；跟踪读取失败未创建 offered/ACK 记录。
- 真实集成首跑 `d7bdcd` 在 reducer 阶段失败：测试把完整快照信封误当 payload；增量身份序列化也遗漏递归只读映射转换。只修测试后 `e1e24f` 已走到重启后最后刷新，但测试把 canonical cursor5误写成4。新代次启动已经产生完整观察并推进源 cursor4，随后刷新应到5；视图游标仍独立。最终 `4975f4` **1 passed**，调用6.18秒、总6.69秒，保留1条既有 pytest 配置警告。失败批次出现的既有 Windows Proactor/selector 警告没有被算成 provider 故障。

最终真实集成使用实际 Windows spawn、CURVE、ServiceHost/registry、worker、Gateway journal 和 SDK SQLite consumer，仅 provider 观察及密钥是合成输入。A 仅获 spot balances，B 仅获 linear positions；伪造另一策略 scope 被拒绝。隐藏的 B 变化使 A 游标保持1，B 进到2；随后 A 收到余额变更，B 收到明确持仓删除。两个策略分别 ACK、独立持久化，查询不增加 provider 连接或读取。

正常停服并用同一 journal 重启后，service epoch 和 run_id 更新，两个流 epoch、ACK 和投影保留。新代次取得完整观察后继续消费，A 到cursor3、B 保持3。四个策略进程、两次服务进程均正常退出0，provider 每个服务 connect/close各一次，SDK 清理与注销不确定计数为零，没有 terminate/kill 兜底。独立源码复核关闭本轮阻塞项，九份 Python 的 Ruff lint/format、精确暂存范围和空白检查通过。

本轮增加 GW03 的权限生产及真实本机恢复证据，不据此宣称完整68项通过。实际 provider 增量适配、跨机、负载与干净发行仍待完成。下一轮优先接通独立 Monitor 的授权写入/生产路径，复用既有 transport、ServiceHost 和 durable store；Monitor 不能把部分账户视图冒充完整经济事实，SDK 的纯 reducer 不能承担外部投递副作用。

## 第12轮：Monitor 独立持久事件入口（2026-10-14）

第11轮父仓提交为 `fbd12d394321da5f761a2c2ccfdced73936144fa`，子父提交、精确 gitlink、空暂存区及进度文档 UTF-8 BOM/LF 由 `d6b3be` 核对。本轮 Monitor/dev 提交 `586ad1b768928e023cd1336b5ebc3cbc02955737`，直接父提交 `eee98cc546c2f180dbdc2d4b90ceb4b3b37890e8`，精确5路径：durable、新 ingress、两份测试和 README。子包先完成本轮组件验收并提交；父仓负责固定装配、配置/操作合同及真实通信验收。

### 配置、权限与持久化合同

原来的默认 Monitor 仍是只读查询。显式选择 `options.role: durable_ingress` 才装配持久入口，唯一端口为 `service.telemetry_ingress`，唯一操作为 `events.append`。普通 `telemetry.append` 与持久事件操作使用不同 grant；SDK 默认注册仍只申请前者，服务 producer 必须用 requested_operations 显式申请后者。配置只含 role 时默认最多10000条、64 MiB保留逻辑内容、64 KiB单事件；三个限制可显式调小，并有代码硬上限。零配置没有新增线程、连接或可选包导入。

adapter 只接受经过 registry 认证和授权的 SERVICE 身份，principal 必须一致。scope 唯一匹配受信 target，event_type 必须属于该 target 的 allowlist。请求只含 schema_version=1、event_id、event_type、occurred_at、data；不能请求另一 scope、producer 或服务端 ID。服务端单独保存可信 producer 元数据和源事件 ID，再嵌入经过 JSON 深度/节点/字节限制及敏感字段拒绝的 payload。此处接收通用服务事件，不自动赋予经济事实完整性、策略归属、账户新鲜度或 PnL 权威。

稳定 ID 绑定 principal/actor/delegate、授权 scope、outbox 目标及源 event_id，按重启重放合同排除 run_id。生产者须跨运行保持源 ID 唯一，并保存原 ID/内容供重放；同一事件完全相同地重发，返回原持久 sequence，内容或时间变更则冲突，不覆盖。调用返回丢失或提交后异常仍是 BUSINESS_OUTCOME_UNKNOWN，没有自动重试；恢复 runtime 后由生产者显式重放原事件。本轮不实现生产者业务状态和待发 outbox 的同库事务。

`append_bounded` 在一个 BEGIN IMMEDIATE 事务里先检查精确重复，再检查容量并插入。只扫描限定行数的 UTF-8 字段长度，不取回整批历史 payload；达到数量或字节限制立即拒绝新事件，不删除旧事实，已满时精确重复仍可成功。限制涵盖保留 ID/scope/type/data 的逻辑字节，不是 SQLite 页、索引或 WAL 的物理磁盘硬上限。旧本地 append 合同保持不变，共享库的其他受信写入方须另行遵守其保留政策。

读取使用独立的永久只读 outbox 句柄和既有 MonitorReadService。默认配置不获得持久入口；未完成的普通策略心跳/指标、控制命令和 provider 连接也不会因这项能力被打开。监控事件写入不冒充交易 writer，不改动 registry 的策略交易代次或账户 owner 规则。

### Root 定向检查

持久层 `aa45f8`：新增20项及受影响旧路径3项，**23 passed / 0.83秒**。覆盖容量事务、精确 UTF-8 边界、双句柄竞争、重开、满额重复、内容冲突、只读拒绝与原 append 兼容。独立源码复核确认有限长度扫描和写入处于同一事务，无静默清理。

入口首批 `db8923` 为15 passed/1 failed：测试构造 `{schema_version: True, **defaults}` 被后面的合法默认版本覆盖，实际没有构造错误输入。Root 只交换测试字典覆盖顺序，`84f333` 补验该节点1 passed / 0.25秒；入口合计16个不同节点通过。生产版本检查没有放宽。

SDK 首批 `ae7ca7` 为8 passed/2 failed，两处断言把 WireEnvelope 冻结后的 operations 元组误写成列表。Root 修正预期后只补验这两项，`c2b263` 为2 passed / 0.53秒；合计7项新接线测试、3项旧默认配置/可选失败检查通过。覆盖 role-only 默认、固定能力/身份透传、错误资源清理、scope 拒绝、旧默认不扩大权限、显式持久操作注册，以及真实 SQLite append 后人为抛错只派发一次且保留未知结果。

上述共49个不同节点通过，各批保留既有 pytest 配置警告。独立源码审查无阻塞；四份 Monitor Python 与四份 SDK Python 的 lint 及 diff 检查通过。新文件和 SDK 格式检查通过；durable.py 一处本轮未改动的既有长行仍被全文件 formatter 提示，没有为本轮改写无关历史行。


### 真实服务通信与本轮交付

Root `d43fe9` 首次执行新增真实集成，**1 passed，调用3.35秒／总3.86秒**，保留1条既有 pytest 配置警告。执行前静态核对修正测试的三处装配错误：生成密钥字典的下划线与 producer ID 横杠不一致、应用客户端缺少合成 secret key、服务端 grant 的 actor 与客户端 identity 不一致。没有放宽生产认证或授权规则。

实际 Windows spawn 启动独立 CURVE 接收服务和只读查询服务，使用真实 ServiceHost、registry、SDK runtime 与 SQLite；只使用生成的测试密钥和合成事件。相同生产者的精确重复返回原 sequence1；伪造账户 scope 被拒绝；同 ID 不同内容保持 BUSINESS_OUTCOME_UNKNOWN。另一受信生产者使用相同源 ID 得到不同服务端 ID 和 sequence2，查询保留可信 actor/principal 元数据。

正常关闭接收服务并在同一数据库、同一注册库重启后，新 runtime 重发原事件仍得到 sequence1。达到2条容量上限时新事件被拒绝并保留未知结果，恢复 runtime 后精确重放仍成功；只读查询始终只有原两条事件。三个服务进程生命周期均按控制协议关闭并退出0，没有 terminate/kill 兜底。客户端 close 正常返回；测试未另行断言其累计注销不确定计数，不据此扩展清理结论。

本轮累计 **50个不同节点通过**。最终 `bd8eba` 检查五份 SDK Python 的 Ruff lint/format 及 tracked diff 空白通过。父仓本轮精确7路径：Monitor gitlink、三份 SDK 源码、两份新测试与本记录；父仓提交号见本文件 Git 历史。Monitor 子包其余工作区和暂存区均清洁。

验收层级为组件与本机真实进程通信。它补足 MON01 的持久接收路径，但未完成生产者持久待发队列、断线补传和业务事实的专用模式；不提升为完整 MON01 或68项正式通过。下一轮复用现有 outbox/checkpoint 和 SDK runtime 接通生产者投递，保持未知结果的原 ID 重放，不新增并行验收框架。真实账户、跨机、负载、AFI 和 Backtrader 完整迁移仍待验收。


## 第13轮：生产者持久队列到远端 Monitor（2026-10-14）

从父仓 `7a356b03789a9d476ac95baa6215fc9072935f0e` 继续，上一轮 `49174f` 已核对精确7路径、Monitor gitlink、源码/记录与提交内容一致、双方空暂存区。此轮仅在父仓增加薄的 `ServiceMonitorOutboxSink`、两份测试及本记录，不修改子包，也不重复实现现有 outbox、checkpoint、队列或重试器。

### 服务生产者如何使用

部署端显式注册 `upstream.telemetry / events.append`，在已经启动的 SERVICE runtime 所属线程中创建 sink。sink 用 scope_ref 选择唯一注册目标，本地 outbox_scope 只限制可消费的本地队列，不参与远端授权。相同 runtime 可以按不同 scope_ref 创建多个 sink，分别管理账户/目的地的游标；同一 selector 对应多个目标则拒绝。

```python
from bt_api_monitor.durable import DurableOutbox, DurableOutboxConsumer
from bt_api_py.service_monitor import ServiceMonitorOutboxSink

# runtime 已按部署配置启动，并显式申请 events.append。
outbox = DurableOutbox(producer_outbox_path)
sink = ServiceMonitorOutboxSink(
    runtime, scope_ref=monitor_scope_ref, outbox_scope=producer_scope,
)
consumer = DurableOutboxConsumer(
    outbox, consumer_id=sink.consumer_id, scope=sink.outbox_scope, deliver=sink,
)
# 业务方先用 outbox.append_bounded(event, max_events=..., max_bytes=...)
# 持久化脱敏事件；以下两行由同一 owner thread 的受监督循环定期调用。
runtime.maintain()
consumer.consume(limit=100)
```

sink 不拥有 runtime，不启动线程，不安排重试，也不替调用方关闭资源。若借用 ServiceHost.upstream，使用 TrustedServiceClients.requested_operations 显式选择持久操作，并由既有 host 生命周期维护/关闭 upstream；投递仍由同一 owner loop 显式调用。未配置 Monitor 的路径不会创建这些对象；导入新 SDK 模块不应导入四组件或 ZMQ 后端。

sink.consumer_id 绑定稳定 producer identity（含 delegate）、目的服务/实例/scope_ref、完整业务 scope 和本地 outbox scope；排除 run_id、registration_id 和 service_epoch，使正常重启保持游标。运行中的 sink 仍检查完整 scope 和短期注册代次，RPC 前后改绑不得确认本地事件。改变逻辑目的地会生成独立游标；沿用同一逻辑服务身份部署新库时，运维仍须迁移已确认数据，不能依赖客户端 checkpoint 重建已丢失的远端历史。

只有精确三字段持久回执通过验证后 callback 才返回：source_event_id 必须对应当前源事件，服务端 ID 必须符合 namespaced hash 格式，sequence 必须为有效正整数。远端 sequence 与本地序号不同；已有 DurableOutboxConsumer 仍只确认源 item.sequence。RPC 异常、未知结果、无效回执、本地 checkpoint 写入失败均保留待发事件；按策略恢复 runtime、重新创建 sink/consumer，再用同一 ID 和内容显式消费。异常不能被吞掉后当作成功。

这一条链路只提供至少一次投递与接收端稳定 ID 去重。producer 业务状态与 outbox 不共享事务；接收端持久化与本地确认也不共享事务。源 scope 的事件类型必须属于目标 allowlist，一个不可接收事件会阻塞后续有序项，不能静默跳过。两个 outbox 均需容量政策，ACK 不删除历史；本轮不加入 retention/GC、普通策略指标队列、告警或交易控制。


### 验收、故障范围与交付

Root `baebbd` 首次运行两份新增测试，**18 passed / 5.55秒**，其中17项定向节点、1项真实进程集成；保留1条既有 pytest 配置警告。定向节点使用真实 ServiceClientRuntime 与本地 DurableOutboxConsumer，只替换 transport 叶节点。覆盖单次派发、网络异常不确认、错误/额外回执字段不确认、远端最大合法序号不能替换本地序号、远端提交后注册代次变更不确认、权限与本地scope拒绝、多scope精确选路、重复目标拒绝及重启稳定consumer ID。没有重新运行上一轮已通过的50项。

执行前静态复核修正两处生产缺陷：receipt 边界误排除2^63-1，以及未按scope_ref筛选导致多账户目标被全局唯一性误拒绝。测试夹具补齐 WireScope 套利 leg 所需 portfolio_ref，并去除对 payload.arguments 的错误二次嵌套；这些在首次执行前修正，无失败测试结果被记为服务或 provider 故障。独立源码复核未留下阻塞项。回执的服务端 ID 不由本地队列scope计算：远端内部target属于受信服务端装配，可靠性仍依赖已认证服务执行其持久化合同。

真实集成调用4.53秒。两个 Monitor 服务生命周期与两个 producer 生命周期均由实际 Windows spawn 启动，经过真实 CURVE、registry 和 SQLite。第一producer用 append_bounded 保存两条事件，第一条正常确认；第二条实际远端append成功后，在本地 acknowledge API 注入 OSError，本地仍是checkpoint1且序号2待发，远端已经有两条。正常退出后用相同本地库和远端库重启，producer run/session变化、consumer ID保持，重放返回原 sequence2，随后本地checkpoint2且consume为空；远端两个ID与内容均不变。

本地scope明确为 `producer-local:synthetic-account`，远端target仍是 `outbox:synthetic-account`，验证两个命名空间不混用。四个进程正常退出0，没有 terminate/kill；两个runtime均close正常、cleanup_failures=0、unregister_uncertainties=0。证据是实际进程重启加本地确认失败注入，不是实际kill、电源故障、网络丢包或交易所账户验收。

Root `390211` 在新解释器中拦截四组件及ZMQ的import，确认只提供SDK/base路径时新模块导入成功且没有加载任何被拦截包。最终三份Python的Ruff lint/format通过。父仓本轮精确4路径为新sink、两份新测试及本记录；提交号见本文件Git历史，子包gitlink不变。

本轮补上服务producer本地持久outbox到远端sink/ACK的通信闭环，仍不宣称完整MON01或68项正式通过。下一步优先把普通策略心跳/指标的有界SDK发射器接到独立Monitor，并验证队列溢出的丢弃计数与失联降级；它须保持与这条持久服务事件路径分离。账户/订单事实生产、Execution/Risk写链路、Backtrader/AFI迁移、跨机和负载验收仍待完成。
## 第14轮：普通策略遥测的有界 SDK 发射器与独立 Monitor 接收（2026-10-14）

从父仓 `8902285546d6018d2f69f638ca754be1bf087595` 继续，上一轮 `390211` 已核对精确4路径、空暂存区与子包工作区清洁。本轮按包顺序交付：base 先给中立的有界遥测样本合同，Monitor 再实现 `telemetry_ingress` 角色的内存接收与授权快照，最后由 SDK 交付只借用 runtime 的有界发射器并接线配置、组件与注册表。三个仓库都只提交本轮文件。

| 仓库 / 分支 | 交付 | 提交 |
|---|---|---|
| bt_api_base / dev | `telemetry_protocol.py`：有界心跳/指标样本 DTO、严格解析与尺寸合同；5项测试 | `9a8167d285e46f1c1489a5bef6008f24a46abe49` |
| bt_api_monitor / dev | `service_telemetry.py`：有界内存接收、按流去重与 scope 快照；9项测试及 README | `24516efc42f0696389592ecd36436c66c28ba270` |
| bt_api_py / dev | 新 `service_telemetry.py` 发射器、四份接线改动、三份新测试、两处既有失效测试修复及本记录 | 见本文件 Git 历史 |

### 行为与使用边界

样本合同固定八个字段，拒绝未知字段、重复键与非法结构：`stream_id`（≤64字节、无空白可打印字符）、`sequence`（1..2^63-1）、`kind` 仅为 `heartbeat` 或 `metrics`、`observed_at` 必须是可表示的有限数值、最多32个扁平数值指标（名称按 ASCII 标识符校验并拒绝含 secret/token/password/credential/apikey/privatekey 的名称）、两个丢弃计数（0..2^63-1）。心跳不得携带指标，指标样本不得为空；规范化 JSON 超过8192字节即拒绝。这是普通遥测的线上合同，不是经济事实、账户新鲜度或可交易性的证明。

发射器 `ServiceTelemetryEmitter` 只拥有自己的内存队列，借用调用方已创建并持有的 `ServiceClientRuntime`：不建线程、不注册或注销、不关闭 runtime、不安排重试。`enqueue_heartbeat`／`enqueue_metrics` 不做任何 I/O，队列按条数和编码字节双重设限（默认64条／64 KiB，硬上限4096条／4 MiB），溢出丢弃最新样本并递增队列丢弃计数；`flush` 只能在 runtime 的 owner thread 调用，逐条投递并在首个失败处停止，失败、回执不合法或结果未知的样本被丢弃并计入投递丢弃计数，后续样本继续留在队列。丢弃计数在下一条样本上报，因此消费者看到的是“此前发生过多少丢弃”，而不是补齐历史。

绑定必须是可选的 `runtime.telemetry` 且被固定：身份、完整绑定签名、授权操作或路由就绪状态在投递前后任一变化，样本即被丢弃而不发送。回执必须是精确的三字段 `stream_id`／`sequence`／`accepted`，且与当前样本一致。`close` 只丢弃本发射器自己的队列，不触碰借用 runtime；策略侧进程不导入 gateway／monitor／risk／execution 或 ZMQ 后端。

Monitor 的 `telemetry_ingress` 角色只绑定 `service.telemetry_ingress`（`telemetry.append`）与 `service.monitor_query`（`telemetry.snapshot`）；旧的 roleless Monitor 仍只有 `monitor.query`／`monitor.read_after`，`durable_ingress` 不变，因此普通遥测角色不会给既有读取路径扩权。服务端按 `(可信身份, scope, stream_id)` 保存每个流的最新投影，序号回退拒绝，完全相同的重发返回原回执且不延长新鲜度，同序号不同内容判为冲突。容量按流数与保留逻辑字节在写入前判定，过期流释放容量；`telemetry.snapshot` 只返回授权 scope 内的有界结果，超过900 KiB 或超出传输回复预算即显式失败。新鲜度来自服务端单调时钟的接收时间，只有心跳才算健康；这些观察全部在内存中，重启即丢失，必须由生产者重新采集，不能当作持久补传。

配置侧只为 monitor 客户端别名开放 `telemetry_queue_max_events`（1..4096）与 `telemetry_queue_max_bytes`（1..4 MiB），其他别名继续拒绝这两个字段。注册表把 `ServiceResultTooLargeError` 映射为 `REPLY_TOO_LARGE` 的分支增加 `(service.monitor_query, telemetry.snapshot)`，与账户读取同样在有界回复预算外显式失败，而不是截断结果。

### 检查与交付

| Root 检查 | 结果 |
|---|---|
| 发射器定向行为 | 15个节点通过，0.48秒；覆盖无 I/O 入队、溢出丢弃最新并上报、字节上限、未知结果只丢一次、回执不合法、非法指标、可选路由缺失仍可入队、必需绑定拒绝、配置读取队列上限、关闭只丢自己的队列、身份或 scope 变化不发送 |
| 组件接线 | 7个节点通过，0.46秒；覆盖角色只声明普通遥测操作、信任身份与 scope 透传、服务端限制非法时先失败、资源在目标非法时关闭、失败遥测不影响无关必需读取绑定 |
| 真实进程集成 | 1 passed，调用5.46秒／总5.89秒；保留1条既有 pytest 配置警告 |
| 受影响旧路径回归 | 201 passed／7.26秒，覆盖配置、配置 IO、注册表、runtime、部署、宿主、monitor 持久入口与生产者 outbox |
| base / Monitor 定向 | 5 passed／0.25秒 与 9 passed／0.27秒 |
| 导入隔离 | 新 SDK 模块在拦截四组件与 ZMQ 的新解释器中导入成功 |
| Ruff lint / format | 八份父仓 Python 文件通过 |

真实集成使用实际 Windows spawn 启动一个 CURVE 接收服务与两个策略进程，加一个应用查询客户端；只有 provider 数据与测试密钥是合成输入。两个策略各自注册到同一服务但得到不同 run_id 与 stream_id，只申请 `telemetry.append`；伪造另一策略 scope 的请求被拒绝。策略先入队心跳与指标、触发一次队列溢出，再在有界 flush 中投递两条并保持 `ready`；随后人为制造一次投递失败，得到 `degraded` 与投递丢弃计数，空队列 flush 不再宣称 ready。应用客户端按授权 scope 查询到两条流的心跳与指标，且策略进程全程没有加载任何领域包。

本轮同时发现并修复两处既有失效测试（都不由本轮改动引起，已用 HEAD 版本复现）：`test_service_registry.py` 的错误码字面集合漏掉第10轮（`fd6fdb61`）新增的 `REPLY_TOO_LARGE`；`test_service_host.py` 的未就绪回滚用例仍用 `object()` 冒充 `GatewayAccountSessionWorker`，而该类型检查自 `66765c3e` 起生效。两处都只改测试期望与夹具，没有放松生产校验。

### 局限与下一步

本轮补齐 MON01 中“SDK 发射器接独立 monitor 服务、心跳/普通指标有界与丢弃计数、失联降级”的部分，并与第12、13轮的持久服务事件路径保持分离：普通遥测是内存尽力而为，不承担补传。它不构成 MON01 或68项计划的正式 PASS，也没有覆盖真实账户、跨机、负载、干净发行以及 Execution／Risk 写链路、Backtrader／AFI 迁移。

下一轮在现有服务宿主与持久原语上推进账户与订单事实的生产，使独立 Monitor 能读到授权的账户/策略视图，同时保持普通遥测、持久事件和交易事实三条路径的边界，不新增平行验收框架。
## 第15轮：Execution 账户归属写入口（2026-10-14）

从父仓 `c0cd400b` 继续。本轮只在执行包与其 SDK 接线内交付：把已有的受管执行台账（意图准入、派发至多一次、UNKNOWN 保留、撤单目标校验）暴露为认证服务边界，不重写状态机、不接入真实 provider、不引入 risk 包。

| 仓库 / 分支 | 交付 | 提交 |
|---|---|---|
| bt_api_execution / dev | 新 `service_order_entry.py`、README 的认证服务边界说明、23项组件测试 | `9f08694` |
| bt_api_py / dev | execution 角色内置项与装配分支、两处既有测试更新、两份新测试及本记录 | 见本文件 Git 历史 |

### 行为与使用边界

`account_owner` 角色现在只发布实际实现的能力：`service.order_entry` 提供 `orders.submit` 与 `orders.cancel`，`service.order_query` 提供 `orders.query`。适配器借用已打开的 SQLite 执行台账、可信 provider 适配器（暴露 `submit(intent)` 与 `cancel(intent)`）以及部署方提供的 `WireScope -> ExecutionScope` 目标表；客户端不能自带 scope，策略/人工 book 归属只来自经认证并解析到可信目标的 `WireScope`，未登记或未授权 scope 在写入台账之前即被拒绝。

提交在调用 provider 之前先持久准入，并且每个 intent ID 至多派发一次：完全相同的重复请求返回同一记录，同 ID 不同内容判为冲突并返回既有记录。provider 失败、派发异常或回报身份不匹配都会留下 `UNKNOWN`，绝不自动重发；调用方只能用 provider 证据对账。撤单必须同时给出原 intent 与台账已确认的 provider 订单号，缺少证据的目标、错配的订单号或另一 scope 的目标都拒绝，且不产生 provider 调用。

未配置准入门时写入路径默认失败关闭并返回 `ADMISSION_REQUIRED`；只有装配根显式声明 `allow_unprotected` 才放行，服务清单无法自行打开该开关。被拒绝的预留记录为持久拒绝（`REJECTED`），provider 调用为零。准入门协议在服务构造时校验（订单门需要 `reserve`，撤单门需要 `claim_before_dispatch`），避免在首次撤单时才失败。回执在存在持久记录时总是携带该记录，因此 `UNKNOWN` 对调用方可见，而不是被报告成普通失败。

### 检查与交付

| 检查 | 结果 |
|---|---|
| 执行包定向行为 | 23个节点通过；覆盖至多一次派发、重复同内容、同 ID 冲突、provider 异常留 UNKNOWN、provider 拒绝、客户端自带 scope 拒绝、未登记 scope 拒绝、run 通配模板、缺准入门失败关闭、准入门拒绝零调用、撤单目标校验、撤单幂等、错配订单号、跨 scope 撤单、授权范围查询、身份/principal 不匹配、非法操作、外部 writer 租约、构造期参数校验与多 scope 归属隔离 |
| 执行包全量回归 | 327 passed / 2 skipped，15.14秒；未改动既有状态机 |
| SDK 接线 | 6个节点通过；覆盖角色能力、只绑查询端口不发布写操作、可信身份与 scope 透传、自带 scope 拒绝、准入策略必填与非法准入资源、资源关闭与精确资源键 |
| 真实进程集成 | 1 passed；实际 Windows spawn 的服务与策略进程经真实 CURVE/registry，重复提交只派发一次，拒绝与 UNKNOWN 不产生第二次派发，撤单幂等，跨 scope 伪造被拒 |
| 受影响旧路径回归 | 184 passed / 6.88秒（配置、配置 IO、注册表、runtime、部署、宿主、新接线）与 46 passed（第14轮遥测与 monitor 持久入口） |
| Ruff lint / format | 两侧新增与修改文件通过 |

真实集成使用实际 Windows spawn 启动执行服务进程与策略进程，只有 provider 数据与测试密钥是合成输入。服务端持有合成 provider 与合成准入门并逐次上报派发、预留与认领计数；策略端只申请 `orders.submit`/`orders.cancel` 与 `orders.query`。首条提交进入 `ACKED` 且 `dispatch_attempts=1`，重复提交返回同一记录且计数不变；伪造 scope 被拒后计数不变；准入门拒绝使记录成为 `REJECTED` 且 provider 调用为零；注入 provider 超时后记录为 `UNKNOWN`，再次提交仍是 `UNKNOWN` 且只有一次派发；撤单成功后重复撤单返回同一记录且只派发一次。正常关闭两个进程后，用同一台账与注册库启动新服务代次，新策略进程查询到同一条 `ACKED` 与 `UNKNOWN` 事实，且新代次的 provider 调用计数为空。

本轮同时更新两处既有测试：宿主中"order_entry 未被公布"的用例改为"写端口必须由可信 provider 交付完整写资源才公布"，并新增资源键精确匹配的用例。两处都随本轮能力落地而变化，没有放宽生产校验。

### 局限与下一步

本轮完成 P4/E1–E2 的服务侧核心：独立装配、稳定业务 ID 幂等、派发至多一次、UNKNOWN 保留、撤单目标绑定与授权 scope 映射。它不包含 provider 能力登记（E7）、虚拟分账与持仓归属（E4）、恢复调度（E9）、订单组（E6）、跨包预留一致性（E5）、真实 provider、跨机与负载验收；EXE01/EXE02/EXE03/EXE04 仍需各自规定的完整证据，68项计划不因此新增正式 PASS。

下一轮优先把 execution 写入口接到 Backtrader 的 Broker 与 SDK 代理，使正常 Cerebro 路径经同一账户入口提交/撤单并接收有界回报，同时保持未配置时的普通 direct/回测路径不变；真实 provider、AFI 写链路与跨机验收仍待后续轮次。
## 第16轮：SDK 受管执行客户端代理（2026-10-14）

从父仓 `b63000b2` 继续。第15轮交付了服务端写入口，本轮补上策略/应用侧使用它的唯一通道：SDK 只借用已启动的 runtime，把订单内容发给服务，服务端负责 scope、归属与 provider 会话。本轮不修改执行子包，也不改动 Backtrader。

| 仓库 / 分支 | 交付 | 提交 |
|---|---|---|
| bt_api_py / dev | 新 `service_execution.py` 客户端代理、两份测试及本记录 | 见本文件 Git 历史 |

### 行为与使用边界

`ServiceExecutionClient` 绑定一个订单入口挂载（`broker.orders`／`application.orders`／`upstream.orders`），可再显式声明查询挂载与 scope_ref；未声明查询路由时 `query` 直接报 `QUERY_NOT_CONFIGURED`，不会猜测路由。代理不建线程、不注册或注销、不关闭 runtime，并限定在 runtime 的 owner thread 上调用。

`submit`／`cancel` 只发送订单内容：请求体不含 scope，执行 scope、策略归属和 provider 会话全部由服务端从认证后的 `WireScope` 解析。客户端做一次封闭词表校验（买卖方向、开平标志、订单类型、有效期、正数量与价格、限价必须有价而市价不得带价、引用与标签的字符与长度），非法输入在本地失败且不产生任何 RPC。查询返回 `None` 表示服务端没有该记录，不会伪造状态。

回执必须严格匹配字段集合与标量类型，任何多余或缺失字段、非有限数值、类型不符、以及 intent/cancel 标识与请求不一致都会被拒绝为 `INVALID_REPLY`。`UNKNOWN` 是正常返回值，代表 provider 结果待对账；只有 RPC 本身不确定时才抛 `ServiceExecutionUnknownOutcomeError`（携带业务标识），调用方必须用 `query` 对账而不能直接重发同一标识。可证明未发出的请求区分报 `REQUEST_NOT_SENT`，其余传输异常按"可能已到达"处理。远端业务拒绝（如 `INTENT_CONFLICT`）携带既有记录时作为 `ServiceExecutionError.record` 返回。

### 检查与交付

| 检查 | 结果 |
|---|---|
| 客户端定向行为 | 13个节点通过；覆盖精确的无 scope 请求体、市价/限价价格规则、13类本地非法输入零 RPC、传输失败不重发、UNKNOWN 作为可对账记录、冲突回执携带既有记录、有限错误码、撤单目标字段、查询缺失与未配置路由、四类畸形回执拒绝、构造期路由校验、借用 runtime 不关闭 |
| 真实进程集成 | 1 passed；实际 Windows spawn 的执行服务与策略进程经真实 CURVE/registry，策略全程只用 SDK 代理 |
| 导入隔离 | 新 SDK 模块在拦截四组件与 ZMQ 的新解释器中导入成功 |
| Ruff lint / format | 三份文件通过 |

真实集成中策略进程用代理提交 `intent-1` 得到 `ACKED`，重复提交返回同一记录且服务端只派发一次；查询命中返回 `ACKED`、查询未登记标识返回 `None`。随后注入一次 provider 超时，代理把 `UNKNOWN` 记录原样返回（`dispatch_attempts=1`），再次查询仍是 `UNKNOWN`，服务端计数显示没有第二次派发；撤单返回 `ACKED` 且只派发一次。两个进程均正常关闭。

### 局限与下一步

本轮只是客户端代理，不含 provider 能力登记、虚拟分账、恢复调度、订单组与跨包预留；也未接入 Backtrader 的 Store/Broker、AFI 的写入口、真实 provider、跨机与负载验收，EXE 系列与68项计划不因此新增正式 PASS。

下一轮把该代理接到本地 Backtrader 的 Broker 与 Store，使正常 Cerebro 路径经同一账户入口提交、撤单并接收有界回报，同时保持未配置时的普通 direct/回测路径不变。
## 第17轮：Backtrader 受管执行适配器接入（2026-10-14）

从父仓 `f1f8e1fb` 继续。本轮在本地 Backtrader/dev 工作区交付：把已有 `BtApiStore` 的 `managed_execution_adapter` 端口填成认证执行服务，使框架订单经同一账户入口提交，而不是退回本地 provider 派发。本轮不修改 Backtrader 既有 direct/回测路径，也不改动其工作区中其他未完成修改。

| 仓库 / 分支 | 交付 | 提交 |
|---|---|---|
| Backtrader / dev | 新 `backtrader/stores/service_execution_adapter.py`、`tests/unit/stores/test_service_execution_adapter.py`，精确2路径 | `7fb3564c3` |
| bt_api_py / dev | 本记录 | 见本文件 Git 历史 |

### 行为与使用边界

适配器借用注入的 SDK 执行客户端（鸭子类型，只要求 `submit` 与 `cancel`），不建线程、不注册、不关闭 runtime，并且**任何路径都不调用 Store 的私有 legacy dispatcher**：缺少 journal、许可或 provider 事实不能因此变成一次直接写。托管订单标识沿用框架已发布的元数据（`managed_intent_id`、`managed_signal_id`、`managed_instrument`、`managed_position_effect`、`managed_metadata_version`），缺项直接拒绝且不产生服务调用；止损、止损限价、移动止损和括号单不被静默降级，而是本地拒绝。

回执固定为三种 Broker 已理解的形状之一：确认投影（带 provider 订单标识与 `accepted` 状态）、非终态未知投影（`execution_unknown=True`，订单保持活动但不被接受成交）、或结构化拒绝（带有限错误码）。只有能证明"服务端没有触碰 provider"的封闭错误码集合才映射为本地拒绝；任何无法识别的错误、传输异常与 `BUSINESS_OUTCOME_UNKNOWN` 都保持非终态未知，等待对账而不是当作干净的失败。撤单确认（`ACKED`）同样保持非终态并标记需要重新对账，只有 `CANCELLED` 才是终态。

### 检查与交付

| 检查 | 结果 |
|---|---|
| 适配器定向行为 | 18个节点通过；覆盖客户端能力校验、确认投影与 provider 标识、市价无价、非法执行类型零调用、缺元数据零调用、平仓强制 reduce_only、卖出方向与绝对数量、UNKNOWN 非终态、REJECTED 拒绝、未知结果不重发、传输未知保持可见、确定失败带服务码、未识别错误保持未知、撤单确认非终态、撤单终态、缺 provider 标识与缺元数据零调用、撤单未知结果可对账 |
| 真实 Store/Broker | 2个节点通过：经真实 `BtApiStore`／`BtApiBroker` 提交，订单被接受并映射 `external_order_id`，legacy provider 派发为零；UNKNOWN 记录使订单保持活动且 `execution_unknown=True`，同样零 legacy 派发 |
| Ruff lint / format | 两份新文件通过，最长行 100 |
| 既有失败独立性 | 用移除新文件后的同一提交复现，确认 stores/brokers 目录中28项失败与本轮改动无关（属该工作区既有状态） |

Backtrader 工作区中已有的 CTP 运行器改动与未跟踪证据目录保持原样，本轮只提交两个新文件。

### 局限与下一步

本轮只完成"提交"经服务入口的 Broker 证据，且是离线合成 provider 与假客户端：撤单只验证到适配器层，未走完整 Broker 撤单链路；没有真实 Cerebro 运行、回报通知、重连恢复、真实 provider、AFI 写入口、跨机与负载验收；BT01/BT02 与68项计划不因此新增正式 PASS。

下一轮在现有适配器上补 Broker 撤单与回报投影的真实链路，并复用已验收的执行服务进程完成端到端只读+写入口场景，仍不扩大验收框架。
## 第18轮：ai-for-investor 授权只读接入与消费者登记（2026-10-14）

从父仓 `b95f91fb` 继续。本轮在本地 ai-for-investor（下称 AFI）/dev 工作区交付 P9A 的消费者登记与 P9B 的只读门禁：应用作为普通 SDK 客户端读取已授权视图，不持有 provider 凭据、不自动登录、不把缺失事实投影成零。本轮不改动 AFI 既有业务路由与脚本工作区中的在途修改。

| 仓库 / 分支 | 交付 | 提交 |
|---|---|---|
| ai-for-investor / dev | 新 `app/services/service_read/`（contracts、consumers、client）、新 `app/api/service_read.py`、`app/api/router.py` 的可选路由登记、两份测试，精确8路径 | `104c2852` |
| bt_api_py / dev | 本记录 | 见本文件 Git 历史 |

### 行为与使用边界

中性只读视图带显式质量标记（`fresh`／`stale`／`not_collected`／`unavailable`）。合同在构造期就拒绝"不可用或从未采集却携带数值"的视图，因此页面不可能把缺失余额显示成 0；只有 `fresh` 才允许把数值当作当前事实展示。`not_collected` 的健康视图不得携带任何指标。

读取适配器借用组合根创建的 runtime：构造与导入都不发起 I/O，`bt_api_py` 在真正读取时才惰性导入（AFI 仍可在未安装可选服务包时正常启动），并且从不导入四个领域包。未登记账户／scope 直接拒绝且不产生任何调用；注册表拒绝（`SCOPE_DENIED` 等）作为拒绝上报，不降级成页面；传输失败或结果未知返回显式的 `unavailable` 视图并带有限诊断码。策略健康只由新鲜心跳证明，指标或进程存活都不算健康；`metrics.snapshot` 之外的字段集合与标量类型都严格校验，畸形快照直接拒绝。

HTTP 端点注册为可选路由：未安装 SDK 时应用仍能启动并把该面标为不可用；未配置读取路径时返回 503 `SERVICE_READ_NOT_CONFIGURED`，不会自行建立连接或伪造数据。消费者登记表逐项记录 AFI 表面、目标能力、权威归属、迁移状态与已取得的最强证据，并拒绝"未迁移却声称更强证据"的条目；`strategy-health` 已标为 `read-migrated`（offline 证据），其余九项保持 `pending`／`contract`。

### 检查与交付

| 检查 | 结果 |
|---|---|
| 合同与登记 | 通过；覆盖缺失事实不得为零、not_collected 不得带指标、心跳才是健康、登记表一致性与证据等级约束 |
| 适配器定向行为 | 通过；覆盖授权账户投影与质量、陈旧保留数值但不算当前、未观测币种显式标记、拒绝与降级区分、未登记账户零调用、快照投影、陈旧／缺失／他人策略流、畸形快照拒绝、绑定构造校验 |
| HTTP 端点 | 通过；覆盖未认证拒绝、未配置 503、质量与空值投影、403 拒绝、404 未登记、传输失败 200+unavailable、健康视图、登记表端点、未绑定 scope 404 |
| 导入隔离 | 新解释器拦截四组件与 ZMQ 后导入成功，且应用读取路径未加载任何被拦截包 |
| Ruff lint / format | 八份文件通过 |

合计 30 个节点通过。真实 AFI 应用在本机无法整包收集（`MarketDataCapabilityStateResponse` 未定义的既有 pydantic 失败，用改动前代码同样复现），因此本轮用最小 FastAPI 应用挂载**真实路由**并只覆盖鉴权依赖来取得 HTTP 证据，其余测试用 `--noconftest` 运行；这不构成"完整应用端到端"证据。

### 局限与下一步

本轮只覆盖只读合同、适配器与端点，未接入既有页面／业务路由，也没有真实服务进程、真实账户、AFI01 的完整 HTTP→SDK→服务授权链、写入链路（AFI07/AFI13）、旧实现退役（AFI10/12）与 AFI11 故障隔离；AFI01–AFI13 均未新增正式 PASS。P9A 要求的脱敏固定数值基准与版本兼容矩阵尚未落盘。

下一轮在现有适配器上接一个真实服务进程（复用第15/16轮已验收的执行与账户服务），把只读链路的证据从 offline 提升到 local-process，并补上基准与兼容矩阵文档。
## 第19轮：AFI 只读链路的真实进程证据与 P9A 基线（2026-10-14）

从父仓 `f16c6669` 继续。本轮把 ai-for-investor 的只读证据从 offline 提升到 local-process，并补齐 P9A 要求的登记基线：来源身份、脱敏固定数值、单位语义、版本兼容矩阵与转换拒绝条件。

| 仓库 / 分支 | 交付 | 提交 |
|---|---|---|
| ai-for-investor / dev | 新 `tests/test_service_read_local_process.py`、新 `docs/contracts/service-read-baseline.md`、登记表证据等级更新与导入隔离测试改为子进程，精确4路径 | `2dd0237d` |
| bt_api_py / dev | 本记录 | 见本文件 Git 历史 |

### 行为与证据

真实进程用例在本机启动一个 Monitor `telemetry_ingress` 服务进程（真实 ServiceHost、注册表、CURVE），另建一个真实策略客户端 runtime 上报心跳，再以应用客户端 runtime 通过**与端点相同的适配器**读取授权快照。证据链为：生产者未上报时 `not_collected` 且不带任何指标；上报心跳后 `fresh`、`is_healthy=true`、序号与流标识正确；超过服务端心跳界限后同一观测变为 `stale` 且不再算健康（数值与序号保留）；服务进程正常退出后再读得到 `unavailable` 与有限诊断码；部署未授予的 scope 直接拒绝（`SCOPE_NOT_CONFIGURED`），不产生页面状态。服务进程按控制协议正常关闭并退出码为零，没有使用 terminate 兜底。

基线文档固定了来源身份与权威归属、七组脱敏固定输入的期望投影、版本兼容矩阵与五条转换拒绝条件；其中"未采集/不可用不得携带数值"仍是合同层强制，而非文档约定。登记表中 `strategy-health` 的 evidence 由 `offline` 更新为 `local-process`，其余九项保持 `pending`／`contract`。导入隔离检查改为在新解释器中执行，避免测试顺序掩盖领域包导入。

### 检查与交付

| 检查 | 结果 |
|---|---|
| 合同与适配器定向 | 18个节点通过（含改为子进程的导入隔离检查） |
| HTTP 端点 | 12个节点通过 |
| 真实本机服务进程 | 1 passed，调用约12.7秒；未上报→新鲜→陈旧→不可用，未授权 scope 拒绝 |
| Ruff lint / format | 八份文件通过 |

本轮仍以最小 FastAPI 应用挂载真实路由取得 HTTP 证据（AFI 整包在本机因既有 pydantic 失败无法收集，用改动前代码同样复现）；因此该部分不构成完整应用端到端证据。

### 局限与下一步

本轮只覆盖只读链路的合同、适配器、端点与本机真实服务；未接入既有页面与业务路由，未做真实部署服务（`real-service`）、真实账户读取、写入链路（AFI07/AFI13）、旧实现退役（AFI10/12）、AFI11 故障隔离与 AFI02/03 的组合视图；AFI01–AFI13 均未新增正式 PASS。

下一轮把该只读适配器接到一个既有 AFI 只读页面／业务路由（先登记真实入口再改），使其成为产品可见能力，而不是仅测试可用的模块。
## 第20轮：Backtrader 受管撤单链路（2026-10-14）

从父仓 `93188bc7` 继续。第17轮只把提交接到执行服务，本轮补齐 Broker 撤单：撤单经同一适配器与账户入口，确认撤单保持非终态并要求对账，legacy provider 撤单路径保持为零调用。

| 仓库 / 分支 | 交付 | 提交 |
|---|---|---|
| Backtrader / dev | `service_execution_adapter.py` 的撤单标识约定、三份新增测试，精确2路径 | `cf9bd63dc` |
| bt_api_py / dev | 本记录 | 见本文件 Git 历史 |

### 行为与边界

未显式提供撤单标识时，适配器按框架既有约定从 intent 派生稳定标识（`cancel.<intent_id>`），因此对同一 intent 重复撤单是幂等的，不会在服务端创建第二条撤单记录；显式提供的标识优先。撤单仍必须给出服务台账已确认的 provider 订单号，否则本地拒绝且不产生任何调用。

Broker 层证据：撤单到达适配器时携带正确的 `cancel_id`／`target_intent_id`／`provider_order_id` 与元数据版本；`ACKED` 撤单不会让框架订单进入终态——订单保持活动并标记需要重新对账（`managed_execution_cancel_reconciliation_required`），这与"provider 确认收到撤单命令不等于订单已撤"的既有立场一致；未知撤单结果同样保持可对账。两种情况下 provider 的 legacy 提交与撤单调用都为零。

### 检查与交付

| 检查 | 结果 |
|---|---|
| 适配器与 Broker 定向 | 23个节点通过（第17轮20项 + 本轮3项：撤单标识约定、Broker 撤单链路、未知撤单结果） |
| Ruff lint / format | 两份文件通过，最长行 100 |
| 既有失败独立性 | Backtrader 工作区中 stores/brokers 目录的既有失败仍与本轮无关，未改动 |

### 局限与下一步

本轮仍是离线合成 provider 与假 SDK 客户端：没有真实服务进程、真实 Cerebro 运行、回报通知与重连恢复、部分成交／撤单竞态、真实 provider、跨机与负载验收；BT01/BT02 与68项计划不因此新增正式 PASS。

下一轮把 Backtrader 适配器接到真实执行服务进程，取得提交与撤单的 local-process 证据（含 UNKNOWN 不重发与重启后查询），与第15/16轮已验收的服务进程复用同一装配。
## 第21轮：Backtrader 适配器的真实执行服务进程证据（2026-10-14）

从父仓 `34294dbd` 继续。本轮把 Backtrader 的受管执行适配器接到**真实执行服务进程**：框架订单经真实 CURVE 传输到达服务端账户入口，服务端持有台账、准入门与 provider 适配器；只有账户数据 provider 与密钥是合成输入。

| 仓库 / 分支 | 交付 | 提交 |
|---|---|---|
| Backtrader / dev | 新 `tests/unit/stores/test_service_execution_adapter_local_process.py`、适配器标签稳定性修复、两份测试更新，精确3路径 | `d87d9810c` |
| bt_api_py / dev | 本记录 | 见本文件 Git 历史 |

### 真实进程证据链

真实 Windows spawn 启动执行服务进程（真实 ServiceHost、registry、SQLite 台账、CURVE），测试进程内建立真实 SDK 策略客户端 runtime 与 `ServiceExecutionClient`，再注入第17/20轮的适配器与真实 `BtApiStore`／`BtApiBroker`。证据：

1. `broker.buy` 提交到达服务并被接受，订单带上服务确认的 `external_order_id`，服务端派发计数为一次，legacy provider 的提交与撤单计数均为零。
2. 相同 intent 的第二次框架订单返回同一持久记录且服务端仍只派发一次。
3. 注入一次 provider 超时后，订单保持活动、`execution_unknown=true` 且成交为零；服务端只有一次派发，`query` 得到 `UNKNOWN`。
4. `broker.cancel` 到达同一账户入口，服务端撤单派发一次，legacy 撤单为零，订单保持活动。
5. 正常关闭服务后用同一台账启动新代次：旧注册被拒绝为 `STALE_EPOCH`（不静默复用），显式 `recover()` 后旧事实仍可读为 `ACKED`／`UNKNOWN`，新代次 provider 派发计数为零。三个进程均正常退出零。

本轮真实进程测试还暴露并修复了一个真实缺陷：适配器默认把框架订单引用写进 intent 标签，而该引用是每个订单对象自增的计数器，导致"同一 intent 重复提交"被判为内容冲突而不是幂等返回。现在默认不发送该引用，只有部署注入稳定引用工厂时才发布。

### 检查与交付

| 检查 | 结果 |
|---|---|
| 适配器与 Broker 定向 | 25个节点通过（含标签稳定性两处新增与更新） |
| 真实本机服务进程 | 2 passed，调用约13.4秒（真实链路 + 精确 Decimal 透传） |
| Ruff lint / format | 三份文件通过 |
| 既有失败独立性 | 该仓库 stores/brokers 目录的既有失败仍与本轮无关，未改动 |

### 局限与下一步

本轮仍是合成 provider 与合成密钥、同机进程：没有真实交易所／券商账户、没有回报通知与重连的完整生命周期、没有部分成交与撤单竞态、没有跨机与负载验收；BT01/BT02 与68项计划不因此新增正式 PASS。适配器仍只覆盖提交与撤单，`notify_order` 投影与恢复回调尚未接入服务事实。

下一轮把服务端订单事实接入 Broker 的回报投影（`notify_order`／成交去重），使服务记录成为框架订单状态的来源，而不是仅由提交回执决定。
## 第22轮：服务成交事实投影与重复执行防护（2026-10-14）

从父仓 `c024677a` 继续。第21轮证明订单能经真实服务进程提交，但服务记录里的成交事实没有进入框架订单；本轮补齐投影，并堵住"同一 intent 的第二个框架订单重复记账"。

| 仓库 / 分支 | 交付 | 提交 |
|---|---|---|
| Backtrader / dev | 适配器成交投影与 replay 标记、两份测试更新，精确3路径 | `be178bb07` |
| bt_api_py / dev | 本记录 | 见本文件 Git 历史 |

### 行为与边界

服务记录的 `ACKED`／`PARTIALLY_FILLED`／`FILLED` 现在分别映射到框架已理解的 `accepted`／`partial`／`completed`，并携带精确的成交数量、均价与累计手续费；框架据此走既有成交应用路径，不需要新增记账机制。若记录声称有成交但数量或均价不可精确解析，则**不按成交记账**：订单保持 `accepted` 并标记 `service_execution_fill_unprojected` 供对账，避免凭猜测记账。

同一 intent 的第二次框架订单不再被当作新提交：适配器把已返回过的 intent 标记为 durable replay，框架既有的 replay 守卫据此精确拒绝（`managed_execution_projection_replay_blocked`），而不是把累计成交再记一遍。这与框架既有立场一致——"持久记录证明 provider 派发，不等于允许再次修改当前内存 Broker"；跨进程恢复仍需审计过的恢复回执，适配器不伪造该回执。

### 检查与交付

| 检查 | 结果 |
|---|---|
| 适配器与 Broker 定向 | 29个节点通过；新增覆盖部分/完全成交精确投影、不可精确解析的成交不记账、Broker 应用完全与部分成交、重复 intent 被 replay 守卫拒绝 |
| 真实本机服务进程 | 2 passed，约13.9秒；真实链路中重复 intent 被拒绝且服务端仍只派发一次 |
| Ruff lint / format | 三份文件通过 |
| 既有失败独立性 | 该仓库 stores/brokers 目录的既有失败仍与本轮无关，未改动 |

本轮同时修正了第21轮记录中"重复提交返回同一记录"的表述：服务端行为不变（同一持久记录、只派发一次），但框架侧现在把第二个订单判为 replay 并拒绝，而不是让它再记一次成交。

### 局限与下一步

仍无真实交易所／券商账户、真实回报推送与重连生命周期、部分成交与撤单竞态、跨机与负载验收；服务事实只通过提交回执投影，尚未有独立的"按持久记录刷新框架订单状态"的轮询/回调通道，也没有恢复回执路径。BT01/BT02 与68项计划不因此新增正式 PASS。

下一轮为 Broker 增加显式的"按服务记录刷新"入口（查询持久记录并投影状态变化），使服务记录成为订单状态的持续来源，而不只依赖提交那一刻的回执。
## 第23轮：按持久记录刷新框架订单状态（2026-10-14）

从父仓 `ca6a46e5` 继续。第22轮让提交回执携带成交事实；本轮增加显式的"按服务记录刷新"入口，使持久记录成为订单状态的持续来源，而不是只在提交那一刻可见。

| 仓库 / 分支 | 交付 | 提交 |
|---|---|---|
| Backtrader / dev | 适配器 `refresh_projection` 与 9 项新测试，精确2路径 | `fb82e0f8d` |
| bt_api_py / dev | 本记录 | 见本文件 Git 历史 |

### 行为与边界

`refresh_projection(intent_id)` 只向服务查询既有记录并投影当前状态，不派发任何 provider 调用，也不触碰 legacy 路由。投影使用与提交回执相同的词汇（`accepted`／`partial`／`completed`／`cancelled`／`pending`+`execution_unknown`／结构化拒绝），因此框架可以复用既有更新路径。

同一条记录在**未变化**时被再次刷新会标记为 replay，避免框架把同一状态记两次；记录推进到新修订（`updated_at_ns` 变化）则正常投影。取消态记录是终态；未知态保持可对账；记录缺失或读不到一律报为未知（`service_execution_record_missing` 或有限诊断码），不伪装成干净的失败。可证明的拒绝（如 `SCOPE_DENIED`）仍按拒绝上报。

### 检查与交付

| 检查 | 结果 |
|---|---|
| 适配器与 Broker 定向 | 38个节点通过；新增覆盖当前状态投影、未变化即 replay、新修订正常投影、取消终态、未知可对账、记录缺失、按确定性映射读取失败、非法标识、刷新不派发 |
| 真实本机服务进程 | 2 passed，约13.4秒（第21/22轮链路未受影响） |
| Ruff lint / format | 三份文件通过 |
| 既有失败独立性 | 该仓库 stores/brokers 目录的既有失败仍与本轮无关，未改动 |

### 局限与下一步

刷新入口尚未接入 Broker 的受监督循环（谁在何时刷新、失败如何退避、回报如何转成 `notify_order`），也没有恢复回执路径、真实回报推送与重连生命周期、真实账户、跨机与负载验收；BT01/BT02 与68项计划不因此新增正式 PASS。

下一轮把刷新入口接到 Broker 的回报投影：由显式循环查询并应用状态变化（去重、只对未终态订单刷新、失败退避），使策略能在不重连的情况下看到服务端的成交与撤单结果。
## 第24轮：Broker 受监督刷新与状态投影（2026-10-14）

从父仓 `b67e5cea` 继续。第23轮有了"按记录刷新"的投影函数，本轮把它接到真实 Broker／Store：由调用方显式驱动一次有界刷新，服务记录的状态变化经框架既有更新路径生效。

| 仓库 / 分支 | 交付 | 提交 |
|---|---|---|
| Backtrader / dev | `BtApiStore.refresh_managed_order_projection`、`BtApiBroker.refresh_managed_orders`、五份新增测试，精确3路径 | `e0e84b223` |
| bt_api_py / dev | 本记录 | 见本文件 Git 历史 |

### 行为与边界

Store 侧只做读取：向已附着的适配器索取该订单 intent 的当前投影，不派发、不撤单、不回落 legacy 路由；没有托管适配器或适配器不支持刷新时显式失败，而不是静默返回猜测值。Broker 侧 `refresh_managed_orders(limit=...)` 是**调用方调度的一次有界遍历**：只处理仍活动且带 `managed_intent_id` 的订单，把投影经既有 `_apply_order_update` 路径应用（含去重与通知），并跳过未变化的持久修订，因此同一状态不会被记两次。

刷新不会自行运行：既有提交、撤单与回报通知行为完全不变（有专门用例证明未显式调用时不会发生任何查询）。参数非法、Store 不支持刷新、适配器未附着都显式报错。

### 检查与交付

| 检查 | 结果 |
|---|---|
| 适配器与 Broker 定向 | 43个节点通过；新增覆盖新修订只应用一次、未变化即跳过、无托管 intent 的订单跳过、读不到记录时保持未知、非法 limit、未附着适配器、未调用即不刷新 |
| 真实本机服务进程 | 2 passed（第21/22轮链路未受影响） |
| 受改动文件回归 | `tests/unit/stores` 与 managed projection 套件：787 passed／28 failed／13 skipped；28 项为改动前既有失败，数量与改动前一致，未新增回归 |
| Ruff lint | 通过（两个既有大文件仅新增方法，未做全文件重排，避免无关 diff） |

### 局限与下一步

刷新循环的调度、退避、以及把状态变化转成策略可见的 `notify_order` 顺序仍未在生产路径装配（当前由调用方显式驱动）；没有恢复回执、真实回报推送、重连生命周期、真实账户、跨机与负载验收；BT01/BT02 与68项计划不因此新增正式 PASS。

下一轮把刷新循环接入一个显式的运行示例/装配（含退避与只刷新未终态订单），并在真实执行服务进程上验证策略能在不重连的情况下看到成交与撤单结果。
## 第25轮：AFI 授权订单状态读取（2026-10-14）

从父仓 `e72b7c90` 继续。第18/19轮让 AFI 能读授权账户与策略健康；本轮补上交易工作台需要的订单状态读取，仍走同一只读门禁。

| 仓库 / 分支 | 交付 | 提交 |
|---|---|---|
| ai-for-investor / dev | `OrderReadView` 中性合同、`OrderBinding` 与 `read_order`、登记表新增 order-status、七份新增测试，精确6路径 | `27b9e7a1` |
| bt_api_py / dev | 本记录 | 见本文件 Git 历史 |

### 行为与边界

订单视图携带持久状态、provider 订单标识、成交数量/均价/累计手续费、终态标志与未知原因，并使用与账户/健康视图相同的显式质量标记；`unavailable`／`not_collected` 视图**不得携带任何状态字段**，否则合同层直接拒绝，因此"读不到"不会被渲染成某个看起来正常的状态。状态必须是大写有限词表值。

读取只经部署授予的订单查询 scope：未登记 scope 直接拒绝（`SCOPE_NOT_CONFIGURED`），注册表拒绝（如 `SCOPE_DENIED`）按拒绝上报，传输失败或结果未知返回显式 `unavailable` 视图；回执字段集合、intent 标识一致性与状态取值都严格校验，畸形或不匹配的回执整体拒绝而不做部分投影。读取只查询台账，不派发、不撤单。

### 检查与交付

| 检查 | 结果 |
|---|---|
| 合同与适配器定向 | 26个节点通过（含 8 项订单读取新增：记录投影、缺失记录、未知可对账、降级与拒绝区分、五类畸形回执、合同拒绝、绑定校验、登记表条目） |
| HTTP 端点 | 12个节点通过（登记表端点断言更新为两项已迁移） |
| 真实本机服务进程 | 1 passed（策略健康链路未受影响） |
| Ruff lint / format | 六份文件通过 |

### 局限与下一步

订单读取的证据等级是 `offline`（登记表如实标注），没有真实执行服务进程、没有真实页面接线、没有写入链路、没有真实账户、跨机与负载验收；AFI01–AFI13 不因此新增正式 PASS。

下一轮把订单读取接到真实执行服务进程（复用第15/16轮的服务装配），把证据从 offline 提升到 local-process，并覆盖"记录推进到成交/撤单后读取到新状态"。
## 第26轮：AFI 订单读取的真实执行服务进程证据（2026-10-14）

从父仓 `e4830f31` 继续。第25轮交付了订单读取的合同与适配器；本轮把它接到真实执行服务进程，证据从 offline 提升到 local-process，并暴露了一处真实缺陷。

| 仓库 / 分支 | 交付 | 提交 |
|---|---|---|
| ai-for-investor / dev | 新 `tests/test_service_read_order_local_process.py`、`_order_view` 信封处理修复、登记表证据升级与两份测试更新，精确4路径 | `41911a2b` |
| bt_api_py / dev | 本记录 | 见本文件 Git 历史 |

### 真实进程证据链

真实 Windows spawn 启动执行服务进程（真实 ServiceHost、registry、SQLite 台账、准入门与 provider 适配器、CURVE），测试进程内建立真实策略客户端 runtime 提交订单、真实应用客户端 runtime 读取：

1. 提交前读取得到 `not_collected` 且不带任何状态字段。
2. 提交后读到 `ACKED`、provider 订单标识与 `is_terminal=false`。
3. 注入 provider 超时后读到 `UNKNOWN` 且带未知原因（可对账）。
4. 服务进程正常退出并用同一台账重启：旧注册被拒绝为 `STALE_EPOCH`（不静默复用），显式 `recover()` 后两条事实仍分别读为 `ACKED`／`UNKNOWN`，新代次派发计数为零。
5. 部署未授予的 scope 直接拒绝（`SCOPE_NOT_CONFIGURED`）。三个进程均正常退出零。

真实进程测试暴露的真实缺陷：`orders.query` 的线上形状是"注册表把处理器的回复嵌在调用结果里"（`{ok, code, result}`），而第25轮的 `_order_view` 只接受内层 `{found, record}`，导致真实链路一律被判为畸形回执。现已按信封解包，并区分"包裹的业务拒绝（拒绝上报）"与"包裹的处理器失败（显式不可用）"；离线用例也补上了这两种信封形状。

### 检查与交付

| 检查 | 结果 |
|---|---|
| 合同与适配器定向 | 28个节点通过（含信封解包两处新增与证据等级断言更新） |
| HTTP 端点 | 12个节点通过 |
| 真实本机服务进程 | 2 passed（策略健康链路 + 订单链路，约22秒） |
| Ruff lint / format | 六份文件通过 |

### 局限与下一步

仍无真实部署服务（`real-service`）、真实账户、页面接线与写入链路、AFI10/12 旧实现退役、AFI11 故障隔离、AFI02/03 组合视图；AFI01–AFI13 不因此新增正式 PASS。

下一轮把该只读适配器接到一个既有 AFI 只读页面／业务路由（先登记真实入口再改），使其成为产品可见能力，而不是仅测试可用的模块。
## 第27轮：AFI 订单只读端点（2026-10-14）

从父仓 `5d27398e` 继续。第26轮证明了订单读取在真实服务进程上可用；本轮把它与账户、策略健康一样暴露为真实只读端点，使该能力成为产品可见接口，而不只是模块能力。

| 仓库 / 分支 | 交付 | 提交 |
|---|---|---|
| ai-for-investor / dev | `GET /api/v1/service-read/orders/{intent_id}?scope_ref=...` 与五份端点测试，精确2路径 | `e1ff226b` |
| bt_api_py / dev | 本记录 | 见本文件 Git 历史 |

### 行为与边界

端点必须显式给出订单查询 scope_ref：订单只能经部署已授予的 scope 读取，不接受推断或默认 scope。回执沿用第25/26轮的显式质量语义：记录缺失返回 `not_collected` 且不带状态字段；未授予 scope 返回 404，注册表拒绝（如 `SCOPE_DENIED`）返回 403；传输失败或结果未知返回 200 + `unavailable` 与有限诊断码；未配置读取路径时返回 503。回执明确标注该状态来自执行台账，不是策略账本，也不授予任何操作权限。

### 检查与交付

| 检查 | 结果 |
|---|---|
| HTTP 端点 | 17个节点通过（新增 5 项：记录投影与权威说明、缺失记录、未授予 scope 404、拒绝 403 与降级 200、未配置 503） |
| AFI 全量（合同/适配器/端点/两条真实进程链路） | 47 passed，约21.7秒 |
| Ruff lint / format | 两份文件通过 |

### 局限与下一步

端点仍未接入既有页面（前端展示、路由与权限入口），也没有真实部署服务、真实账户、写入链路与旧实现退役；AFI01–AFI13 不因此新增正式 PASS。

下一轮登记并改造一个既有 AFI 只读入口（先记录当前真实路由与调用，再把它切到该端点），使其进入产品路径。
## 第28轮：刷新循环的调度与退避（2026-10-14）

从父仓 `928f49e5` 继续。第24轮有了 Broker 的一次有界刷新，本轮补上"何时刷新"：调度与退避逻辑，仍不拥有线程。

| 仓库 / 分支 | 交付 | 提交 |
|---|---|---|
| Backtrader / dev | 新 `backtrader/stores/service_refresh_loop.py` 与 9 项测试（含真实 Broker 驱动），精确3路径 | `fe427b27d` |
| bt_api_py / dev | 本记录 | 见本文件 Git 历史 |

### 行为与边界

`ManagedOrderRefreshLoop` 只回答"现在是否该刷新"并执行**至多一次有界遍历**：不建线程、不自行启动、不改变 Broker 既有行为。失败的一轮**不抛异常**而是退避（指数增长到上限），因此服务不可读只会降低刷新频率，不会打断调用方循环；失败同时通过计数器与有限错误码暴露，不会静默停滞。恢复的一轮把间隔重置为基础值并报告本轮应用的订单引用；未变化的持久修订仍然什么都不应用。配置（间隔、上限、退避系数、批量上限、时钟）在构造时校验，时钟可注入以便确定性验收。

### 检查与交付

| 检查 | 结果 |
|---|---|
| 调度与退避定向 | 8个节点通过：首次即可运行、未到点不调用、失败退避到上限、恢复重置并计数、无结果仍算成功尝试、异常按类型报码、配置校验、仅由调用方驱动 |
| 真实 Broker 驱动 | 1个节点通过：接受中的订单经真实 Store/Broker 在一次到期刷新后变为已完成，未到期与未变化修订均不重复应用 |
| 真实本机服务进程 | 2 passed（第21/22轮链路未受影响） |
| Ruff lint / format | 三份文件通过 |

### 局限与下一步

调度器仍未被生产装配显式接线（调用方需自行在事件循环或策略 tick 中驱动），也没有 `notify_order` 顺序保证、恢复回执、真实回报推送、真实账户、跨机与负载验收；BT01/BT02 与68项计划不因此新增正式 PASS。

下一轮把调度器接入一个显式的运行装配/示例（含驱动点与关闭顺序），并在真实执行服务进程上验证"不重连即可看到成交与撤单结果"的完整时序。
## 第30轮：成交记录经刷新调度投影到框架订单（2026-10-14）

从父仓 `eda6af6f` 继续。第28轮有了调度器、第21/22轮有了真实服务进程链路，本轮把两者接起来：合成 provider 报告一次有据成交，服务台账记录它，刷新调度把它投影成框架订单的完成状态。

| 仓库 / 分支 | 交付 | 提交 |
|---|---|---|
| Backtrader / dev | 真实进程测试的 provider 增加"有据成交"模式与调度驱动断言 | `0ed3e0c38` |
| bt_api_py / dev | 本记录 | 见本文件 Git 历史 |

### 真实进程证据链

服务端合成 provider 在收到指令后对有据成交返回 `FILLED` 观测（数量 2、均价 101.5）：

1. 该 intent 的框架订单在提交回执阶段即成为 `Completed`，成交数量与均价与记录一致，服务端只派发一次，legacy provider 提交/撤单计数为零。
2. 另一条记录未推进的挂单在多次刷新后仍保持 `Accepted` 且成交为零——刷新不会凭空制造成交。
3. 刷新循环报告零失败；服务端派发计数证明没有重放。

### 检查与交付

| 检查 | 结果 |
|---|---|
| 适配器与调度定向 | 52个节点通过 |
| 真实本机服务进程 | 2 passed，约14.2秒 |
| Ruff lint / format | 通过 |

一处需要如实记录的观察：真实链路中"记录未推进的挂单"之外的某条活动订单（服务端仍为 `UNKNOWN` 的那条）在刷新时会被投影一次当前状态。因此该断言不再要求整轮刷新返回空元组，而是检查具体不变量（挂单不变成成交、已成交订单不被重复记账、失败为零）。这条"UNKNOWN 订单在刷新时被再次投影"的行为本身是幂等的（状态未变），但值得在后续轮次明确其通知语义。

### 局限与下一步

仍无真实交易所账户、真实回报推送、`notify_order` 顺序保证、恢复回执、跨机与负载验收；BT01/BT02 与68项计划不因此新增正式 PASS。

下一轮明确"刷新投影到 `notify_order`"的通知语义（何时通知、重复投影是否抑制通知），并把该行为固化为用例。
## 第31轮：刷新投影的重复应用与通知语义（2026-10-14）

从父仓 `9699b85d` 继续。第30轮观察到"服务端仍为 UNKNOWN 的活动订单在刷新时会被再投影一次"，本轮把该行为固化为明确合同：**未变化的持久修订不得被再次应用**。

| 仓库 / 分支 | 交付 | 提交 |
|---|---|---|
| Backtrader / dev | 投影携带持久修订、Broker 记忆每个订单已应用的投影、鸭子类型适配器的隔离用例，精确3路径 | `fd7307841` |
| bt_api_py / dev | 本记录 | 见本文件 Git 历史 |

### 行为与边界

投影现在携带 `service_record_revision`（持久记录的 `updated_at_ns`），Broker 在处理刷新时记住每个订单最后一次应用的投影指纹（状态、修订、状态词、未知标志、成交数量与价格）。指纹相同即跳过：**同一持久修订不会被应用两次，策略也就不会为已经看到过的状态再收到一次通知**；修订推进且状态变化时正常应用。适配器自身的 replay 标记仍然保留，两层各自独立成立——本轮新增的用例用鸭子类型适配器（不做任何 replay 标记）单独验证 Broker 层这一保证。

同时确认了一条既有事实：`_apply_order_update` 在状态未变化时本来就不通知；因此"重复投影"的风险主要在状态被反复重放时，现已由指纹拦截。

### 检查与交付

| 检查 | 结果 |
|---|---|
| 适配器与调度定向 | 53个节点通过（含新增的隔离用例） |
| 真实本机服务进程 | 2 passed（约14.4秒） |
| 受改动文件回归 | `tests/unit/stores` 与 managed projection 套件：797 passed／28 failed／13 skipped；28 项与改动前一致，未新增回归 |
| Ruff lint / format | 通过（两个既有大文件仅新增/修改局部逻辑，未做全文件重排） |

### 局限与下一步

通知语义只在离线与合成 provider 下验证：仍无真实回报推送、真实账户、跨机与负载验收，也没有恢复回执路径；BT01/BT02 与68项计划不因此新增正式 PASS。

下一轮把刷新循环与"服务端事实推进"的通知时序纳入真实进程场景（例如在真实服务进程上验证：记录推进 → 刷新 → 策略只收到一次状态通知），并补上关闭顺序的显式装配。

## 第32轮：接续盘点与真实查询预算（2026-10-15）

按用户“先分析其他研发人员完成进度，再继续”的要求，核对现有 dev 和第14–31轮提交。
SDK `5b21feb7`、Execution `9f08694`、Backtrader `37fa5b8ae`、AFI `e1ff226b`
为接续基线；第14轮早已由 `c0cd400b` 交付，不重复开发。SDK 和子包干净，Backtrader
原有 CTP 改动/删除路径 `0` 与 AFI 原有6改3增保留。三路独立只读审查分别核对 SDK、
Backtrader 和 AFI，没有执行历史测试或真实账户动作。

核对修正了验收表：MON01 的实际缺口是正常业务 producer 接持久事件链，而非附加真实账户/
双机/负载条件；源码导入拦截不等于 MIG04 发行安装；AFI HTTP 模块尚无应用生命周期、
用户到 scope 授权和页面接线。Backtrader `37fa5b8ae` 的通知记录器在即时成交后才安装，
且允许零成交通知，故该测试不能证明延后成交经刷新到策略回调。原提交保留，补充更强验证。

同时修复一处多订单运行缺陷：`refresh_managed_orders(limit=32)` 原来按已应用投影计数，
不变/重复/空投影不消耗预算，可能一轮查询全部挂单。现在每次实际 adapter 查询都计数，
无论结果是否变化；按持久的轮转队列访问，调用前推进位置，失败后仍让后续订单得到访问。
每轮删除终态/移除/无 managed ID 的项并加入新增项，保留订单身份和既有修订去重逻辑。
只限制每轮 RPC 次数；没有声称总订单扫描的 CPU/内存或单次 RPC 用时有新的硬上限。

| 仓库 / 分支 | 精确范围 | 提交 |
|---|---|---|
| Backtrader / dev | `backtrader/brokers/btapibroker.py` 局部修改、`tests/unit/brokers/test_managed_refresh_budget.py` | `82c0b4fd0` |
| bt_api_py / dev | 验收状态汇总与本记录 | 见本文件 Git 历史 |

Root 执行 `pytest --noconftest -p no:asyncio -p no:cacheprovider -q
tests/unit/brokers/test_managed_refresh_budget.py tests/unit/stores/test_service_execution_adapter.py
-k refresh`：**21 passed / 29 deselected**（5项新增、16项受影响刷新检查），4.60秒，
保留一条已有 asyncio 配置警告。独立静态复核无阻断问题；新增测试 Ruff 检查通过，
格式整理前后 AST 相同，未为交付重复运行验收。测试使用真实 Broker/Store 与可控适配器，
属于本地组件证据，不是 provider、真实账户或68项正式用例通过。

下轮补真实服务进程中的延后成交与策略通知；随后处理读取失败与订单业务状态混淆、
刷新退避及显式生产装配。迭代10保持未完成，不使用测试数量充当正式 PASS 数。

## 第33轮：读取故障保留订单、退避与真实策略通知（2026-10-15）

Backtrader 在现有 dev `82c0b4fd0` 后提交 `335e5d358`，精确7路径：Broker、服务执行
适配器、刷新调度器及4份定向测试文件。SDK 仅更新本记录与验收汇总；其他已有修改保留。

修复了三个正常刷新问题：

- 查询遭到 `SCOPE_DENIED` 时，旧适配器把读取拒绝转换成订单拒绝；现在任何失败的读取
  或已知记录消失都产生有限的 `ServiceExecutionReadError`，Broker 保留业务状态、成交量、
  价格和身份，记录读取不可用及不确定标记，调度器统计失败并退避。不发新订单、不切 direct。
- 同修订 ACKED/部分成交读取恢复后，在重复投影检查之前清除读取故障；有效台账 `UNKNOWN`
  仍是业务未知，不算查询失败。本轮途中已经应用的订单引用保留在错误与统计中；失败调用
  返回空元组，调用者可从 `last_applied_refs` 查看已经发生的投影。数值配置拒绝 bool、NaN、
  infinity 和转浮点溢出。
- 持久回执的 `average_price` 是累计均价。投影现同时传递 `avg_price`，让 Broker 根据前后
  累计成交额计算增量价格；先成交1份@100.5、再累计2份@101.5时，第二份为102.5，最终
  均价101.5。原先仅传 `price` 会把累计均价误当成第二份成交价。

真实本机进程验证新增两个场景：执行服务接收正常 SDK 提交并持久 ACKED，真实 Cerebro
策略先收到 Accepted；测试宿主随后通过公共 store API 和同一 writer 的有效租约注入合成
部分成交，再分别注入最终成交或部分成交后的撤单。策略的真正 `notify_order` 回调序列严格
为 Accepted → Partial → Completed/Canceled，累计数量和价格准确，重复读取不再通知。
两条路径各只派发一次，legacy 派发为零；Store 关闭、runtime 进入 closed 和服务进程正常
退出均有断言。本测试未额外核对 runtime 的远端注销不确定计数。这里是测试宿主模拟
provider 回报，未证明真实交易所回调适配器。

Root 运行五份受影响测试文件（`--noconftest -p no:asyncio -p no:cacheprovider`）：
`test_service_execution_adapter.py`、`test_service_refresh_loop.py`、
`test_managed_refresh_budget.py`、`test_service_refresh_notification_local_process.py`、
`test_service_execution_adapter_local_process.py`，**68 passed / 29.53秒**，只有原有 asyncio
配置警告。两个新参数化真实进程场景与原服务进程回归均通过。源码5路径与进程测试2路径
分别完成独立静态复核；六份适配器/调度器/测试文件 Ruff 检查通过，Broker 仅局部编辑。
两份测试的格式整理前后 AST 相同，没有重跑已通过的验收。

这是本轮68项测试，不是正式计划68案例全部通过。刷新仍由策略显式驱动，没有生产自动
装配；恢复回执/游标、风险预留闭环、正常业务事件到 Monitor、AFI 应用接线、发行、负载及
双机/venue 等仍待完成。下一轮优先把有界刷新接入显式生命周期，并继续补正常服务链路。


## 第34轮：执行会话接入普通 Cerebro 生命周期（2026-10-15）

在现有 Backtrader dev `335e5d358` 上完成并提交 `833aff2172548d10d749670b5152b43efa270e09`，
精确6路径：新增 `ServiceExecutionSession`、Broker 局部 hook、两份定向测试、使用说明和
AGENTS 事实条目。SDK 只更新本记录及验收汇总；原有 CTP 改动、删除路径 `0`、AFI 改动保留。

新的显式入口 `ServiceExecutionSession(runtime, ...).run(cerebro)` 独占尚未启动的 SDK
runtime 的生命周期。构造客户端和适配器不连接服务；单次 run 在启动 Store 之前注册并核对
唯一、必需的订单提交/撤单和查询路由，要求两者完整 WireScope 相同。不额外强制 SDK 可选的
run_id，也不新增 enabled 开关或配置 schema。配置继续使用 `parse_client_config`。

Broker 每次正常轮询先维护租约，再驱动到期的有界刷新；读取退避不会拖慢维护调用。必需租约
维护失败直接退出运行，不自动恢复注册、重放订单或切 direct。Broker.start 拒绝重新启动已结束
会话；channel、优化模式、只读代理和外部管理 Store 在资源启动前拒绝。本轮普通 bar 入口可供
部署调用，既有 live examples 与配置 runner 尚未批量切换，跨账户订单组也未因此完成。

退出时先停止轮询、执行原 Broker/Store 停止政策，再关闭 runtime。通用 Cerebro 在准备、策略
构造/start/stop 失败时可能漏掉 Broker.stop，本入口在未尝试停止时补一次；已经尝试失败则不重复
交易收尾。Broker 停止原主体抽取后 AST 完全相同，没有新增撤单或平仓政策。新 wrapper 记录本次
停止的异常、FAIL/INCOMPLETE 摘要；原运行异常优先保留。清理报告区别关闭失败和仅注销不确定，
后者不能解释为远端注册已释放；运行没有原异常时，清理不完整会抛错。没有配置的 Broker 不导入
SDK/四个服务组件，也不创建会话。

| 检查 | 结果 |
|---|---|
| 最终受影响批次 | 15个新生命周期节点、2个真实本机进程节点、13个既有 Broker 启停/轮询/恢复收尾节点；首次29 passed / 1 failed，18.24秒 |
| 唯一失败修复 | 新 fallback-stop 测试夹具未启动 Broker，真实 stop 正确返回 None，导致夹具解包报错；补启动后只重跑该节点，1 passed / 4.06秒。生产源码未因此改变，合计30个唯一节点均通过 |
| 真实正常运行 | SDK/CURVE/ServiceHost/SQLite/Cerebro；策略不调用 refresh/start/maintain，Accepted → Partial → Completed，累计均价正确，重复部分成交读取不重复通知；实际注册租约期限在正常 maintain 后推进 |
| 真实启动异常 | Strategy.start 抛出的同一异常对象保留；Store 断开、runtime closed、cleanup_failures=0、unregister_uncertainties=0；宿主收到正常关闭回执并 exit 0，无 terminate/kill |
| 冷进程与配置 | 拒绝导入 SDK/四组件的冷进程中普通 Broker 构造/stop 正常；使用说明的 schema-6 双绑定 YAML 经实际 parser 校验 |
| 独立审查与格式 | 源码生命周期与集成测试/说明分别静态复核；发现的停止报告、共享 Store、线程边界问题已修复。3份新 Python 文件 Ruff lint/format 通过；格式整理前后 AST 相同 |

命令使用 `C:/anaconda3/python.exe -m pytest --noconftest -p no:asyncio -p no:cacheprovider`；
批次保留1条既有 asyncio 配置警告。初版2个进程场景14.01秒通过；独立审查后改动停止路径，
才纳入最终受影响批次重验，没有为归档重跑已通过的套件。Root stage/commit/post 验证精确6路径、
正确父提交、空 index 和本轮路径干净，未提交其他修改。

证据为本机合成 provider 生命周期与订单通知：测试控制端通过公共台账 API 注入回报，客户端
使用受控单调时钟触发实际续租；不是交易所回报适配器或真实账户验收。入口不创建维护线程，
长时间阻塞的 feed/用户回调仍会拖延续租；每轮查询次数有界，未增加整个批次的墙钟硬上限。
BT01/BT02 保持部分状态，未增加68项正式 PASS。下一轮继续正常业务事件到 Monitor 的持久投递
接线，再补服务读写统一装配与 AFI 应用生命周期/授权；不另建平行验收框架。


## 第35轮：Execution 业务日志到独立 Monitor，关闭 MON01（2026-10-15）

继续保留其他研发人员已交付的代码。在现有 SDK dev `e8cd0ece` 上新增显式业务事件投递器，
Execution 子包先在 dev `9f086941` 上提交只读 journal reader 为
`fbbb10ecb22dae0633faebf61797c42d50b4445e`。本轮不修改 Monitor、Gateway、Risk、Backtrader
或 AFI 的业务源码，不动历史账户/进程验收。SDK 提交号见本记录 Git 历史。

### 实现与边界

`ExecutionJournalReader` 直接以 SQLite `mode=ro` 和经读回确认的 `query_only` 打开已有库，
不调用会迁移 schema 的 store 构造器，不获取 writer lease。订单与撤单按精确 ExecutionScope
分开分页；SQL 限定字段长度和类型、完全不选择 `payload_json`。每页最多1000条和2 MiB
选取文本字段，检查文件身份、journal incarnation 与行代次，保留 scope 过滤产生的序号间隙。
这里没有声称 WAL 模式的 SQLite sidecar 在物理层面绝对零写入。

`ServiceExecutionMonitorRelay` 借用已注册的 service runtime 与 reader，显式 `poll(limit=32)`
才发送；整轮上限128次 RPC，两个流跨轮轮转，发送前推进轮转位置。它在独立进程装配，不接进
订单回调、ServiceHost maintenance 或 readiness。未配置精确 `clients.monitor /
upstream.telemetry` 绑定时，纯配置检查返回 false，不创建可选资源，不新增 enabled 开关。

源 journal 已与 Execution 业务状态同事务提交，本轮不再创建第二份本地事件队列。独立 SQLite
消费游标按目的地加本地源通道、日志代次、精确 scope、流和投影版本命名。consumer_id 在同一
源代次的进程/runtime/session 重启间稳定，新代次另建通道；它不会发送到 Monitor。源 sequence
与远端回执 sequence 独立，后者不能替代源游标。每条远端持久回执确认后，
复核此次源行仍相同，才用短 CAS 事务推进游标；RPC 期间不持有源/游标数据库事务。当前游标的
源行消失、内容改变或同代次日志回退会停止投递，不清零游标。并发同事件确认幂等，较新或冲突
确认不能回退游标；发送失败/回执不确定/本地写失败保留同事件重放。游标库限制4096个命名空间
和2048个SQLite页，不代表源 journal 或长期磁盘占用已有完整治理。

投影仅含固定生命周期元数据、精确纳秒时间和可信的 provider/环境/账户/策略/交易日归属。
外层类型是 `execution.lifecycle` 与 `execution.cancellation`；原业务事件类型作为有界元数据
保留，不解释金额/手续费/余额/PnL。账户和可选策略必须与已授权 WireScope 匹配；拒绝本轮无法
过滤的多账户集合、portfolio、group、leg、manual book 限制。Monitor 外层 source_event_id 是
确定性的投影 ID，原 Execution UUID 保存在 payload 内，二者在测试与文档中明确区分。

使用与关闭顺序见 `docs/guides/execution-monitor-relay.md`。relay.close 不关闭借用的 reader/
runtime；runtime 恢复注册后需显式 rebind，稳定目标变化拒绝继承旧游标。未交付新的独立 CLI/
supervisor、源日志 retention/压缩/磁盘配额、Gateway/Risk 全量业务 producer 或组合风控规则。

### 本轮验收

| 检查 | 结果与证据 |
|---|---|
| Execution reader | 作者在生产 store/facade 夹具上执行一次：5 passed / 0.96秒；包括两流跨 scope 稀疏分页、无 payload 读取、坏字段、缺文件、代次/文件替换、关闭；独立静态复核通过 |
| SDK relay 定向 | 初次17节点：14 passed / 3 failed，4.08秒。三个失败是夹具/断言问题：轮转后误期望下一条仍是 execution、未真实制造稀疏序号、同账户使用不同 writer ID。修复后连 scope 边界9 passed / 1.55秒；增加两项源变更/CAS回归后5 passed / 1.35秒，其中3项与前批重叠。最终24个唯一节点通过，不把各批次数相加 |
| 正常业务真实进程链 | Root `0bf0dd` / `8786f9`：新增集成文件1 passed / 12.42秒；真实 Windows spawn、CURVE、registry、SQLite、SDK submit/cancel、Execution reader/relay 与独立 Monitor |
| 导入与配置 | Root 冷进程阻止 Execution/Monitor/Gateway/Risk/transport/zmq 导入，加载未配置 Monitor 的既有 service YAML并检查返回 false；没有领域包加载。不是隔离 wheel 安装验收 |
| 格式与复核 | 新 Python 文件 Ruff lint/format通过；reader格式前后AST一致。源码和集成分别独立静态审查；Root保留精确范围、现有dev与子包先提交顺序 |

SDK 各批保留1条既有 `asyncio_default_fixture_loop_scope` 配置警告。Reader为作者执行，真实进程
节点为Root执行；没有把作者结果冒称Root重跑，也未重复第12–14轮已接受套件。前3项单位夹具问题
归于本轮测试设置，不能归咎 provider；独立源码审查还修正了小预算轮转、误配游标库先修改后拒绝、
源行在RPC期间变化仍确认以及不支持scope的边界。

真实进程场景先在 Monitor 未启动时通过正常 SDK 提交订单、撤单；relay 注册失败未创建游标库，
随后第二笔订单仍只派发一次。使用真实业务提交后的元数据，测试仅将 payload_json 改为非法JSON
哨兵以证明 reader 不读取它，不伪造 outbox 行。Monitor 上线后，第一条真实 append 已落盘并返回
合法回执，测试注入本地游标写失败，观察 remote_delivered=1 / checkpointed=0。正常关闭并重启
Monitor 与 relay、保留两端库，补传订单和撤单两流，首个远端事件 ID/sequence 不变，总数不重复，
游标追上源日志末端，再 poll 为空。执行服务 provider 调用计数始终不增。

所有场景进程正常 close / exit 0，没有 terminate/kill；relay runtime 的 cleanup_failures=0、
unregister_uncertainties=0。离线注册失败的临时runtime也正常关闭。此处只有一条活跃scope，另一个
账户scope用于验证reader返回空；两个活跃策略同名intent的归属隔离由组件测试覆盖。本机集成证明
“远端确认后本地游标写失败”的恢复，不声称真实网络丢回复、双活scope端到端、双机或真实账户验收。

### 正式用例裁定

按正式计划第10节的 MON01 原文，合并第12–14轮已接受的持久入口/重投递与独立策略SDK有界遥测
证据，本轮正常 Execution 业务 producer/outbox/sink 补齐最后缺口：**MON01 正式 PASS，当前1/68**。
第13轮相关sink及测试相对 `89022855`、第14轮遥测源码/测试相对 `c0cd400b` 无差异，Monitor仍为
已接受 `24516efc`，没有为裁定重跑历史套件。此前状态汇总把Gateway/Risk所有producer都列为MON01
门槛，混入了M1/P6更大范围；本轮按正式条目校准，不修改正式要求，也不以30个本轮测试节点替代
正式案例数。跨包业务生产者全量覆盖、监控规则和控制闭环仍未完成。

MON02 仅新增“Monitor离线不阻塞非监控必需订单路径”的部分证据，授权控制/冻结恢复未实现；
MON03 仍缺系统行情观测及完整多scope授权矩阵。其余正式用例状态保持原结论。下一步继续按正常
业务入口推进 AFI 应用生命周期与 scope 授权、Backtrader 服务读写统一装配及未完成的账户/组准入，
不恢复 Optional16，也不新增平行验收基础设施。

## 第36轮：AFI 响应模型冷导入修复与生产接线边界核对（2026-10-15）

在现有 AFI dev `e1ff226b07768504de8f405ccd4b7407442a6d3f` 上完成两路径修复，提交为
`65cba4c18211592d5b0c8184a336d45905a55a8c`。本轮仅调整
`src/backend/app/schemas/market_data_platform.py` 的响应模型声明顺序，并新增
`src/backend/tests/test_market_data_capability_schema_import.py`。未另建工作区。

`MarketDataCapabilitiesResponse` 原来先于它引用的 `MarketDataCapabilityStateResponse`
声明，在冷进程直接构造 FastAPI response_model 时可能保留未解析引用。现把被引用类型放到
前面；Root AST 核对确认两个类的字段/验证器与其他语句均未改变，仅声明顺序不同。

### 验收与提交

- Root `1e609d` / `eff605`：真实 schema 在冷子进程导入后立即注册 FastAPI APIRouter，
  不先验证数据或调用 model_rebuild；1 passed，7.04秒，Python退出0。
- 命令为 `C:/anaconda3/python.exe -m pytest --noconftest -p no:cacheprovider -p no:asyncio
  src/backend/tests/test_market_data_capability_schema_import.py -q`。4条已知配置警告分别为
  asyncio_default_fixture_loop_scope、asyncio_mode、timeout、timeout_method。
- 新测试只使用临时目录与合成设置。子进程审计拒绝 subprocess.Popen、os.system 和 socket
  connect/bind；Windows 版本查询使用标准库对 PermissionError 的既有回退，不伪造系统版本。
- 独立静态审查通过；Root Ruff lint/format、AST 等价与 whitespace 检查通过。
- Root stage `eca0a2`、commit `8f971d`、post `bbbf19` 验证 dev、父提交、精确两路径、
  本轮文件干净和空暂存区；AFI 原有6项修改、3项新增逐项哈希不变。未重复通过的测试做归档。

本轮诊断曾出现三个未隔离的测试子进程超时，以及一次 Root 宽范围冷导入超时。原因已通过
公开调用栈定位：app 初始化导入数据库/SQLAlchemy，触发 platform 的 Windows 版本查询；
本机 HKLM Command Processor AutoRun 无条件激活 Conda，引起 cmd/Python 递归。
仅保留 CONDA_SHLVL 并不能修复它。Root 按精确来源和创建时间清理了这些诊断产生的进程族，
没有触碰历史验收保留进程，也未修改系统注册表或 Conda 配置。最终定向测试使用上述拒绝外部
操作的保护；失败属于本轮测试环境/设置，不是交易所或业务验收失败。不声称诊断全程无强制清理。

### 生产装配尚缺的条件

只读审查确认 `configure_service_read` 仍仅由测试调用，生产 app 无对应配置和 lifespan 接线。
现有路由丢弃 current_user，再调用全局客户端；如果直接启用，会让已认证用户共享全部已配置
scope。异步路由中的同步 RPC 还会阻塞事件循环，而 SDK runtime 具有固定 owner 线程约束，
不能简单把每个请求分散到线程池。

下一轮需由服务端可信配置把认证 TokenPayload.sub 映射到 principal/delegate 和允许的 scope，
先拒绝越权 selector，再在固定 owner 线程创建、维护、调用并关闭 runtime；所有 identity 和
服务端 grant 必须来自可信装配。未配置时保持关闭，不增加策略内嵌服务。AccountBinding 的
scope_ref 也须与实际注册授权相符，不能仅凭字符串字段推定权限。前端消费者与完整应用接线
仍待交付。

证据等级仅为真实 schema 冷导入与路由 response_model 注册；没有运行完整 app startup，
没有 HTTP→SDK→服务的用户授权链验收。AFI01 仍为部分，正式 PASS 保持 MON01、合计1/68。

## 第37轮：通信 HWM 与并发边界验收，关闭 TRN01（2026-10-15）

用户要求增加并行加快交付后，将 AFI 授权/线程/会话/集成与 SDK Gateway/通信拆为六条互不重叠
的实现线，Root统一整合和验收。本轮先关闭现有通信功能的两个证据缺口，未新增通信后端或框架。

transport 子包在现有 dev `39b34c4cf5b1d6ba9bac9b8c66ad4115c16043c9` 上仅修改
`tests/test_service_v2.py`，提交 `fef4964fd4843df80fd85a97beaca31f9f4352ba`。新增两个真实
CURVE loopback 节点：读取两端 owner 线程上的 live socket SNDHWM/RCVHWM，确认服务端3、
客户端5分别生效并完成关联正确的收发；在首个请求已进入服务处理器时从竞争线程调用同一客户端，
确认 owner-thread 守卫拒绝、处理器只执行首个请求、原回复关联正确且线程/socket正常关闭。
这是配置生效和单owner并发边界，不声称 HWM 的平台实际队列容量等于配置值或完成饱和负载验收。

Root `9c243c`：两个新增节点2 passed / 0.43秒 / Python退出0，保留2条已知Windows Proactor/
pyzmq selector兼容警告。测试进程禁止 shell命令创建以避开本机cmd AutoRun；真实socket与线程
不拦截。作者和Root均核对窄diff，Ruff lint/format、git diff --check通过。Root stage `6114aa`、
commit `6bfe1a`、post `2cdcf0` 确认正确父提交、精确单路径和子包干净，未重复通过的测试归档。

TRN01其他条件继承已有执行记录：第02轮transport完整包30 passed（`3834c511`），包括晚到
回复、ROUTER身份复用的密封回复隔离、UNKNOWN/NOT_SENT与尺寸；SDK14项包含配置驱动的
真实spawn注册/读取/续租/关闭。后续transport修改过close/retire路径，不能称源码完全不变；
第03轮9+2项和`251df839`交付记录的6项已在更新源码上验证清理、正常CURVE、NOT_SENT与
UNKNOWN超时退役。因此复用其有效证据，未无条件重跑历史套件。

正式计划 TRN01 要求的配置驱动收发、晚到、UNKNOWN、尺寸/HWM/并发与正常关闭已有上述组合
证据，裁定 **TRN01 PASS**。当前正式通过 MON01、TRN01，合计 **2/68**；剩余66项继续各自
验收。TRN02行情gap、TRN03完整撤权矩阵、双机、100策略负载和provider验收不在本轮通过范围。

## 第38轮：同账户十策略共享行情与明确拒绝，关闭 GW01（2026-10-15）

本轮在已有共享行情实现上修复确定拒绝被错误投影为 UNKNOWN 的缺陷，并补齐策略与账户的可信
关联。Gateway 子包父提交 `08222008250f6d4e1c8ef5e832f10987f0a19c50`，只修改 market_hub
与对应测试；SDK只修改 service_components、service_registry 和对应registry/market集成测试。
子包先提交，父仓只更新该gitlink、本轮四路径和两份进度文档；并行AFI账户scope改动不混入。

GatewayMarketRegistration 新增可选 account_ref，由服务注册授权后的 context.scope传入。
服务检查请求与登记的账户一致；账号只用于归属校验，不加入公共行情key或分割去重流。
默认None的公共注册兼容。两个不同账号可关联同一允许公开的行情流，但这不是私有账户信息转发。

SDK仅在market.subscribe、精确的GatewayMarketHubError/GatewayMarketServiceError类型、
MARKET_KEY_NOT_EXPORTED或MARKET_KEY_DENIED两个错误码下，转成可信的拒绝异常；Registry
再限定service.market_source/market.subscribe及精确异常类型，返回SCOPE_DENIED。任意异常的
同名code或其他操作仍走HANDLER_FAILED/UNKNOWN，不能据错误字符串推定无业务副作用。

本PUB endpoint要求每个授权principal的key universe一致，不支持在同一公开endpoint混合不同
权限。实际测试拒绝的是不在导出universe的key；不构造不可达的principal级PUB过滤假场景。

Root `3103c5` / `7bf150`：三项3 passed / 39.91秒 / Python退出0，1条已有asyncio配置警告。
两项定向检查覆盖精确拒绝边界、跨账户公共流共享与错账号零副作用；第三项复用并更新已有真实
Windows spawn十策略入口，核对十个不同strategy/principal都关联同一账号、只打开一个上游。
越权订阅返回精确SCOPE_DENIED，前后upstream/registration/pending release及provider计数不变；
继续验证一方退出其余继续、崩溃租约回收及最后一次释放。包含显式崩溃故障注入，未把它误写成
所有策略均正常退出。测试末端provider为可计数合成实现，真实socket/CURVE/注册/发布与策略
进程均走现有生产入口。受影响的已有测试本轮只执行一次，没有重跑其它已接受套件。

六份源码/测试Ruff和两仓git diff --check通过，Root复核有限错误映射及账户归属与公开流边界。
正式GW01的同账户十策略、一次上游、退出隔离、最后释放和越权明确拒绝条件齐备，裁定
**GW01 PASS**。当前 MON01、TRN01、GW01，合计 **3/68**；十账户/一百策略GW02、完整
私有账户转发和多权限endpoint/撤权矩阵仍需单独完成。

## 第39轮：AFI 按用户授权与固定线程会话，完成只读链路集成（2026-10-15）

本轮将 AFI worker、授权路由、SDK session 与真实服务集成拆为四条并行实现线；另外两条
Gateway/通信线已分别在第37、38轮提交。Root统一验证实际边界、集成和分仓提交，未另建
worktree，也未扩大 Optional16 或新增平行验收框架。

### 交付与职责

- SDK dev `84710c27685bea154b9a6a48fc72f7892934abd9`，父提交 `4d5cebf52`，精确两路径：
  `bt_api_py/service_account.py` 及对应 unit test。ServiceAccountClient 新增可选
  expected_scope_ref，在 refresh 续租后取得实际 binding，再核对 scope，错配时在 snapshot RPC
  之前明确拒绝；默认 None 保持现有调用兼容。
- AFI dev `117255edd3e9266d09123469b2a457c27b4ee3a0`，父提交 `65cba4c1`，精确11路径：
  API/client，新增 access/session/worker，五份对应测试，以及现有服务只读部署基线。
- HTTP 使用真实 get_current_user 解析的 TokenPayload.sub，查可信不可变授权目录。每个 subject
  绑定独立 worker 与已获服务端授权的 APPLICATION_CLIENT identity；请求头/query 中的身份字段
  不能改变它。账户、订单scope、监控scope分别精确授权；未知用户与未授权资源均返回403。
- worker 在一个固定非daemon线程内创建、启动、维护、读取和关闭session/runtime；异步路由只
  排队等待。有界队列、关闭优先、待处理请求取消、维护到期与启动失败清理均有定向检查。
  session 验证精确 active mount/scope/operation，以及账户/策略归属；关闭失败显式报错。
- 只读client关闭缓存account facade，保留失败对象，拒绝后续读取，不关闭借用的runtime；
  session负责其拥有的runtime。配置目录本身不创建身份、不授予服务权限、不管理生命周期。

### 定向验收

1. SDK Root `130e6d`：2 passed / 0.84秒 / exit0，1条既有配置warning，覆盖匹配与续租后
   scope错配；错配时snapshot请求数为0。此后 stage `2220d3`、commit/post `7bc967`
   验证精确两路径和干净索引。
2. AFI worker 共11个唯一节点通过：Root `216296` 首批9通过、2个fixture失败；
   修正Windows时钟分辨率下维护等待及factory启动同步后，`0fb707` 仅重跑两项，2 passed /
   0.32秒 / exit0。更早 `3d12b2` 的过宽socket守卫误拒绝Windows asyncio self-pipe；
   这些均属本轮测试设置问题，未计作业务或交易所失败，没有重跑已通过节点。
3. AFI access/API/session：Root `42a148` / `db45ae`，35 passed / 2.88秒 / exit0。
   包括精确subject授权、跨用户/伪造字段拒绝、scope与identity校验、关闭失败和未配置行为。
4. 新增集成 Root `59151a` / `674b68`，1 passed / 10.11秒 / exit0：
   真实JWT→最小FastAPI的ASGI HTTP调用→双用户独立owner-thread SDK→独立本机CURVE
   Execution ServiceHost/SQLite日志。两用户读到各自订单；跨用户403且worker读取数不增；
   独立验证服务端拒绝未授予identity与跨scope注册；合成provider仅收到最初两次订单派发。
   owner线程、runtime和服务进程正常关闭，cleanup/unregister无不确定性。
5. AFI各批保留4条既有pytest配置warning，API/session及集成另有既有Pydantic model_id
   warning。Python 3.11.5，关闭自动插件加载，--noconftest、no:asyncio、no:cacheprovider；
   冷导入前禁用dotenv并提供合成设置，限制cmd/os.system以避开已定位的Conda AutoRun。
   未修改系统配置。测试使用真实loopback/CURVE；没有把网络和线程整体替换成fake。
6. 独立静态复核无阻塞；10份Python文件Ruff通过，最后三文件仅格式/注释变化，Root AST
   核对行为相同。AFI stage `a3822d`、commit `076d52`、post `d5c589` 验证精确11路径、
   正确dev/父提交、空索引和原有9项无关文件哈希不变；已通过测试没有为了提交再次执行。

本轮共47个AFI唯一节点与2个SDK节点通过，不等于49个正式验收案例。ASGI调用未启动网络HTTP
server，Execution末端为合成provider；没有真实账户、双机或完整AFI应用startup证据。

### 当前剩余与下一轮

main仍缺从可信部署配置装配目录/worker的lifespan入口，默认未配置时返回503、不创建服务连接；
文档提供显式lifespan示例且用try/finally关闭。前端消费者、组合成员与版本/归属、多币种和FX、
审批写入、分析worker及旧实现退役未完成。AFI01仍为部分，正式PASS保持
**MON01/TRN01/GW01，3/68**。下一轮优先接上可信配置与正常应用生命周期，再接实际页面；
Backtrader普通runner/examples装配与账户/组风险准入按各自边界并行，不让策略内嵌四个服务。

## 第40轮：实际存储和 owner 绑定，关闭 GW04（2026-10-15）

Gateway 在现有 dev `20a3983` 上仅新增 `tests/test_router_storage_binding.py`，
已提交为 `59b164ab7f89c6428ae6546103aad6058dab4c16`。生产 router、authority 和
SQLite 身份校验代码没有变动。父仓只更新该 gitlink 与两份进度文件，其他并行开发保留。

四个新节点通过真实 SQLite 和现有 GatewayCommandRouter/GatewayAccountWriterAuthority
验证：同文件绑定可调用一次合成 executor，并实际查到持久 owner/epoch 与命令记录；
异文件绑定在 router schema 写入前拒绝；同文件但未取得本地 lease，或持有已被新 owner
代次替换的旧 lease 时拒绝，executor 调用数和 action claim 数均为零。没有修改 lease
私有状态或把假 authority 当作实际绑定。正常返回仍标为 RETURNED_UNVERIFIED，不冒充交易所确认。

Root `b6527e`：`C:/anaconda3/python.exe -m pytest --noconftest -p no:cacheprovider -q
tests/test_router_storage_binding.py`，显式 base/gateway 源路径、关闭插件自动加载，
**4 passed / 0.46秒 / exit0，无warning**。Ruff通过；格式修正由AST相等检查确认无语义变化，
未为交付重复测试。独立只读审查确认正式计划第754行要求覆盖齐全；未执行真实provider、
双机或hardlink别名场景。后者不是该条目的已验收范围。

裁定 **GW04 PASS**，当前 MON01/TRN01/GW01/GW04，合计 **4/68**。提交后Gateway索引
为空；该记录不修改既有真实账户、历史保留进程或其它正式用例结论。

## 第41轮：撤单期间成交的真实状态交错，关闭 EXE01（2026-10-15）

Execution 从现有 dev `fbbb10ecb22dae0633faebf61797c42d50b4445e` 开始，仅修改
`tests/test_service_order_entry.py`，新增两项正式条目缺失的竞态回归。生产代码不变。
使用真实 ExecutionOrderEntryService、ManagedExecutionFacade 和 SqliteExecutionStore，
合成provider在cancel端口调用期间通过公开 record_provider_observation 写入成交事实：

- 部分成交后取消成功，订单最终 CANCELLED，保留数量0.75、均价50010和累计费用0.25。
- 完全成交后provider拒绝取消，取消记录 REJECTED、订单保持 FILLED，保留数量2、均价50100
  和累计费用0.75；不能将已成交订单降级为取消。

两例均重放同一submit/cancel ID，核对provider提交与撤单各只调用一次。测试是确定性时序
交错，不宣称多线程压力或真实venue回调；正式计划第755行允许真实状态机/存储配合成provider。

作者一次新节点检查：`C:/anaconda3/python.exe -m pytest --noconftest -q` 后接
`tests/test_service_order_entry.py::test_cancel_winning_after_a_partial_fill_preserves_fill_and_fee`
与 `tests/test_service_order_entry.py::test_full_fill_during_cancel_rejects_cancel_without_downgrading_order`，
关闭pytest插件自动加载，**2 passed / 0.30秒 / exit0，无warning**。Root复核精确diff，
Ruff lint/format及diff检查通过。独立只读审查确认与已有同内容重复和异内容冲突用例合起来
满足EXE01；相关service/facade/cancellation/store源码自已接受`9f08694`以来未变，旧用例
不为交付重复运行。子包dev提交为 `ce73f3f9f96b066afe4a44c0198ffc7301575f1d`。

子包先提交，本轮父仓仅更新Execution gitlink和两份进度记录。
裁定 **EXE01 PASS**，正式通过 MON01/TRN01/GW01/GW04/EXE01，合计 **5/68**。
EXE02崩溃阶段与EXE04完整准入反例仍待各自验收，不由本轮推导通过。

## 第42轮：行情缺口与断线恢复，关闭 TRN02（2026-10-15）

在 SDK 现有 dev `15e93604490f1c1f14c2d4844e8802628b992e92` 上仅新增
`tests/unit/test_service_market_faults.py`，不改变生产代码。本轮父仓提交只含此测试和两份
进度文档，其余 Risk、Execution、Monitor 并行修改保留。

四项检查使用真实 GatewayMarketHub、CURVE ZMQ PUB/SUB loopback 与 ServiceMarketClient
生命周期：首次实际收到 socket 帧后核对权威 head/cursor；暂停消费后补齐中间缺帧及没有
后续帧可提示的尾部丢失；真实解码后注入乱序/重复并验证有序唯一交付；关闭实际 SUB socket
后重放断线期间数据，epoch 变化要求显式 resync。旧 cursor 不被静默替换；接受新 epoch
仍明确 snapshot_complete/full_baseline_available 为 false。

作者最终定向命令为 `C:/anaconda3/python.exe -m pytest -p no:asyncio -q
tests/unit/test_service_market_faults.py`，显式配置 SDK/base/transport/gateway 源路径，
**4 passed / exit0**。五条环境 warning 为一条既有 asyncio 配置与四条 pyzmq Proactor
兼容提醒。首次默认插件加载在 collection 的 pytest_asyncio Package.obj 失败，属于测试
环境问题，未产生候选用例结果。Ruff与空白检查通过；独立只读审查通过，没有重复已通过测试。

本轮控制 registry/handler 使用同进程 fixture，新增故障经真实数据 socket；独立进程的生产
ServiceHost 控制/数据接线与 epoch 路径复用已有 `test_service_market_integration.py` 的
有效验收，未把 fixture 称为真实跨进程控制。丢失在实际 socket 解码后注入，不声称 OS 队列
溢出或 HWM 饱和。结合上述有效证据满足该条目，裁定 **TRN02 PASS**。
当前正式通过 MON01/TRN01/TRN02/GW01/GW04/EXE01，合计 **6/68**。

## 第43轮：实际订单服务接入持久 Risk 准入（2026-10-15）

Risk dev 从 `a5c45a3c5f77453eab022965462d1da2fdaa4157` 提交四路径为
`80fa67fb0cca45d1456d1f2f8983782a7c5eea46`：新增中立 DurableRiskAdmissionAdapter
与测试、惰性导出，以及 InstrumentRiskAdmissionMapper 的账户级估值单位修复。SDK 只新增
`tests/unit/test_service_risk_order_integration.py`，并更新 Risk gitlink 和本轮两份记录。

适配器不导入 Execution/Gateway，逐次绑定订单 ID、账户及已配置的策略分配；它将精确的
RiskDeniedError/PermitInvalidError 有限错误投影为 PermissionError，因而已知拒绝由
Execution 返回 REJECTED/admission_denied，未知存储故障仍 BLOCKED。可信 instrument
valuation_unit 在没有策略 allocation_reader 时也传到账户预留；缺失单位仍不能通过固定
单位政策。没有 allocation_reader 的策略订单只代表账户级风险，不能声称策略预算已执行。

Risk 定向检查9 passed / exit0、独立源码复核 GO，Ruff和空白检查通过。该次命令显式优先
Risk/base/Execution sibling src，但未保留实时 __file__ 输出，不补称历史来源证明。
随后一次 SDK 真实 spawn/CURVE/ServiceHost 检查明确断言当前 Risk adapter/admission/mapper
和 Execution store/facade 来源，**1 passed / 2.69秒 / exit0**；两批各有一条既有 pytest
asyncio 配置 warning。SDK 命令关闭插件自动加载，使用 `--noconftest -p no:cacheprovider`。

通过实际 SDK 订单端口提交错账户、错 metadata 与超额20万订单，均为精确拒绝、零派发尝试、
无permit/provider ID、无预留及provider调用。10万合法订单 ACKED 一次，持久 dispatch claim
绑定账户/intent/permit/cause；同 ID 重放保持相同结果和一次provider调用。正常关停后只读
SQLite 核对仅一条合法预留和claim，三个拒绝ID均不存在。合成provider位于末端，前面的服务、
认证通信、账本与Risk判断为真实实现。SDK测试为520行，SHA256
`562e87581c080cac89a268dd1236ecaab40bdc0684b915f19d1b44eb889a6475`。

本轮关闭了实际集成发现的估值单位丢失和已知拒绝误归类问题；没有独立Risk服务/无Execution
路径、跨进程预算竞争或真实账户证据，**RISK01–RISK03仍未正式通过，正式数保持6/68**。
已通过源测试不为交付重跑，其他并行修改保持独立。

## 第44轮：Backtrader 可运行的配置入口（2026-10-15）

Backtrader 现有 dev 从 `833aff2172548d10d749670b5152b43efa270e09` 提交为
`53d2bf93949737f2ba6f51979f3f3d13b0d1b450`。精确七路径：ServiceExecutionSession
模块及两份测试、`examples/service_execution_session/` 的run/config/README和AGENTS登记。
原有删除路径0、两份CTP runtime与一份CTP测试差异提交前后相同，未跟踪证据目录保留。

新增 `run_configured_cerebro` 解析一个策略Execution client及必需的orders/order_query路由，
再调用受信runtime工厂；只有配置为None时保持普通Cerebro.run，错误配置不会回落到直接交易。
公开命令 `C:/anaconda3/python.exe -m examples.service_execution_session.run` 构造实际
BtApiStore/BtApiBroker/Cerebro，并通过该入口运行。示例使用临时CSV、临时CURVE身份和本机
spawn服务，末端明确为synthetic-no-write且拒绝submit/cancel，不读取凭据或报告账户现金。
本地初始cash/value为0占位，不是观察到的账户快照。

三个新增helper节点通过；CLI子进程节点修复仅该节点后最终 **1 passed / 14.49秒 / exit0**。
最初pytest_asyncio在collection失败，禁用该插件后剩一条既有配置warning。CLI曾暴露Windows
Proactor警告及CSV默认跳过首行，两处分别修复后仅重跑失败节点；最后CLI stderr为空、数据
三根bar，runtime/store/host正常关闭，关闭验证完成后才输出成功JSON。py_compile、JSON解析
和空白检查通过；独立源码复核GO，没有为了提交重跑通过节点。

证据为本机合成生命周期，不覆盖策略虚拟资金/持仓、多服务统一读取、全部重连/回调故障和旧
场景迁移，**BT01/BT02仍部分，正式数6/68**。Root `654858` 完成精确七路径提交与空索引核对；
SDK本轮仅提交这两份进度记录，不改变Backtrader以外的代码或子包gitlink。

## 第45轮：Monitor 授权控制与持久最终结果组件（2026-10-15）

Monitor dev `24516efc42f0696389592ecd36436c66c28ba270` →
`85fd3f0059a3272dfe92487fd7ae88563a2adaee`，精确四路径：新增service_control及测试，
control账本扩展与惰性导出。签名控制绑定已认证APPLICATION_CLIENT身份及固定issuer/account/
mode/scope/actions；owner claim/ack仅接受配置中的精确SERVICE身份。claim SQL在选择/租用
之前同时过滤account和mode；相同请求与最终结果重放幂等，改内容冲突，UNKNOWN保持非终态。
公共monitor.control与内部owner claim/ack操作分离，组件不推断冻结原因已解决。

作者定向检查56 passed，独立源码复核GO后补同账户同scope但不同mode反例，单独1 passed；
两批exit0、各一条既有pytest配置warning，未重跑已通过56项。Ruff通过；Root提交时删除
测试EOF多余空行后空白检查通过，未改行为。Root `1c7b59`核对四路径与空索引。

父仓仅更新Monitor gitlink和两份记录。SDK认证端口接线、实际owner/Risk执行控制、未解决
冻结拒绝resume以及端到端故障结果仍待集成，**MON02仍部分，正式6/68**。本轮不是控制
命令已在真实账户执行的证据。

## 第46轮：AFI 可信读取配置与应用生命周期组件（2026-10-15）

AFI现有dev `117255edd3e9266d09123469b2a457c27b4ee3a0` →
`90c404cab63b0eb17697e7f776275cee331d7ab5`，精确七路径：新增deployment与lifespan测试、
config/main接线、provider删除接口204空响应，以及两份schema的声明顺序修复。后两项修复
真实main/router冷导入暴露的前向类型依赖，字段含义不变。原有九项README/Windows脚本内容
提交前后SHA256相同，未纳入提交。

SERVICE_READ_DEPLOYMENT_JSON以SecretStr隐藏于repr/dump，严格有界解析受信subject/identity/
scope/read mount/grant/peer/key配置；空值不构造worker。完整启动后发布不可变授权目录，
关闭前先撤下读取入口；部分启动逐一关闭，失败时保留不确定对象，避免同一次失败再次close。
当前目录为模块全局状态，运行约束是每进程一个应用实例，不声称并发多app隔离。

项目venv Python3.12.10共六个唯一节点通过：首批4通过、2因缺SDK源码路径失败；补齐真实
SDK及子包src后仅重跑两个失败节点，**2 passed / 7.04秒 / exit0**。关闭插件自动加载与
--noconftest，四条warning均为既有pytest配置。后一次命令为
`D:/temp/afi_iter10_lifespan_venv_r4_20261015.ps1`；实际相关SDK七份源码前后pin相同，导入
来源已验证，父仓HEAD仅作来源记录。未为提交重跑；Root两份新文件格式修正经AST等价确认，
Ruff/空白检查通过，独立源码复核GO。Root `2988f1`完成精确七路径提交与空索引核对。

明确证据边界：测试导入真实app.main并调用其lifespan，替换通用run_startup/run_shutdown，
使用最小FastAPI服务读取路由及实际ServiceReadWorker配合合成session；并未通过默认
_build_worker/_create_runtime连接服务。先前Anaconda缺依赖placeholder运行只作诊断，
不计为安装验收；早期一次.env读取尝试在解码失败，未输出内容，最终venv运行在导入前拒绝
.env读取并使用合成设置，无此尝试。所有测试均不代表完整产品启动或真实账户。

默认配置到真实SDK服务链、页面接线与完整授权矩阵仍待下一轮，**AFI01仍部分，正式6/68**。
SDK本轮只提交两份记录，不改变其它并行实现。

## 第47轮：正常宿主崩溃重启恢复，关闭 EXE02（2026-10-15）

Execution dev `ce73f3f9f96b066afe4a44c0198ffc7301575f1d` →
`e239a5807ad6bcf0144ccdd47e81c2d4047bc6d6`，四路径为store/facade/service及新崩溃测试。
当前writer lease下，事务只将精确scope的DISPATCHING改成UNKNOWN/review_required，并同事务
写一个dispatch_unknown事件；PENDING_DISPATCH和已回报终态保持原义，不进行provider调用。
五个真实子进程退出边界检查 **5 passed / 2.94秒 / exit0 / 无warning**，覆盖claim前、claim后、
provider内、返回后写回报前、回报持久化后；重启、重复恢复和原ID重放核对持久状态与调用数。

SDK service_components在写端口启用时、宿主开放处理前完成恢复；失败则启动失败，查询端口
不取得写锁或恢复。新增生命周期锁解决相同writer ID能续租而导致双宿主恢复活跃订单的问题：
同一个已解析DB路径与独立registry DB也互斥；同一个内存store对象亦互斥。资源关闭失败时
保留锁直到确认关闭。锁是路径sidecar方案，要求相同canonical路径和受信未替换sidecar，
不覆盖hardlink别名或外部unlink/replacement，不声称这些操作已验证。

新SDK文件六个唯一节点全部通过。首次4通过、2因测试误写host状态/位置scope参数失败；
仅修正两个节点后 **2 passed / 3.00秒 / exit0**。首次四warning含三条Windows Proactor，
测试限定selector后最终仅一条既有pytest配置warning。真实spawn宿主在合成provider写入
独立持久调用日志后os._exit(73)，父进程核对DISPATCHING/calls1/unknown0；另一独立spawn
宿主换registry DB正常启动，重放前已UNKNOWN，原ID重放仍UNKNOWN、calls1/unknown1，正常
关闭一次并exit0。调用的是实际组件handler和构造的ServiceCallContext，不冒称ZMQ客户端
认证链；正式EXE02验证的是持久恢复与不重复派发，通信另由TRN用例负责。

独立包/宿主/新增实际重启源码复核GO，Ruff格式/静态和空白检查通过。共享SDK启动行为变化后，
Root `288426`定向回归真实Risk订单集成：**1 passed / 2.66秒 / exit0 / 一条既有配置warning**；
这是新生产改动的回归，不是为交付重复历史QA。Root `158b2d`已先提交Execution四路径；父仓
本轮仅更新该gitlink、SDK组件/新测试及两份记录，CFG05未跟踪测试排除。

裁定 **EXE02 PASS**，证据为LOCAL_SYNTHETIC_NORMAL_SERVICEHOST_CRASH_RESTART及五边界
子进程检查，没有真实账户/provider验收。正式通过 MON01/TRN01/TRN02/GW01/GW04/EXE01/EXE02，
共 **7/68**。

## 第48轮：补齐配置拒绝边界检查，CFG05保持部分（2026-10-15）

SDK现有dev `356e35e2c6778eb7ce029df95ddfb28487da6b97` 上仅新增
`tests/unit/test_service_config_cfg05_acceptance.py`和更新两份记录，没有生产改动。
新增客户端/服务端register_to、服务端/组件enabled、五个服务身份或政策引用、策略身份缺失
以及旧远程形状输入经新service CLI拒绝的11项检查。作者最终定向 **11 passed / exit0**，
一条既有pytest配置warning；最初10项结果被补充客户端register_to后的11项结果替代，不计21。
Root `94b45d`核对源码、Ruff lint/format通过，独立源码审查未发现组件缺陷。

旧输入只在新离线validator获得UNKNOWN_FIELD，没有socket/process/thread/可选包导入副作用；
这不能证明原有旧运行入口要求迁移。空components等已有验收不重跑；当前Backtrader实际版本
为v4，计划第80行说明v5仍是目标，不虚构v5运行验收。**CFG05保持部分，正式仍7/68**；
旧运行入口的明确迁移行为在消费者切换/退役时另验，不通过本轮测试标题推定已完成。

## 第49轮：Execution 准入端口合同反例，EXE04保持部分（2026-10-15）

Execution现有dev `e239a5807ad6bcf0144ccdd47e81c2d4047bc6d6` →
`e9abd0b803532b37dc0caf36af91935b3d439123`，仅新增
`tests/test_exe04_execution_only_admission.py`。实际ExecutionOrderEntryService/facade/SQLite
配合结构准入fixture，覆盖正例、缺门、过期、错账户、错动作和旧owner fencing代次；所有拒绝
核对submit/cancel计数均为零，重放不增加派发。冷子进程导入实际service_order_entry并拒绝Risk导入。

作者定向命令为禁用插件自动加载后的
`C:/anaconda3/python.exe -m pytest --noconftest -p no:cacheprovider -q bt_api_execution/tests/test_exe04_execution_only_admission.py`，
最终 **7 passed / 0.68秒 / exit0 / 无warning**；Ruff检查和格式通过。独立只读复核修正前曾HOLD
冷导入未覆盖实际入口及缺门只检查submit，最终两处补齐后GO；没有重跑EXE01/02或已接受套件。
子包精确单文件提交，工作区与暂存区为空，提交blob与checkout一致；父仓仅更新gitlink及两份记录。

正式要求复核发现：TTL/account/action的拒绝逻辑由fixture实现，生产目前只有可注入结构端口，
尚无计划§5.2要求的无Risk基础准入实现。真实fencing反例发生在激活前，也不等于permit已绑定
并在最终claim重验owner代次。故证据为SOURCE_FAKE_EXECUTION_ADMISSION_PORT_CONTRACT_ONLY，
**EXE04保持部分，正式仍7/68**。下一轮实现生产基础gate和正常ServiceHost装配，不能用
allow_unprotected或固定放行的验证器代替。

## 第50轮：账户过期游标与ACK边界，关闭 GW03（2026-10-15）

SDK dev在`061fdb8c6ed8a8ad6c61bba77b926575c9b74d12`上新增
`tests/unit/test_service_account_cursor_recovery_integration.py`，无生产改动。实际spawn
ServiceHost、CURVE RPC、GatewayEventJournal与SQLite ServiceAccountConsumer先消费cursor1，
服务端另offer2而本地仍为1；head/offered均为2时越界ACK3拒绝，持久进度仍2/1。重开客户端
与投影后，真实capture_snapshot压缩至2，追加tail3；下一次poll从snapshot2连续接上3，
投影包含三个事件且无重复/缺口，pending_ack清空，服务端持久进度3/3。异账户decoy保持隔离。

作者只运行新增节点：禁用插件自动加载，显式SDK/base/gateway/transport源码路径，
`C:/anaconda3/python.exe -m pytest --noconftest -q tests/unit/test_service_account_cursor_recovery_integration.py`，
最终 **1 passed / 2.24秒 / exit0**，一条既有pytest配置warning。此前两次失败是fixture错误
假定不可变MappingProxy/tuple为dict/list，已修正；没有生产缺陷推断。Ruff检查及格式通过。

独立只读审查逐项核对正式计划753行，结合已接受第08轮越权/错epoch/未offer ACK及服务
重启持久进度、第09轮真实consumer在SQLite commit后ACK前os._exit(73)并恢复、第11轮过滤
流和双策略隔离，确认完整GW03证据。历史测试未重复运行；本轮新测试直接核对数据库snapshot、
保留tail、不同账户行和consumer progress，不用测试标题代替证据。

裁定 **GW03 PASS**，新增一个正式用例，当前 **8/68**。依据为LOCAL_SYNTHETIC_CURVE_ACCOUNT_CURSOR_RECOVERY
及上述已接受继承证据；本用例不要求真实provider、账户、双机或负载，那些验收仍各自待完成。
本轮仅提交新测试与两份记录，不纳入并行Risk/Monitor子包变更。

## 第51轮：Risk 跨进程账户与策略额度竞争组件（2026-10-15）

Risk dev `80fa67fb0cca45d1456d1f2f8983782a7c5eea46` →
`03e90fb4ed106ee24e11e78451e1906eab2f5509`，仅新增
`tests/test_risk01_multiprocess_admission.py`。20个独立Python进程经文件barrier同步，共用实际
DurableRiskGate/SQLite；按账户0至9依次形成十个竞争波次，每波十策略、每策略两个竞争者。
独立场景分别检查账户100额度下五笔20通过/十五笔拒绝，以及策略25额度下每策略两笔20仅一笔
通过；各自核对精确拒绝码、不同品种与账户/策略归属，重开DB核对持久预留及原permit幂等。

作者一次定向 **1 passed / 25.32秒 / exit0**，一条既有pytest配置warning；Ruff和py_compile通过。
命令使用C:/anaconda3/python.exe、显式risk/base src、禁用插件自动加载、--noconftest和
-p no:cacheprovider。独立只读复核GO_LOCAL_CROSS_PROCESS_RISK_COMPONENT_ONLY，未重复测试。
精确单文件包提交，索引为空；父仓更新该gitlink与两份记录，后续冻结API改动不在本轮。

此处100个账户—策略身份分十波次，**不是100策略同时竞争**；RISK01仍部分，下一定向验收
将同时启动100个策略进程。无真实账户/provider/跨机证据，也不以这些非本项条件掩盖实际并发
缺口。**正式仍8/68**。

## 第52轮：Risk 精确冻结原因解析接口（2026-10-15）

Risk dev `03e90fb4ed106ee24e11e78451e1906eab2f5509` →
`29f6b5ad91b13226afc0bd9538bdc1980b31f5c2`，精确四路径：core/admission、两个导出initializer
和新增test_freeze_resolution。`resolve_freeze_exact(scope,cause_id)`在同一BEGIN IMMEDIATE
事务中区分CLEARED、ALREADY_RESOLVED、NOT_FOUND，并返回该账户是否仍有其它active原因。
结果为中立FreezeResolution类型；旧resolve_freeze不变，dispatch-inflight仍拒绝并要求专用
journal reconciliation proof。调用方不必查询内部DB或从reason字符串推断冻结身份。

三个新测试一次 **3 passed / 0.49秒 / exit0**，一条既有pytest配置warning，Ruff/格式/
py_compile通过。实际SQLite测试覆盖精确scope、其它原因保留、无记录/已解除、两个gate并发
解析一清除一已解除、旧API兼容以及真实dispatch claim冻结拒绝。独立只读审查GO；Root核对
提交的生产API和测试，未重跑已接受套件。包级四路径提交后父仓仅更新gitlink和两份记录。

此接口不授权Monitor直接清除自动风险原因；后续SDK控制适配器仍需验证签名、精确手动cause、
命令顺序与实际owner结果。**MON02保持部分，正式8/68**，并行100进程验收文件不纳入本轮。

## 第53轮：一百策略进程同时竞争，关闭 RISK01（2026-10-15）

Risk dev `29f6b5ad91b13226afc0bd9538bdc1980b31f5c2` →
`72b8cbd5e54650d020689fdf233ff8cc96460151`，仅新增
`tests/test_risk01_hundred_strategy_processes.py`。真实100个独立Python策略进程分别绑定
10账户×10策略，在同一barrier前全部初始化/就绪/存活后一次释放，调用共享SQLite的实际
DurableRiskGate；不是20进程波次或线程替代。账户cap场景每账户十笔20争100，五笔通过五笔
拒绝；策略cap场景账户500不构成瓶颈，每策略两笔20争25，只准一笔。覆盖五品种、全部
账户/策略归属与精确拒绝码；重开库核对持久快照、预留行及通过/拒绝请求重放结果不变。

指定Anaconda、显式risk/base src、禁用插件自动加载、--noconftest/-p no:cacheprovider，
新节点一次 **1 passed / 20.32秒 / exit0**，一条既有pytest配置warning。两阶段实测100/100
loaded/ready/started/正常exit，barrier释放跨度0.141/0.078秒，零terminate/kill、全部回收。
Ruff/空白检查通过。独立只读审查核对源码、两份进程观察及SQLite，Root另核对源码断言和
原始观察，未重跑已通过节点；Root `537361`完成包级单文件提交。

两份实际生命周期观察原字节保存于`evidence/risk01-100-process-20261015/`。拒绝明细没有
另行归档，其精确码/数量与重放由成功pytest断言覆盖；观察JSON仅支持进程生命周期结论。
按照正式计划759行裁定 **RISK01 PASS**，当前 **9/68**。该项要求真实跨进程admission，
不要求provider/跨机；不由此推导LOAD01持续30分钟或真实账户通过。父仓仅更新Risk gitlink、
两份进程观察及两份进度记录，不纳入并行生产修改。

## 第54轮：Windows 默认事件循环的传输依赖修复（2026-10-15）

Transport dev `fef4964` → `614e2d3837e93bd9a8d30066b883e47a03020d51`，仅修改
pyproject.toml，声明 `tornado>=6.1; platform_system == 'Windows'`。实际 AFI 默认
Proactor 事件循环启动 PyZMQ ThreadAuthenticator 时暴露缺少 selector-thread 依赖；
使用包依赖声明修复，不在应用中强制替换全局事件循环。

AFI 新默认 lifespan 集成节点使用 Python 3.12.10、任务隔离依赖目录和实际 spawn
ServiceHost/CURVE/SDK 客户端；两个认证主体分别使用独立 owner thread，验证实际 HTTP
读取、跨主体/跨 scope/伪造身份拒绝及全部正常关闭。最终冻结节点 **1 passed / 11.69秒 /
exit0**，四条禁用插件后既有 pytest.ini 配置 warning；22项输入来源和前后 pins 相符，
宿主 exit0、pipe/process 关闭。独立只读复核 GO，未重跑该最终节点。

包提交先完成；本父仓轮次仅更新 transport gitlink 和两份进度记录。AFI 单测试路径随后
在其现有 dev 独立提交，原有九项修改保留。证据为本机合成默认应用组合，不是完整页面、
真实账户或 AFI01 正式验收。**正式仍9/68**。

AFI 后续已独立提交 `303e5cd17dd606278933a21b74253832f8cd5aa2`，精确单测试路径，
索引空且原有九项无关状态保留；未重复已接受节点。父仓第54轮为 `0c07ed4e`。

## 第55轮：普通 SDK 冷导入避免默认加载 spdlog（2026-10-15）

Base dev `9a8167d` → `5dbf9bfafd9fec2523c28688337d6f8af77b709f`，四个日志源码/测试路径。
干净发行安装暴露普通 `import bt_api_py` 加载 spdlog 原生扩展并以 Windows
0xC0000005 崩溃；Python except Exception 无法提供该情形的回退。默认日志改用标准库，
只有显式 backend=spdlog 才导入、校验其能力；保留 SpdLogManager API，隔离不同配置的
handler/cache。SDK 的 spdlog 从核心依赖移至 `bt_api_base[spdlog]>=0.15.8` 命名 extra。

Base 两个定向测试文件 **12 passed**，一条既有 pytest 配置 warning，独立只读审查 GO。
任务临时目录构建 Base/SDK wheel，分别验证物理安装 spdlog 时普通路径仍无探测/导入，
以及无 system site、未安装 spdlog/四领域包的干净 venv。补齐 Backtrader 声明依赖后
pip check 无冲突；安装产物正常导入 SDK，BtApi(debug=False) 使用 DirectBackend 并关闭，
实际 Cerebro 合成回测处理三根 bar。最初 --no-deps 的 Backtrader 缺依赖/NumPy版本不符
是安装矩阵设置问题，修正后才作以上结论。

Root核对包提交及生产源码后，仅提交Base gitlink、SDK pyproject和两份记录，保留其它并行
修改。此轮为冷导入与日志可选依赖修复，核心 pyzmq 依赖仍待独立修复，完整代理发行矩阵
未完成；不关闭CFG01/CFG04/MIG04，**正式仍9/68**。

## 第56轮：十账户一百策略共享行情与账户会话，关闭 GW02（2026-10-15）

仅新增SDK测试 `tests/unit/test_service_gateway_hundred_strategy_integration.py`、原字节
进程观察和两份进度记录。实际100个独立策略进程、10个账户ServiceHost、1个行情ServiceHost，
合计111个不同PID；100策略在同一barrier前全部就绪存活，再由各自真实ServiceClientRuntime、
ServiceMarketClient和ServiceAccountClient完成CURVE注册与访问。provider仅替换末端。

定向新节点 **1 passed / 31.03秒 / exit0**，禁用插件自动加载后一个既有pytest配置warning；
Ruff检查和格式通过。原始观察核对100策略和11服务全部正常退出、零强制清理/清理失败，
启动跨度59.5472ms。一个兼容MarketSubscriptionKey共用一次上游，最终启停1/1；十个
账户provider各连接/读取/关闭1/1/1。策略000先退出时其它99个存活，其同账户九个仍可读，
共享行情继续交付；最终注册清空、provider正常释放。账户001在远程发现阶段拒绝错账户
注册；随后的snapshot调用因无路由在本地拒绝，不标成远程snapshot拒绝证据。

独立只读审查核对真实生产调用与assertions，Root另读源码/观察并确认完整GW02条目要求。
原字节观察29445字节，SHA256 `b3eb34e71eae349670117e4089a00955a9b19ece31f93a9bb24a901aa9190e17`，
保存于 `evidence/gw02-100-process-20261015/`。未重跑已接受GW01/RISK01套件。
裁定 **GW02 PASS，正式10/68**。本项是本机合成连接/订阅合同；不推导LOAD01持续30分钟、
双机或真实账户通过。异常清理逐进程升级的总等待较长，本次未进入该路径。

## 第57轮：Execution 生产基础 admission 包级实现（2026-10-15）

Execution dev `e9abd0b803532b37dc0caf36af91935b3d439123` →
`bb7e5a2348f507936de13519ea85f46c574371aa`，九个明确源码/测试/迁移说明路径。
新增生产 ExecutionBasicAdmissionGate 和代码注册的 provider validator，绑定服务端可信
身份/作用域、完整订单、provider参数与能力版本、writer lease代次及到期时间；一次性permit
在pre-dispatch guards之后最终复核，由submit_authorized实际接收验证后的参数。Risk gate
保持独立，可共同启用；Basic-only不依赖Risk。缺少gate不能用allow_unprotected隐式兜底。

只有PENDING_DISPATCH且attempts0、无provider事实并匹配context/reference时才可在新lease
下CAS重新准入；DISPATCHING/UNKNOWN不重新派发。schema v21增加两个nullable admission
字段，v20升级不重跑旧CTP迁移，保留原CLAIMED状态和Riskpermit。独立静态复核GO。

最终针对basic admission、guard后到期、历史迁移边界及两个真实子进程崩溃恢复分支，
**21 passed / 14 deselected / 4.52秒 / exit0**；Ruff/格式/compileall/空白检查通过。
预claim崩溃恢复后只派发一次；已派发崩溃恢复UNKNOWN且零重派。未重跑已接受EXE01/02。
Root核对包提交、生产validator和正常service API，父仓仅更新Execution gitlink及两份记录。
实际SDK ServiceHost配置接线和认证客户端验收下一轮完成；**EXE04仍部分，正式10/68**。

## 第58轮：Risk 冻结原因仅首次激活，防止延迟旧请求重新冻结（2026-10-15）

独立Monitor审查发现真实竞态：旧owner在Risk效果前暂停，新owner回收UNKNOWN并完成
FREEZE/RESUME后，旧owner调用旧freeze UPSERT会重新激活同一cause。进程内锁或效果前
查询无法封闭跨数据库的间隙。Risk dev `72b8cbd5` →
`68d6cd25f6e995090016ada71123e1ed213f3c26` 独立五路径修复：新增freeze_activation模块、
admission最小18行转发/导出、两个包导出及专门测试。

`activate_freeze_once(scope,cause_id,reason)`在原risk_freezes表的同一写事务中仅首次
insert，返回CREATED/ALREADY_ACTIVE/ALREADY_RESOLVED，以及排除目标后的其它active事实。
重试不覆盖最初reason，已解除行不由该API重新激活；保留旧freeze显式upsert语义，且拒绝
dispatch-inflight保留cause。API不硬编码Monitor命名空间，由SDK可信适配器校验。

从已接受HEAD导出的干净临时源码快照仅叠加本窄补丁，新增节点 **6 passed / 1.39秒 /
exit0**，一条既有pytest配置warning；包括实际spawn进程在解除后重放仍不激活，及账户
隔离、其它冻结、reason保留、旧API兼容。独立只读GO，Root核对实际提交与API事务。
仅精确hunks提交，RISK02较大admission草稿和未跟踪exposure.py原内容保留、索引空；父仓
只更新Risk gitlink与两份记录。SDK Monitor仍需采用此API并验证两个owner的延迟竞态及
真实ServiceHost链路，**MON02尚未通过，正式10/68**。

## 第59轮：Execution-only 正常服务入口，关闭 EXE04（2026-10-15）

SDK account_owner资源映射新增basic_admission_gate，并将其交给实际ExecutionOrderEntryService；
无任何准入gate且没有显式旧allow_unprotected声明时，正常启动拒绝。仅提交service_components
中这组明确hunks、新增test_service_execution_basic_admission_integration及两份记录；同文件
尚未接受的Monitor接线保留在工作区，不纳入本轮。

真实spawn ServiceHost/策略客户端、CURVE、ServiceExecutionClient和SQLite检验Basic-only正例，
注册provider validator验证后的authorization.parameters由末端合成provider实际消费并独立
持久化。缺policy启动拒绝、错action、精确到期、可信wire/account映射不一致、最终claim前
实际writer token1换token2均拒绝；provider journal只含正例一次。过期发生在已记录claim后，
dispatch_attempts=1但实际provider调用为零；旧代次保持DISPATCHING待恢复，不伪造取消。
服务与客户端均拦截/检查Risk和Gateway未载入，成功路径正常关闭且所有子进程exit0。

两个新节点分别通过：missing-policy节点首次通过未重复；集成节点修正测试时钟原差1ns和
claim计数预期后 **1 passed / exit0**，一条既有pytest配置warning。Ruff/格式/compile通过。
独立只读复核GO，Root核对实际provider参数、持久化断言、拒绝与清理范围，未重跑EXE01/02。
按正式计划EXE04裁定 **PASS，当前11/68**；本例合成provider满足条目要求，不代表真实账户。
此处不宣称每个其它Risk-only组合已强制启用BasicAdmission，§5.2更广组合仍逐项验证。

## 第60轮：Monitor 签名控制、原子效果和正常服务链，关闭 MON02（2026-10-15）

Monitor dev `85fd3f0059a3272dfe92487fd7ae88563a2adaee` →
`36e33aa81bbebbbee3a47149b5ff270046808f08`，精确七个包源码/测试路径，包工作区与索引干净。
HMAC v2签名绑定精确RESUME目标cause；v1 RESUME拒绝，历史未完成v1控制保守隔离。
SDK MonitorRiskControlOwner采用第58轮Risk原子activate_freeze_once；两个真实gate/owner
覆盖A延迟在效果前、B回收UNKNOWN并ACK FREEZE/完成RESUME、A随后实际Risk调用返回
ALREADY_RESOLVED且不能改写B终态。finalize仅排除正在确认的精确claim自身重复TTL失效，
其它过期claim仍处理；旧owner和legacy/跨executor UNKNOWN均保持保守。

SDK显式role=control只公开monitor.control；owner claim/ack为进程内调用，不宣告公共能力。
control-only客户端无需查询端口，遵循binding.required；默认读与混合读/可选控制行为保留。
八类明确前置授权拒绝才转成SCOPE_DENIED，异常effect/storage/ACK继续UNKNOWN；RESUME仅
解除签名绑定的手动cause，保留其它Risk冻结与dispatch latch，不把ACK称作账户可交易。

包/SDK定向 **41 passed / 2.83秒 / exit0**，共享接线回归 **8 passed**；实际spawn
ServiceHost/CURVE节点 **1 passed / 4.02秒 / exit0**，均仅既有pytest配置warning。
最初negative被registry错误映射UNKNOWN，修复精确映射后继续；后续关闭失败是测试误调用
不存在的DurableControlLedger.close，按其逐操作连接生命周期修正，保留实际Risk close。
独立只读复核确认源P1已消除、签名越权无ledger/effect、ACK丢失恢复有序、重复无效果与
正常host exit0。无真实provider/账户操作。

为排除工作区未验收RISK02草稿影响，Root额外将实际执行依赖换为已接受68d6cd25的干净
源码快照，逐项比对19个Risk源码文件（只容许CRLF投影差异），再定向执行延迟owner竞争
和真实CURVE两个节点：**2 passed / 2.95秒 / exit0**，一条同类warning。这是依赖一致性
核验，不将重复节点算成新增用例；未重跑未受影响的旧套件。

结合第35轮已有Monitor/relay不可用不阻塞订单和撤单证据，正式MON02两部分均满足，裁定
**MON02 PASS，当前12/68**。父仓仅提交Monitor gitlink、SDK适配器/四个共享接线文件、
三个新测试与两份记录；Risk独立下单、LIVE_GROSS、pyzmq可选安装等并行修改不纳入。

## 第61轮：ZMQ 可选依赖与真实隔离安装（2026-10-15）

Base dev `5dbf9bfafd9fec2523c28688337d6f8af77b709f` →
`5d4380f3f69aef1561669de74a357945baf41e41`，仅pyproject、旧runtime_remote与新增
optional-dependency回归三个路径。Base和SDK从核心依赖移除PyZMQ，新增显式transport-zmq
extra；旧远程runtime在显式构造时才导入，无依赖时报安装提示，不回退到direct。
聚焦三测试文件 **10 passed / exit0**，一条既有pytest配置warning；独立源码审查GO。

使用固定已提交源码快照加本轮精确候选构建wheel，普通resolver安装至无system-site的
独立venv。SDK构建基线为历史已接受`509869e5`，不是本轮稍后出现的工作区代码；Base基线
5dbf9bfa加精确两源码overlay，transport为614e2d38，Backtrader为53d2bf93干净Git archive。
Python3.14基础包和无extra客户端pip check通过，未安装PyZMQ、spdlog或四领域包；实际
DirectBackend正常构造关闭，Cerebro处理三根bar。显式extra的客户端与独立服务venv完成
真实CURVE一次合成请求、响应身份/关联ID校验、服务正常exit0；保留Windows Proactor使用
Tornado selector线程的一条运行warning，不声称stderr为空。

Python3.11正常resolver选择NumPy1.26.4和PyArrow26.0.0，pip check虽通过，base gateway
导入却被PyArrow的NumPy>=2运行检查拒绝。该失败保持OPEN_COMPATIBILITY_GAP，不能用3.14
结果覆盖；CTP U1A受保护来源清单的pyzmq条件依赖也尚未修复。新服务缺少transport时目前
报ModuleNotFoundError，完整安装提示与发行组合仍待下一轮。**CFG01/CFG04/MIG04仍部分，
正式12/68**。

Root核对实际包提交、源码diff、wheel元数据与矩阵JSON；父仓仅提交Base gitlink、SDK
pyproject、两份构建/矩阵记录和两份进度文档。记录位于
`evidence/optional-zmq-install-20261015/`，通过节点未为交付重跑。其他Risk/负载修改保留。

## 第62轮：AFI 不可变组合版本与账户去重投影（2026-10-15）

AFI现有dev从303e5cd1提交`d9358be81b7d26a99dd9b670eecdc254ee0081af`十二路径，再以
`de4d845eeb44589271fb06eff7e02ee22302811f`四路径修复独立审查发现的问题。组合版本记录
JWT subject owner、source_type、成员清单及hash，按owner/ref/version精确读取；新版本
append-only，唯一约束防并发版本覆盖。live成员创建和投影都复核可信grant，经实际
ServiceReadWorker读取完整SDK AccountKey，在应用内部校验key身份后去重；不向HTTP暴露
真实账户键。重复账户别名只计一次，冲突/过期/缺身份不投影完整总额。重叠组合标为
display_only/non_creditable；策略归属未采集时保留账户总额残差，不推算策略份额。

最初目标API/SDK测试 **2 passed / 4.87秒**，四条既有pytest配置warning；SQLite重复
upgrade与约束检查通过。独立审查发现overview的FastAPI依赖仍会提前构造交易manager，
以及既存表验证遗漏id主键。修复使composition参数路径在依赖解析阶段跳过manager，
无参数的legacy路径继续使用它；迁移既存表必须有精确id主键。修复版API和迁移回归
**2 passed / 4.75秒 / exit0**，五条warning，Ruff/格式与空白检查通过，独立复审GO。
实际HTTP回归验证组合/不完整参数manager调用0、legacy调用1、跨owner404/无grant403/
伪造owner422；三个selector对应两个完整账户键，总额1500且重复别名不增加总额。

Root核对两次精确提交、生产依赖分支、迁移和HTTP断言。ServiceReadWorker是真实代码，
末端session为合成数据，不是provider/真实账户证据。research/imported/paper适配器仍
adapter_not_integrated；页面版本选择、Execution归属事实与完整AFI02仍待实现，AFI01
整体门禁也不由本轮替代。**正式仍12/68**。AFI索引空且原九项README/scripts修改保留；
父仓本轮仅登记两份进度文档，不重复已通过测试。

## 第63轮：Monitor 系统行情观察投影（2026-10-15）

Monitor dev `36e33aa81bbebbbee3a47149b5ff270046808f08` →
`7c9a669f4d6aeefd20e4a0ba028b1444e553aa1d`，仅新增market_observation模块/测试和包导出。
投影器接受经调用方认证的Gateway市场帧，要求精确service identity、无账户/策略的system
scope、market.event schema及key/stream对应；输出普通events.append结构与稳定幂等ID。
观察语义仅为consumer_received_frame，时间取Gateway发送时间，不推断源端持久化、
行情新鲜度或交易所事实。payload不转发quote/source/entitlement/account字段；事件ID
仍可关联原stream派生身份，不作为保密机制。

聚焦 **3 passed / exit0**，一条既有pytest配置warning；Ruff/格式/compile/diff检查通过，
独立源码审查GO。实际GatewayMarketHub.publish构造帧，末端publisher为fake；普通Monitor
ingress持久化并幂等重放，system/account/strategy三目标使用同一event allowlist，只有
system分区读到事件；错误scope/identity/stream/schema拒绝。Root核对生产源码、精确提交
和这些断言。SDK市场消费者到Monitor的有限relay、真实服务授权/无遥测订单事实组合待
下一轮完成；本轮仅包级投影组件，**MON03仍部分，正式12/68**。父仓只更新Monitor gitlink
与两份进度记录，包索引/工作区干净，其他未提交工作保留。

## 第64轮：Python3.11 默认解析的 PyArrow/NumPy 兼容（2026-10-15）

Base dev `5d4380f3f69aef1561669de74a357945baf41e41` →
`fd6bd0fd1fb292f0adfac947a6d2476f6397ce24`，仅pyproject一条路径。PyArrow26运行要求
NumPy2，而Backtrader在Python<3.13保留已标定回测基线的NumPy<2约束；Base gateway顶层
TickWriter仍实际需要PyArrow。采用PEP508 marker：Python<3.13要求PyArrow>=14,<26，
>=3.13保留>=14。没有删除TickWriter依赖或改Backtrader数值基线。低Python版本但选择
NumPy2的Base-only用户也会暂受该上界，这是明确的保守兼容范围。

从已接受Base HEAD快照加唯一pyproject改动构建wheel，使用第61轮固定SDK/Backtrader
wheel在全新Python3.11.5 venv正常pip解析安装，无constraints或--no-deps。自然选择
NumPy1.26.4/PyArrow25.0.1；pip check无冲突，冷导入gateway/TickWriter、普通DirectBackend
与Cerebro三bar通过。四领域包、ZMQ、spdlog未安装，默认路径无相关探测；显式缺transport
仍拒绝且不回退。独立源码审查GO，Root核对精确包diff、安装记录和实际冷导入日志。

本轮关闭第61轮观察到的Python3.11兼容故障，未覆盖全部Python/平台及所有服务代理组合。
记录保存于`evidence/optional-zmq-install-20261015/pyarrow-compat-result.json`；原失败保持
历史。父仓只更新Base gitlink、该结果与两份记录，**正式仍12/68**；CTP U1A可选依赖身份
清单及剩余CFG/MIG条目另行处理。已通过3.14安装节点未重复。

## 第65轮：SDK 系统行情观察有限转发（2026-10-15）

SDK dev `02c645a1d03decf23def598083e2fe7a5ac2022d`（父`5c5a6750`）只增加
service_market_monitor与对应聚焦测试。relay借用同一owner线程的真实类型market client/
runtime，绑定固定account-free Monitor events.append路由及当前registration/epoch；
逐帧投影系统消费观察，有界pending队列保留同一event ID/payload重试，Monitor失败时仍
返回原行情帧，状态明确记录丢失、UNKNOWN及恢复要求。队列只在内存，不能证明崩溃后补传。

作者聚焦测试7 passed，一条既有pytest配置warning；Ruff/格式/compile/diff检查通过，
两份独立静态审查GO，Root核对精确两路径提交和空索引。测试使用合成runtime/client叶子，
不是实际注册/CURVE/Monitor ingress接线。显式import此relay仍顶层依赖Monitor投影模块，
这不满足计划要求的策略端无四领域包；后续将纯投影合同移至中立base，再做真实多服务
验收。当前只接受本地组件证据，MON03/CFG04均未正式关闭，正式12/68。

## 第66轮：direct CTP 可选依赖身份边界（2026-10-15）

SDK现有dev本轮只修改bt_api.py及新增test_ctp_u1a_optional_runtime_manifest.py，另更新
两份进度记录。受保护direct CTP来源清单移除不参与该路径的可选PyZMQ/spdlog；必需依赖
缺少名称、版本、文件清单或清单为空时明确拒绝。清单改变会改变审批物料摘要，旧审批
不能继承，必须重新签发；没有修改实际审批、读取外部私有物料或运行CTP/provider。

聚焦9 passed，一条既有pytest配置warning；Ruff/格式/diff检查通过，独立只读复审GO。
合成metadata覆盖可选包存在/缺失、必需包及四种不完整metadata拒绝；合成旧摘要经现有
entry物料比较拒绝，并验证一次性capability已消费。Root核对源码、全部测试断言及两
文件SHA-256：a3fbe7928d2be64feaf0f4544fcc084e438144bf6266d336ead5719786efa29f、
fe4c460e514ec782708d976dc450a4388b1b8d22ed2318db398ab7ac3919e7e5。
证据仅为source/metadata synthetic，不是签名、实际arm或账户验收；CFG01其余普通配置
资源观察及完整CFG04/MIG04仍待完成。正式保持12/68，已通过测试未为提交重复。

## 第67轮：Execution 账户虚拟分账与残差组件（2026-10-15）

Execution dev `bb7e5a2348f507936de13519ea85f46c574371aa` →
`3e0c6bc376f5d64385ef2a6ec56344dca2886acb`，精确五路径：账户对账模块、contracts、
store、导出及聚焦测试。组件消费现有执行outbox，不另造fill journal；绑定完整账户键、
owner目录版本、账户/归属基线、journal incarnation/cursor与provider观察区间。累计
部分成交转为相对基线的数量/均价/费用增量，按strategy/manual book归属；未解释事实
保留UNALLOCATED和残差，分页/缺基线/UNKNOWN/冲突明确降级。

独立审查发现并修复四类问题：旧outbox缺失或错误incarnation的整条intent隔离；外部
order/fill品种、方向、数量一致性；外部UNKNOWN必须PARTIAL；timeline/quarantine使用
(scope_key,intent_id)，防止跨策略相同intent ID相互覆盖。最终聚焦5 passed/0.52秒，
Ruff/格式/compile/diff通过，独立复审GO（未重复执行测试）。Root核对提交、实际源码和
跨scope lineage回归，子包工作区/索引干净；父仓只更新该gitlink及两份记录。

接受等级为包级合成组件；provider/目录完整性仍是可信装配输入，实际账户owner读取及
授权手工book接口尚待集成。当前只支持NET对账，lot/cost basis/已实现PnL仍未实现；
这些缺口保持登记，不推定EXE03正式PASS。正式12/68，下一步正常服务链验证。

## 第68轮：Risk LIVE_GROSS 持久敞口与时效边界（2026-10-15）

Risk dev `68d6cd25f6e995090016ada71123e1ed213f3c26` →
`9af8ef9c0a7bc7f60118b9d4ae6e0ec1eedd3e3d`，精确五路径：core/admission、
core/exposure、两处导出和聚焦测试。LIVE_GROSS为显式选择，旧RESERVATIONS_ONLY默认及
fingerprint保持；已结算派发、基线、订单/fill来源、valuation/FX/multiplier按SQLite
事务持久记录。未转订单的有效预留计入占用，转换后不双算；gross由绑定事实重新计算
并向保守方向舍入，不相信调用方给出的低估值。

支持ACK/部分成交/UNKNOWN/确认撤单/重启及同订单修订的新估值；相同修订只允许不变的
订单/成交事实配新journal观察。过期基线允许当前fence的必要订单核对并持久冻结新增，
不能用陈旧算术清除既有gross超限冻结；满足清空条件后才接受新完整基线。独立审查补齐
authority fence等待与SQLite BEGIN IMMEDIATE等待后的时效复核，reserve/validate/claim
事务末端再核验事实与permit TTL，过期claim不落latch。

作者最终聚焦36 passed/8.45秒，一条既有pytest配置warning；Ruff/格式/compile/diff通过，
独立源码复审GO。用例含真实SQLite writer锁等待、待派发预留账户/策略限额与过期观察；
Root核对五路径提交和关键回归，Risk索引/工作区干净。父仓只更新Risk gitlink和两份
记录，未重复RISK01大规模并发验收。接受等级为包级合成来源，不是实际provider或完整
SDK订单观察链；RISK02仍部分、正式12/68。RISK03的PROOF_READY崩溃恢复另开小轮。

## 第69轮：AFI 组合版本列表与页面接线（2026-10-15）

AFI现有dev `de4d845eeb44589271fb06eff7e02ee22302811f` →
`cd47e8d3d385b1b88a2bf773b90273527ec84714`，精确九路径：组合route/service/API测试，
前端API/Page/两个测试及中英文locale。JWT owner过滤分页版本目录，页面按精确
(portfolio_ref,membership_version)读取；legacy模式明确分开，缺失数值不补0，未接来源、
覆盖缺口、策略归属缺失与重叠组合不可叠加/不可授信均呈现。

独立审查修复重复账户冲突/排除的展示、机器状态本地化以及并发append导致offset分页
重叠缺行：每页使用同语句窗口count，前端发现total变化回到第一页重取并按版本键去重；
回归验证变更后53个不同版本完整呈现。最终后端API1 passed（既有Starlette deprecation
warning）、前端46 passed；Ruff/格式/ESLint/生产build/diff通过，build保留既有
大chunk提示。独立复审GO，Root核对提交、owner-filtered查询、分页及页面分支。

第72轮复核更正：本轮曾记录vue-tsc通过，但没有留存可核对的原始命令/日志。将实际生成的
components.d.ts/auto-imports.d.ts放回同一cd47e8d3源码后，完整typecheck为exit 2、81条
诊断；不能用缺少这些声明文件的exit 0替代完整检查。该历史通过声明不再作为验收依据。

AFI索引为空，原九项README/scripts无关改动保留；父仓仅更新本轮两份记录。接受为合成
API/UI集成，不是实际账户/Execution归属证明；research/imported/paper事实adapter仍
明确不可用。AFI02/03未完成，正式仍12/68，已通过节点不为交付重复运行。

## 第70轮：SDK 行情观察的四领域包导入隔离（2026-10-15）

第65轮显式relay仍需Monitor包，违背策略只用SDK的边界；本轮修复该缺口。Base dev
`fd6bd0fd` → `b4aabd1e17b9c7252fa7b4d266932087d99b5517`新增纯Gateway系统遥测
投影合同，调用方提供目标event/schema；不实现Monitor存储/规则/服务。Monitor dev
`7c9a669f` → `536a4f04747182749fabdac5e28624f80465bc53`仅将原投影模块改为兼容
wrapper，保留公开异常类型、原schema、稳定ID及输出。SDK relay改从Base导入，中立
校验/序列化不复制，Monitor协议值留在SDK适配层。

Base定向Gateway合成投影/重试ID/脱敏检查通过；Monitor原三投影测试通过；SDK聚焦unit
加新隔离子进程共8 passed，一条既有pytest配置warning。python -I子进程在显式导入
checkout relay前阻断四领域包，确认零导入尝试/零loaded模块及正确源码origin。各轮
Ruff/格式/compile/diff检查、独立只读审查GO，子包先提交且干净；Root核对两子包diff、
SDK改动及隔离断言，父仓精确更新两gitlink、两SDK源码/测试及两份记录。

此检查证明当前源码的显式relay导入隔离，不等于无四包发行安装或真实多服务MON03。
pending仍仅内存，不能当持久补传；后续实际CURVE服务链已准备待运行。正式12/68。

## 第71轮：Risk 派发结果回执与新 owner 恢复组件（2026-10-15）

Risk现有dev `9af8ef9c0a7bc7f60118b9d4ae6e0ec1eedd3e3d` →
`a3b73f19614352644a2a4c9678cd77d6931c38ce`，精确四路径：admission、两处导出和
新增恢复测试。只读dispatch_resolution_receipt在一个SQLite快照中核对已settle的
INCREASE、claim、冻结原因、持久resolution和恢复audit；没有resolution的inactive
latch不能解释成ACK。已解析回执带回原始ACKED_TRACKED proof，不修改Risk状态。

新resolve_dispatch_freeze_recovered要求可信journal authority验证原PROOF_READY及
order/fill链、原writer身份和当前更高fence，并持有当前fence直到Risk事务完成。事务
再次检查exact claim，原子写入resolution及不可更新/删除的恢复audit，只解除对应
dispatch冻结，保留其它冻结和settled占用。既有resolver没有放宽；重放、证据冲突、
旧fence和事务失败均拒绝或回滚。SDK实际历史journal核对与崩溃分支仍需单独集成。

包级命令 `C:/anaconda3/python.exe -m pytest tests/test_dispatch_resolution_recovery.py -q`
通过10项/2.18秒，保留一条既有pytest配置warning。Ruff/格式/compile/diff通过，独立
静态复审GO_SOURCE_ONLY；Root核对四路径提交、SQLite回执/事务、重启及回滚断言，子包
索引/工作区干净。测试中的journal authority和provider证据为合成，不是实际SDK或
真实账户证明。父仓只更新Risk gitlink及两份记录，未重复已接受RISK01/02检查；正式
仍12/68，RISK03保持部分。

## 第72轮：AFI 已发布研究来源读取及类型检查纠正（2026-10-15）

AFI现有dev `cd47e8d3d385b1b88a2bf773b90273527ec84714` →
`fc69f6e8b91d0c6e3ead5f4e7d9d8623f5f198e0`，精确七路径：组合service/API测试、
前端API/Page/页面测试及中英文locale。research_artifact绑定AssetAnalysisReport，
查询经USER任务与当前JWT主体过滤，缺失/他人记录统一不可读；先核对内容hash及报告身份，
再投影已发布decision的有限字段。研究报告不作为持仓/现金/收益或执行归属，币种未声明、
新鲜度未定义、账户价值null和覆盖不完整均明确展示；imported/paper尚未接入。

聚焦后端API1 passed、页面34 passed，Ruff/格式/ESLint/生产build通过，独立静态复审GO。
完整 `npm run typecheck` 实际exit 2、81条诊断。用相同ignored生成声明对照cd47e8d3，
旧提交也是81条：四条既有PortfolioPage DefaultRow错误及其余77条相同诊断；本轮没有
新增诊断，但不能称全量typecheck通过。旧提交缺少生成声明时exit 0不是等价环境，因此
本轮纠正第69轮未留原始日志的无条件通过表述。原始当前输出在
`D:/temp/afi_current_typecheck_20261015.txt`，对照输出在
`D:/temp/afi_cd47e8d3_typecheck_baseline_20261015/typecheck-head-with-current-generated-dts.txt`。

Root核对七路径提交、实际owner/hash/字段投影及完整诊断。AFI索引空，九项无关README/
scripts修改保持；父仓仅提交两份进度记录。接受等级为合成API/UI研究来源组件，不是
AFI02/03完整验收，正式仍12/68。类型边界根因另轮修复，已通过UI检查未为交付重复。

## 第73轮：CFG01 隔离普通路径验收（2026-10-15）

固定已提交SDK cdb1b81e39b661afb145ff3d9e94695c97429d7e生成0.15.5 wheel，在新Python
3.11.5 venv正常解析安装SDK/Base/Backtrader及依赖，pip check通过。一个原始probe观察
无新块与空clients的实际public loader/CLI、默认BtApi DirectBackend正常关闭、正常
Cerebro一根合成bar；四领域与ZMQ/spdlog包缺席，服务模块零加载、可选构造/运行阶段
资源计数零。未替换SDK或Cerebro业务实现。

原probe状态保留ASSERTION_FAILED / exit1：唯一错误断言将build_tool_version从manifest
顶层读取，实际在build.build_tool_version且为1.6.1。独立只读metadata核对wheel/安装
版本0.15.5和hash一致；另保留manifest把配置65字节误写68的描述错误，其Git blob/内容
hash正确。原运行未重复。Root和独立审查按CFG01业务要求逐项审查运行事实及更正，裁定
**CFG01正式PASS，合计13/68**；没有把原失败进程改记为通过。

证据与完整边界见[evidence/cfg01-current-cdb1-20261015/root-adjudication.md](evidence/cfg01-current-cdb1-20261015/root-adjudication.md)。
原始八payload保持精确字节；包含probe、manifest、observation、metadata更正及pip日志。
隔离依据实际venv启动命令/环境、distribution/direct_url及依赖路径；原JSON未记录
BtApi.__file__/sys.prefix，不补造。导入阶段两个Popen、一个socket及句柄+438均保留，
不宣称全局零OS资源。当前只关闭CFG01；CFG02–04/MIG04与远程代理/真实账户仍待完成。

## 第74轮：多服务启动期间的注册租约维护（2026-10-15）

LOAD01短试跑暴露已有SDK启动缺陷：多个binding逐一注册时，先注册的30秒租约可能在
start完成前过期。不能靠延长租约降低验收压力。本轮在ServiceClientRuntime的starting
阶段内部续租，RPC发送前后核对required deadline，超时预算受最早租约剩余时间约束；
续租不会递归触发维护，starting不向公共call/healthy暴露为registered。

成功register的ID/epoch立即保存为inactive清理记录，通过其余receipt验证后才提升为
active。迟到receipt和BaseException不丢远端清理身份；无法留存ID时显式计未知注册。
startup回滚仅unregister可跳过过期租约准入，仍使用正常超时与ACK验证，保留不确定性；
receipt验证及第一次unregister都被中断时，可按原ID再次清理。未修改30秒租期或负载。

实际命令在禁用pytest插件自动发现下运行：`C:/anaconda3/python.exe -m pytest -q
--noconftest -p no:cacheprovider tests/unit/test_service_runtime_startup_lease.py
tests/unit/test_service_runtime.py tests/unit/test_service_market.py
tests/unit/test_load01_hundred_strategy_30min.py::test_load01_startup_rpc_maintenance_checks_each_boundary_with_controlled_clock`。
原工具结果c72b24：53 passed/6.50秒，一条既有pytest配置warning；分别为新startup7、
既有runtime37、market8、LOAD runner单个受控时钟节点1。未运行100进程或30分钟负载。
Ruff/格式/compile/diff及独立静态复审通过；Root核对实际diff、清理保留及新测试。

本轮精确提交startup runtime hunks和新测试及两份记录；尚未接受的book操作登记与Risk
submit-only能力两块留在工作区，LOAD runner也不纳入本轮。实际QA时runtime为
dc43f210fbc95a0d9d94b875f2333ce024ff9cbf9771cfa157f6aaf5534723ef；仅还原这两块
无关待交付能力后的提交blob为879913584345abc686d425c5d149c8cd43ffb4d77c388ce186c1df520b67ea0c。
新startup测试为cd656d43b5863658986b597d0d30c9b7f53ca278564590fae91e938a9d6c1429。
源码组件修复不等于LOAD01正式通过；下一步使用固定依赖版本重新完成短试跑，再进入
原定30分钟验收。正式仍13/68，没有为提交重复已通过检查。

## 第75轮：AFI 表格行泛型边界修复（2026-10-15）

AFI现有dev `fc69f6e8b91d0c6e3ead5f4e7d9d8623f5f198e0` →
`d666ebb2cd95e08b18f2a27c452e6f2e612e50fe`，精确24个Vue文件、50行新增注释。
第72轮复现的81条诊断来自Element Plus ElTableColumn泛型未从父ElTable的data推导，
生成声明存在时slot row退回DefaultRow。每个受影响column前增加@vue-generic，使用
所在表实际typed集合元素类型或已声明的模型类型；没有any/cast、删除生成声明或降低
typecheck要求。

在保留真实components.d.ts/auto-imports.d.ts的同一环境，完整 `npm run typecheck`
exit0；24个修改文件的ESLint（max-warnings 0）及diff检查通过。独立只读审查逐项
确认50个注释紧邻column且与数据来源类型一致，Root核对精确提交和代表性diff；未为
这项纯类型修复重跑已接受UI业务套件。AFI索引空、九项原有README/scripts改动保留。
父仓本轮仅记录该已接受提交，第69轮历史证据限制仍保留，不追溯改写为等价环境通过。
正式仍13/68，AFI功能验收缺口未由typecheck通过替代。

## 第76轮：Execution 正常服务分账读取与 EXE03（2026-10-15）

SDK account_owner经新service_execution_account_books组合适配器复用Execution订单入口和
AccountBookService。账户事实、目录、人工归属和完整性来自服务端可信resource，RPC只接受
空查询参数；策略仅见自己的book，人工应用须独立授权，完整账户视图须账户读取授权。
读取前后绑定同一journal generation和outbox bounds，事实读取与对账之间新增订单则拒绝
旧cut。无source不公布books操作；既有query客户端默认不申请该操作，显式opt-in仍需服务
grant。query-only装配不获取writer锁或运行订单恢复，非法source/资源组合拒绝并正常关闭。

Root使用已接受Execution 3e0c6bc376f5d64385ef2a6ec56344dca2886acb的19个Git原始源码
导出，未导入正在开发的P5A工作区。实际runner/原始日志/JUnit/来源/前后pins/result在
`D:/temp/iteration10-exe03-sdk-root-20261015-a`及`-b`。a执行两个新测试文件，6 passed /
1 failed（3.70秒）；三个业务集成节点全部通过，新wiring节点向Pipe发送MappingProxy
而失败。仅修fixture纯数据投影后，b只运行该失败节点，1 passed（2.09秒）。没有一次
7/7运行，也没有为交付重复其它6项；每次均有一条既有pytest配置warning。a失败host已
退出，父端正常关闭报告BrokenPipe，无强杀；b要求全部正常退出。a/b输入前后均未变，
导入来源验证Execution导出及SDK当前源码。最终wiring另经Ruff格式修正，AST逐项相等；
三文件Ruff检查通过，独立静态复审及Root源码核对通过。

两策略提交同品种同intent文本ID但独立scope，分别部分成交2/1、费用0.12/0.08；真实
SQLite/outbox驱动分账。含基线后两策略持仓为3/-1.5，manual为0.75，UNALLOCATED为
-0.50；provider增量1.25与账簿对齐，持仓残差零，费用残差0.03明确保留。人工外部
订单/成交只进入对应book，未知外部归属不分摊到策略。包括越权、请求注入、过大响应、
源缺失及读取期间journal前进的拒绝。provider dispatch、目录、账户快照和外部活动为
确定性合成叶子，真实业务入口/状态机/对账未替换；不证明生产provider采集完整性。

依正式EXE03第757行要求，Root与独立裁定接受本机合成服务对账范围，**EXE03正式PASS，
合计14/68**。NET以外、lot/PnL、真实账户及全P4功能不由本条推导。提交仅含adapter、
两个测试、Execution相关components/runtime hunks及两份记录。QA共享runtime为B3EF6561
前缀、components为96FCE6CB前缀；提交排除未验收Risk hunks，所选LF blobs分别为
f15ce15e895c1752ceb791d586ff23babf112461cf25c7edf58a8ac990b33793及
e8d81a79670c8a8bb8dca73f8a8f3488839f7767ef0a234ee16e791075cc92f7。
Risk源码/config/normalization及两个包的P5A工作不随本轮暂存，现有dev工作流继续。

## 第77轮：Risk 同账户组向量预留组件（2026-10-15）

前轮SDK已提交为c066dcc6c1e2bd7b6c756bb755c980750ecda3f9。Risk现有dev由
a3b73f19614352644a2a4c9678cd77d6931c38ce提交到
b2165edcf31ba23e53c6afaf3f7c0c52fac739ad，精确六路径：admission、instrument、
order_admission、两个包export及test_group_vector_reservations。Root核对提交、实际
SQLite claim/mapper实现及干净子包索引/工作区；父仓本轮只更新gitlink与两份记录。

同账户整组腿在一个BEGIN IMMEDIATE中检查account/strategy额度并预留，后腿失败整体
回滚，重放绑定原group/leg/policy/deadline。普通singleton入口拒绝组permit。query/
release保留已claim/UNKNOWN腿和占用，仅释放明确未claim资源；原settle路径兼容组claim。
不可变reserved intent保留最大quantity/notional；实际对冲子腿可缩小，但必须经过
可信instrument mapper、相同scope/经济身份/profile且不越过最大量和金额。实际hash与
预留hash分别持久化，claim绑定当前事实时间，事务提交前再次检查期限/估值有效期；
不同实际腿重放拒绝。profile仅组mapper显式设置，旧普通RiskIntent fingerprint保持。

实际聚焦命令 `C:/anaconda3/python.exe -m pytest -q tests/test_group_vector_reservations.py`
12 passed；先前受影响group/order/instrument/import-boundary组合50 passed、既有
durable_risk_gate 62 passed。各次均一条既有pytest配置warning，不相加为独立案例数。
六路径Ruff lint/format及diff检查通过，独立静态审查GO_SOURCE_ONLY；未为提交重跑。

本轮只接受Risk包组件及合成SQLite证据。coordinator/current writer授权由Execution/
SDK可信guard负责，必须持有实际writer lease并跨claim/dispatch保护；此接线及正常
组服务未接受。Risk receipt的scope.key是可信AccountScope规范JSON，不能拿wire
account_ref直接比较；reserved Risk hash、actual Risk hash、Execution request hash
保持分离。P5A/P5B、ARB/DIM、真实provider均未正式通过；总数仍14/68。

## 第78轮：共享行情到 Monitor 正常服务链与 MON03（2026-10-15）

前轮SDK59b3f959fe1ea181b8c23987c6228c5bdfdd489c已记录Risk组件。新增一个正常
服务集成测试，使用实际parsed service_directory、TrustedServiceClients、身份/grant/
scope/peer/登记关系启动Gateway、Monitor ingress、reader三个ServiceHost。relay和
ServiceMarketClient共用reader_host.upstream，生命周期由原host正常关闭。

合成GatewayHub帧经CURVE、Base投影、relay append、Monitor durable SQLite outbox及
read query，核对完整envelope/payload、认证producer、有限market字段、Gateway源
epoch/sequence/sent time和occurred_at。system能读到一条，account/strategy各为空；
另一账户读与relay改为账户写scope均SCOPE_DENIED。使用实际next_cursor检查空tail、
has_more及类型；合成quote marker未进入投影，不给策略或账户健康背书。客户端/host
关闭且全部子进程exit0，无强杀。

实际成功命令为禁用pytest插件自动发现后的 `C:/anaconda3/python.exe -m pytest
--noconftest -p no:cacheprovider -vv -s --junitxml <h>/junit.xml
tests/unit/test_service_market_monitor_curve_integration.py::test_gateway_market_frame_reaches_system_monitor_and_stays_out_of_other_scope_views`。
证据目录 `D:/temp/iteration10-mon03-root-curve-20261015-h`：1 passed/5.02秒、exit0，
20源码pins及五仓branch/HEAD前后一致。保留3条PyZMQ Proactor/Tornado warning及1条
既有pytest config warning。log SHA BC75998C32FD3F689F4F10D4A803A7B544F2E799FD7794C52A1D7A51BFE1901A；
result SHA 6F2270BABDFAFCDAE3F2D22F3D85C9108DE4788AE1E990F44B97E4F0300FD283。
执行test SHA E8EB6CFE9CC97869D7EE66CA4360BCBF336719E52B06CE96821D4B14C56E0F01，
原始源码另存h/executed-test.py。交付只做Ruff空行/格式修正，AST与执行源码相同，
Ruff通过；未重跑已通过节点。前序配置/启动/断言schema失败全部保留，未记为通过。

Root读取原始日志/结果并与独立裁定结合历史证据：第11轮实际账户/双策略授权正反例，
第14轮not_collected且无指标、第35轮策略只登记orders/order_query而无telemetry仍
保有订单事实，第63/70轮系统投影；本次补实际共享行情服务链缺口。依MON03原文裁定
**MON03正式PASS，合计15/68**；独立review旧12→13计数被当前14→15替代，不改其证据
结论。仅为合成数据下的本机真实服务合同，不是live行情/账户、持久relay或LOAD通过。
本轮精确提交新test与两份记录，所有未验收Risk/Execution/LOAD修改继续保留。

## 第79轮：Execution 组腿授权与派发组件（2026-10-15）

第78轮SDK提交6722d5eb55ba33c2bfd58dcf9ae830747698ddaa。Execution现有dev由
3e0c6bc376f5d64385ef2a6ec56344dca2886acb提交为
5de46fa8cbda959eac6f0a6703f746cbb85f02a4，精确八路径：export/facade/
group_contracts/service_component/service_order_entry/store及两个聚焦测试。Root核对
提交与实际authority/lease/receipt实现，父仓仅更新该gitlink及两份记录。

新增typed GroupPermitBinding和独立GroupLegAuthorization。业务binding持久化group/
leg/portfolio/strategy/account、预留permit、三种不同intent哈希和原始deadline；
授权attempt另外追加持久当前coordinator/account epoch及执行writer lease指纹，不把
刷新授权改成新的业务ID。server取得真实lease后进入可信authority context guard，
跨Risk claim和provider dispatch持有，guard可阻止并发撤权/换代；不同epoch域分别
绑定，不未经合同把account authority epoch等同SQLite fencing token。

仅显式submit_group_leg入口接组binding，普通submit/cancel拒绝组namespace。复用
原Facade/SQLite/UNKNOWN路径，已claim或不确定状态只查不重发、不单腿释放预留；
receipt比较可信Risk AccountScope.key指纹，不能从wire account_ref猜身份。
v21→22迁移只加组字段与不可变审计，不重放历史CTP cutover。正常API尚未登记为SDK
远程能力，生产authority及服务端coordinator/advance/recovery下一轮接线。

实际51项聚焦（group_order_entry、execution_store及CTP factory相关）4.74秒通过，
无测试warning；Ruff lint/format、py_compile和diff检查通过。独立首次HOLD定位
授权先于lease与Risk scope错比，修复后的独立静态复审GO；guard竞态fixture验证provider
返回前并发epoch/revoke不能穿过。未为提交重跑已接受套件，子包提交时索引/工作区空。
证据为包级合成authority/provider，不是SDK组RPC或完整P5A，正式仍15/68。

## 第80轮：CFG03 配置组合与无副作用矩阵（2026-10-15）

SDK父提交d9964eb56c79b2370909fd3cdeed9d7326e1af1e。本轮只新增配置矩阵测试，
使用公开parse_service_config/parse_client_config。六种正例为全部四包、G+E、E+R、
G+M、E+M、R+M；五种反例为跨账户复用scope、重复客户端挂载、服务端口争用、缺backend、
拼错Risk字段。核对精确错误code/path及输入不变；在解析调用期间拒绝并计数socket、
DNS、subprocess、thread、multiprocessing、SQLite和可选领域/transport导入，计数为零。
guard安装在包导入之后，因此不声称整个Python/pytest进程零资源或冷导入无副作用。

作者先前11项通过仅有摘要、完整命令和原始日志不可恢复，未据此提前增加正式PASS。
Root第一次可追溯正式验收使用固定已提交6722d5eb55ba33c2bfd58dcf9ae830747698ddaa
SDK导出；__init__、配置和直接本地依赖与该提交Git blob逐项相符。当前未接受Risk
配置扩展不进入本次解析。配置SHA为8df0d2d5248215402872f241d40de2d11f89e59363af2d1a904ff3f5c4993bff，
测试SHA为393ac9c2fdc7c1e29f32498c294f07eb0883903a54961ca7185a39ddf9e941b5。

Root工具96e137：`C:/anaconda3/python.exe -m pytest --noconftest --import-mode=importlib
-p cfg03_origin -p no:cacheprovider -vv --junitxml=D:/temp/iteration10-cfg03-root-20261015-a/junit.xml
D:/bt_api_py/tests/unit/test_iteration10_cfg03_matrix.py`。禁用插件自动发现、固定SDK导出及
Base源码PYTHONPATH；cfg03_origin仅记录/验证实际配置模块路径和前后两源码pin。
11 passed，0.54秒，pytest/Python exit0，一条既有未知pytest配置warning；Ruff通过。
完整日志/JUnit/exit-code/before/after及origin插件保存在上述-a目录。日志SHA
cea55152bc0c0279a2c6175a67fd8887720288abe12e3cc4ea55ee51797c6bd7，JUnit SHA
e1f4718e6a33dd20ee744ecc6a362585fb665ac46fd4055af58631d3d58d8f98。

独立静态审查及Root逐项源码核对通过。依正式CFG03的“配置正反例及无副作用检查”
验收要求裁定**CFG03正式PASS，合计16/68**。CFG02真实组合服务、CFG04四包未安装
客户端代理矩阵仍独立待验，不借此提升其状态。精确范围为新测试和两份记录，未接收
其它Risk/Execution/LOAD候选修改；不为交付重复本次通过的检查。

## 第81轮：AFI imported 原始来源与组合投影（2026-10-15）

第80轮SDK已提交c8a5b7165f248320b20d7623a68c4049f4b2548c。AFI现有dev由
d666ebb2cd95e08b18f2a27c452e6f2e612e50fe提交为
aead91066655effe42e2dd1098da28243f6b56bf，精确17路径；Root核对提交、source contract
与实际剩余status，原九项README/scripts改动保留，索引空。父仓本轮仅更新记录。

在既有导入记录中增量保存有界canonical原始JSON、schema、SHA256、显式可选来源日期/
币种；旧记录不补造原始来源。组合成员使用不可变import引用，经ledger owner关联校验后
读取；PortfolioPage实际composition入口增加来源选择和原始记录投影，research/imported
与账户事实分域。完整性包含日期与币种覆盖，损坏hash和缺失数据明确呈现，不推导账户
总值、现金、FX、新鲜度或Execution归属。日期覆盖要求完整ISO日期往返或完整ISO datetime
解析；`2026-10-12garbage`不算已注明日期，回归明确三条仅一条有效。

作者最终API工具037316为6 passed/exit0，四条既有pytest配置warning；先前合并API/
migration/composition聚焦9 passed/1 skipped，skip是环境缺已有可选SDK
bt_api_base.account_protocol。前端Vitest三文件51 passed（dcc869），定向ESLint
max-warnings0（ede5e5）及Ruff（9bca77）通过。独立只读审查对修正后快照GO。
源码提交后补完完整`npm run typecheck`，session24506/launch da6582最终exit0无诊断；
`npm run build` session24503 exit0，prebuild核对48项approval artifact，Vite构建4082
模块/35.64秒，保留既有大chunk warning。未为交付重复已接受业务测试。

上述AFI命令输出仅在原工具记录，作者未保存独立磁盘日志，不宣称已有JUnit或日志归档。
composition源SHA52bb217ef5acac888b1b32c872186363abdce840b2e0cf464eb8082a1d7e5d2d；
API测试SHAe30468c27f27105be9c75f4e532ae95d88cb269a19deeddf4b01dd5fd5b628f1。
本轮为owner隔离的合成API/UI和迁移组件；真实账户/完整AFI02–03/12仍未通过，正式仍16/68。

## 第82轮：Backtrader 显式策略归属账簿读取（2026-10-15）

前轮SDK记录提交2d92d1b5。Backtrader现有dev由
53d2bf93949737f2ba6f51979f3f3d13b0d1b450提交为
01fc254cfd4c81f659be7c4051b2d53a79b9fe6a，精确五路径：session、Broker、新策略账簿
view及unit/integration测试。Root核对提交、原始成功日志/JUnit和source-origins；索引
为空，原CTP三文件、删除0及历史证据目录保持。父仓仅记录本轮，不改变这些外部仓内容。

策略显式调用get_strategy_account_book_view(strategy_ref,account_ref)，要求真实运行中
session、required order_query绑定、exact已认证scope及显式获授execution.account_books.query。
使用现有SDK正常调用，校验完整strategy-owner单一book、账户/策略身份、position/fee及
baseline<=current游标。共享Broker默认getters不猜策略身份；缺cash/value明确不可用，
不以账户余额或Risk预算替代。策略进程生产路径不导入Execution领域类。

单进程聚焦7 passed/一条既有配置warning；首次unit因pytest-asyncio Package.obj在
collection失败，禁用不适用插件后成功。真实ServiceHost/CURVE/Cerebro节点首次session
85581 exit1，fixture遗漏cerebro.addstrategy导致仅默认Strategy运行，没有执行book查询；
独立审查后只修此注册，session30773得到1 passed/8.36秒/exit0，一条既有配置warning。
成功节点核对两个读取、精确策略持仓/费用、错账户拒绝、cash/value unavailable及正常
runtime/service退出。未把测试预设合成事实解释成真实provider或成本账。

命令为`C:/anaconda3/python.exe -m pytest -p no:asyncio
tests/integration/test_btapi_strategy_account_book_local_process.py -q --junitxml <r1>/junit-r2.xml`。
独立审查GO；Ruff只报告btapibroker.py原有非改动行RET501，编译通过。
证据根`D:/temp/iteration10-backtrader-strategy-account-book-20261015-r1`保留初次command/
pytest.log/junit.xml/exit-code与成功command-r2/pytest-r2.log/junit-r2.xml/exit-code-r2，
没有覆盖失败。source-pins.txt/source-origins.json验证SDK d9964eb、Base b4aabd1、
Execution5de46fa固定Git导出及实际Backtrader dev来源。正式BT01/BT02还缺资金/成本、
完整恢复/回调与场景迁移，仍为部分；正式总数保持16/68，不重复本轮已通过检查。

## 第83轮：Risk 首次成交终态与组腿可信账户映射（2026-10-15）

SDK父提交00974c21。Risk现有dev由b2165edcf31ba23e53c6afaf3f7c0c52fac739ad
提交为72d955e6ff1ddc35aabaf67ef88dc48a765f38df，精确七路径：两个export、
core/admission、core/exposure、order_admission及两个聚焦测试。Root核对实际提交、
分支与空索引/工作区；父仓仅更新Risk gitlink和本轮两份记录。

新增首次正成交终态证明：完整FILLED或部分成交后CANCELLED、leaves=0、精确claim/
派发次数、不可变fill和当前可信估值/来源，才可在同一事务写入既有exposure/fill账、
保存resolution并解除对应dispatch latch。reservation保持SETTLED，重复证明不双计，
不清其它冻结；UNKNOWN或不完整事实不能走此路径。普通exposure更新仍需已有派发证明，
没有另建OMS账本。组腿claim要求owner提供持久可信AccountScope，与mapper结果精确比较；
不从wire account_ref猜Risk账户ID，普通单笔映射行为保留。

作者实际聚焦命令为`PYTHONPATH=src C:/anaconda3/python.exe -m pytest -q
-p no:cacheprovider --noconftest tests/test_dispatch_exposure_resolution.py
tests/test_group_vector_reservations.py`，最终22 passed、exit0，一条既有未知pytest配置
warning。前序fixture错误保留；最后仅对两个export作导入排序，py_compile、Ruff及
diff检查通过，未为归档重跑行为测试。独立risk_freeze_api_review对本轮源码GO；
现有工具输出为QA依据，不把未提供的原始磁盘日志称为已有归档。

这是合成SQLite/adapter组件证据。SDK真实生产观察链、正常组协调ServiceHost及完整
P5A/RISK02仍待接入和验收，正式总数保持16/68。父仓其它待验收修改全部排除。

## 第84轮：Risk 独立订单入口与真实重启恢复（2026-10-15）

SDK父提交44846f4fd33f34f9b48350013ab697600300e77b。本轮精确九个source/test路径：
_normalization、service_components/config/runtime，新增Risk order entry/journal、
Risk集成与装配测试、纯标准库进程helper；加两份记录共十一条。行情版本、Execution
authority、LOAD和REG02候选均排除。本轮只用普通ServiceHost、ServiceExecutionClient
及原BtApi DirectBackend，不新增独立验收入口。

Risk account_owner按显式清单提供orders.submit/query；没有实现cancel便不授予该能力。
服务端持久writer fence和Risk最终准入位于实际provider写之前；策略不配置Risk查询
代理也不能绕过。正常化order/fill保留有界显式provider来源投影，区分请求回填默认值与
原始来源事实，验证完整性、唯一client ID及订单/成交对齐。journal持久记录准备、claim、
单次派发、观察、PROOF_READY及ACK；不确定派发只查原业务ID，不重派。

前序Root d为7 passed/4 failed；e为9 passed/4 failed。d定位fixture向错误Pipe发snapshot
及装配器只允许UNKNOWN而拒绝合法恢复ACK；e定位foreign fixture使用非法application挂载，
以及append_recovered_ack缺updated_at_ns，使严格history验证失败又被ACK保护分支掩盖。
原日志/结果保持。本轮恢复ACK加入事件hash绑定的真实时间戳；当前receipt/history无法验证
或显式provider查询不确定时追加UNKNOWN，保留不可变ACK历史和Risk占用，禁止重派。
这是当前验证不确定的投影，不改写provider曾接受的历史事实。其它内部ACK路径默认保留。

Root f实际执行8个受影响节点（工具d7e278/session56065，完成48e129），使用固定Risk
72d955e6 Git导出、Base b4aabd1/Transport614e2d3导出和本轮SDK：8 passed/82.94秒/exit0，
一条既有pytest配置warning。覆盖正常gate/幂等/元数据及真实错账户拒绝、claim后中断、
provider写后中断、歧义查询、三个PROOF_READY/Risk提交/ACK落库中断窗口及新增失效receipt。
正常关闭和故障注入后的有界回收断言通过，forced cleanup为零；预期故障进程退出不被
解释成所有子进程均exit0。恢复启动和重复提交零provider读取/零再次派发，随后显式查询
恰好一次order与fill读取，持久事件/时间戳/hash和原占用一致。

测试已移除对Gateway测试模块的间接依赖：六个进程helper与原函数AST完全相等，仅替换
五处import。f的实际父进程模块观察未加载Execution/Gateway/Monitor；这不是未安装证明。
所有选定SDK/test源码pins前后一致。命令、PYTHONPATH、stdout、exit、JUnit和origins在
`D:/temp/iteration10-risk-recovery-root-direct-20261015-f`；日志SHA
3f3e4e9403b2cce595a1a685a7620b3c8fc42af2bc4527f71f412f13c5d1ae2a，result SHA
d1279eec6f9e4020265bc9a7b8d55f02052cdb7986e36849f62e26393b8dd81a。
最终entry SHA16540e7c4c391d932a32f036bc352810f171e0fbdfff7a8db09ea1bc968acbce，
journal SHAbcb6976f6c2d93c08186cacccf4dff7c53b024f54adcbce012e79ec5663e72cf，
integration SHA7ffacbfe20f0c6e2f5652c8d3be3de7c2206a848300b15c7556430024e1b98a8。

同一_normalization修改另做既有public API定向回归（7a7914）：14 passed/72 deselected，
1.74秒、exit0、一条既有配置warning，覆盖原始默认行为、成交价格/费用、RequestData、
CTP容器和Binance成交来源；日志/JUnit在f的normalization文件。九路径Ruff与diff检查
通过，最终恢复delta独立源码review GO。既有e的九项装配检查未重复；不能把分次结果
叙述为一次全套通过。

接受等级是合成provider下的真实本机进程/传输/SQLite闭环。RISK03尚缺新venv中未安装
Execution/Gateway的正式隔离安装证据；RISK02完整成交敞口观察仍另验。正式保持16/68。

## 第85轮：Execution 持久两腿协调组件集成（2026-10-15）

第84轮SDK已提交0821e41f2ec967aa7bce01234dd1824e3aeb4f95。本轮仅更新Execution
gitlink及两份进度记录。Execution现有dev从5de46fa8cbda959eac6f0a6703f746cbb85f02a4
提交到84d97c9f4f85828cb649ed69c147e2ad4cf77c00，精确十路径；Root重新核对十项
checkout SHA、实际提交、干净工作区和空索引，未重复已接受测试。

新增持久组合同、SQLite组状态和顺序两腿协调器；首腿部分终态使用真实Risk resolution，
按确认成交推进对冲。丢失回复时重开store后查询原业务ID，不能再派发；绝对期限只阻止
新增派发，已有对冲的事实查询仍可进行。Risk release成功但本地仍为RELEASE_REQUESTED
时可恢复；已claim的腿不被释放。AccountScopedGroupAdmissionAdapter由owner注入可信
AccountScope，真实Facade/ExecutionOrderEntryService调用Risk严格scope入口，允许可信
映射的wire别名而不猜账户；没有适配器时明确GROUP_ACCOUNT_SCOPE_ADAPTER_REQUIRED。

作者定向运行test_group_order_entry、test_group_coordinator及test_group_risk_integration：
20 passed/3.02秒；十路径Ruff/格式、compileall及diff检查通过。独立exec_p5a_round_review
对包级合成证据GO；release丢回复用例在同一coordinator重试，不宣称该分支重开SQLite。
执行记录为.codex-tmp/p5a_execution_group_r1.json，SHA
fc5fe59e43f10e9cf87f4b593d568718f1f10e33681e60bd366ff1e316d01f49；其parent_head
保留生成时上下文，实际子包父提交以commit_parent及Git为准，父仓本轮基线为0821e41f。

本轮接受包级合成组件，不接受SDK组RPC/可信authority的完整接线、跨账户实际provider
或ARB正式用例。authority的终态重放/拒绝回归另在当前SDK轮修复；正式仍16/68。

## 第86轮：REG02 多服务部分失败正式验收（2026-10-15）

父仓基线2b8a3c3fe41aaca159f9756c06e18a5994513b7c已集成第85轮Execution。
本轮只提交新增REG02集成测试、五个公开证据文件及两份进度记录，不包含正在开发的
topic-v2/authority/LOAD。实际验收运行固定已提交SDK44846f4f、Base b4aabd1、Gateway
59b164a、Monitor536a4f0和Transport614e2d3导出；parent及两个child均核对实际加载来源。

正常SDK ServiceClientRuntime连接两个独立spawn ServiceHost及CURVE端点。预先建立
Gateway读取登记和持久合成持仓事实，再依次测试第二必需服务拒绝SCOPE_DENIED、必需
端点缺失REQUEST_NOT_SENT；各自恰好新增一条已回收临时登记，原active登记保留，失败
runtime无bindings且调用拒绝。可选遥测缺失返回一次显式降级，只挂载store.account；
遥测调用无可用路由，业务事实仍能读取。最终四个runtime关闭，两个host正常ack/exit0，
零forced cleanup、零cleanup error，所有业务SQLite行前后相同。没有provider或凭据输入。

r1为fixture CURVE key名不匹配；r2为Windows spawn导入tests.unit路径错误；r3为
mappingproxy不能直接JSON序列化；r4在子进程最终closed ack后继续读pipe，把正常EOF
误报cleanup错误。均属本方fixture/runner缺陷，原日志/结果保留，不计通过。修复后的
r5只运行同一必要节点：1 passed/exit0；一条既有pytest配置warning。最终源码独立GO，
不因交付重复执行。源测试42100 bytes/SHA b619bcc6e9decd24ea86841a59ad7c99a081bf61897afc0622cda8bc0a1a8afb。

Root对照正式计划REG02逐项核对测试断言、原始observation、stdout及JUnit，裁定本条
正式PASS。运行目录D:/temp/iteration10-reg02-partial-failure-20261015-r5；仓库保留
observation、command、stdout、JUnit与独立Root裁定于evidence/reg02-partial-failure-20261015/。
reviewer消息误报42003字节；run-summary与Root实测均为42100，双方SHA一致，Root裁定用
实测文件与该SHA，不修改原记录。原observation.formal_pass_claimed=false保留，正式
裁定是本轮新增记录。正式总数17/68；本条不证明REG01/03/04、真实账户或跨机器验收。

## 第87轮：RISK03 未安装 Execution/Gateway 的真实服务准入（2026-10-15）

第86轮已提交12674ae6c93a9bd3f72c782cdcce2cf159307749。本轮只交付隔离运行证据
及两份记录，没有修改SDK生产代码或重复第84轮八个恢复节点。新目录
D:/temp/iteration10-risk03-isolated-20261015-r1使用Python3.11.5 venv，明确关闭
system-site-packages，从固定Git导出构建Base b4aabd1/Risk72d955e/Transport614e2d3及
SDK0821e41f wheel，以正常pip resolver安装且非editable；pip check通过。
Execution/Gateway/Monitor distributions和import spec均缺席。SDK wheel SHA
473b65fbbc45f7506209c102f0bcd0a33995dd428231b34a0de6440ba675ea9f。

Root在artifact cwd运行单个既有正常节点（工具e8c169）：1 passed/4.49秒/exit0，
零warnings。测试根仅复制已提交tests/目标/helper，并加入空unit包标记以支持Windows
spawn；没有把SDK源码根放到PYTHONPATH。安装/复制源码与Git只存在CRLF/LF差异，Root
四个关键文件逐字节归一化比较一致；不把原始hash差异说成精确相同。

普通ServiceExecutionClient经实际CURVE/ServiceHost和BtApi DirectBackend调用真实
Risk gate/journal。策略仅申请orders及query，没有risk客户端；前两笔正常准入，原ID
重复和策略重启后重放不双派发，订单及成交观察可查询；超额、元数据错版和越权账户均
明确拒绝，provider写入计数保持两次。所有测试拥有进程按既有helper正常关闭且无fallback。

只读atexit记录得到四个加载SDK的进程，解释器/prefix均为venv，所有有__file__的
SDK/Base/Risk/Transport模块均位于其site-packages；没有加载三个禁用可选包。
bt_api_risk.containers为无__file__的namespace，未记录其__path__；另有一个无SDK模块
的Anaconda辅助记录，不宣称所有被观察解释器都在venv。上述限制原样记入Root裁定，
不影响实际四个SDK进程和未安装包的本条证据。Root初次metadata汇总错误要求namespace
有__file__，后改为如实分别记录，不重跑节点、不改写原始观察。

正式计划RISK03要求的未安装组合、最终准入、订单观察、拒绝零provider写入和无回退
已逐项满足，Root裁定正式PASS，总数18/68。provider事实为合成，本条不证明真实账户、
RISK02完整成交敞口、组协调或长期负载。证据见evidence/risk03-isolated-20261015/。

## 第88轮：SDK 协商并使用 topic-filtered 行情 v2（2026-10-15）

第87轮已提交3fcfabac。本轮精确十一条：Transport gitlink、五个SDK源码、三个topic
测试及两份记录。Transport现有dev29ab21e714292a363538491e4ff8461d336d1dfc的四路径
组件轮已独立接受，8个实际CURVE测试通过；本轮不重复包级QA。

配置允许只在market端点显式选择整数market_wire_version=1/2，未填写保持旧规范化
配置。ServiceHost将发现能力与实际publisher绑定到同一profile版本；Registry广播
明确版本。Runtime将旧三字段描述视作v1，畸形/冲突描述及版本不匹配在注册激活前拒绝，
optional绑定也不能吞掉这些错误。ServiceMarketClient v2把精确MarketSubscriptionKey
传给支持create_topic_v2的工厂，不支持时明确失败；v1仍调用旧二参数工厂且不传新kwargs。
因此此轮必须同时交付四共享文件和service_market，不单独交付shared.patch。

Root第一次命令因PowerShell参数数组把JUnit路径拆开，零测试/exit4；修正argv后r2
七文件172节点为167 passed/5 failed。五个失败均是新fixture用非法clients.market，
改为注册的clients.gateway，并按实际parser区分bool的INVALID_TYPE与范围INVALID_VALUE；
作者仅补跑这五个失败节点，5 passed。既有167成功节点不为交付重跑；不声称一次172/172。
相关检查含config/registry/runtime/host/market及两份新unit/合同文件。r2原始命令、日志、
JUnit在D:/temp/iteration10-topic-v2-sdk-20261015-r2，16条warning为既有pytest配置/
Windows PyZMQ Proactor兼容提示。

新的真实接线节点由owner线程启动正常ServiceHost/CURVE RPC+PUB，两个实际SDK订阅
不同stream；分别只收到对应marker及sequence。另起v1默认profile验证原数据路径，
v2客户端连接v1服务明确MARKET_WIRE_VERSION_MISMATCH。初次实际失败是fixture把
ClientCurveKeys三个bytes的位置写反，源码API核对后改为明确server_key/public_key/
secret_key关键字，没有放宽生产检查。最终r4单节点1 passed/2.46秒/exit0，2条既有
warning；启动及失败cleanup经独立review修复，最终要求线程join、host closed、provider
订阅start/stop平衡且active为空。日志/命令/JUnit位于同名前缀的r4目录。

最终integration SHA26c645aea51776f8fe2722d6f3f46857c46b5133832e4d07dc2ec75fc8643c11。
八个source/test Ruff检查及五源码diff检查通过，五源码和测试生命周期独立源码GO。
证据是实际本机线程/网络数据链与包级过滤，不是进程隔离、HWM饱和、百策略吞吐或30分钟
LOAD01；没有新增正式case。下一步将已修的LOAD runner接入该已提交版本再短试跑。

## 第89轮：Execution 可信组派发 authority 原语（2026-10-15）

父提交436e55751fdf71fd46a145738d1bde4c498e8e6f。本轮仅新增
service_execution_group_authority.py与对应聚焦测试，再更新两份记录，精确四路径。
依赖已提交Execution84d97c9及当前Registry合同，不修改共享Registry/Runtime/Host。

SQLite authority由受信本地operator激活/撤销，绑定实际Registry创建的context、当前
registration/principal/coordinator generation、portfolio/strategy/account及真实账户
writer lease。dispatch之前持久hold，不能按TTL自行释放。completion verifier只在
精确ExecutionStore intent/binding/authorization attempt及可信已知结果匹配时释放；
UNKNOWN、缺证据、不匹配或校验异常保留hold，不因guard正常return假定订单成功。

独立review最初发现两项阻塞并已修复：已ACK同ID重放不创建新持久hold/attempt，而是在
当前授权与lease下验证完整旧记录及历史attempt后只读返回；provider正式REJECTED允许
无order ID，但必须有精确store字段及完整有序、同incarnation outbox证明该provider拒绝。
这不是对任意缺ID结果放行，UNKNOWN重放仍无Risk/provider调用且保留hold。

作者通过真实Registry context→ExecutionOrderEntryService/Facade/SQLite，使用合成
Risk/provider叶子运行7个聚焦节点：7 passed/2.83秒，一条既有pytest配置warning。
前次pytest_asyncio插件收集问题未运行业务，关闭该插件后成功；Ruff/格式/py_compile
通过，最终独立acceptance_review为GO且未重复测试。Root核对最终源码SHA
e34d9afe203556e32a2d0d715985b53e21b80d047493d09dc561af8e3a210c93、测试SHA
eda3423c401b622ac98338bcd2a94e8a40272e5632b89a8bcdc5e6eb348f55cc，未为交付重跑。
QA依据为作者工具结果及独立源码review，不声称有另外的Root七测或磁盘原始日志。

接受范围是原语的包/Facade/Store合成链。尚未接通正常ServiceHost组RPC或P5A正式
链；拒绝证明目前分页扫描当前scope outbox，内存有界但延迟随历史增长，不声明热路径
性能已接受。完整SDK组服务集成下一轮处理，正式总数仍18/68。

## 第90轮：AFI 正常 lifespan 到服务策略 book 投影（2026-10-15）

AFI现有dev提交c85b7c355057058fc2027b190a5c510a50f959c8，父aead91066655effe42e2dd1098da28243f6b56bf。
精确十路径：portfolio compositions/API、service_read API、portfolio_composition服务、
service_read access/client/contracts/deployment/session/worker及既有HTTP集成测试。
Root核对实际提交十路径、空index及九个原README/scripts改动仍保留；本父仓只记两文档。

正常app.main.lifespan创建真实ServiceReadWorker及SdkServiceReadSession，owner线程
使用普通SDK/ZMQ连接独立spawn ServiceHost的Execution account-book读服务。HTTP
创建明确组合版本，按可信账户selector和owner_ref读取策略book；返回持仓/费用及
未分配残差，缺账户价值时保持不可用、coverage incomplete，不借用账户总值冒充策略值。
内部AccountKey与SDK执行scope token不外泄，公开selector单独处理；错账户403、异JWT
主体404。生产session/runtime/transport未替换；synthetic边界是provider事实和临时DB。

本轮修复了多个fixture/环境前置缺陷：import根路径、generic gate放错basic_admission
slot、临时数据库未初始化、检查不存在的worker._session、公开selector与内部ID混用。
已有失败及其有限startup/cleanup诊断保留，不计通过。最终使用项目Python3.12.10 venv、
固定SDK d996及Base/Execution/Transport/Monitor导出，单节点
test_live_composition_projects_only_trusted_strategy_books_from_sdk_host：1 passed/
10.96秒/exit0，4条既有pytest配置warning；Ruff/格式通过，独立afi_lifespan_review GO。
未为提交重跑。测试只读threading.setprofile观察精确session方法code，constructed/
started/read_account_book/closed均在同一worker线程31856，没有包装替代业务方法。

原日志、命令、环境和源码pin在AFI src/backend/.codex-tmp/afi_iter10_p9b_final_r3_20261015/；
子进程diagnostic记录ready、正常close、exit0、pipe/process closed、无terminate和cleanup
failure。Root读取原始diagnostic与pytest日志复核，接受本机合成HTTP/SDK/服务链。

AFI01仍缺完整scope/审批伪造及重放矩阵；AFI02/03仍缺paper、多币种/FX、完整账户与
策略汇总核对，不能据这一个成功节点宣布这些整条通过。正式保持18/68。

## 第91轮：LOAD01 调度及 SDK 行情 v2 runner 接线（2026-10-15）

父提交f519819c3d2cf803d0198843251bbe49fdd78e86。本轮仅交付
tests/unit/test_load01_hundred_strategy_30min.py及两份进度记录；不修改生产SDK或子包。
runner为190946字节，SHA-256
5f82ecddbdca50f837fef5ff3afed62751794ca6e38887f3bf7ee4233d50ff86。
保留100策略、10账户、独立行情/Monitor共112子进程、20主题、200条/秒上游、
每账户每秒2次订单生命周期及30分钟正式负载。服务器与客户端均通过正常SDK profile
选择market_wire_version=2；没有手工替换subscriber或降低队列/租约/资源门槛。
调度使用共同起始时刻、轮转poll预算，并先处理维护、进度及订单，避免单路行情饥饿。

固定导出D:/temp/iteration10-load01-fixed-source-436e5575-v2-20261015-r1绑定
SDK436e5575及Base b4aabd1、Execution84d97c9、Gateway59b164a、Monitor536a4f0、
Risk72d955e、Transport29ab21e。七个Git archive中862个Python成员、28个实际导入
源码检查通过；候选runner单独按上述pin复制，未把父仓其它未提交修改带入负载。
窄测原日志config-focused.stdout.log为4 passed、1 deselected、exit0，1条既有配置
warning；独立load01_maintenance_review对精确runner静态GO，Ruff及py_compile通过。
Root读取日志、复核checkout pin后提交，不为交付重跑四项检查。

接受级别仅为runner源码/配置/调度检查，未运行新的120秒pilot或30分钟正式负载。
原失败pilot与强制回收结果保留。最新准备记录pilot-readiness-r3.json纠正r1/r2的
导入计数及HEAD描述，原记录未改写。其内存样本10369859584字节低于固定门槛
10603200512字节；Root本轮复查亦未满足门槛，因此不启动负载、不结束其他进程。
下一步在本提交之后重新采样资源，达标才运行固定导出的120秒pilot；成功后才进入
30分钟验收。正式用例仍18/68，LOAD01不增加PASS。

## 第92轮：组协调长期注册与逐笔 group/leg 绑定（2026-10-15）

第91轮已提交28854c73a235645adcc0f6a6997053d6592504f1，Root随后核对其runner的
Git blob、checkout和固定导出三者原始字节相同，不涉及换行归一化；资源复查仍未达标。
本轮源码提交c6c832f4e12bf999dd554ba518d9421ecf6b1eb8，父28854c73，精确两路径：
service_execution_group_authority.py及其聚焦测试。后续本记录提交只更新两份文档。

此前authority把group/leg固定到Registry长期scope，使同一协调者无法处理后续组。
现要求注册scope两个字段均为空，逐笔operation scope只允许补入group/leg，其余所有
字段与真实登记scope一致，两个新值还必须与可信GroupPermitBinding一致。旧固定
group/leg注册明确拒绝激活。既有active generation、账户writer lease、持久hold、
UNKNOWN保留及受信completion验证保持不变。

作者本轮9项聚焦测试通过（3.14秒，1条既有配置warning）；最初pytest-asyncio插件在
collection阶段不兼容，关闭该插件后运行成功，不能把首次collection说成业务失败。
Ruff、format、py_compile、diff-check通过。独立iteration10_parallel_assessment静态
GO且没有重复QA；Root核对提交范围及两个最终SHA：源码
8538ddfae2affef28457b6d943bd1a971461f675b1eb438e027e436db7434017，测试
caa88d3628fdf1d85fa4117c9499ce963cf08ce93c72272b595dba6010527fb0。
作者提交早于本轮独立review回报；Root已重申后续父仓由Root在review完成后统一提交。

新增多组/旧模式拒绝例使用真实Registry注册及coordinator.identity取得context后直接
调用authority/guard；completion verifier为合成叶子。它不证明正常组write RPC或
ServiceHost handler闭环。正常组服务仍需Risk持久claim/no-fill回执、Host唯一upstream
借用、受信协调注册生命周期及真实账户入口；这些缺口已按owner分配，未用假回执绕过。
本轮是稳定注册源码组件接受，正式18/68不变。

## 第93轮：AFI01 正常 HTTP/SDK 服务链读取授权矩阵（2026-10-15）

第92轮记录已提交SDK9ba1af20。AFI本轮在现有dev提交
e18b0a3cb4383cd134f94a9be1d47cc8a4dd16f4，父c85b7c355057058fc2027b190a5c510a50f959c8，
仅src/backend/tests/test_service_read_authorized_http_integration.py一条路径；没有修改
生产代码或重跑已接受P9B节点。Root检查提交范围、空index与原六修改/三未跟踪脚本保留。

新增唯一node经真实main.lifespan/worker/SdkServiceReadSession、实际SDK/CURVE及独立
ServiceHost读取Execution AccountBook，服务侧source回调观测principal、actor、delegate、
account_ref和内部account key。合法同JWT重复GET可用，附加伪造identity/approver
header/query不能改变真实授权；过期token、错误scope、越权账户、对读端点POST及
composition伪造approver输入均拒绝，业务provider写入/准入计数为空。实际观察只序列化
scope.account_ref；source另执行完整WireIdentity/WireScope等值授权，不把有限投影称
全字段scope审计。

首轮失败是测试把SDK内部account:<digest>误与AccountKey.account_key_id比较，修复
断言后r2单节点1 passed/11.51秒/exit0，5条既有pytest配置与Starlette弃用warning。
原r1保留，两个尝试child均正常退出。最终test SHA
b4e3e995f22d1e650f78e24740681b3bd749294f369f59a320269717f16531b9，90550字节。
Ruff/format/py_compile/diff检查通过；独立afi_lifespan_review静态GO，未重复QA。
原日志在AFI src/backend/.codex-tmp/afi_iter10_afi01_read_matrix_r2_20261015/，
pytest.log SHA e2b2454d57e7366aa4771bb91dc0fba0e6ed3544c1983d1f259da4b3edc6f131。
Root读取日志、exit0与诊断：session构造/启动/两次读取/关闭同线程11880，host ready、
正常关闭、pipe/process closed，无terminate和cleanup失败。

本轮接受本机合成读取授权链。AFI未实现独立tenant模型，不能用owner/subject隔离
替代多租户证明；写操作/审批权限及幂等防重放仍需P9C。本轮不是完整AFI01或真实账户
接受，正式总数仍18/68。

## 第94轮：Risk 持久组回执与 SDK 离线费用合同兼容（2026-10-15）

父仓交付父提交7d1a0be5d7a640ab6f24a89e51a28477481e49df。Risk在现有dev先提交
dc18a62dbf8cb6a9757f58792d605d6d61bb83ef，父72d955e；精确8个源码/测试路径，
独立risk_freeze_api_review GO，四个聚焦测试文件103 passed/20秒，1条既有配置warning。
原103项结果来自作者执行记录，没有另存原始磁盘日志；Root不为补日志重复已接受QA。
Root核对真实包提交范围和空index，本父仓只更新Risk gitlink、两个兼容文件及两份记录。

新增公开map_group_intent纯映射与严格scope验证、只读query_group_leg_claim，以及
持久DispatchTerminalResolutionReceipt查询。no-fill释放返回可重开核验的类型化回执，
UNKNOWN仍保留；DispatchTerminalProof现在显式要求完整费用历史及零费用记录，并绑定
到fingerprint/持久记录。旧缺失字段不自动补零，ACKED_TRACKED原有分支保持独立。
这些API是正常组RPC的依赖，不等于组RPC或ARB正式通过。

父仓原fake_dispatch_authority构造no-fill proof缺少新费用字段。兼容修复只适用于
明确的offline fake provider合同bt-api-offline-replay-no-fee-v1：精确零成交REJECTED
响应持久化完整零费用证据，response/reconciliation摘要绑定它，proof及guard从同一
存储事实取值。缺失旧行、费用数量矛盾或不完整均拒绝；不为真实provider推定零费用。
新增实际Risk回执/重开及自洽摘要但费用损坏的回归，ACKED行为不变。

两文件为bt_api_py/runtime_plugins/fake_dispatch_authority.py（47410字节，SHA-256
7fdc9134ba80d33d707b5e1fda393df706339f451d89a9210741393365fd6630）及
tests/test_runtime_fake_dispatch_journal.py（26579字节，SHA-256
a014403535134e0506b995ab8cc7bc6bde3a0a2dcd22572c8d9d7a4618d8895e）。
命令：C:/anaconda3/python.exe -m pytest -q -p no:cacheprovider -p no:asyncio
tests/test_runtime_fake_dispatch_journal.py；19 passed/9.65秒/exit0，1条既有配置warning。
初次默认pytest-asyncio collection不兼容保留为环境诊断，不算业务失败。
原日志D:/temp/iteration10-risk-fake-dispatch-fee-20261015-r1/pytest.log，SHA-256
45e7906c1628ae1f98d4ee3273b261e50a89365f80eb1d72e22e84967df18390；Root读取核对。
独立review对精确两文件GO，Ruff/format/compile/diff检查通过；不为交付重跑。

本轮接受包级和离线合成组件，正常ServiceHost组链、RISK02实际观察链及真实账户仍待
对应验收；正式总数18/68不变。共享Host/Registry和RISK02的其它未提交改动不纳入。

## 第95轮：CFG02 显式 Gateway 服务与无领域包客户端隔离安装验收（2026-10-15）

第94轮已提交6b2fc430857fdc2ff688ecd3ae62e5252d3f1529，精确五路径、空index，
Risk子包dc18a62已先提交。本轮新增CFG02正式PASS，总数19/68。

测试tests/unit/test_iteration10_optional_install_matrix.py为精确pin
017797364f74ebd61e3210052864f5d994d7b5f35e3f85834a1b7bc2b0b01455，独立静态GO。
两个新Python3.11.5 venv通过正常resolver安装固定非editable wheel、pip check成功，
均禁用system site packages。客户端只需SDK/Base/Transport，四领域包的distribution、
find_spec及loaded均不存在；服务端仅加Gateway，Execution/Risk/Monitor不存在。
实际构建SDK28854c73，Base b4aabd1、Gateway59b164a、Transport29ab21e；后续metadata
通过归档PAX/git bytes确认SDK不是c6，并核对八模块Git→archive→source→wheel→安装
链；相对Git blob的CRLF差异明确记录，不宣称raw相同。

唯一节点经正常parse/ServiceHost显式启动一个market_hub，无enabled字段；摘要精确
组件/端口/五操作。普通ServiceClientRuntime与ServiceMarketClient实际CURVE登记、
订阅和接收精确key/data/sequence4；正常provider启停1/1、登记归零、runtime/host
关闭、reader停止、子进程exit0，无强制回收。1 passed/1.86秒；JUnit一节点零失败，
服务stderr一条Windows ZMQ selector warning完整保存。异常清理分支的部分close异常
仍被抑制，本次正常路径证据不用于宣称全部失败清理通过。

原产物D:/temp/iteration10-cfg02-real-20261015-r1，Root读取原始日志/JUnit/命令/stderr，
复核四archive/wheel和八installed源码pins，未重复通过QA。测试、八个原始证据文件、
Root裁定、目录字节保留规则及两份记录作为本轮精确范围；源安装记录23133字节/SHA
dfb88e090c8e4530515498c27729d39760f6e335f82f4544cb00f53b2333f320。
证据目录evidence/cfg02-isolated-service-20261015/。本条为本机真实服务/代理、合成行情，
只覆盖store.market；CFG04所有代理矩阵、真实账户、双机及LOAD01仍须各自验收。

## 第96轮：组账户执行与组预留专用配置角色（2026-10-15）

第95轮已提交b9e36cbcaf302eefc1be1ef8221552d465e45c55，精确13路径；Root验证
十个证据目录文件Git blob与checkout原始字节一致、index为空。CRLF原始日志使用
CR-at-EOL-aware whitespace检查保留，不重写成功输出。本轮只交付配置parser、新
聚焦测试及两份记录，Host/Registry/builders与实际adapter的并行改动不纳入。

service_config.py加入execution/group_account_owner专用角色，允许order_entry和
order_query端口（可按现有配置合同选择子集），及risk/group_reservations仅允许
service.group_reservations端口。两角色只接受role选项，不从YAML获得授权；operator
policy、真实Registry身份及运行时资源约束仍由服务启动/调用阶段校验。既有coordinator
必须有portfolio_ref，普通account_owner/admission的配置合同不变。

源码47157字节/SHA-256
6518fb59849db9624edea84a532d8b03e9c4c3dee14322c05e9c5eb85252ac1b；新增
tests/unit/test_service_group_role_config.py为8251字节/SHA-256
162469c2be9e5e1c7ddda7e7f616e9759f93b1118533d07b3cbb185cc9db25af。
聚焦命令C:/anaconda3/python.exe -m pytest --noconftest
--basetemp=.codex-tmp/service_group_role_config_r1_20261015/pytest-temp -q
tests/unit/test_service_group_role_config.py，17 passed/0.67秒/exit0、1条既有配置warning。
覆盖正确角色/端口、错端口/未知角色/缺引用、YAML授权字段拒绝及纯解析时领域import、
socket/thread/process拒绝。Ruff/format/compile/diff通过；独立afi_lifespan_review静态GO。
Root核对两pin并读取原pytest.log与exit_code.txt，未重复QA。

接受仅为配置源码组件；实际组RPC和完整P5A仍依赖Host生命周期、账户预留及真实provider
事实的持久证明。CFG06不因此正式通过，总数保持19/68。

## 第97轮：Risk 可信账户别名与只读组状态接口（2026-10-15）

第96轮已提交56ab112154c0c0e92cb6b956a87faf41fadf0a30。本轮Risk在现有dev先提交
a099e367afd503cd38f3787e3cba578e2b244db4，父dc18a62dbf8cb6a9757f58792d605d6d61bb83ef；
范围为core/instrument.py、core/admission.py、order_admission.py及四个对应测试文件，
共七路径。Root核对真实提交范围、父提交与子包工作区/index为空，父仓只更新Risk gitlink
和这两份进度文档。父仓提交SHA由本记录的Git历史定位，其他并行改动保留。

InstrumentRiskAdmissionMapper支持由可信装配显式指定wire_account_ref，区分SDK路由
别名与Risk持久account_id，默认仍要求原账户ID。普通订单和组订单均校验provider、环境
和精确别名；不会改写原OrderIntent或fingerprint。缺失/非法strategy_id在allocation reader
调用之前拒绝，不能先读取错误策略的分配再报错。

新增read_group_vector_snapshot使用SQLite query_only及单个读事务投影已持久化的
reservation/claim/resolution；不初始化政策、不做TTL清理或补写。过期ACTIVE行按存储
事实返回，不代表可派发授权；真正claim仍执行原有时限与政策检查。旧有写入型query
接口保持原语义。该接口供正常组服务纯查询使用，不接受跨进程共享SQLite作为协议。

作者四文件聚焦结果65 passed/6.93秒/exit0、1条既有配置warning；其精确命令和磁盘日志
未保留，可用证据为原工具输出。随后strategy校验顺序修复后，仅运行受影响
python -m pytest -q tests/test_instrument_admission.py：33 passed/1.45秒/exit0、同一配置
warning，亦无磁盘日志；不声称最终源码重新完整通过65项。Ruff七路径及diff-check通过。
独立risk_freeze_api_review对修复后的七路径静态GO，未重复测试；Root审阅三个生产文件
差异，没有为交付重跑已接受QA。

接受级别为Risk包级接口组件，正常ServiceHost组RPC及P5A仍未完成，正式19/68不变。
REG03当前实际失败停在竞争会话未拒绝，尚未进入订单/风险业务保留矩阵；生产builder
遗漏write_operations的修复另轮验证。LOAD01新样本2026-10-15T13:47:12.522Z为
9956110336字节，低于固定10603200512字节门槛，pilot未启动；不降低门槛或结束其他进程。

## 第98轮：普通写能力登记与 REG03 持久业务生命周期（2026-10-15）

第97轮提交 d873609deba9f457f8bac51a0664296cb0c110f4。本轮在现有 SDK dev 交付
service_components/Host 的普通写能力元数据及可选 account-books 读取修复、两个聚焦测试、
REG03 原始证据和两份进度记录。共享文件只暂存固定候选中的明确改动，保留组角色接线
和其它并行开发；不更新尚待 SDK 集成的 Execution gitlink。本提交由本节 Git 历史定位。

Execution/account_owner 的 submit/cancel、Risk/account_owner 的 submit 现在被标记为写操作，
PreparedComponent、build 后 ServiceCapability 和 Host 计划一致，Registry 因而拒绝同一策略
第二个活跃写会话。可选账户 book 源不存在时仅允许缺 execution.account_books.query，
其余能力及写操作集合仍精确校验。源组件由独立审查 GO；作者两项聚焦检查通过，一条既有
pytest 配置 warning，该结果不冒充真实进程验收。

Root 固定 c6 基线及已有两文件候选运行 REG03 节点，真实 spawn ServiceHost/CURVE/SQLite
覆盖幂等、双活拒绝、注销、服务器时钟租约过期、重启旧 epoch 拒绝和显式恢复。原 UNKNOWN
订单、风险占用/claim/freeze 全程保持，provider 只派发一次，无撤单。1 passed/5.24秒/exit0，
没有 warning 报告；两 host close ACK、join 后 exit0，正常关闭句柄，无强制或失败清理。
EOF 未观察，不宣称 EOF 通过。合成 provider 与可注入 Registry 时钟不等于真实账户验收。

执行副本 42065 字节/392f509a…f1096 已逐字归档；canonical 测试增加仅无环境变量时的
仓库根推导和 lint/format 清理，41742 字节/c20eb948…b05f0，静态复核 GO，未重复通过的
运行。原始命令/JUnit/输出/业务观察/source binding/Root 裁定保存在
`evidence/reg03-durable-registration-20261015/`。既有失败及原结果保留。

本条正式 REG03 PASS，合计20/68；REG01 政策回执、完整 CFG04、TRN03、RISK02、
组 RPC/真实 provider 事实闭环及其它计划项仍按各自证据推进。

## 第99轮：TRN03 受限行情撤权与授权矩阵收口（2026-10-15）

第98轮已提交0959c4d3c24c6f1698debc92ae5359e5d4274588，精确18路径，Root逐项校验
已提交原始证据/生产LF源码及共享文件工作区保持，index为空。本轮仅新增TRN03测试及
原始证据和两份记录，生产实现不变；源测试与执行副本26372字节/9d55ce69…0498c一致。

R3在固定c6+已接受普通Host修复上通过1项真实ServiceHost/CURVE/PUB测试：A+B接收
旧epoch行情；正常关闭旧host后同端点只允许B，旧A的持续SUB重连有明确ZAP认证拒绝，
B收到新epoch唯一marker而A未收到，A新RPC登记REQUEST_NOT_SENT且无binding。
两次host关闭断言exit0/reaped，provider启停各1/1，无强杀/cleanup failure。
1passed/5.11秒/exit0，一条既有pytest配置warning；R1/R2失败及源字节保留。

本次结合第02轮真实SDK/CURVE伪造身份/账户/动作拒绝与transport远程模式/ZAP/ROUTER
principal证据、第03轮跨账户策略读取、第38轮越权订阅及第60轮MON02控制重放，独立
逐条审查GO，正式TRN03 PASS，合计21/68。旧节点只引用已有聚合验收记录和源码提交，
不伪造逐节点日志/hash、不重复已通过QA。证据矩阵和原产物位于
`evidence/trn03-authority-revocation-20261015/root-adjudication.md`。

所有连接为loopback；allow_remote/wildcard配置不等于物理双机。撤权采用维护停止/重启
并缩小audience，不声明无中断热撤权。11个选定源码前后pin相同，显式PYTHONPATH已记录；
未单独记录运行时__file__，失败的post-run来源探针不作成功证据。真实账户和DIST仍待验。

## 第100轮：组派发前复核与结果回调组件（2026-10-15）

第99轮提交1aae98aae68e0599ea517b2a63cc07e3ed146b84，精确13路径/原始证据字节
核对通过、index为空。本轮只更新Execution gitlink、SDK authority及聚焦测试、两份记录。
Execution现有dev先完成27beb184667058144dff5522988ccf097b75ff7f（父84d97c9，五路径）
及d2b49c44fdc8689e5728ed2f01a9919c1ee66afe（父27beb，二路径），子包index/工作区为空。

Execution在唯一Risk claim之后调用受信after_group_claim，再复核当前组授权、真实writer
lease和截止时间；不做第二次claim。hook失败保留UNKNOWN/hold且零provider派发。
受信call-local provider_dispatcher与before/after回调要求配套，RPC不能选择它们。终态
after_group_result在held context内执行；失败保留风险/hold但不篡改已知Execution终态。
ACKED/PARTIAL/UNKNOWN不冒充已完成resolution，重放不再次派发。

SDK authority通过实际SQLite coordinator generation、唯一owned hold、exact intent/binding/
authorization/lease及真实ExecutionStore中尚无观察的DISPATCHING attempt复核，拒绝fake
completion callback。它使用Registry已授权调用快照，不在handler中途重新查询Registry
session expiry/service epoch/policy，亦不声称有中途撤权lease。

Execution第一轮17项聚焦通过，第二轮21项/1.84秒通过并独立静态GO；SDK聚焦18passed、
6deselected/4.44秒/exit0、一条既有配置warning。SDK运行只有原工具stdout，没有磁盘日志；
原测试pin8745d3b7…5ca0，之后仅docstring与test lint调整，最终authority e1b9da62…8491c、
test f26c3e62…2f862经独立静态等价复核GO、Ruff/diff通过，不重跑accepted QA。

接受级别为包级及SQLite组件，尚非正常组ServiceHost/provider闭环，21/68不变。IOC可信
provider合同、组proof journal、真实组RPC和两腿/恢复链继续实现；普通账户路径与未接受
shared Host/Registry改动不纳入本轮。提交SHA由本节Git历史定位。

## 第101轮：CFG04 五类代理隔离安装集成（2026-10-15）

第100轮已提交70938108460d15d79f8bb194687cce073990dae5，精确五路径，index为空。
本轮仅交付可选安装测试增量、原始R5证据及两份记录。固定安装组合SDK28854c73、
Baseb4aabd1e/Gateway59b164ab/Transport29ab21e/Execution84d97c9/Riska099e367/Monitor536a4f04，
两个Python3.11.5隔离venv，client没有四领域包，server独立进程安装四包，pip check均通过。

store.account、broker.orders、broker.order_query、risk.read_model、runtime.telemetry实际
代理交互完成，真实ServiceHost/CURVE/SQLite与合成provider/admission；配置拒绝客户端
components/embedded/服务端槽。唯一新节点1passed/2.60秒/exit0；无pytest warning，服务
stderr一条PyZMQ Proactor warning保留。runtime、host和reader正常关闭，child exit0，
无强制回收。测试打印JSON未由成功日志持久化，不声称独立业务报告存在。

测试与执行副本83431字节/d2901493…c577bf一致；CFG02两个原函数AST未变，独立静态窄GO。
Root只读核对七wheel、两安装报告和19项Git→wheel→installed源码（仅CRLF/LF差异），
未重跑通过QA；元数据50089字节/b8011ae4…01534b5。原始证据、精确测试及限制见
`evidence/cfg04-isolated-five-proxies-20261015/root-adjudication.md`。

此结果只接受该固定安装组合，不能推定当前HEAD新版Host/components/config通过。
组代理只解析配置、account_books未调用、market沿用CFG02，完整CFG04仍部分，21/68不变。
不修改生产、不更新gitlink、不迁移工作区；提交SHA由本节Git历史定位。

## 第102轮：CFG04 账户簿隔离代理调用（2026-10-15）

第101轮已提交edb72152616629fbc6238b993f472f5f997717b2；本轮只交付一个新测试节点及证据。
固定安装组合仍为SDK28854c73/Execution84d97c9和第101轮其余wheel，两个隔离venv。
客户端四领域包distribution/spec/module前后缺席，通过公共ServiceClientRuntime.call
和真实CURVE查询execution.account_books.query。Execution真实SQLite/outbox返回策略
持仓1.25、费用0.13 USDT、完整coverage游标0→4；provider和外部基线为合成。

精确DD2DB38A…AEB715D节点1passed/2.28秒（JUnit1.938秒）/exit0，无pytest warning，
server stderr一条PyZMQ warning保留。业务JSON、正常runtime/host关闭、两个reader停止、
进程exit0、零清理失败/不确定项及无forced cleanup均有日志和断言。Root核对原始证据，
独立静态GO；新增来源核对Git→wheel→installed。两次先前失败保留，不重复已通过QA。
原CFG02/R5测试本体不变，默认模式不进入新增部分成交路径。

来源及限制见evidence/cfg04-isolated-account-books-20261015/root-adjudication.md。
此为旧固定发行组合的实际本机子项，不是当前新版实现、真实账户或完整CFG04通过。
group代理仍待验收，正式21/68不变。没有生产/gitlink修改或新worktree；提交SHA由Git历史定位。

## 第103轮：REG01 政策回执及实际授权矩阵（2026-10-15）

第102轮已提交4861237c83765682a1c77324c23670290b550100，精确15路径且index为空。
本轮四个SDK路径增加access/Risk/requirements分离回执和可信policy alias映射；仅接受
固定REG-only候选，保留同文件其他group WIP。Root固定edb基线加四候选，实际启动父4861237c，
六个已提交包gitlink干净；178来源文件前后不变。3B8DAA54…A5146C5测试新节点一次通过，
pytest1passed/5.74秒、exit0、外层stderr空、无warning摘要，独立完整条款审查GO。

真实ServiceHost/CURVE注册/RPC取得有效能力、访问政策/Risk政策/就绪版本，Gateway账户读取
及合法Risk订单成功。伪造策略、错误账户、未授权订单和Gateway内部端口绕过均拒绝；
每次拒绝后Risk写/订单查询/成交查询与Gateway写/读/连接/关闭计数都不变，合法路径随后
只新增一次provider写。client/runtime/host正常关闭、子进程回收，无forced cleanup。
合成provider、本机真实进程边界明确；无单独业务JSON，证据为精确断言和原始通过记录。

按正式条款新增REG01 PASS，22/68。早期夹具失败及未执行候选保留，未重复已通过QA。
来源/原始日志与scope见evidence/reg01-policy-receipts-20261015/root-adjudication.md。
本轮只将4个接受源码overlay写index，保留checkout并行group WIP；不更新子包或建worktree。

## 第104轮：Risk 实际政策只读绑定（2026-10-15）

第103轮SDK已提交872631277f2ad6c8a7aabd46f3a090b630a91ec7，REG01正式PASS，22/68。
本轮Risk先提交79c04d30a541f473311b7d48727370c7e331ed10（父a099e367），精确三个路径：
order_admission、惰性导出和聚焦测试。新增不可变RiskAdmissionPolicyBinding与实际
DurableRiskAdmissionAdapter.policy_binding，公开真实policy_id/fingerprint/accounting_mode。
ID接受域与既有RiskPolicy一致，包括保留合法首尾空白；不从配置标记推断实际政策。

作者工具a0f984聚焦11passed/exit0，一条既有pytest配置warning；没有保存独立原始stdout/JUnit，
证据边界在evidence/risk-policy-binding-20261015/round.json明示。独立静态审查trn02_acceptance
GO，Root核对精确diff、三pins、提交scope/blob/index；未重跑接受QA。当前父轮只更新Risk
gitlink和此记录，不包含SDK group实现。子包已先提交，未新建worktree。

用途是让组装配按实际gate拒绝尚缺共同cursor域证明的LIVE_GROSS；这不是完整LIVE_GROSS
支持。组journal revision与账户baseline revision目前不能互换，后续必须绑定真实同代次
账户cursor和完整baseline。RISK02完整FX/重启/实际基线及组服务闭环仍待完成，正式22/68不变。

## 第105轮：组订单目标保留 portfolio scope（2026-10-15）

第104轮SDK已提交d6e68b94c20ed8bfc991891056ff239721671b57。本轮Execution先提交bf5760da891168ba83cd0cc18ee174bbbca2f4e7，父d2b49c44，
精确两个路径：service_order_entry.py和test_group_order_entry.py。组腿转换为稳定目标scope时
继续保留portfolio_ref，避免已授权组合目标无法命中，以及不同组合被错误归并。

独立静态审查backtrader_entry_review GO；唯一新增focused节点1passed/0.83秒/exit0，无warning。
同account/strategy/run的portfolio B在Risk claim/settlement、provider及store写入之前拒绝；
唯一可信portfolio A成功。原始命令、日志、JUnit、退出码及源码前后pins保存在
evidence/execution-portfolio-scope-20261015/。Root核对接受pins、精确提交scope/blob和空index，
没有重复QA。仅为包级SQLite/合成provider证据，不能推定ServiceHost/CURVE或ARB正式通过。

本父轮更新Execution gitlink及记录，保留SDK组接线和其它工作区修改；未新建worktree。
下一步是公开同一Risk gate身份校验接口，再完成真实组服务链与UNKNOWN保留验收。
正式PASS仍为22/68。

## 第106轮：组准入的实际 Risk 对象身份校验（2026-10-16）

Execution先提交9943e7bb26ba91754462b23308bc24d352faa16d（父bf5760da），精确两个路径：admission.py与新增
test_group_admission_identity.py。公开require_admission_gate(expected)以对象is比较实际
wrapped gate；同scope fingerprint但另一gate明确拒绝，且校验不调用gate，不引入可选Risk导入。
SDK组bundle可以使用公共接口验证装配，避免相同scope被误当成相同准入权威。

独立静态审查backtrader_entry_review GO；唯一新增节点1passed/0.47秒/exit0，无warning。
两个adapter各自正确gate接受、双向错误绑定拒绝且gate调用计数均零。接受QA不重跑，
命令、原始日志、JUnit、退出码、runner和前后源码pins保存在
evidence/execution-admission-gate-identity-20261016/。Root核对精确blob/scope、checkout不变及空index。

父SDK仅更新gitlink和记录。组bundle调用、新两腿集成及UNKNOWN保留仍在独立验收中；
此轮不证明ServiceHost/CURVE、LIVE_GROSS或ARB正式完成。正式22/68不变。

## 第107轮：Backtrader 显式多策略账户簿与生命周期（2026-10-16）

Backtrader先提交815a834c3db185ee51c8927e6eea9cdb9fe32330，父01fc254c，精确六路径。显式route+真实Strategy绑定提供
分离owner book，共享Broker维持账户getter语义；重复绑定/错误writer scope零派发。
owned runtime身份去重并启动/维护/关闭；preflight拒绝、空运行、refresh import/setup
失败释放尚未启动的ownership，borrowed runtime不被代关。独立源审最终GO。

Root R1 ownership节点1passed；positive初次因无首bar下单失败，R2暴露fixture多余
directory kwargs，均保留。修复后Root R3仅positive 1passed/8.15秒/exit0，808来源及
五仓HEAD不变；正常closed/exit0、无forced。固定SDK7e1精确export（非dev worktree）+
Execution9943/Baseb4a/Transport29ab，不能推定dirty SDK group链通过。1既有config warning。
证据位于evidence/bt02-multi-strategy-20261016/，包括命令、原始日志、JUnit、失败历史、
导出来源及postcommit；既有通过QA未重复。Root核对六路径blob、空index及CTP等无关变化保留。
cash/cost/valuation与完整恢复仍待后续，正式22/68不变；SDK本轮只提交记录与证据。


## 第108轮：组订单终态权限复核

在SDK现有dev修复结果回调的阶段错配：保留DISPATCHING派发校验，新增真实FILLED/REJECTED持久行与同代outbox完整证明，回调变动则保留hold。Root r1因fixture target遗漏portfolio四例失败；修正新例及同样受影响的旧例后，r2为7passed/3.04秒/exit0、一条既有配置warning，402输入和四仓HEAD不变。Execution固定9943源码，未使用资金账WIP。独立静态GO；不重复QA用于交付。

仓库/分支：bt_api_py/dev；父提交0833ef579915ad1a501d6561fa185e799db0f4c5，实际提交见本轮Git记录。范围为authority源、聚焦测试和证据/进度；子包gitlink及其它WIP均保留。正式仍22/68。下一步是普通两腿真实Risk/Execution证明链，再到Host/CURVE；本轮不代表ARB完整接受。证据见[evidence/arb-authority-result-20261016/root-adjudication.md](evidence/arb-authority-result-20261016/root-adjudication.md)。


## 第109轮：持久资金成本账与租约边界

资金账新增可信基线、累计成交游标、按owner归属的现金/持仓/费用与现货平均成本。完整全局outbox扫描拒绝过滤或截断；基线前已累计成交只记增量，迟到活动中的受管订单不会重新分配到人工账。SQLite v23保存基线、事件和head，写入、head更新、提交前复核writer租约；重设基线拒绝activity代次变化和游标回退。complete与BALANCED明确区分，未知成本或不支持的产品保留不可用。

这是合成provider事实与真实SQLite的包级证据；没有ServiceHost/真实账户验收，尚未接入Backtrader资金账或完整恢复，不能替代BT01/BT02、AFI、ARB完整通过。Root仅运行本轮两份新测试文件一次：17passed/0.88秒/exit0、无warning，137公共输入及Execution/Base HEAD前后不变；静态独立审查GO。初始旧spec未执行，元数据pin转录校验失败在pytest前已修正；没有已接受QA重跑。

仓库/分支：Execution/dev提交dadd0a6bc7c1d31aba0f58e4d6101478be8d3ebc（父9943e7bb），五个源码/测试文件；父SDK/dev本轮只更新Execution gitlink及证据/进度，父提交a127fc6e，实际SDK提交由本轮Git记录给出。两仓索引在各自提交后为空，其余修改保留。正式仍22/68。下一步接入真实服务账本投影、再推进Backtrader恢复。证据见[evidence/execution-financial-ledger-20261016/root-adjudication.md](evidence/execution-financial-ledger-20261016/root-adjudication.md)。


## 第110轮：AFI双账户汇总与未分配账

AFI默认read runtime在有账户绑定时明确请求account.snapshot，双账户fixture统一source授权、Registry grants及profile的application identity。组合API透传SDK唯一UNALLOCATED账与coverage，分别保留当前未分配账和基线后对账残差，不改变SDK会计计算或重复加总。

Root r5通过一个runtime装配节点，但真实双账户节点因旧identity返回DENIED；r6修正identity后已能读取服务，旧断言把UNALLOCATED持仓当成incremental residual而失败。r7只重跑失败的真实链路，1passed/15.51秒/exit0，四条既有pytest配置warning。2115公共输入及AFI HEAD前后不变；两个Gateway和两个Execution真实spawn/CURVE Host均正常closed/exit0、failure_count=0，应用owner线程完整关闭。正常FastAPI lifespan→HTTP→SDK读取合成账户总额160+790=950；strategy持仓2.5/4、UNALLOCATED3.5/5、incremental residual0.5/1分别核对，重叠组合不累加，跨owner404。r5/r6原结果保留，已通过装配节点未重复。

这是本机真实进程与合成provider事实证据，HTTP使用ASGI客户端；不是真实账户、前端展示或完整AFI02–AFI03验收。strategy value仍不可用、creditable=false、总coverage incomplete；paper、多币种/FX和完整异常矩阵继续待验。固定SDK及Base/Execution/Transport/Monitor导出来自既有P9B组合，Gateway使用固定当前源码；不能将此结果推定为所有当前SDK候选已接受。正式22/68不变。

AFI/dev三路径提交2d081f4308215c4aa7f90d656039026fd9713e2e（父e18b0a3c）；静态审查GO，子仓索引空、既有无关修改保留。SDK/dev本轮只提交两份进度和证据，父74f892f0，实际提交由Git记录给出。证据见[evidence/afi-dual-account-projection-20261016/root-adjudication.md](evidence/afi-dual-account-projection-20261016/root-adjudication.md)。


## 第111轮：Risk整数时钟和提交前有效期复核

Risk默认有效期判定改用time.time_ns整数时钟，保留显式旧seconds clock的既有转换兼容，并允许单独注入clock_ns。精确非负int校验拒绝bool/float/负值；仍严格拒绝未来观察和已到期事实，没有增加容差或sleep。终态resolution写入后及组vector所有扫描/写入后，在事务退出前再次核对事实、deadline/TTL和LIVE_GROSS有效期，过期则整轮回滚。

Root独立运行本轮新test文件16passed/3.35秒/exit0，一条已有pytest配置warning；133源码输入及Risk/Base HEAD前后不变。覆盖默认整数clock与legacy分离、相等/未来/expiry边界、基线/订单/终态回滚、reservations-only和LIVE_GROSS组最终切点回滚。独立静态审查最终GO。作者的18项还包含两项受影响旧group节点，Root未把作者结果冒充自身18项。此前本机20000对时钟采样证明float往返可产生负纳秒差；这是本机新观测，不是恢复先前失败的具体时间。

当前只接受typed synthetic proofs和真实SQLite包级行为；不等于SDK类型证明链、ServiceHost、真实账户或RISK02完整通过。SDK两个contextmanager修复另在集成轮验收；正式仍22/68。

Risk/dev两文件提交3e02dee8b86c0b9ccfa369d6e4761cf07d5a73c9（父79c04d30），父SDK/dev只更新Risk gitlink及证据/进度，父f4fd2a1f，实际提交由本轮Git记录给出。两仓提交后索引空、其它修改保留。下一步恢复先前失败的三个真实typed claim参数，再推进完整Risk/组ServiceHost链。证据见[evidence/risk-integer-clock-20261016/root-adjudication.md](evidence/risk-integer-clock-20261016/root-adjudication.md)。


## 第112轮：账户级准入保留真实订单数量

合法account-only OPEN经InstrumentRiskAdmissionMapper已取得可信数量单位与订单数量，但原返回条件额外要求strategy_id，导致持久reservation缺数量，SDK实际终态证明在_actual_claim_order_bounds拒绝。修复只从三个返回字段条件删除strategy_id要求；有可信metadata quantity_unit才保留instrument/quantity/unit，策略allocation分支未改。没有给SDKfixture添加虚假strategy来绕过问题。

Root新四项真实mapper/SQLite gate回归通过，0.80秒/exit0，一条既有pytest配置warning；133输入和Risk/Base HEAD前后不变，独立static GO。覆盖account-only reserve/claim/settle/typed terminal以及缺单位、缺metadata digest和错账户。测试journal authority仍为synthetic，这不是完整execution journal/provider证据；作者33项旧mapper测试不冒充Root验收，也不为交付再跑。原SDKtyped r2两例失败记录保留，接下来仅复验两例。

Risk/dev两路径提交5f6ba0b2d7dd7a5589392e299ce2ecb90fef9d7b，父3e02dee8b86c0b9ccfa369d6e4761cf07d5a73c9。父SDK/dev仅更新Risk gitlink及本轮证据和两份进度记录，父5f29a66d，实际SDK提交由本轮Git记录给出。正式22/68不变；RISK02完整正常服务观察链、FX/TTL/重启仍待验。

证据见[evidence/risk-account-only-mapping-20261016/root-adjudication.md](evidence/risk-account-only-mapping-20261016/root-adjudication.md)。


## 第113轮：持久账本纯只读投影接口

新增SqliteExecutionStore.read_account_financial_projection(account_key, expected_directory=...)，只在pure_read_transaction中校验并返回已持久化的AccountFinancialProjectionV1；不reconcile、不写账、不调整lease。校验baseline/directory/projection哈希、cut/head、连续outbox来源、每单cursor/posting以及当前Execution journal。journal推进后旧head不可读；返回的是最后一次持久化的活动事实，不声称当前provider、行情或FX新鲜度。

独立静态审查发现并修复两处真实合同差异：外账户全局outbox行仍保存intent hash但不得分配cursor/posting；UNALLOCATED只在residual表示，不在registered owner books中。Root仅运行三个新回归，3 passed in 0.84s、exit0、无warnings；137源码输入及Execution/Base HEAD前后不变。覆盖SQLite重开、读前后数据库不变、过期head拒绝、来源篡改拒绝以及同库另一账户真实事件。旧17项账本suite没有为交付重复运行。证据限本地SQLite/合成provider，不是SDK ServiceHost、Backtrader或真实账户验收。

Execution/dev两路径提交1373b13ecf29d78addc988921a0234d24101c837，父dadd0a6bc7c1d31aba0f58e4d6101478be8d3ebc。父SDK/dev仅更新Execution gitlink、本轮证据及两份进度记录，父2e9bace6；实际SDK提交由本轮Git记录给出。正式22/68不变，BT02仍需可信生产资源接线和实际Host/Cerebro及恢复验收。

同期SDK typed-claim r3的两个positive参数均到达append_terminal_exposure_ack后因TERMINAL_EXPOSURE_RECEIPT_MISMATCH失败；原结果保留于D:/temp/iteration10-risk-typed-claim-root-20261016-r3（401源/4HEAD不变）。该失败不是本轮reader验收，不能计入正式PASS。尚未创建额外worktree；用户的并行工作区问题仅做方案评估。

证据见[evidence/execution-financial-reader-20261016/root-adjudication.md](evidence/execution-financial-reader-20261016/root-adjudication.md)。


## 第114轮：AFI未分配账与增量残差分离展示

AFI组合视图增加live账户的UNALLOCATED账展示，把当前持仓/累计费用、provider变化与相对baseline的增量position/fee residual分开。账户总额沿用原投影，不由策略归因反算，不新增策略cash/value，不把overlap相加。API类型兼容旧响应：缺account_book_sources时隐藏新增区，缺unallocated_book时显示不可用。保留coverage incomplete、非可入账及overlap非加总提示，增加中英文文案。

Root以固定五路径及446个前端源码/配置pin运行两个新Vue组件测试，Vitest 2 passed / 35 skipped、exit0、1.47秒，stderr空且AFI HEAD和全部pin不变。35项未运行，不声明整文件37项通过。作者另报告typecheck、目标ESLint和diff-check通过，独立静态审查GO。证据是合成API的UI组件验收，不是浏览器实际后端/账户或完整AFI02/03验收；第110轮真实HTTP/四Host API证据独立保留，未重跑。

AFI/dev精确五路径提交db32c3ce46e6b8e03bdaef42f3e18ce20c64c4ac，父2d081f43；无关README/Windows脚本修改保留且index空。父SDK/dev本轮只记录证据及两份进度文档，父4b059936；实际SDK提交由Git记录给出。正式22/68不变。后续仍需paper、多币种/FX、全异常矩阵与产品迁移的独立完整验收。

证据见[evidence/afi-unallocated-book-ui-20261016/root-adjudication.md](evidence/afi-unallocated-book-ui-20261016/root-adjudication.md)。


## 第115轮：SDK正常账户簿接通持久资金成本账

正常execution.account_books.query服务新增financial子对象，直接通过注入的可信SqliteExecutionStore和FinancialOwnerDirectoryV1读取已持久账本。检查account/目录及完整owner集合、每本book的cut、执行generation/cursor和响应前完整journal bounds；GET不reconcile、不写账。account完整视图包含目录books及独立cash/position/fee residual；strategy视图只返回绑定owner，不返回账户残差。原position/fees_since_baseline保持原语义，新cumulative_fees/现金/成本有独立字段和cut。明确PERSISTED_CUT_NOT_LIVE_SOURCE_VERIFIED，不输出NAV；没有financial目录扩展方法时也返回明确不可用而非遗漏字段。

Root新节点通过：1 passed in 1.37s，exit0、一条既有pytest配置warning，367源码pin及7个仓库HEAD前后相同。测试使用真实Execution DTO和SQLite持久投影经正常Service.handle查询，验证账户/策略隔离、旧source兼容、缺失/错目录、旧cut及GET前后total_changes不变。独立静态review GO。证据为本地合成事实/服务方法，尚非新增financial子对象的ServiceHost/CURVE或Backtrader消费验收；旧Host账户簿证据不能替代。下一轮接真实Host及Cerebro消费，继续完成BT02而非停在此组件。

SDK/dev本轮精确两源码路径及证据/两份进度记录一并提交，父fdfb84fd；Execution依赖为已提交1373b13。源码service_execution_account_books.py=A73E7CC8E71E1FFD96978A1F14E06633404645E0106E46E3585CCC66482AA808，测试=398130067521EC6F530BE183739E6C00B0A1089132F52DD6049BC2E50D049FBB。实际提交见Git记录。无开发worktree，未触真实账户，正式22/68不变。

证据见[evidence/sdk-financial-account-books-20261016/root-adjudication.md](evidence/sdk-financial-account-books-20261016/root-adjudication.md)。


## 第116轮：AFI持久资金成本账响应兼容

第115轮SDK正常账户簿响应新增financial子对象后，AFI的旧11字段精确合同会拒绝新响应。本轮修复该消费者兼容缺口：继续接受原11字段，仅增加明确的financial扩展；校验已知schema、账户、执行generation/cursor、完整ledger cut和owner形状。资金/成本是持久owner账投影，保持原账户总额、估值与legacy费用口径，不把这些数值加入provider总值。financial的BALANCED/RESIDUAL与实际残差一致；legacy PARTIAL及其独立cut保留。

Root首次执行最终新增15项合同检查：15 passed、exit0、1.11秒，4条插件禁用后的既有pytest配置warning、stderr空；2094个AFI/固定SDK及依赖源码和原9项无关文件pin、AFI HEAD前后不变。固定SDK b58918bb与Base b4aabd1e/Execution1373的提交源码导出，测试断言7个实际模块来源/hash。检查包含真实SDK Service.handle回包经AFI读client解析，以及canonical financial DTO/JSON形状的可用数据正反例、owner/cut/状态矛盾拒绝。独立静态审查最终GO；早期作者失败和未执行Root r1 spec保留，Root只运行最终r2一次。不重复旧UI或四Host验收。

AFI/dev仅两路径提交dd1e14a287cebc1137999045d1332d86bdab3806（父db32c3ce）；原README/Windows脚本变更保留，index空。SDK本轮仅证据和两份进度文档，父b58918bb，实际提交由Git给出。证据是合成服务响应兼容合同，不是本轮HTTP/Host/真实账户或完整AFI02/03验收；当前正式22/68不变。Backtrader真实资金成本消费、Risk终态Host和组服务链路继续独立验收。

证据见[evidence/afi-financial-book-contract-20261016/root-adjudication.md](evidence/afi-financial-book-contract-20261016/root-adjudication.md)。


## 第117轮：组预留未知回执保留与持久恢复

组预留调用发生回执丢失时，真实SDK会携带BUSINESS_OUTCOME_UNKNOWN错误码；原协调器把任何大写code都当作确定拒绝，可能在账户owner已提交ACTIVE预留后将组终态拒绝，漏掉该账户的恢复。本轮只将明确typed GroupReservationDeniedError认作确定拒绝，其它reserve异常进入UNKNOWN/RECOVERY_REQUIRED；GROUP_NOT_FOUND查询分类保持。回归模拟远端已产生ACTIVE预留再丢回执，关闭并重开本地SQLite后仅query恢复，不重复reserve、不提前release或派发订单；原确定拒绝释放及正常组路径仍通过。

Root对固定1373已提交源码加唯一group_coordinator候选覆盖运行三项受影响检查，3 passed、exit0、0.66秒、无warning、stderr空；138个来源pin及Execution/Base HEAD前后不变，pytest中验证并记录coordinator与store实际源码位置/hash。排除其它未接受paper改动。初次Root r1在测试前失败：origin插件错用checkout CRLF的store hash核对提交LF导出；原日志保留。只修正该已由git show证实的expected hash后r2首次运行三项测试成功，没有重复已接受整套组测试。独立静态审查GO。

Execution/dev精确两路径提交743a0b9feef5b625fbd98269e8ab374f4d80adc8（父1373b13），其它paper候选diff保留且index空；SDK本轮更新该gitlink及证据/进度，父663b8eee。接受等级是SQLite持久恢复与typed合成owner端口，不是本轮网络回执丢失、ServiceHost或完整ARB02/04验收。正式22/68不变；实际三Host正常/UNKNOWN-hold组链的作者证据已产生，Root仍需按固定最终组合验收。

证据见[evidence/execution-group-unknown-reserve-20261016/root-adjudication.md](evidence/execution-group-unknown-reserve-20261016/root-adjudication.md)。


## 第118轮：策略账户簿显式账户绑定

OWNER_BOOK 的旧 coverage 投影裁剪了 canonical account_key，而新增 financial 子对象有自己的 ledger_cut.account_key。服务端原本已把两条读取绑定到同一可信 Execution 账户；没有观察到跨账户输出。本轮把 reconciliation.coverage.account_key 显式保留到 OWNER_BOOK coverage，让 Backtrader 等消费者能独立核对两条投影的账户一致性。Wire account_ref 与 canonical account_key 仍是不同标识，不能直接互比。

唯一生产变化是一行字段投影；新回归走真实 ExecutionOrderEntryService.handle 和持久 SQLite financial projection，验证 target account_key、legacy coverage 与 financial cut 三者一致，且查询前后数据库 total_changes 不变。Root 954fce 运行该新节点：1 passed、exit0、1.49秒，一条已知 pytest 配置 warning，stderr 空；369个来源pin及7个仓库HEAD前后不变。Execution 使用743a已提交源码的精确 Git blob 导出，排除未提交paper代码。独立源码审查GO，未重复第115轮已接受节点。

本轮在 SDK/dev 父91e3662837514a30b5cb0e1f25c79fe219af6124提交两个明确源码/测试路径及本记录，Risk/group/paper等其它变化保留。证据是本地真实handler/SQLite、合成账户事实，不包含新的ServiceHost/Cerebro或真实账户验收；正式22/68不变。下一步在固定已提交SDK上验证Backtrader账户绑定、成本完整性与同run重开。

证据见[evidence/sdk-owner-book-account-binding-20261016/root-adjudication.md](evidence/sdk-owner-book-account-binding-20261016/root-adjudication.md)。


## 第119轮：Execution受管paper撮合与原子账本

Execution 增加受管 spot MARKET paper 端口：PaperOwnerDomain显式绑定模拟账户、策略、experiment、模型版本、报价来源、币种和初始账；没有默认资金、隐式估价或live派发。受信报价的generation/cursor只能消费一次，数量、步长、币种、费用与报价时效参与确定性撮合。普通Execution授权/订单意图链仍先取得唯一dispatch claim；持久化时在同一SQLite事务内复核writer lease和admission，将订单观察、outbox、paper receipt、Decimal现金/持仓成本/费用原子提交。

审查发现的完整性缺口已修复：读取和结算共用完整cut校验，旧UNKNOWN/未决订单、缺receipt的provider事件阻止新结算；只豁免本次合法DISPATCHING claim。通用provider对账不能绕过paper账本产生孤立事件。进程在结算前/事务中/提交后退出时，恢复只读取已提交receipt或保留UNKNOWN，不重读报价撮合。正常Execution非paper派发/观察/恢复行为保留。

Root d06749首次验证最终候选：29 passed、exit0、6.05秒、无warning、stderr空；含17项paper及12项原Execution派发/观察/五阶段进程恢复回归。142个源码/测试/config/runner pin及Execution/Base HEAD前后不变。独立源码审查GO。作者历史r1/r2失败来自不忠实fixture（外键、UNKNOWN边界、domain/报价标识）；原结果保留，作者r2的14通过+r3的3通过与r4的12通过准确按并集记录，不冒称历史一次29/29。

Execution/dev精确七路径提交ae1dffd4c13f9c55551258a1b01a3a5324d8f11d，父743a0b9，postverified index空。本SDK轮只更新该gitlink、证据及进度，父6e38c528；其它Risk/group/BT/AFI工作不纳入。证据为包级合成报价、真实SQLite及子进程崩溃恢复，不是ServiceHost/AFI入口、真实行情、旧paper状态迁移或完整AFI13验收。LIMIT、持续部分撮合及旧系统切换仍在完整目标范围内；正式22/68不变。

证据见[evidence/execution-managed-paper-spot-20261016/root-adjudication.md](evidence/execution-managed-paper-spot-20261016/root-adjudication.md)。


## 第120轮：Backtrader策略资金成本服务消费与正常重开

Backtrader显式策略账本消费服务端financial cut，提供按币种现金、持仓成本与累计费用；不把旧单次费用当成累计费用，也不据缺失估值生成NAV。读取要求canonical account_key、策略、游标和financial cut一致；缺少/错账户绑定使financial不可用，旧可信持仓仍可读取。非零持仓缺失成本行或成本未知时，cost_basis_complete降为false，现金可用但平均价不生成。

Root首次验证最终三个文件：18单元用例及一个真实Cerebro/ServiceHost节点，共19passed，exit0，13.83秒。集成使用两个策略共享Broker、真实CURVE通信和SQLite，正常关闭并重开服务与客户端，保留相同策略RunID；现金、数量、成本及费用与重开前一致，未重复派发或重复入账。测试和Host实际来源均打印并检查；814个来源pin和五个仓库HEAD前后相同。stdout有一条既有pytest配置warning，stderr有两条Windows Proactor为ZMQ注册selector线程的RuntimeWarning，不能称为无warning。独立静态review GO；外部检查确认四个无关BT tracked改动和空index保持。

实际依赖为固定SDK 6e38c528与Execution 743a0b9的Git源码导出，Base/Transport为当前固定dev；执行时仓库HEAD为SDK302674dc、Execution ae1dffd，不将历史导出组合冒称最新全仓发行验收。Backtrader/dev精确三个文件提交1fc58a3d3f8a5d4b97c23d3623107649fb15c56f，父815a834c，postverify index空且无关改动不变。本SDK轮只归档原QA及提交记录、更新进度，没有重复已通过QA。证据为本机合成provider的真实服务/Cerebro/SQLite消费与正常重开，不是实盘、完整故障恢复/回调崩溃矩阵、估值或全部场景迁移；BT01/BT02仍部分，正式22/68不变。

证据见[evidence/backtrader-strategy-financial-service-20261016/root-adjudication.md](evidence/backtrader-strategy-financial-service-20261016/root-adjudication.md)。


## 第121轮：受管组订单三Host正常服务集成

组协调器、账户组执行和Risk预留服务已接通正常ServiceHost构建、受信角色/政策、Host自有upstream、注册生命周期及组/两腿RPC。provider-v2合同绑定revision、fill watermark、费用与币种，正常归一化事实进入GroupProofJournal；普通Risk入口保留GTC限制，组流程只借用已提交RiskOrderJournal的writer fence。

Root r6原始验收7passed/11.12秒/exit0：一个真实本机三Host/CURVE/SQLite节点及六个wire回复回归。第一组两腿FILLED/PAIRED且残差0；第二组B端事实不完整，保持UNKNOWN和持久hold，query不重发。两账户provider各两次提交/订单查询/成交查询，三Host正常关闭、无强制回收。367个来源pin和7个仓库HEAD前后相同，一条既有pytest配置warning、stderr空。实际使用SDK91e36628及固定Execution743a0b9原始源码导出；本轮parent74228cdd，不据此宣称当前全包发行验证。

此前已接受options5项、runtime5项、proof2项、authority7项各自原始结果和pin一并保留，没有重跑通过的QA。19个明确source/test路径中，components、registry、Risk entry只提交group相关部分；Monitor格式、无关export、普通Risk查询/终态全部未验收改动仍在checkout。完整路径均匹配至少一份原已接受QA pin；normalization的候选LF与checkout CRLF经Git path filter得到同一blob。未绑定QA pin的bundle测试保留untracked，已提交role_config/authority测试不重加。

Root由19个候选的真实Git-filter blob生成有效diff（256b270d…f3d67ecaf），git apply --check --cached通过，独立静态审查GO。R1/R2草案的CRLF比较/坏diff产物未作为应用依据；原件保留。没有宣称隔离候选树QA，交付依据为原实际Host结果和所选hunk/依赖核对。提交不更新gitlink、不改checkout源码字节。证据为RESERVATIONS_ONLY的本机合成provider服务链；LIVE_GROSS共享cursor、各ARB完整否定/部分成交/补偿/恢复矩阵、BT/Sizer/Monitor、双机，以及CFG04独立安装组代理和CFG06完整角色/政策目录仍未完成。正式22/68不变。

证据见[evidence/group-three-host-service-integration-20261016/root-adjudication.md](evidence/group-three-host-service-integration-20261016/root-adjudication.md)。


## 第122轮：Backtrader真实成交回调与重复投影

新增一个Cerebro/ServiceExecutionSession集成节点，通过真实ServiceHost、CURVE和SQLite派发一个稳定intent并接收完整成交；策略收到一次Completed和一次开仓trade回调。随后在回调中读取同revision的受认证服务投影并再次传入Broker更新入口，检查仓位、成交数量、平均价、手续费和回调次数不重复增长。回调与关闭后的观察使用公开无I/O缓存报告，避免假provider空持仓刷新污染本地成交观察。持久dispatch_attempts、reserve与settle均为一次；Session、runtime和Host正常关闭，无强制回收。

作者在最终冻结test pin 4cf0f713…46e70ea0上执行原r3：1passed、exit0、8.72秒，一条既有pytest配置warning，stderr空。独立静态review GO；Root核对原command/JUnit/exit/log及当前test字节后接受，不重跑通过节点。该直接runner没有全依赖源/HEAD前后快照，故不宣称其具备该证据。固定SDK为6e38导出；Execution为743a的换行归一化导出，不冒称Root原始Git-blob导出。原r1节点名错误和r2假持仓刷新失败保留。

Backtrader/dev仅新增测试提交470b425d75fae37f873cd85f00ff56b150753240，父1fc58a3d，Root提交后验证精确单文件、empty index和四项无关tracked变化保留。本SDK轮只归档证据和进度。该节点使用合成provider/admission，不含新策略进程恢复、完整回调崩溃边界或真实账户；BT01/BT02仍部分，正式22/68不变。

证据见[evidence/backtrader-execution-callbacks-20261016/root-adjudication.md](evidence/backtrader-execution-callbacks-20261016/root-adjudication.md)。


## 第123轮：受管paper正常ServiceHost接线

SDK仅在execution/account_owner且公开service.order_entry时接受受信服务器resource paper_owner_domain；拒绝None和其它角色/端口的多余resource，客户端/YAML没有新增权限。Host构建经ExecutionAccountOwnerService条件转交该domain，Execution包继续执行精确domain/port/账户/策略绑定及基础admission验证。未配置paper时保留原调用参数形状。共享components只提交paper相关hunks，既有Monitor格式及TrustedRiskPolicyBinding导出不纳入。

作者首次正确启动的新节点使用真实spawn ServiceHost、ServiceExecutionClient、CURVE和SQLite，MARKET请求同ID重放仍只撮合一次，持久receipt和现金/持仓/费用核对一致，关闭后重开SQLite读取不改账。错domain和live目标在启动时拒绝、quote零调用；正常客户端/Host退出且无强制清理，Risk/Gateway未导入。原r2为1passed、exit0、3.44秒，一条既有pytest配置warning；三项review源码pins、SDK9d1与Execution ae1 HEAD前后不变。r1在collection前因PowerShell参数分词退出4，原记录保留。独立静态逻辑review和交付hunk review通过；Root核对原日志、JUnit、pre/post及候选，不重复通过的节点。

本次直接runner记录了三个改动文件的pre/post与两个HEAD，未记录全部依赖pre/post或加载模块origin，故不宣称完整发行/原始导出来源验证。原始checkout中的其它未提交变化未被接受；候选hunks由原测试覆盖和独立scope核对支持，没有另称隔离候选树QA。当前SDK/dev父748d8b76，提交三个明确source/test及本轮记录，保持checkout原字节与无关改动。证据为本机合成报价paper服务链，不是真实provider、AFI入口、R/M组合、LIMIT持续部分撮合、旧数据迁移或完整AFI13；正式22/68不变。

证据见[evidence/sdk-paper-service-host-20261016/root-adjudication.md](evidence/sdk-paper-service-host-20261016/root-adjudication.md)。


## 第124轮：AFI受认证手工单进入统一Execution owner

AFI新增服务订单HTTP入口、服务访问权限、持久operation-key模型/迁移及操作键到稳定intent的映射。键绑定subject、principal、actor、delegate、服务器scope绑定和请求指纹；相同键/内容复用intent，不同内容冲突。账户、策略、操作者、委托和scope来自服务器可信目录，客户端额外actor/审批字段拒绝。调用进入既有service-read owner线程与SDK runtime，再交给正常Execution owner，不新增旁路派发。已批准目标缺少完整可信审批合同仍明确拒绝，本轮没有授予该能力。

真实链先发现AFI错误要求双层业务reply：SDK已去掉wire层。新无Host回归使用真实SDK start/call/Registry及Execution._reply复现旧503，修复后focused unit8/8通过（两条已知pytest配置warning）。r7真实链通过首轮HTTP检查，却在lifespan内部提前断言deployment.closed；仅把四个断言移到该context正常退出后，未修改生产清理或放宽断言。r8唯一新Host节点1passed/exit0/11.01秒，验证两次lifespan、A同键顺序重放、B独立intent、409内容冲突、422伪造actor、403未知scope，服务侧actor/delegate和owner-thread一致，provider仅两次写入，worker/deployment/Host正常关闭。25个源pin及AFI/SDK/Execution/Base HEAD前后相同。三条warning为两个既有pytest timeout配置项及Starlette 422弃用；原r6b/r7失败证据保留。

独立静态review GO；review消息曾误摘录旧deployment pin，已更正为当前37020字节/60a17fb8…9e7c43b，Root与原manifest核对一致。Root核对原r8 command/JUnit/exit/pre/post和当前15个AFI源，不重跑已通过节点。AFI/dev提交1cf08d2a4673ea557bf8d11e7a1642e541ea7199，父dd1e14a；精确15paths、empty index，README/Windows脚本等无关改动保留。SDK本轮只归档记录，没有AFI gitlink。

本节点在单一Python进程内顺序重建两次lifespan，应用操作键DB为内存SQLite；Execution owner使用合成provider/真实本机Host与SQLite。尚未证明双AFI worker并发同键、持久应用DB/进程重启、已批准目标/审批撤销或真实账户，不能宣布完整AFI01/AFI07。下一轮补持久数据库与真实两进程竞争/恢复，再推进审批服务合同。正式22/68不变。

证据见[evidence/afi-manual-service-orders-20261016/root-adjudication.md](evidence/afi-manual-service-orders-20261016/root-adjudication.md)。


## 第125轮：组服务测试的已提交依赖闭合

将两个已提交组服务测试依赖的SQLite合成provider叶子抽为独立stdlib测试helper；provider account改为实例参数，消除对未提交exposure测试以及其risk-only测试全局变量的依赖。未改生产代码；Root核对两个原测试的81/88条Assert AST均未改变，三个候选与独立artifact逐字节一致。独立静态review GO。

在唯一的新非Git artifact中，从SDK ed5ce2e及已提交的Base b4aabd1e、Execution ae1dffd4、Risk 5f6ba0b2、Gateway 59b164ab、Transport 29ab21e7、Monitor 536a4f04导出源码，只覆盖本轮三个测试路径。一次 --collect-only 成功收集两个目标节点，exit0；JUnit tests=0，没有运行测试体或启动Host。582个artifact源码pins前后一致，stderr为空；保留一条禁用插件自动加载所致的pytest配置warning。Root核对原spec/result/stdout/JUnit、当前候选、全部artifact pins；没有重复第121轮已接受的七项运行验收。

验收等级 ARTIFACT_COLLECTION_ONLY：接受测试依赖闭合与可收集性，不宣称新运行行为、发行安装、真实账户或ARB完整矩阵通过。当前SDK/dev父ed5ce2e，提交三个明确test/helper及本记录，保留其他开发改动，正式22/68不变。此提交为CFG04从固定提交制作安装验收支持文件解除依赖阻塞。

证据见[evidence/group-fixture-closure-20261016/root-adjudication.md](evidence/group-fixture-closure-20261016/root-adjudication.md)。


## 第126轮：Execution组合预算持久原子预留

Execution/dev提交5e6ba3e90e04f5e2f5ad0944e6557f2a1eb1edc5（父ae1dffd4），精确八个source/test路径：新增受信组合预算政策、按Risk真实InstrumentRiskRegistry计算的手续费/滑点估值、按组合持久预算receipt与SQLite事务竞争约束。相同ID重放绑定原政策/quote；未知及已配对组保留HELD，未定价的活跃v1历史行拒绝新授信；活跃政策指纹不一致拒绝。只有明确未派发或经证明无成交且预留已释放的路径才释放预算。

内置估值器对缺可信价格界的MARKET明确返回group_budget_market_price_unbounded，发生在Risk评估前；共享MARKET合同与存量读取保持兼容，其它受信quote builder仍可提供有证明的价格界。不声称内置MARKET估值、跨账户分布式原子事务或完整ARB02通过。

作者最终22项通过，独立静态review GO；Root为排除并行开发中的store.py依赖，从已提交ae1dffd源码加本轮八项原字节overlay构造固定候选，依赖Risk5f6ba0b2/Baseb4aabd1e。一次候选QA为22passed/3.79秒/exit0，无warning、stderr空，188个源码pins前后相同；覆盖真实SQLite及双spawn预算竞争，Risk API真实、provider/authority事实合成。原17pass/1fail暴露旧scope fixture漏portfolio_ref，已按现行合同修复且最终suite包含原节点；原21pass仅工具transcript，最终作者22pass原日志保留，均不替代Root固定候选结果。

Root提交及postcommit验证八项blob/checkout、空index和无关recovery store改动保留。本轮SDK仅记录包级交付，gitlink暂留ae1dffd：现有SDK组Host尚未注入新必需预算，必须在下一轮接线与组合验收后一起更新gitlink，避免发布断链组合。不重复已通过的22项；不增加正式22/68。证据见[evidence/group-budget-package-20261016/root-adjudication.md](evidence/group-budget-package-20261016/root-adjudication.md)。


## 第127轮：Backtrader 正常入口拒绝旧远程配置

现有 Backtrader dev `8e1851ac7dc59dae51c1b92ac5d9b3a9d4209a77`（父 `470b425d75fae37f873cd85f00ff56b150753240`）仅提交 config.py、cli.py 和一份回归测试。旧 Gateway/forwarding 根字段以及旧 Store 实际消费的十个非空 BT_GATEWAY 环境变量返回明确迁移错误，发生在 runner 派发之前；空值及未知后缀不阻断 v4 本地回测。

验收依据：作者控制台报告 6 passed、1 条既有 pytest 配置警告，独立静态复审 GO，Root 核对精确三路径、提交对象、空 index 和无关 tracked diff 保持。作者没有保存原始日志、JUnit 或单独退出码字段；Root 未重跑测试，不补造这些证据。测试使用正常 CLI/legacy shim 和合成 runner，证明配置入口行为，不证明真实交易或完整回测。

CFG05 仍为部分完成：当前 runtime 只支持 v4，v5 显式不支持，未把此拒绝测试计为 v5 支持。正式总数仍 22/68。记录见 evidence/cfg05-normal-entry-20261016/root-adjudication.md。


## 第128轮：CFG04 七代理独立安装正式通过

固定发行组合：SDK `9d1dc457af0e0e4e94895ca215a27137e86fa20f`，Execution `ae1dffd4c13f9c55551258a1b01a3a5324d8f11d`，其余 Base/Gateway/Risk/Monitor/Transport 精确提交及 wheel hashes 见 artifact-manifest.json。客户端独立 venv 只有 SDK/Base/Transport，四领域包缺席；实际服务位于另外的进程及服务端 venv。test-support 基于已提交 `213f1114`，另含两条新测试支持文件；它不是 SDK wheel 的源码版本。

Root 使用既有统一 runner，修正 cwd 为外部冻结支持根，清除 PYTHONPATH/PYTHONHOME/PYTEST_ADDOPTS 并显式绑定两个 server Python：剩余 market/group 两节点 2 passed、exit 0、7.82s、零 warnings、stderr 空、1004 个输入前后不变。结合 qa-r1 已通过的五代理节点，三个唯一节点覆盖全部七代理、客户端拒绝 components/embedded/服务端槽、实际交互及正常关闭。不是一次 3/3：qa-r1 原始 1 pass/2 fail 和 qa-r2 cwd 启动错误均保留，已通过五代理没有重复。

Root 另外核对372个项目wheel文件与指定Git提交内容一致（368个仅CRLF/LF差异已逐条登记），source archive→wheel→installed 字节一致。独立静态复审逐项对照正式 CFG04 后 GO；未将仅源码检查代替运行证据。

CFG04 正式 PASS，正式总数由22/68升至23/68。仅适用于上述固定发行组合与本机合成provider，不代表当前最新SDK组合、真实账户、ARB02、负载或双机通过。两份新增测试文件和证据在本轮SDK dev提交，其他WIP保留。详见 evidence/cfg04-installed-seven-proxy-20261016/root-adjudication.md。


## 第129轮：AFI 手工操作跨进程竞争与持久重启

AFI dev `13ab6f912a568877846e25f42ae94fd3969de61e`（父1cf08d2a）仅提交正常HTTP集成测试。两个独立AFI app进程对同一磁盘SQLite应用DB并发提交同键同体，真实lifespan/SDK worker/Execution Host产生同一intent、一个operation持久行和一次合成provider派发；同键异内容409且行不变；关闭后第三个app进程用同DB重放得到相同intent/ACK。身份、actor/delegate/account/manual-book/action及最终journal事实均有断言。

Root r2唯一节点1passed、exit0、28.77s；两条既有pytest配置warning（timeout/timeout_method），stderr空；2159个源码/固定artifact pins及AFI HEAD前后不变。三个app进程均通过close receipt/PID/单worker/exit0/无强杀/句柄关闭断言，Execution Host正常关闭；未另存成功路径每个进程的receipt JSON，不夸称逐进程原始回执已归档。固定SDK40d3e17/Executionae1来源，不是当前可变SDK工作区。

r1启动失败原样保留：子进程清空PATH引发Windows ctypes.util.find_library KeyError，独立import-only诊断确认；修复只保留PATH和合成USERPROFILE。原r1仅记4个cleanup失败总数，无法据此证明正常退出；未回填旧结果。新的失败诊断保留所有进程代次的有限清理事实。

独立验收复审确认本轮关闭手工单并发与持久重启缺口，但AFI07仍缺策略单/已批准目标同owner、审批摘要版本过期撤销、已接受组撤销结果和普通订单不改组腿。正式数仍23/68，不重复本轮成功节点。证据见evidence/afi-manual-operation-multiprocess-20261016/root-adjudication.md。


## 第130轮：SDK 受信组合预算接线

仅提交service_execution_group及其两个测试文件，并将Execution gitlink从ae1dffd更新到已验收预算包5e6ba3e。认证后固定target提供policy/quote builder；校验principal、strategy、portfolio、账户和政策指纹；缺policy在run绑定/预留/派发前拒绝，query仍可用，wire不能自带预算。未纳入其它SDK Risk/恢复或E store.py WIP。

精确三pin独立静态GO；作者报告unit10pass和三Host/CURVE/SQLite1pass，均1条既有pytest配置warning。实际三Host节点验证两腿终态和UNKNOWN hold，未测实际跨组超预算竞争。integration工具调用1b288b可核对；unit原调用未恢复，只保留结果摘要；两次都无保存stdout/JUnit、逐模块运行来源/pins，未隔离共享SDK/E未提交上下文。证据等级为作者工作区QA加静态source review，不是Root验收或固定提交发行组合接受。

Root读取production diff并核对三文件/已提交E预算接口/精确Git对象。原命令记录R1存在路径转录错误，保持在.codex-tmp；交付R2以结构化integration命令和unit命令不可恢复的声明纠正，未重跑或伪造原始输出。后续固定提交正常服务验收仍需预算拒绝、跨组竞争与恢复。ARB02部分、正式23/68。详见evidence/group-budget-sdk-wiring-20261016/root-adjudication.md。


## 第131轮：Execution/SDK 持久恢复快照与增量读取

Execution/dev f04851d91a7b336636b02ed9b6dd5cba1dc71037（父5e6ba3e）提交store及聚焦测试两路径；SDK本轮提交账户簿适配器、公开client恢复方法与聚焦测试三路径，并更新该gitlink。SQLite同一事务读取原子cut，检查全局journal连续性，按受信目录和认证scope选择订单/事件；目录前后变化、generation不符、未知事件或超限均拒绝，没有静默截断或provider读取。默认账户簿请求保持兼容。

恢复合同为持久策略scope，不按WireScope.run_id隔离；快照为DURABLE_CUT_NOT_PROVIDER_LIVE。快照最多512订单/20000历史事件、wire结果48KiB，事件页最多128条；超限失败，不宣称无界全账户恢复。客户端使用正常query绑定并解开一层业务result；签名手续费允许负maker rebate，原始tags不投影。

作者记录包级4passed/0warning、SDK5passed/1条既有pytest配置warning，均exit0；独立静态review GO。原始命令与结果来自保留的作者工具记录，没有保存raw log/JUnit或完整依赖来源快照。Root核对五路径pins、SDK diff/测试和包提交，不重跑已通过QA；证据等级为作者工作区QA加静态源码审查，不是Host/Cerebro恢复或正式BT02验收。旧v21兼容测试从当前DDL修改版本及旧payload再重开，只证明该迁移路径，不是完整历史DDL fixture。

正式23/68不变。下一步将Backtrader持久manifest/投影/callback恢复接入固定提交的正常服务链，验证独立策略进程恢复及回调中断边界。证据见evidence/execution-sdk-recovery-views-20261016/root-adjudication.md。


## 第132轮：Backtrader 持久意图与恢复事件组件

Backtrader/dev a50aea8c4cc863341cdb1338aebc38edee25fb8a（父8e1851ac）提交六个明确路径：恢复journal、adapter/session接线、两份测试及AGENTS六行状态说明。稳定logical run的submit/cancel manifest先于RPC持久化，事件receipt/投影/cursor/callback pending同事务提交；callback返回后才确认，异常后可重放，语义为at-least-once。恢复模式的submit回复只作接受证据，不能凭其FILLED字段重复记成交；scope不匹配在manifest/RPC前拒绝。

作者R11原始log和JUnit为27passed/0failed/0error/exit0、4.65秒、一条既有pytest配置warning；独立静态review GO。Root核对原始文件hash、27节点、六路径精确pins、源码diff，未重跑通过的测试；提交后验证精确六文件、empty index及四项无关tracked修改保留。该QA使用本地journal/fake client，并未导入SDK恢复client或运行Cerebro/Host，不能称SDK链验收或完整来源快照。

本组件尚未把恢复事实绑定到fresh Broker Order，也未将恢复快照作为已有累计执行/持仓基线导入Broker。下一轮增加真实Broker恢复桥接：restore与新成交区分、稳定intent显式绑定、既有事件更新路径、真实队列回调，以及独立策略进程在投影后/确认前中断的恢复。不得以通用callback重试代替这些要求；账户总量仍依赖权威账户读模型，execution订单快照不冒充完整账户资金/持仓。固定服务依赖SDK596ca47b/Executionf048已提交。正式23/68不变。

证据见evidence/backtrader-recovery-journal-20261016/root-adjudication.md。


## 第133轮：正常入口拒绝旧 Gateway selector

Backtrader/dev db96d8566188bc602a77ae37539dc1269fe7e8ea（父a50aea8c）提交两个路径：CLI与legacy迁移测试。BT_STORE_PROVIDER经strip/lower后为gateway或以_gateway结尾时，在任何运行派发前返回MIGRATION_REVIEW_REQUIRED；direct或未设置仍可进入v4本地回测。判断与真实Store的provider选择语义相符。

作者r1在pytest-asyncio收集阶段失败（exit2、业务执行零项）；r2为4passed/1failed（exit1），失败仅为测试把输入Gateway词误认作固定提示中的原始值泄露；修正测试后r3只重跑三种拒绝值，3passed/exit0、一条既有配置warning。两项direct/unset正例沿用r2成功结果，生产CLI pin未变。Root核对原始JUnit/log及最终pins，不表述为一次5/5。独立静态审查GO，Backtrader提交精确两个路径、index空、无关tracked修改保留。

该正例仍使用合成runner，正常code-owned v4入口到真实Cerebro运行的新增节点待Root执行。CFG05要求保持“仍受支持”的v4/v5可用；当前v4受支持，v5是未来计划，不能把新增v5实现当作本条额外缺口。未接受真实provider/账户，正式23/68不变。

证据见evidence/cfg05-legacy-provider-selector-20261016/root-adjudication.md。


## 第134轮：Risk 订单敞口完整观察链服务接线

本轮仅提交SDK Risk order entry、SQLite journal及exposure integration test三个源码/测试路径。实际BtApi归一化查询进入Risk证明链，修复EXPOSURE_APPLIED持久时间字段、post-ACK UNKNOWN精确事件形状和CANCELLED零leaves不应要求活动订单估值价格；保留严格claim、permit、attempt、source revision与writer fence校验。

Root r20真实spawn ServiceHost/CURVE/SDK节点1passed/exit0、10.18秒、一条既有pytest配置warning，stderr空；368项固定来源前后不变。覆盖首次FILLED、ACK与后续部分成交、重复查询不重复计量、信息不完整UNKNOWN保留敞口、完整CANCELLED释放leaves、释放后新订单、超限拒绝不新增provider写入。Host和strategy正常close/join/exit0，测试确认无fallback terminate/kill和清理失败。r19本地完整链及严格形状节点2passed/exit0是辅助证据，不替代该Host；通过节点未重跑。

来源是r8历史候选加本轮overlay：SDK历史213f1114、Execution raw 743a0b9f与固定Base/Risk/Gateway/Monitor/Transport；不是当前整个dev运行证明。365/368固定输入与捕获时checkout相同，另三个SDK Execution/account-books/group文件有已提交后继版本；源码清单/provenance完整保留。测试依赖的risk-only fixture函数已在HEAD，当前该文件的两项未运行typed-terminal测试不提交；components的格式和未使用export、registry格式、其他WIP均保留。独立静态GO与Root精确来源/结果检查支持此范围。

证据等级为本机真实服务进程、合成provider的Risk订单敞口接线；无真实账户/生产baseline声明。完整RISK02仍需按正式条款补所需恢复与失效分支，当前Host节点未覆盖敞口应用后重启、TTL/数据过期、FX或非单位乘数，不从包级证据推导全链通过。正式23/68不变。

证据见evidence/risk-order-exposure-service-20261016/root-adjudication.md。


## 第135轮：CFG05 正式通过，真实 v4 正常回测入口

Backtrader/dev 4c316d342a221e94c681bd8717430491ac119d59（父db96d856）提交唯一新integration test。Root e09bf1/c82db2在db96的固定527个Git原始package blob与唯一测试overlay上运行正常backtrader_runtime CLI，生产default registry/dispatcher进入code-owned v4 local-backtest runner，真实Cerebro/default broker读取四条包内CSV数据，返回completed。结果1passed/exit0、11.92秒、零warning、stderr空；713个输入与BT HEAD前后不变。测试child正常返回并由subprocess.run等待退出。

测试检查可选SDK/四包/provider导入、socket连接/绑定、Python线程及multiprocessing子进程启动均未尝试，最终只MainThread且无multiprocessing active child。它不是全OS资源监控；runner的provider_submissions=0是已检查无下单路径的结果常量，不冒充真实provider计数。未执行订单、真实账户或网络。实际CLI返回payload由测试内assert消费，成功时未另存完整child JSON，不声称有该逐阶段原始档案。

第一次Root调用97312b在pytest收集阶段失败（exit4）：artifact位于SDK .codex-tmp下，隐式继承祖先pytest的namespace配置，导致相对包导入TypeError；业务节点执行零次，712pins与HEAD不变。只在新spec中显式固定独立pytest.ini/rootdir后运行，冻结test/package未改。原失败结果保留，成功节点不重复。提交验证精确一文件、empty index、所有无关tracked修改保留；通过测试的第278行空白EOF原字节保留。

CFG05逐条裁定：R48已接受的11项离线拒绝检查与既有EMPTY_COMPONENTS检查覆盖enabled/register_to/空服务清单/政策身份引用；R127正常CLI/legacy入口覆盖旧Gateway/forwarding形状及十个已消费BT_GATEWAY环境变量，在派发前明确迁移拒绝；R133补真实BT_STORE_PROVIDER selector的gateway或*_gateway拒绝。R133最终三拒绝通过与先前两direct/unset通过分别记录，不写成一次5/5。新增节点补足原合成runner留下的真实v4回测缺口，CFG01的正常DirectBackend证据仍可沿用。正式计划只要求仍受支持v4/v5；当前v5是未来目标，不追加实现门槛。

独立条款审查GO，Root根据上述各层证据裁定CFG05正式PASS，累计24/68。保留R127作者6passed/一条warning但缺原始log/JUnit与独立exit记录的限制，不将它追溯为Root运行；已接受旧测试未重跑。该用例不要求真实provider账户证据。其他44项尚未全部完成。

证据见evidence/cfg05-v4-normal-runtime-20261016/root-adjudication.md。


## 第136轮：AFI 批准目标持久化组件（2026-10-16）

- AFI 现有 dev `a6d769474ece728818710d293ea9ad61ca55a4c7`，父 `13ab6f912a568877846e25f42ae94fd3969de61e`；六个明确路径：模型/导出、迁移、持久服务、测试与固定合同。实现精确身份/作用域/版本/digest绑定、外部稳定intent预留、撤销/消费CAS、append-only事件及必需的当前状态provider边界。
- 作者数据库组件QA：R8单独14passed/exit0，R11新增/受影响5passed/exit0，各两条既有pytest配置warning；不是一次19项测试。R8无保存的原argv，R11命令仅作者报告，原stdout/JUnit/exit已保存。独立静态复审GO覆盖最终六路径；Root只核对源码/原证据与提交，不重跑已接受测试。
- 修复既有schema兼容校验的required nullable字段与FK删除动作；file-backed SQLite两个独立AsyncSession竞争验证单一预留winner。consume/revoke仅顺序覆盖，未证明同时争用；CHECK兼容仅验证必要SQL片段，非完整Boolean等价。
- Root精确提交六路径，index为空；六项原有tracked和三项untracked文件保持。保留合同中两处Markdown硬换行与末尾空行，未为交付改写冻结文本。证据：`evidence/afi-approved-target-persistence-20261016/`。
- 等级：AUTHOR_DATABASE_COMPONENT_QA_AND_INDEPENDENT_STATIC_REVIEW_ONLY。尚无生产current-state registry、HTTP/SDK/Execution/Host批准目标链；AFI07不计PASS。AFI应用审批policy与live Risk policy严格分离。正式累计维持24/68。



## 第137轮：Execution 批准目标派发组件（2026-10-16）

- Execution现有dev `868dc1c602514a675bb1887ec8a3c975933d48c5`，父 `f04851d91a7b336636b02ed9b6dd5cba1dc71037`，精确八路径。先提交子包，再更新SDK gitlink；SDK批准操作装配/配置仍为下一轮WIP，未混入此次提交。
- server-owned完整身份/作用域到approval owner绑定；stable operation/intent与规范target digest；持久DISPATCHING后消费批准，只允许CONSUMED_NEW继续Basic→Risk claim→writer lease→provider。明确AFI应用审批policy不是live Risk政策。受保护普通下单拒绝；新增严格server-only approved_target_required布尔选项。
- 独立审查曾发现任意异常.code被误判明确拒绝，已修为仅精确ApprovedTargetAuthorityError且非ambiguous时允许明确拒绝；伪造code的传输异常保留UNKNOWN，不释放、不调用provider、不重consume。历史原27项作者控制台通过但无原log/JUnit；修复5项与新增option1项分别保存原stdout/stderr/JUnit/exit，均exit0/零warning。不是一次33项测试，未重跑已接受节点。
- 最终八路径独立静态GO；Root核对源码及原始证据、精确scope/父提交/过滤后Git blob与空index。没有Root固定来源测试或正常ServiceHost/AFI交易路径证明。
- 证据 `evidence/execution-approved-target-dispatch-20261016/`。AUTHOR_WORKTREE_QA_AND_STATIC_SOURCE_REVIEW_ONLY；AFI current-state生产provider、同步authority装配与HTTP/SDK/Host完整链尚待验收。无新增正式PASS，累计24/68。


## 第138轮：Risk 可信汇率估值与事务有效期（2026-10-16）

- Risk现有dev `c6fcacda5efb5153d8c3e2be7b17f335f2732a9e`，父 `5f6ba0b2d7dd7a5589392e299ce2ecb90fef9d7b`，精确六个source/test路径。先提交子包，再更新SDK gitlink；未创建worktree，其他SDK工作区修改保留。
- 不可变InstrumentRiskFxRate绑定报价币种、估值单位、汇率、source revision/digest与时间区间；订单保留原始报价价格，Risk将本金与明确单位的费用换算为估值单位。Mapper要求受信汇率对象与来源匹配，opening intent绑定metadata/FX有效期交集。
- reserve/claim在事务入口、写前和最终风险扫描后复核有效期。新测试确认claim/freeze实际写入后遇过期会一并回滚；旧同币种payload/digest/fingerprint保持兼容。
- 作者r2为25 collected、23 passed/2 failed；r3仅三个受影响节点，两个事务节点通过、旧格式oracle仍失败；r4只重跑修正后的旧格式节点，1 passed/exit0。r2之后生产delta仅无FX时Decimal precision操作数恢复；r3与r4均绑定最终production pins。旧格式离线HEAD对照证明生产输出原本相同，错误是测试预期尾零。没有一次25/25全绿测试，原失败证据保留，未为归档重跑已过节点。
- 独立六文件静态GO；Root核对原stdout/JUnit/exit、源码pre/post pins、scoped commit/父提交/过滤后Git blob和空index。接受AUTHOR_PACKAGE_QA_AND_STATIC_SOURCE_REVIEW_ONLY，未运行Host/provider/account。本轮供下一步SDK敞口应用后重启与失效FX完整Host链使用；RISK02仍部分，无新增正式PASS，累计24/68。


## 第139轮：SDK批准目标接线与同owner多策略路由（2026-10-16）

- 本轮在SDK现有dev提交十个source/test路径：六SDK文件、三个unit测试及一个必要integration helper依赖。service_components/service_host以精确HEAD-based overlay分块入index，保留无关Monitor格式/TrustedRisk export及其他WIP；其余八路径按已审候选交付。父93c2470c，Execution依赖仍868dc1c。
- approved_target_authority按服务端资源装配，required严格布尔、无authority时拒绝启动；只有实际authority服务公布批准操作。客户端默认不注册批准操作；显式批准单操作注册只授予orders.submit_approved_target，普通submit在transport前被拒，四个批准字段严格映射。修复先前必须同时申请普通submit的最小权限缺口。
- 同账户同writer允许不同scope_ref，writer身份含mount/service/instance/transport；重复路由与跨writer仍拒绝。真实ServiceClientRuntime/Registry双策略SERVICE group-leg节点证明无scope歧义拒绝，指定scope只到对应策略。本地transport/合成handler，不是Host证据。
- 原SDK focus为19pass/1fail后单失败节点1pass；server-required新增3pass；路由focus77pass/1fail、旧fixture单节点再次失败后忠实fixture1pass；approved-only节点两次public API oracle失败后源核对、独立GO、1pass/exit0。原始失败与warning保留，不合并成一轮全绿，不重跑已接受节点。
- Root核对R3十路径manifest/patch、base Git blobs、所有原JUnit及最后两次source前后pins；独立静态GO。QA均为候选工作区，未运行固定overlay套件。integration文件仅作为已测cleanup helpers的源码依赖纳入，整个spawned Host测试未接受；下一步从本提交导出固定来源执行新的ARB02 Host用例。AFI07/ARB02不增PASS，累计24/68。


## 第140轮：受管 paper fill V2 持久读取合同（2026-10-16）

- Execution/dev `12372d82bb5c871e8a46c39c3daed9f85edccb0c`（父 `868dc1c602514a675bb1887ec8a3c975933d48c5`）已独立提交三个路径；本SDK轮仅更新该Execution gitlink并归档assessment/postcommit，不包含SDK业务源码。
- 新增 managed-paper V2 专用只读接口 `SqliteExecutionStore.get_managed_paper_fill_v2_for_event(...)`；既有公共V1合同未升级。receipt使用 `MANAGED_PAPER_MATCH` 的Unix纳秒时间，一个match样本驱动评估与receipt重放；本地event-created时间仅作诊断。读取在单个只读SQLite快照中校验事件链。旧V1记录仍可读取，但不提升为V2成交。报价在评估至事件提交间过期时，订单/事件/receipt/book写入回滚，dispatch claim保持UNKNOWN，重复intent不重新撮合。
- 作者控制台报告22 passed/exit0/2.77秒/无warning；作者报告的argv保存在assessment中，但原始command文件、stdout、stderr、JUnit和源码pre/post快照均未保存。独立静态审查GO。本轮只复制现存assessment/postcommit，不重建或补造缺失档案，也不重跑测试。
- 证据等级 `AUTHOR_CONSOLE_QA_AND_STATIC_SOURCE_REVIEW_ONLY`。本V2接口尚未通过新的SDK ServiceHost/AFI或Backtrader恢复链验收；保留第123轮既有E-only paper-owner Host证据且不与V2混称。BT02与AFI13继续部分，正式累计24/68。


## 第141轮：AFI07 批准目标 SQLite authority 组件证据归档（2026-10-16）

- AFI 独立仓库 `a421354b38740f26531645accd8e13338fadbf4d`（父 `a6d769474ece728818710d293ea9ad61ca55a4c7`）提交13个source/test路径；AFI不是SDK gitlink。本SDK轮仅归档已存在的Root QA、source assessment/postcommit及必要的R2启动修正记录，并补充进度说明。
- Root固定来源QA `D:/temp/afi_iter10_afi07_authority_source_root_20261016_r1`：27 passed/exit0/4.80秒/零warning，13个源码pin前后相同；afi_lifespan_review对最终13路径静态GO。该组件覆盖批准目标SQLite持久化与当前状态authority边界，不包含HTTP/API到SDK/Execution的Host接线。
- 保留作者R1的24/27及一个生产tuple/list兼容差异、两个fixture缺陷；作者R2在pytest插件注册阶段失败，执行测试0项。R2 correction将其分类为启动环境未按计划设置导致的harness/setup错误，原运行未改写。本轮只复制R2 correction摘要，不复制完整旧运行目录或临时锁文件。
- 接受等级 `AFI07_APPROVED_TARGET_SQLITE_PERSISTENCE_AUTHORITY_COMPONENT_ONLY_NOT_HTTP_SDK_EXECUTION_HOST_ACCEPTANCE`。没有HTTPSDK/Execution/ServiceHost批准链验收，AFI07仍未正式通过；正式累计24/68。


## 第142轮：Backtrader 持久恢复与回调组件证据归档（2026-10-16）

- Backtrader/dev `48bde5d76bd666ce876763a613f27b92e9c62074`（父 `4c316d342a221e94c681bd8717430491ac119d59`）已提交五路径：Broker恢复cut/有序receipt接线、Execution adapter与SQLite恢复journal、Strategy恢复通知及其聚焦测试。独立静态review对最终五pin为GO；本SDK轮只归档两个作者运行的原始记录与assessment/postcommit，不更新SDK源码或gitlink。
- 组件覆盖：按恢复cut加载快照、事件与cursor，绑定持久intent与owner投影；callback通知在交付后确认、异常可重放；成交容量在事务内原子校验，防止over-close。CLOSE、CLOSE_TODAY、CLOSE_YESTERDAY保留原始effect，并只按`(data_name, tradeid)`聚合，不宣称日桶容量语义。
- 作者R1为12 passed/2 failed、exit 1，原始stdout/stderr/JUnit/run.json保留；该轮仅有pre-run源码pins，没有post-run pins，不补造。修复后R2独立为16 passed/exit 0/4.15秒，有一条已知pytest配置warning；R2记录有匹配的source_pins_before/after。两轮结果分别归档，不写成一个合并测试数。独立静态review GO，Root未重跑已通过QA。
- 等级`AUTHOR_WORKTREE_QA_AND_STATIC_SOURCE_REVIEW_ONLY`。证据是本地SQLite/Broker组件；没有新的ServiceHost、Cerebro、fresh-process恢复、provider/account或完整BT02验收。独立开发中的managed-paper V2消费者不纳入本轮。BT02仍部分，正式累计24/68。


## 第143轮：managed-paper成交V2 SDK恢复投影与显式版本接口（2026-10-16）

- SDK/dev `13f17e4b6397b129dcb82d627221a0fa8894e151`（父 `e57d692f43858bcb785decb54ced4c832e99865e`）已提交三路径：`service_execution.py`显式支持恢复事件查询版本参数，`service_execution_account_books.py`按受验证的Execution store receipt投影managed-paper V2成交事实，新增四节点聚焦测试。本轮只归档已存在QA原始记录、assessment和postcommit，不更新SDK源码/gitlink。
- `query_recovery_events_after(..., version=2)`是显式opt-in；缺省仍是严格V1，版本值只接受精确整数1或2，拒绝bool和未知版本。V1事件/页面形状及`RECOVERY_SNAPSHOT`路径保持原行为。V2仅在store对paper `provider_observation` 的持久receipt完成同快照校验后添加`details.paper_fill_v2`；旧V1、非paper及无匹配V2 receipt不补造成交时间或费用事实。
- `paper_fill_v2`精确23键：`schema`, `time_source`, `fill_id`, `match_time_ns`, `quantity`, `price`, `commission`, `commission_currency`, `commission_model_id`, `commission_model_version`, `event_id`, `event_sequence`, `journal_generation`, `scope_key`, `intent_id`, `intent_fingerprint`, `account_ref`, `strategy_ref`, `quote_source_ref`, `quote_generation`, `quote_cursor`, `quote_instrument`, `receipt_sha256`。不含本地event-created时间，也不重复嵌套submit fingerprint；信任边界绑定外层已验证事件和V2 receipt。
- 作者R1为2 failed/2 passed/exit 1：MARKET fixture漏`price: null`，请求在任何报价或持久写之前被拒绝。R2为1 failed/3 passed/exit 1：match和commit采样恰好相等，导致不稳定的时间不等式断言；只调整测试时钟。R3独立4 passed/exit 0/1.49秒，保留一条既有pytest配置warning。三轮stdout/stderr/JUnit/run.json分别归档，未拼成一次累计全绿；最终静态review GO，源码pre/post pins相同。
- 证据等级`SDK_AUTHOR_FOCUSED_QA_AND_STATIC_SOURCE_REVIEW_ONLY`。无新ServiceHost/Backtrader消费链或BT02完整恢复验收；不增加正式PASS，累计24/68。


## 第144轮：ARB02共享组合额度竞争与重启证据（2026-10-16）

- SDK/dev `1ecee85ed678edf49853ed25ebb53752941ae9e7`（父 `ea41c3368b5577af34ad215faa513d5bc05c8e25`）提交三路径：同服务owner下合法多策略scope路由修复、对应Registry部署回归和三ServiceHost组预算集成节点。本轮只归档已接受源码与原始QA、source assessment、postcommit；不改源码或子包gitlink。
- Root固定来源三Host/CURVE场景通过1项/11.69秒/exit0；另有4项无Host部署验证通过。两策略client请求重叠，由单一coordinator串行裁决：第一组形成UNKNOWN并保持组合额度，第二组在account Risk reserve/provider dispatch前被拒；coordinator正常关闭后重开，查询和拒绝请求replay保持原持久结果。
- 独立静态审查仅覆盖精确三源码pin。R3在coordinator Host ready前因合法scope路由被部署validator误拒；R4完成业务场景和正常Host清理后，旧oracle错误假设portfolio先拒绝的group必然有account Risk vector。二者原stdout/result保留，最终只接受修复后的R5结果。
- 该场景证明两个client调用在阻塞provider期间重叠和coordinator串行裁决，不证明同时SQLite事务竞争。未覆盖reservation TTL到期、全部Risk reservation提交后派发前coordinator崩溃恢复、UNKNOWN跨TTL的完整矩阵，不增加ARB02正式PASS；累计24/68。


第145轮（MIG02）：真实本机CURVE v2服务端先以有效v2请求/回复证明端点就绪，再接收由旧 forwarding.OrderCommand/serialize_message 生成的扁平JSON；旧帧无业务回复，业务handler计数相对基线未增加。Root固定节点1passed/exit0/0.81秒，stderr为空；保留一条Windows PyZMQ/Tornado RuntimeWarning。结合CFG05已接受的旧远程配置/环境拒绝及普通direct/backtest运行证据，Root裁定MIG02正式PASS。限制：新节点未运行旧forwarding客户端，未单独验证其超时fallback，也未覆盖ServiceHost或跨机部署；不据此推定MIG01/MIG04或账户/provider验收。无同次运行import-origin记录。详见evidence/mig02-old-wire-20261016/root-adjudication.md。


## 第146轮：RISK02可信FX估值与敞口重启Host证据（2026-10-16）

- SDK/dev `2f9d6a99cc95b0c22188ae2759ff28017d6d2eea`（父 `c1d9d6926f2e1151ef487fff419329d2ca13af8e`）已提交三个风险入口/持久journal/Host测试路径。来源是固定SDK `04707f4b`、六个固定包提交及三路径overlay组成的固定源码候选，不是后来变动的checkout；独立静态review对三pin为GO。
- Root V8固定来源真实ServiceHost/CURVE/SQLite synthetic provider节点1 passed/exit 0/21.49秒；1962个source pin前后不变，正常关闭/join/exit且无fallback。V7 direct canonicalization节点1 passed/5.74秒为既有接受结果，仅引用不重跑。V5/V6 direct的fixture oracle失败及V7 Host的错误logical run注册失败均保留在原目录与有限失败诊断中；Host仅接受V8结果，不合并历史失败。
- Host场景将EUR报价保留为原始报价，以可信EUR/USD事实和非单位合约乘数估值：EUR 20 × 数量2 × multiplier 3 × 1.25 = USD 150；部分成交0.5对应USD 37.5已成交敞口与USD 112.5剩余；重启后同一logical run使用新client sessions并保留已应用敞口/业务身份；过期FX fail closed并保留此前敞口，fresh FX 1.30后取消/重估为USD 39已成交、剩余0。此合成费用为零，不证明非零EUR费用换算。
- 证据等级`LOCAL_SPAWNED_SERVICEHOST_CURVE_SQLITE_SYNTHETIC_PROVIDER_FX_RESTART_NOT_REAL_ACCOUNT`。未覆盖派发前permit/claim TTL到期且provider写数为零，也未覆盖已派发UNKNOWN跨TTL与restart的占用保持；无真实账户/外部venue。RISK02仍部分，正式累计25/68。
- source pins覆盖所列固定源码输入，不证明全部运行时导入均来自该集合；BtApi插件发现仍可能加载环境中已安装的插件。


## 第147轮：批准目标注册表精确授权修复（2026-10-16）

- SDK/dev 父提交 `24e24c760aa1b9428d20e27a05d4ffe57b2a05e8` 上，仅纳入 `bt_api_py/service_registry.py` 的审核授权hunks及对应单元测试；注册表使用accepted-only partial blob，排除checkout中已有的 `_dispatch` 格式化WIP。
- Root固定来源唯一节点 `test_approved_target_write_uses_only_its_exact_application_grant` 1 passed/0.66秒/exit 0，零warning，10个source pin前后相同，stderr为空。独立静态审查对两条精确源码pin为GO。测试覆盖精确approved-target应用授权、伪造actor/delegate、跨账户/selector，以及普通 `orders.submit` 注册和调用拒绝。
- 证据等级 `UNIT_FIXED_SOURCE_NO_HOST`：未启动ServiceHost，未验证AFI HTTP/SDK/Execution端到端、真实Risk/provider/account或并发；不构成AFI07正式通过。正式累计仍25/68。
- QA使用固定最小SDK包初始化shim，只加载真实Registry及列出的Base依赖；这是隔离组件检查，不是正常SDK包初始化或普通发行组合验收。


## 第148轮：Risk组合分析包组件证据归档（2026-10-16）

- Risk/dev `756ffbd42caac1618f286239dedecce278d781d2`（父 `c6fcacda5efb5153d8c3e2be7b17f335f2732a9e`）已独立提交两个路径：`src/bt_api_risk/portfolio_analytics.py` 与 `tests/test_portfolio_analytics.py`。本轮SDK父仓仅归档该gitlink及原始QA/静态审查证据，不改Risk源码；SDK/dev父为 `3ac75d1d7af33074aba8c05a9c0f5428fc962211`。
- 作者R1为14通过/1失败/exit 1，完整保留为诊断；修复后的R2独立运行17/17通过、exit 0、stderr为空，命令、环境、JUnit、stdout、result-index及source pre/post均原样归档。独立静态审查对精确两文件为GO，未运行测试、导入或Host。
- 该证据只覆盖Risk包内cash+spot NAV与Modified Dietz收益率估计组件；不含独立analysis worker、SDK/ServiceHost接线、limits/cancel或完整分析指标。scope为 `AUTHOR_WORKTREE_QA_AND_STATIC_SOURCE_REVIEW_ONLY` / `SOURCE_PACKAGE_COMPONENT_ONLY`，CFG06、AFI04未通过，正式累计仍25/68。


## 第149轮：AFI 已批准目标 HTTP→SDK→Execution 链（2026-10-16）

- AFI/dev `a421354b38740f26531645accd8e13338fadbf4d`（运行前后不变）上，固定 SDK 导出 `D:/temp/afi_iter10_approved_target_sdk_sources_20261016_r6_fixed`（SDK `3ac75d1d` 及当时子包）运行 15 个未提交候选路径：API/权限/ORM/migration、service_read 接线（access/client/deployment/session/worker）、可信 authority、HTTP operations 服务和集成测试。验收后已提交仅该 15 个路径：AFI/dev `b47a68c45ecad74eb7fddd9302af268b9623cde2`（`feat(service-orders): route approved-target submissions to the execution owner`）；README/scripts 6 项修改与 scripts/windows 3 项新增仍原样保留。
- R6 固定来源运行一次失败并保留：`iteration10-approved-target-http-qa-root-r6.json`（`c0a197ef…`），exit 1、`1 failed, 2 warnings in 23.58s`，失败点 `test_service_read_authorized_http_integration.py:6370` `assert len(synthetic_risk_permits) == 1`（实际 2）。诊断确认非产品缺陷：已接受设计在 `_admit` 中先于持久 claim 和审批 consume 预留 Risk permit；stale 审批走 DEFINITIVE_DENIAL，由 `_block_before_dispatch` 释放该 intent 的 permit。Execution journal 佐证释放成功：stale intent 落 `BLOCKED(APPROVAL_POLICY_STALE)` 而非 `REVIEW_REQUIRED`；已派发 intent ACKED 并持有 permit 至 settle。R4/R5 与第147轮前置修复记录继续保留。
- 仅修改测试文件（`f7ca663a…` → `a7c44613…`）：合成 Risk gate 增记 `release(permit_id, reason)`；facts/close 载荷增加 released 列表；断言改为 2 个不同 intent 预留、恰好一次释放 `(permit-<denied-intent>, APPROVAL_POLICY_STALE)`、已派发 intent 的 permit 未释放，并在正常关闭时复核同一账目。无生产源码改动，未重跑已接受节点。
- R7 固定来源运行通过：spec `iteration10-approved-target-http-qa-root-r7.json`（`5a1d07fa…`），runner `iteration10-focused-qa.py`（`8b7f470b…`），命令 `C:/Anaconda3/python.exe D:\bt_api_py\.codex-tmp\iteration10-focused-qa.py <r7 spec>`，输出 `D:/temp/afi_iter10_approved_target_http_root_20261016_r7`。exit 0、`1 passed, 2 warnings in 23.84s`（两条既有 warning：Starlette 422 弃用与 quandl 导入）、stdout sha256 `977f4eb6…`、stderr 为空、2147 个 source pin 前后不变、AFI head/分支不变。
- 已覆盖：策略审批 policy 发布 201、审批目标创建 201；首次提交 200 ACKED 且 provider 仅派发 1 次；同键重放 200 且 intent_id 相同、仍只派发一次；同键异内容 409 `IDEMPOTENCY_CONFLICT`；跨策略版本 stale 409 `APPROVAL_POLICY_STALE`（Execution 桥接拒绝且零 provider 调用）；客户端伪造 owner/actor/intent 字段 422；他主体 403 `SERVICE_READ_ACCESS_DENIED`；撤销后提交 409 `APPROVAL_REVOKED`、过期提交 409 `APPROVAL_EXPIRED`（两者为 HTTP 预留预检查）；3 次服务调用的精确 principal/句柄/账户/策略身份事实、owner 线程；authority 资源恰一次关闭、host 正常关闭零清理失败。真实 AFI lifespan/HTTP/SDK/派生的 Execution ServiceHost 子进程/SQLite journal；合成 Risk 与 provider 叶。
- 证据等级 `SYNTHETIC_HTTP_SDK_EXECUTION_HOST_APPROVED_TARGET_WITH_SYNTHETIC_RISK_AND_PROVIDER`。局限（按交接边界）：非全 AFI07，无批准目标跨进程并发/重启派发证明，无策略单、组撤销处置及“普通操作不改组腿”证据，无真实账户/venue。AFI07 仍部分，正式累计 25/68 不变。证据见 evidence/afi-approved-target-http-20261016/root-adjudication.md。


## 第150轮：RISK02 permit TTL / intent deadline / UNKNOWN 重启 Host 证据（2026-10-16）

- SDK/dev 父提交 `833b101c` 上，仅纳入本轮已验收的三条路径：`bt_api_py/service_risk_order_entry.py`（parse 与 claim 间 deadline 复核 + 未认领 release 容错，`89b2eade…`）、`bt_api_py/service_risk_order_journal.py`（accepted-only partial blob `f10c2e89…`，仅恢复 `RESERVED→ADMISSION_DENIED` 过渡；checkout 中的 DIM01 改动块继续保留不提交）、新增 `tests/unit/test_service_risk_order_ttl_restart_integration.py`（`466e42e8…`）。
- Root 固定来源 spec `iteration10-risk-ttl-root-spec-r5.json`（`ccdf572e…`，2094 pins，cwd 固定候选 `D:/temp/it10riskttl-candidate-r6`），runner `iteration10-focused-qa.py`，输出 `D:/temp/it10riskttl-root-20261016-r5`：exit 0、`1 passed in 20.26s`、stdout sha256 `f677cd5a…`、stderr 为空、2094 个 source pin 前后不变，正常关闭且无 fallback 清理。
- 场景1（claim 前 permit TTL 到期）：permit 时钟第 9 次读取时 LIVE_GROSS 终检过期并清扫，`ADMISSION_DENIED`(PERMIT_NOT_ACTIVE) 恰一次，`gate.release` 以 `PERMIT_NOT_ACTIVE` 证明 permit 未激活且未认领，零 provider 写、零敞口增额。场景2（parse 与 claim 间 intent deadline 到期）：持久 deadline 源为 `canonical_payload`（provider wire payload 不携带 deadline，`OrderRequest.from_dict` 派发重建不受影响），第二次时钟读到期即 `DEADLINE_EXPIRED` 拒绝，无 claim/dispatch。场景3（provider 已写但返回不确定）：UNKNOWN + USD150 冻结保持，TTL 过期后重启仍 UNKNOWN、不重派。
- 诊断链保留：r1–r4 依次暴露 fixture 精确类型判定、fixture poll 默认永阻塞、journal 缺 `RESERVED→ADMISSION_DENIED` 过渡（HEAD 潜在缺陷：reserve 后任何拒绝都会令 handler 崩溃并对外呈现 UNKNOWN）、deadline 误读 `order_request` 恒为空；逐一修复后仅接受 r5。r1–r4 输出目录原样保留，不覆盖、不重复原样重试。
- 证据等级 `LOCAL_SPAWNED_SERVICEHOST_CURVE_SQLITE_SYNTHETIC_PROVIDER_PERMIT_TTL_INTENT_DEADLINE_UNKNOWN_RESTART_NOT_REAL_ACCOUNT`：合成 provider、非真实账户/venue，真实账户链仍未验收。RISK02 仍部分，正式累计 25/68 不变。证据见 evidence/risk-order-ttl-restart-20261016-r150/root-adjudication.md。


## 第151轮：AFI 已批准目标跨进程并发与重启持久性（2026-10-16）

- AFI/dev 基线 `b47a68c4`（第149轮提交后的15路径）上，R7 固定来源单节点 spec 扩展为 R8 双节点（`iteration10-approved-target-http-qa-root-r8.json`，`f054da8c…`）：新增 `test_approved_target_operation_is_durable_across_concurrent_processes_and_restart`，测试文件 pin `a7c44613…`→`282d1307…`，repository pin 更新为 `b47a68c4`；重建脚本（随证据归档）证明 R8 = R7 + name/nodes/output/repositories/测试pin 五处改动且字节等同。
- 固定来源运行 `D:/temp/afi_iter10_approved_target_http_root_20261016_r8`：exit 0、`2 passed, 2 warnings in 47.96s`（两条既有 warning：quandl 导入弃用、Starlette 422 常量弃用；节点1 20.10s、节点2 26.91s）、stdout sha256 `6338ff5e…`、stderr 为空、2147 个 source pin 前后不变、AFI head/分支不变。
- 跨进程节点覆盖：仅同步两个真实 HTTP 请求起点（AFI 预留、SQL 事务、SDK 派发均为真实执行），两个独立 app 进程（PID 各不相同且非测试进程）同键提交各得 200、同一 intent_id、均 ACKED；恰一行 operation（approved_strategy_target），含 owner/principal/actor/delegate 身份引用、request_sha256、selector/scope/account/strategy 引用及 approval_ref/target_sha256；已批准目标 intent 恰预留一个合成 Risk permit，重放提交由持久记录服务、无第二次准入或 provider 调用；同键异内容 409（HTTP_409）且操作行不变；重启代（新 PID）同键提交仍 200 且操作行不变；两进程回收 exit 0、Host 正常关闭。
- 验收后仅提交测试文件到 AFI/dev：`34f59117`（父 `b47a68c4`，`test(service-orders): verify approved-target durability across concurrent processes and restart`），提交 blob 与 spec pin 字节等同（`282d1307…`）；README/scripts 6 项修改与 scripts/windows 新增继续保留。SDK 父仓本轮仅归档证据，无源码改动、无 gitlink 更新。
- 证据等级 `SYNTHETIC_HTTP_SDK_EXECUTION_HOST_APPROVED_TARGET_WITH_SYNTHETIC_RISK_AND_PROVIDER`：真实 AFI lifespan/HTTP、派生 Execution ServiceHost 子进程、SQLite journal；合成 Risk 与 provider 叶。仍缺策略单、组撤销处置与“普通操作不改组腿”证据，AFI07 仍部分，正式累计 25/68 不变。证据见 evidence/afi-approved-target-cross-process-20261016/root-adjudication.md。


## 第152轮：ARB02 组合预算过期未认领释放与崩溃后 UNKNOWN 保持（2026-10-16）

- Execution/dev 精确两路径提交 `dc8bd7a`（父 `12372d82`，`feat(group): reconcile expired unclaimed reservations before dispatch`）：`src/bt_api_execution/group_coordinator.py`（过期未认领预留的恢复/派发前拒绝与仅在证明精确向量后的安全释放，`61b8508d…`，+89/-5）与 `tests/test_group_coordinator.py`（focused tests，`fd7df6bc…`，+89）；提交 blob 与验收 pin 字节等同。SDK 父提交仅纳入五个已验收工作区路径并更新该 gitlink。
- SDK 五路径（accepted bytes）：`bt_api_py/service_group_reservations.py`（`675a54b7…`）、`bt_api_py/service_execution_group.py`（`5606785c…`）、`tests/unit/test_service_group_reservations.py`（`ebbdad38…`）、`tests/unit/test_service_execution_group.py`（`24010a49…`）、`tests/integration/test_arb02_group_budget_service.py`（`b24e4f99…`）。其余 WIP（service_components/host/registry/journal、DIM01 文件等）保留不提交。
- Root 固定来源 R11 spec（`iteration10-arb02-group-budget-fixed-source-r11`，`a749673a…`；overlay manifest `fa6e9bc1…`，7 路径候选 pin 与 live pin 双列；候选 = 归档 c1d9d69 系 SDK 导出 + 7 overlay）唯一节点 `test_expired_unclaimed_release_and_dispatched_unknown_hold_across_coordinator_crash`：输出 `D:/temp/iteration10-arb02-group-budget-fixed-source-r11-qa-output` exit 0、`1 passed in 40.32s`、stdout sha256 `b6f1a594…`、stderr 为空、1808 source pin 前后不变、五个 live 仓库 head（SDK `833b101c`、base `b4aabd1e`、execution `12372d82`、risk `756ffbd4`、transport `a397fdb4`）运行前后不变。
- 诊断链保留：R10（exit 1、`1 failed in 82.31s`）与 R10-r2（exit 1、`1 failed in 42.21s`，`expired_started[1:3] == ("submit", _GROUP_EXPIRED_UNCLAIMED)` 断言失败）原结果目录原样保留并随证据归档；根因判定为 fixture 终态断言与现场语义冲突——deadline-crossed 已派发腿在 fill 观测前失去 5s writer lease，生产 proof guard 正确将该尝试记为 UNKNOWN（GROUP_OWNER_FENCE_UNAVAILABLE）且不消耗已布防的 incomplete-fills fault（fault 保持 pending、provider 计数 1 写 0/0 查询）；仅测试侧对齐断言（`c57bc8bc…`→`b24e4f99…`，生产代码零改动）后 R11 通过。
- 覆盖：过期未认领预留的释放/拒绝与协调器崩溃后已派发 UNKNOWN 保持（TTL/崩溃/UNKNOWN 合成场景）。被排除节点 `test_two_strategy_clients_compete_for_one_portfolio_hold_across_reopen` 函数体与已提交 `50a393e7` 逐字相同（仅其后新函数的装饰器使文件字节变化），保持第144轮 R5 正式验收结论，本轮不重复运行。
- 证据等级 `FIXED_SOURCE_THREE_SERVICEHOST_CURVE_SYNTHETIC_PROVIDER_TTL_CRASH_UNKNOWN_SCENARIO_ONLY`：本机三 ServiceHost/CURVE + 合成 provider，非真实账户。ARB02 仍部分，正式累计 25/68 不变。证据见 evidence/arb02-group-budget-recovery-20261016/root-adjudication.md。


## 第153轮：SCN01 99 案例源码合同映射（设计阶段只读清点，2026-10-16）

- 新增 `docs/迭代计划/迭代10-可选组件与可配置通信/SCN01-99案例源码合同映射-20261016.md`（28640 字节，sha256 `d3f9d4675fc846ce481f8aac0a264ad4aa8c1f066b617a1ed13e37eeac8a1153`）：99 个 provider 客户端源文件（binance 33、okx 33、simnow 33，无缺口）逐文件登记 AST 提取的动作/权限活动、RISK 分级（binance 7 DANGEROUS/13 WRITE/13 READ；simnow EM03=READ）、设计阶段权限类别（observe/trade_write/session_control/account_admin）与合同行号修正（Binance `dualSidePosition` 行 74、`ctp_client.py:237–271` 登录、OKX `okx_client.py:195`、SimNow OrderRef `ctp_client.py:478–480`、EM01 disarm 行 95、EM02 pause/resume 128/160），附录 A/B 收录行动清单与 unified 9 目录说明。
- 只读清点：未运行任何 provider 调用、未使用任何账户、无新增可执行代码、未改动任何 SDK/测试源码。独立抽检复核与文档记载一致（33/33/33 计数、Binance 行 74、SimNow EM03 RISK=READ、binance 7/13/13）。
- `config.yaml` 审计与 unified 9 目录迁移属本轮范围之外，随后续轮次推进；SCN01/SCN02 状态由“未开始”更新为“部分/设计核对”。正式累计 25/68 不变。
- 证据见 evidence/scn01-99-case-contract-mapping-20261016/root-adjudication.md。


## 第154轮：CFG06 policy_catalog 控制面与 analytics/ml extras 边界（2026-10-16）

- 范围：SDK 服务授权形状整理（`bt_api_py/service_host.py` 合并 operations/write_operations 错配判定并保留 `service.market_source`/`service.order_query`/`service.order_entry` 三处例外）、`bt_api_py/service_components.py` 新增内置 `("risk","policy_catalog")` 角色（公开端口 `service.risk_policy` 五操作 `policy.read/draft/approve/publish/receipt`、写操作三分、`catalog` 资源类型校验）、`service_registry.py` 纯格式整理；risk 子仓提交不可变政策目录控制面（`PolicyCatalogStore`/`PolicyCatalogService`/`ConfirmedPolicyStore`）与 extras 拆分（numpy→[analytics]、scikit-learn→[ml]、缺 extra 时 `RiskManager`/`AnomalyDetector`/`RiskEnsembleModel` 显式 ImportError）。新增 `tests/unit/test_service_policy_catalog_control_plane.py`（5 项）与 `tests/unit/test_service_components_group_runtime_bundle.py`（1 项）。
- 固定来源验收：spec `.codex-tmp/iteration10-cfg06-root-spec-r1.json`（sha256 `177941af1abed9e042fcf45929307fceabfc260f80dda979b8c11aa10a3dec8f`，170 pins），输出 `D:/temp/it10cfg06-root-20261016-r1`：runner/pytest exit 0、6 passed/1 warning（5.05s）、junit 6/0/0/0、sources/heads 前后不变（parent e2f51910/risk 756ffbd4/base b4aabd1e/exec dc8bd7a3/zmq a397fdb4）、stdout sha256 `ec6a3e5023e76d23432e7ee76faaf11d8db609f41da83657bdca9d645aa0399c`。
- 行为证据：真实 ZMQ+CURVE ServiceHost 上 application-client manager 21 步线内 draft/reissue/publish-before-approve/approve/publish/read/缺失/未版本化/错类型/未发布读取等拒绝码；service 出站 client 仅注册 `policy.read`（publish 本地 `AMBIGUOUS_OR_MISSING_ROUTE`、请求 publish 的绑定 `SCOPE_DENIED`）；catalog host 关闭后 `ConfirmedPolicyStore` 仍按已确认版本解析、新注册不可达；子进程 meta_path 拦截 numpy/scipy/sklearn/pandas 后 base 风险包完成完整政策流、三个分析/ML 名称显式 ImportError 标注 extra；`group_policy` 角色仍 internal-only（`NO_SUPPORTED_PUBLIC_PORTS`、未触资源）如实记录。
- 独立静态复核：SDK 5 文件（`.codex-tmp/cfg06-review-status.md`）与 risk 3 文件（`.codex-tmp/cfg06-risk-review-status.md`）均 GO。
- 提交：risk `feat(risk): serve immutable policy catalog control plane and gate analytics extras`（`a1485ee2`）；父仓 5 文件 + risk gitlink + 文档。CFG06 仍为部分/本机进程：group_policy/portfolio_analytics 真实注册与完整 analytics worker 待后续轮次；正式累计 25/68。
- 证据见 evidence/cfg06-policy-catalog-control-plane-20261016/root-adjudication.md。


## 第155轮：Backtrader managed-paper V2 恢复日记账/回调投影交付与 CFG06 组合复跑归档（2026-10-16）

- 范围：Backtrader 子仓（D:/source_code/backtrader，dev）提交 `b002afa2`（父 48bde5d76，"Add restart-safe recovery quote journal and session callback projection for managed paper V2"，10 文件 +4115/−42）：恢复报价绑定（feeds/service_recovery_quotes.py，bar 失配 fail-closed）、recovery journal schema v3（未知版本/事件版本变更拒绝、单消费租约 token 门控全部 V2 写入）、策略先持久 Trade checkpoint 再回调、ACK 仅回调成功后；崩溃后重放走 checkpoint 水合而非重执行；feed/session/adapter 全部 opt-in（缺省沿用 v1/legacy 行为）。
- 验收：作者 r5 12passed/exit0、r6 238项7fail/1err（修复前保留）、r7 `--noconftest` 602passed/18deselected/exit0 且 stderr 空（18 deselect 与父 48bde5d76 基线 14fail+4err 一一对应）、r8 conftest 4passed/exit0；r7 十文件 source pins 与提交 blob 一致；排除项（ctp 三文件、`0`、docs/_internal）未入提交。独立静态复核 GO（.codex-tmp/btv2-review-status.md）：blob 10/10、fail-closed 设计核对、deselect 1:1、诚实性核对，无授权/安全洞；非阻塞项（回调半程无专测、3 个 deselect 节点涉改且均已父级失败、quote mixin 内存态、SQLite 无剪枝）如实记录。
- CFG06 组合复跑：第154轮提交组合候选树（99bec079 + 20 子模块 pins，risk a1485ee，DIM01 WIP 邻居替换为提交字节）独立复跑 6passed/exit0；170 pins 中 134 精确、30 仅 eol（blob 字节一致）、4 为 DIM01 WIP 邻居（替换后仍 6/6），子进程边界节点未加载主工作区 bt_api_py 字节；归档 evidence/cfg06-policy-catalog-control-plane-20261016/combo-verification.md。
- 提交：父仓本提交仅文档与证据归档（Backtrader 非本仓子模块，其 dev 提交 b002afa2 独立记录）；正式 PASS 仍 25/68，BT02 仍部分（本证据为组件/本机 SQLite 级，真实 fresh-process 杀进程/重启恢复链另轮验收）。
- 证据见 evidence/bt-v2-recovery-journal-20261016/root-adjudication.md。


## 第156轮：portfolio_analytics 真实角色切片交付（CFG06a，2026-10-16）

- 范围：risk 子仓新增 `src/bt_api_risk/service_analytics.py`（durable SQLite 分析任务服务：固定四操作、公开端口 `service.risk_analysis`、资源键 `analysis`、存储键=每 principal 的 run-free portfolio scope 规范 JSON、上传幂等/摘要冲突 fail-closed、提交幂等与 `TASK_REF_CONFLICT`、每 scope pending+running 配额 `TASK_QUOTA_EXCEEDED`、cancel 幂等/`TASK_TERMINAL`、pending TTL 到期清扫、重开时将 interrupted running 标记 `TASK_INTERRUPTED`、owner 线程 maintain 执行器按 store-clock 每秒至多一次状态推进、全部错误码为常量字面量无调用者回显）；SDK `bt_api_py/service_components.py` +87/-0 恰四个 hunk（builtin 表项 `("risk","portfolio_analytics")` 含 validator_module_name、`build_component` 的 `ANALYSIS_STORE_INVALID` 精确类型与 profile/模式/配额/字节上限一致性、`SUPPORTED_OPERATIONS` 恒等校验 `BUILTIN_COMPONENT_INVALID`、owner-thread maintain wiring 可调用性检查）；新增真实 ZMQ+CURVE 控制面测试 `tests/unit/test_service_portfolio_analytics_control_plane.py`（6 项、45 项线内断言）。
- 固定来源验收：spec `.codex-tmp/iteration10-cfg06a-root-spec-r1.json`（172 pins = 第154轮 170 项静态导入闭包按当前工作区逐项重哈希【其中 11 项因 DIM01/ARB03/MIG01-R1/CFG06a 在建工作区状态与第154轮 pin 不同，照实固定】+ 新增 2 文件），输出 `D:/temp/it10cfg06a-qa-20261016-r1`：runner/pytest exit 0、12 passed（analytics 6 + 既有 CFG06 回归 6）、junit 12/0/0/0、sources/heads 前后不变（parent 4e46ff01、risk a1485ee2[QA 时点]、base b4aabd1e、exec dc8bd7a3、zmq a397fdb4）、stderr 空、stdout sha256 `a67cb65ea7c214a8aea953ffa6700334255b1e3f4447409597ab91abb44a5422`。
- 行为证据：线内负例覆盖两层拒绝（SDK parse 门 `MISSING_FIELD`/`INVALID_VALUE`/`UNKNOWN_FIELD`/`VERSIONED_REFERENCE_REQUIRED`/`DUPLICATE_VALUE`/`PORT_ROLE_MISMATCH` 与 risk 校验层 `COMPONENT_OPTIONS_INVALID`，均零资源提供者调用）；reader 写请求本地 `AMBIGUOUS_OR_MISSING_ROUTE`、外部绑定 `SCOPE_DENIED`、跨 scope 读 `TASK_NOT_FOUND`；相同输入两个 task ref 复现字节一致结果载荷；跨 scope 提交/task 隔离；base 安装（子进程 meta_path 屏蔽 numpy/sklearn/pandas/scipy）服务全部四操作。
- 独立静态复核 GO（`.codex-tmp/cfg06a-review-status.md`）：三文件 hash/blob/size 全对、`service_components.py` 恰四 hunk 无越界、store 语义/授权/双拒绝层/45 项断言逐条核对、无调用者回显、无重型依赖进口；复核者独立复跑 6+6 passed；非阻塞观察（`INPUT_ALREADY_COMPLETE` 等路径未直接测试、单进程 store）如实记录。
- 提交：risk `feat(risk): add durable portfolio analytics task service for the analytics role`（`131175a4`，父 a1485ee2；DIM01 WIP 邻居 admission.py/exposure.py 原样保留）；父仓本提交 2 文件（service_components.py、新测试）+ risk gitlink + 文档与证据归档。
- 缺口：AFI04 跨进程 analytics 服务运行仍缺；group_policy 角色（CFG06b 工作线在途）仍缺；单进程 store 无 OS 文件锁（与单 owner 线程执行器一致）。CFG06 仍部分，正式 PASS 25/68。
- 证据见 evidence/cfg06a-analytics-role-slice-20261016/root-adjudication.md。


## 第157轮：MIG01-R1 旧转发退役入口点 fail-closed 交付（2026-10-16）

- 范围（additive gating only，7 文件）：`bt_api_py/_contracts/errors.py` 新增 `LegacyForwardingRetiredError(BtApiContractError)`（attrs `target`/`detail`）；`_contracts/__init__.py` re-export；`bt_api_py/__init__.py` 新增 `_RETIRED_FORWARDING_EXPORTS`（13 名）且 `GatewayClient` 经 `__getattr__` 抛错（`__all__` 仍可枚举，star-import 同样显式抛错而非静默）；`bt_api_py/bt_api.py` `_build_backend` 的 ZMQ 分支在任何 socket/线程前抛 `LegacyForwardingRetiredError("transport_mode=ZMQ")`（`ForwardingConfig` 保留为拒绝输入）；3 个线内测试更新（test_bt_api_quality、test_direct_zmq_bt_api_contract、test_normalized_public_api 的 ZMQ 初始化改断言拒绝与无 create_feed 回退）。
- 固定来源验收：r3 重跑（commit-time tip，per 独立复核 finding #2）：spec `.codex-tmp/iteration10-mig01-r1-scan-spec-r3.json`（7 pins 重哈希不变），输出 `D:/temp/it10mig01-r1-20261016-r3`：exit 0、83 passed、junit 83/0/0/0、sources/heads 前后不变（parent 5ff3da11、base b4aabd1e）、stderr 空、stdout sha256 `ff80a781b13c20daf78eb7a306e930862ef33568b68e16b2e88e12fb325022a2`；r2（99bec079 时点、stdout 93af382b…）为被复核原始运行、r1 工件一并归档（r1↔r2 spec pin 差恰 `tests/test_bt_api_quality.py` 一文件，lint-only rework 声明由工件佐证，复核 finding #3）。
- 行为探针（fresh interpreter）：顶层 `ForwardingClient` → `LegacyForwardingRetiredError`（target=ForwardingClient）；`BtApi(transport_mode="zmq")` → 在任何副作用前抛错、线程数稳定、`bt_api_py.forwarding`/`bt_api_py.gateway`/`zmq` 均未加载；direct 模式正常构造。
- 残差清单（照实登记，MIG01 未完成）：168 处引用 / 36 文件（forwarding 59、py.gateway shim 6、base gateway 12、GatewayRuntimeRegistrar 9、ZmqBtApiBackend 33、zmq mode 49；唯一行 155）；旧目录仍在盘（py 文件 14+4+16）；wheel 0.15.4 仍含 19 条 legacy 条目 / 145；egg-info 90 行；CI 3 文件命中。
- 独立静态复核 GO（`.codex-tmp/mig01-r1-review-status.md`，scoped 于 R1）：工件完整性/失败先于副作用/错误类稳定导出/星导入显式失败/线内测试/无安全洞；4 条非阻塞 findings 已逐条处置（矩阵节点数修正为 34–35、errors.py 增行修正为 19、head 锚点以 r3 重跑命名真实 parent、r1 工件留存佐证 rework、scan 排除 gitignored build/ 已披露）。
- 破断矩阵（未 hack）：test_operation_dispatch 14–15、test_environment_guard 3、test_execution_session 3、test_gateway_runtime_unknown_execution 14 —— 均正依赖已退役路径，归属 MIG01 终局 re-home 轮，明细见 author-status.md。
- 缺口：旧目录与依赖闭包整体退役未做（MIG01 不新增 PASS，正式 25/68）；R2 增量（4 模块 re-home + D2 base-runtime slice）为下一步。
- 证据见 evidence/mig01-r1-retired-entrypoints-20261016/root-adjudication.md。


## 第158轮：ARB01 共享账户夹具有效化交付（2026-10-16）

- 范围（test-only，1 文件）：`tests/unit/test_service_account_integration.py` 共享账户变体夹具参数化重构（blob 088f091b→b6136b32，+150/−22，全部为参数替换/测试体抽取，无弱化断言；仅移除 2 行 assert 且已参数化恢复于 927-928）；共享测试体 `_exercise_shared_account_variant`（809-1077）保留基线断言并新增：同挂载歧义路由 `AMBIGUOUS_OR_MISSING_ROUTE` 拒绝（959-962）、每账户键恰一个活跃 provider upstream（1005-1014）、close 后 connect/close 平衡（1073）、跨交易所与同 venue 共享合约身份维度（938-954）。3 个验收节点（1080/1092/1107）覆盖默认双账户共享、跨交易所、同 venue 同品种；无 skip/xfail/monkeypatch。
- 固定来源验收 r3（commit-time tip）：spec `.codex-tmp/it10arb01-20261016-r3-qa/focused-qa.json`（37 pins 不变），输出 `D:/temp/it10arb01-20261016-r3`：runner/pytest exit 0、3 passed、junit 3/0/0/0、sources/heads 前后不变（parent 46697739、base b4aabd1e、gateway 59b164ab、transport a397fdb4）、stdout sha256 `aa9329cd2bb278e9905328ad6b11e0427d67dbfb70a30ed841068e2e79ad62fb`；r2（parent 5ff3da11 时点、stdout d1c68d9a…）为被复核原始运行、工件完整性复核通过（37 pins 全对、junit 3/0/0/0）。
- 独立静态复核 GO（`.codex-tmp/arb01-review-status.md`）：diff 逐块核对（22 处删除全为参数化替换/抽取，新增断言净 +12）、r2/r3 工件与 pin 复核、无隐藏空白修改；非阻塞观察："行情订阅不因账户数重复" 在本文件以会话级 upstream 非重复（每账户键一个活跃 session + 精确 provider 读计数）体现而非字面订阅断言。
- ARB01 条款覆盖（本机进程级）：一策略双账户登记 + 另一策略共享其一、跨交易所与同 venue 同品种、账户/组越权与歧义路由拒绝、逐账户调用/状态计数、每账户 upstream 不重复。
- 证据见 evidence/arb01-shared-account-fixtures-20261016/root-adjudication.md。


## 第159轮：AFI07 剩余子条款收口与正式通过（2026-10-16）

- 范围（AFI 测试仓提交 + 父仓证据归档）：`D:/source_code/ai-for-investor` 仅提交测试文件 `src/backend/tests/test_service_read_authorized_http_integration.py` → AFI/dev `794eab0c`（父 `34f59117`，`test(service-orders): cover AFI07 shared-owner, revocation and group-leg remainder`，+1627/−0 纯追加块 7054-8680，blob `6612a7bb…` 与 QA 读取字节一致）；README.md/scripts 6 项修改与 scripts/windows 3 项新增继续原样保留。
- 固定来源验收 r9（5 节点）：spec `.codex-tmp/iteration10-approved-target-http-qa-root-r9.json`（authored 归档于本证据目录 qa/r9/，输出 spec 与 authored 字节等同），输出 `D:/temp/afi_iter10_approved_target_http_root_20261016_r9`：RUNNER_EXIT=0、`5 passed, 2 warnings in 68.33s`（两条既有 warning）、junit 5/0/0/0、2147 pins 前后不变、AFI head `34f59117` 运行前后不变、stderr 空、stdout sha256 `27501f42…`。节点：r8 双节点回归 + 新增 `test_afi07_strategy_and_http_orders_share_one_owner_with_exactly_once_dispatch`（同一 owner 线程/journal 上 HTTP 手工单 + HTTP 已批准目标 + 直连 SDK 策略单，恰 3 次授权派发、plain/unauthorized 为空、重放同 intent_id/provider_order_id、身份行含 operation_key sha256→intent_id）、`test_afi07_ordinary_operations_do_not_modify_group_legs`（普通 cancel/submit 对组腿保留 id 拒绝 INVALID_REQUEST 且组腿 id 不入 journal；组快照 canonical-JSON 跨操作字节一致）、`test_afi07_accepted_group_revocation_disposition_is_durable`（不安全释放拒绝 ContractValidationError；安全相位 → REJECTED_BEFORE_DISPATCH + budget RELEASED + 持久复开后不变）。
- 独立复核 GO（`.codex-tmp/afi07-remainder-review-status.md`）：diff 纯追加无弱化（1627/0、单一 hunk、无 skip/xfail/monkeypatch 越过 owner/host/journal 路径）、r9 工件 10/10 字节等同、authored-spec==输出 spec（`b5e699fc…`）、2147/2147 pin 重哈希全对、runner 与 r8 字节等同；并独立复跑冻结 spec（仅 output 改名 r10fresh）：`5 passed in 100.19s`、junit 5/0/0/0、stdout `bb0e849c…`、sources/heads 不变。
- 条款映射（正式迭代计划.md:799 两栏逐片段）：手工单/策略单/已批准目标经同一 owner（r9 节点3 + r124/r129/r149/r151）；两个 AFI worker 并发/重启重放同操作只派发一次与同键异内容拒绝（r129 双 HTTP 进程/磁盘 DB、r151 双 app 进程 + 重启代、r9 冲突断言）；审批摘要/版本/过期/撤销校验（r149 全链 409/422/403）；已接受组撤销有处置结果（r9 节点5）；证据栏 真实 HTTP/SDK/订单 journal + 合成 provider 计数（r9 恰 3 次）、持久操作键→intent_id 映射/归属/最终事实、普通操作不修改组腿（r9 节点3/4）。逐片段均有证据 → **AFI07 正式通过，累计 26/68**。
- 披露（不阻塞裁定）：(1) 组撤销节点在 SqliteOrderGroupStore/coordinator 真实机具上直接执行（无 HTTP→SDK→host 路由），条款要求的“有处置结果”由持久处置满足；(2) 双 worker 并发已在手工单与已批准目标两类真实复现，策略单类共用同一 owner/journal/操作键机具（节点3 同 owner 恰一次计数），未单独复现双 worker 策略单并发；(3) 两腿同账户组 reservation 按 account_ref 去重呈单相位（测试内注明）。
- 迁移说明：r9 工件自工作区暂存位置 `evidence/afi-approved-target-cross-process-20261016/qa/r9/` 并入本目录（字节不变）；该目录 r8 与第151轮记录原样保留。
- 证据见 evidence/afi07-remainder-owner-group-legs-20261016/root-adjudication.md。


## 第160轮：DIM01 trade_id 域隔离经 Risk owner 全链贯通并正式通过（2026-10-16）

- 范围（SDK 5 文件 + risk 子仓 2 文件）：`bt_api_py/service_risk_order_entry.py`（fail-closed trade-domain 校验；identity-conflict latch 冻结并存；`average_price` 仅投影 journal 已验证 ACK）、`bt_api_py/service_risk_order_journal.py`（两条验证路径强化 reference average_price 等值、terminal ACK 无价拒绝、trade-identity 声明匹配）、`tests/unit/test_service_order_entry_components.py`（期望 op 集对齐生产既有 ops）、`tests/unit/test_service_risk_only_order_integration.py`（新增 2 节点）、新增 `tests/integration/test_dim01_identity_isolation_service.py`（1828 行单节点）；risk `core/admission.py`（`risk_freezes.blocking` + `latch_dispatch_identity_conflict`）、`core/exposure.py`（可选 `trade_id_domain_ref`/`trade_id_scope`）；risk `service_component.py` 其它工作线 WIP 原样保留未提交。
- 固定来源验收 r2a（集成节点）spec `.codex-tmp/it10dim01-p3-r2a-spec.json` / r2b（owned units）spec `.codex-tmp/it10dim01-p3-r2b-spec.json`（同 7 pins）：r2a `D:/temp/it10dim01-p3-20261016-r2a` exit 0、1 passed、junit 1/0/0/0、stdout `2903f1ec…`；r2b `D:/temp/it10dim01-p3-20261016-r2b` exit 0、20 passed（组件 6 + unit-integration 14）、junit 20/0/0/0、stdout `5c5046d1…`；两运行 sources/heads 前后不变（父 46697739）、stderr 空。
- 独立复核 GO（`.codex-tmp/dim01-p2-review-status.md`）：digest 修复与生产 927-935/3455-3464 字节语义等同、无生产弱化（净强化：fail-closed 校验、ACK 拒无价、声明匹配）、测试真实断言无 skip；fresh-basetemp 全文件运行复现 6 failed/14 passed（恰为命名 6 restart 节点），判定 registry run_id 释放/接管语义缺口（`service_registry.py` 1940-1948/2050-2057、`service_runtime.py` 332），属不同归属域、排除有据（后续工作线 #32）。
- 条款映射（正式迭代计划.md:773）：同策略多品种（strategy-a 同账户 spot BTC/ETH + perp BTC）、同账户多策略（strategy-a/b 同账户 spot）、同 venue 双账户（fixture venue account-a/b）、同名不同产品/环境合约（BTC-USD spot v1 vs perp v7，含别名与轮换 profile 不开口新身份空间）＋订单/成交号域内复用 UNKNOWN+latch 不双记、域间同名合法；完整 SDK/owner 存储及路由（真实 ZMQ+CURVE ServiceHost/ServiceClientRuntime + owner SQLite）；逐维正反例与去重结果（providers 恰 1 行、trade_ids `('trade-1',)`）。→ **DIM01 正式通过，累计 27/68**。
- 提交：risk `feat(risk): latch trade-identity conflicts and bind optional trade-id domains`（089b5efd，父 131175a4）；父仓本提交 = 5 文件 + risk gitlink + 证据目录与进度/汇总文档。
- 保留与披露：6 个 restart 节点为既有已提交节点（HEAD 已含），因 registry 缺口继续失败；`tests/unit/test_service_risk_order_journal_decimal_match.py`（未 pin）保留未提交。
- 证据见 evidence/dim01-trade-id-domain-isolation-20261016/root-adjudication.md。


## 第161轮：MIG04 发行组合安装与正常入口兼容性正式通过（2026-10-16）

- 范围（docs-only 父仓提交，无源码/子仓改动）：归档固定来源作者包（`D:/temp/it10mig04-r3-20261016-r1`：report.md + logs/46 件 + run/ 脚本与配置 + registry SQLite）与 commit-time 补充验证（`-supplement/`），并回填汇总表头累计（此前停留在 25/68）。
- 组合与 pins：SDK `46697739`（较上轮 +3）、risk `131175a4`（+1）、base/transport/gateway/execution/monitor/binance/backtrader/AFI 8 仓不变；10/10 tar 哈希记录（01b；8 个不变仓与 r2 字节相同），commit-time 对全部 10 pins 重归档，与 01b 逐字节一致（supplement/archive-repro.txt，git 2.42.0；闭合 01-archive.log 空文件缺口）。
- 构建/安装：10/10 wheel exit 0（02b sha256）；certlib 无打包配置（02c 原始 pip 报错照实归档）→ 以 archive 导入级覆盖（披露 N2）；4 个全新 venv wheelhouse-only 安装 exit 0，pip check 4/4 `No broken requirements found.`。
- 运行验证：策略 venv 四包+zmq `ModuleNotFoundError`（普通路径无四包/无 ZMQ）且两配置 CLI exit 0；service venv 真实 gateway `market_hub` 单组件 start→close、无 cleanup 失败（仅既有 PyZMQ Proactor warning）；extras venv ml `ImportError` 点名 'ml'、模拟 numpy 缺席下 analytics 点名 'analytics'、base 路径无 numpy/sklearn/scipy/joblib；consumers venv `backtrader` 1.4.0、binance entry point、certlib archive 导入、AFI `app`——commit-time 净 cwd 复核 4 模块全部 site-packages 来源（supplement/45b，修正原 45 记录 cwd 遮蔽）。
- 独立评审 GO（`.codex-tmp/mig04-r3-review-status.md`，sha256 `b3652fc2…`，归档于本目录 independent-review.md）：183 行——30/30 哈希复核（10 tar + 10 wheel + 6 脚本，含与 r2 的逐字节对照与 wheel METADATA 交叉验证）、退出码/JSON/冻结逐项核对、10 项溯源抽检、SDK/risk/AFI pins 祖先验证、stray-tar 事故残留扫描无污染；GO 条件为 §8 残差披露清单与 certlib 严格读法例外明示——两者均已落入本裁定，D1/D2 由 commit-time 补充直接关闭。
- 条款映射（正式迭代计划.md MIG04 两栏）：指定组合可安装（10 wheel+4 venv+pip check）、代码版本（pins/冻结解析）、schema/wire（配置 v1/v2 解析 + CURVE/WireIdentity 经 wheel 装载的 ServiceHost 真实启停）、extras 明确拒绝（ml live / analytics 模拟缺席）、状态库格式（ServiceHost 经 wheel 创建/使用 registry SQLite 正常关闭）、干净安装+入口跨仓集成（CLI/插件 EP/backtrader/AFI）、不用 submodule 源码导入（全部 site-packages 来源）、普通路径无四包/无 ZMQ——逐片段满足 → **MIG04 正式通过，累计 28/68**。
- 披露（不阻塞裁定）：N1 analytics extra 非 pip 可达（base core 依赖 numpy）；N2 certlib 无发行物（import 级）；N3 每 venv freeze 为事实 lockfile；N4 live dev heads 会移动（依赖 pin 纪律）；N5 wheel 字节不可复现（zip 时间戳；tar 哈希证源、wheel 哈希证构建）；schema/wire 为 smoke 范围（合成 provider、零客户端流量）；组合 provider 仅 binance wheel（ctp 明确不在组合内、树中无 simnow）。
- 证据见 evidence/mig04-release-combo-20261016/root-adjudication.md。


## 第162轮：SCN02 R1–R4 证据归档（unified 9 目录说明 + 零 I/O 回放扫 + SimNow 零写观察，2026-10-16）

- 范围（docs-only，无源码变更）：归档 SCN02 R1（9 目录读写能力说明 `SCN02-9目录读写能力说明-20261016.md`）、R2（零 I/O 回放/dry-sweep：9 目录逐一 dry/replay/拒绝探针，全部 exit 0 且自报 network 0 / order_write 0）与 R3/R4（SimNow 零写观察：013_1/013_2/013_3/014_1 首获 repo-wide `LIVE_OBSERVE_PASS`（exit 0，零仓位/零委托/零成交，write_health armed=false）；015 `OBSERVATION_PASS`（ticks 231、reject TRUSTED_NOW_INVALID 231、HFT 仍 FAIL/NOT_ADMITTED）；014_2 确定性失败 `ValueError: exchange must be an exact non-empty string`（2/2 复现、feature_minutes 0、order_write 0）如实归档，修复工作线另行推进）的原始证据：SUMMARY、逐目录 cmd-run/exitcode/stdout/stderr/key-facts、replay-evidence 报告、run-evidence、git 基线。
- 归档裁剪（如实记录）：仅排除 6 个超过 600 KiB 的原始会话/行情日志（TradeLogger JSONL 与超大 stderr），完整目录树保留在 `D:/temp/it10scn02-r12-20261016-r1/` 与 `D:/temp/it10scn02-r34-20261016-r1/`：
  - `sweep-r12/013_1/replay.stderr.txt`（2336467 B）
  - `sweep-r12/013_2/replay.stderr.txt`（812573 B）
  - `sweep-r12/013_3/replay-evidence/quotes.jsonl`（3853893 B）
  - `sweep-r12/013_3/replay-evidence/signals.jsonl`（4249394 B）
  - `sweep-r12/013_3/replay-trend-evidence/quotes.jsonl`（3846393 B）
  - `sweep-r12/013_3/replay-trend-evidence/signals.jsonl`（4163672 B）
- 红线与证据边界（照实）：全程未使用 --allow-write、零写观察/回放；backtrader HEAD b002afa2 前后一致（含 R3/R4）；凭据扫描 0 真实泄漏。本轮为 SCN02 增量证据归档，NOT SCN02 正式 PASS：014_2 观察修复、R5（012/007 边界事实）与 R6（准入演练）仍缺，正式裁定归 R7。SCN02 不新增 PASS，正式 28/68。
- 证据见 evidence/scn02-r12-r34-evidence-20261016/root-adjudication.md。


## 第163轮：DIM06 CTP adapter 合同固定源 QA 证据归档（增量，2026-10-16）

- 范围（docs-only，无源码变更）：归档 DIM06（正式迭代计划.md:778）固定源对照 QA。r1 全子集（13 模块 519 节点）：513 passed / 3 failed / 3 skipped，pytest exit 1；3 个失败均为 test_execution_session.py::test_session_uses_real_gateway_command_roundtrip_with_native_mt5_intent[result0-True/result1-False/result2-False]，归因于运行当时未提交的 MIG01-R1 legacy-forwarding 退役（该退役现已提交 `46697739`；3 节点去留待 gateway-wire 轮处置）。r2 同子集 −3 deselect：513 passed / 3 skipped / 3 deselected，exit 0；两轮 sources_unchanged / heads_unchanged = true（HEAD 4e46ff01、base b4aabd1e、ctp a497bab6 前后不变），stderr 空。3 个 skip = 2 个 POSIX 目录 fsync 平台节点 + 1 个 pytest-asyncio 与 pytest 8.0.0/importlib 不兼容的异步节点（环境限制，如实登记）。
- 条款→合同映射（8+E）：1 CTP 交易日、2 结算读回、3 重连代次、4 OrderRef 恢复、7 账户管理动作与其他策略隔离、8 UNKNOWN 阻断恢复、E 未实现管理能力明确拒绝 = COVERED（合同级）；5 各 venue 持仓模式 COVERED（其他 venue 显式不支持；保证金池维度属 DIM03 AccountResourceKey 线）；6 订单类型不兼容拒绝 COVERED（CTP limit-only 前置拒绝），venue×TIF 不兼容矩阵仍缺（需新合同）。
- 证据边界（照实）：vehicle 依条款右列 = adapter 合同 + 本地故障验证，provider 行为另按 VENUE02 记录；固定源/合成、无真实账户、无 Host 服务栈。DIM06 不新增 PASS，正式 28/68；正式 PASS 需补 #6 TIF 合同、#5 归属裁定与 3 个 session 节点处置。
- 裁剪与完整性：未入档 pytest --basetemp 瞬态 scratch（r1+r2 共 1872 文件 / 3154691 B，目录树保留于 D:/temp/it10dim06-20261016-r1/、-r2/）；入档文件字节原样，600 KiB 上限内排除 0 个：
  - （无）
- 来源一致性（信息性）：r2 spec 30 pins 中 30/30 与当前 dev 树逐字节一致。
- 证据见 evidence/dim06-ctp-contract-qa-20261016/root-adjudication.md。


## 第164轮：ARB03/DIM05 IOC 部分成交与次腿拒绝恢复 R2 增量（2026-10-16）

- 范围（SDK 4 文件）：`bt_api_py/service_execution_group_proofs.py`（完整 IOC CANCELLED 部分成交支撑路径：源事件接受门 0<filled<quantity、`_source_proof_kind` FILLED/CANCELLED_PARTIAL/REJECTED_NO_FILL、CANCELLED exposure proof、PARTIALLY_FILLED 中间观测提交、`_status_from_facts` 平均价；末尾两处最小修复：REJECTED 原因码小写 `provider_rejected`（冻结契约 `^[a-z][a-z0-9_]{0,127}$`）与无成交回执回显 `order_revision`。diff 全量 +125/-25）、`bt_api_py/service_execution_group_authority.py`（`_assert_current_execution_partial` + 双 provider_observation 出处链，+158/-15）、`tests/unit/_service_group_provider_fixtures.py`（+13/-4）、新增 `tests/integration/test_arb03_dim05_group_partial_fill_service.py`（2 节点）。
- 验收（固定来源 r2，`D:/temp/it10arb03dim05-20261016-r2`）：runner exit 0；2 passed（29.85s）；junit 2/0/0/0；stdout sha256 `b0cfab73…`、stderr 空；sources/heads 前后不变；spec `425af923…`（与 focused-qa.json 字节等同）；result `0484337f…`；runner 与 `iteration10-focused-qa.py` 字节等同。pins：root abf1cd56（运行后仅 1 个 docs-only 提交至 77668953，0 代码文件 0 gitlink 变更，D5）、base b4aabd1e、execution dc8bd7a3、risk 089b5efd（+266 为 CFG06b WIP；本提交不改 risk gitlink，D4）、transport a397fdb4；2336 源 pins 独立全量复算一致。
- 独立静态复核 GO（`.codex-tmp/arb03-dim05-r2-review-status.md`，sha `aba5ab74…`）：哈希全量复算一致、候选与工作区字节等同、两处末尾修复为冻结契约所必需且无弱化（原因码正则未放宽、`order_revision` 仅增保真，测试断言全部可溯源）；D2：PROOF_READY 顺序为生产强制、无测试级断言，不得引用为测试证据；D3：冻结候选另含 CFG06b/load01 WIP（对两节点无涉）；D6：R121 单次瞬态失败为作者自证保留；D7：CFG06b 对 `service_components.py` / `service_execution_group.py` 的现场改动不得被本轮提交卷入。
- 条款映射：ARB03 首腿部分成交（CANCELLED 1.5/2）、第二腿 REJECTED、按步长对冲 3.000、补偿耗尽保留未解决（RECOVERY_REQUIRED + hedge_residual_unresolved，残差 base 3）→ 2 场景覆盖；首腿零/全成交、第二腿部分成交 → 仍缺。DIM05 一账户两合约（spot BTC-USD + perp BTC-USD-PERP）/整组一次预留/部分成交配对 → 覆盖；跨期、旧合约退出恢复（契约不可表达）→ 仍缺。两用例均未满足全部条款，正式 PASS 不变（28/68）。
- 证据等级 FIXED_SOURCE_SYNTHETIC_PROVIDER_…_SCENARIO_ONLY；本提交 = 上述 4 文件 + 本证据目录与进度/汇总文档。


## 第165轮：CFG06b group_policy 角色与组协调器准入闸门（2026-10-16）

- 范围（risk 子包 1 文件 + SDK 2 文件 + 2 新增单测）：`bt_api/bt_api_risk/src/bt_api_risk/service_component.py`（+266/-0：`GroupPolicyError`/`GroupPolicyStore`（`group_policy_versions` 表、版本 sha256 校验、首 pin 终局、冲突/越权引用拒绝）/`GroupAdmissionDecision`/`GroupPolicyService`（`group.admission.evaluate`，版本校验先于范围校验 fail-closed））、`bt_api_py/service_components.py`（+26/4 hunks：`("risk","group_policy")` builtin 注册、构建期 gate 类型/ref/ready 三校验、coordinator `group_admission` resource 键与 ctor 接线）、`bt_api_py/service_execution_group.py`（+18：新提交路径 gate 位于 `_parse_request` 之后、`run_bindings.bind` 之前；retry/重放路径按设计旁路；`GroupPolicyError` 码经内层 try/except 不被外层 INVALID_REQUEST 掩盖）、新增 `tests/unit/test_service_group_policy_control_plane.py`（18 节点）与 `tests/unit/test_service_group_policy_admission_gate.py`（13 节点）。三个 diff 均为纯插入，无删除。
- 验收：验证电池 run-a..f 全 EXIT 0（13/18/5/1/11/6 passed；含冻结 policy_catalog 无公共端口节点、group runtime bundle、组执行与线协议回归；r2 目录为未 pin 补充日志，D4）。固定来源 QA r1（`D:/temp/it10cfg06b-qa-20261016-r1`，runner `iteration10-focused-qa.py`（`8b7f470b…`，与归档 runner.py 字节等同）+ spec `.codex-tmp/iteration10-cfg06b-qa-spec-r1.json`（`a4351a09…`））：exit 0、54 passed（junit 54/0/0/0 `fcc9dd6a…`）、stdout sha256 `38769d74…`、stderr 空、result `15ce1500…`、139 pins（六节点模块导入闭包 + runner + 外部 ini `f9aada43…` + 两补丁源现场字节）、source-before==source-after、heads 前后不变（root f308c8d8、risk 089b5efd、base b4aabd1e、execution dc8bd7a3、transport a397fdb4）。risk 现场 +266 文件已按 QA 候选字节先行提交为子包 `c7fc809b`（仅该文件），本提交更新父仓 risk gitlink。
- 独立静态复核 GO（`.codex-tmp/cfg06b-phase2-review-status.md`，sha `018688a1…`）：哈希/候选/语义/条款/测试体全通过（纯插入无删除；gate 仅新提交路径、恰咨询一次；fail-closed 每码零副作用；冻结回归绿；retry 旁路由调用计数 + 现场篡改双重证明）。D1 提交范围仅 5 文件+证据+risk gitlink（service_registry.py/service_runtime.py（registry #32）、load01、decimal_match、round-r20、`%SystemDrive%`、`0` 一律不登记）；D2 三个外部文件 QA 后漂移（DIM03 admission.py `fd129688…`→`28b9918b…`、registry #32 两文件 `cea39dac…`/`e5b8ba12…`→`60712659…`/`3d7fde59…`；r1 对运行期字节有效，CFG06 正式轮须重建 spec 并复跑两新测试）；D3 冻结测试过时 docstring 不改；D4 证据管线（runner/ini 在库外、r2 未 pin 补充件）；D7 证据 sha 引注同本条。
- 条款映射：CFG06 缺口“group_policy 真实角色注册/服务链”关闭于 role builtin + build 校验 + coordinator gate + risk 服务单元层（两新测试 31 节点 + 冻结回归），第 156 轮已关闭 portfolio_analytics 真实注册；仍缺宿主组合 3（正式迭代计划.md:538“group_coordinator + group_policy 和最小账户委托”的真实 ServiceHost+CURVE 矩阵）与公共访问拒绝负面、combo-3 固定来源 QA 轮 → CFG06 仍部分，不新增正式 PASS（当前 28/68）。
- 证据等级 `FIXED_SOURCE_CFG06B_RISK_GROUP_POLICY_ROLE_AND_GROUP_COORDINATOR_ADMISSION_GATE_UNITS_WITH_CFG06_REGRESSION_UNITS_ONLY`；本提交 = risk 子包 1 提交（`c7fc809b`）+ 上述 2 SDK 文件 + 2 新测试 + risk gitlink + 本证据目录（33 件）与进度/汇总文档。


## 第166轮：registry 释放运行接管（工作线 #32，DIM01 restart 披露收口，2026-10-16）

- 范围（SDK 2 文件，+109/-35）：`bt_api_py/service_registry.py`（`_claim_strategy_write` 释放检测仅用 durable 状态：任一活跃 claim → 纯 DUPLICATE_ACTIVE_RUN（result `{}`）；全部释放且恰一个其他运行 → 携带 `result.strategy_write_run_id` 的元组拒绝；BEGIN IMMEDIATE 串行化竞争 adopter、败者纯拒绝、无双活窗口；同 run 释放重绑与 HEAD 等价；旧进程 session 失效后写路径以 NOT_REGISTERED 与 claim 复核双重拒绝，fail-closed）、`bt_api_py/service_runtime.py`（`ServiceRuntimeError.result` 默认 `{}`；`_rpc` 失败分支附加 result；策略注册重试恰一次经 `_released_run_adoption_run_id` 校验；采纳 scope 贯穿后续 ops 与 startup 清理；非确定性失败仍记 unknown registration）。提交 `ed09b3ca`（sha：registry `7c708a43…`、runtime `3d7fde59…`）。
- 验收：目标 `tests/unit/test_service_risk_only_order_integration.py` 20 节点——r1 两轮 20 passed；r2（提交树）run1 20 passed/exit 0（junit tests=20 failures=0）；关联套件 run-reg3 31p、run-rh 81p、run-reg03 1p、run-arb 6p、run-dim01 1p、run-oe 6p 全绿；run-grp 59p/1f 与 run-hostint 1f/1p 为外国红（D3，第168轮已修复）。qa/ 归档 R2 三轮日志与 post-run sha256。
- 独立复核 GO（`.codex-tmp/reg32-review-status.md` sha `68b240ef…`）：语义/竞争窗口/全仓 DUPLICATE_ACTIVE_RUN 断言全过；D2 `sdk-fix.diff` 陈旧但 mtime/哈希链证明被测量为终稿字节；D4 wire 可见变化仅释放单运行向量附 run id，仓内 exact-dict 消费者已核对。
- 条款映射：DIM01 第160轮披露"registry run_id 缺口后续工作线 #32"关闭于注册/接管语义层；DIM01 保持正式 PASS，DIM01–DIM09 组仍部分，正式 28/68 不变。
- 证据等级 `FIXED_SOURCE_REGISTRY_RELEASED_RUN_ADOPTION_UNITS_AND_CURRENT_TREE_REGRESSION_ONLY`；证据见 evidence/reg32-released-run-adoption-20261016/root-adjudication.md。


## 第167轮：DIM03 保证金池预留限额（risk `e2bedb3` + 父仓 gitlink `ee01865a`，2026-10-16）

- 范围（risk 子包 3 文件）：`src/bt_api_risk/core/admission.py`（live diff +252/-27：`RiskIntent.resource` 可选 `AccountResourceKey` 并入 fingerprint；`set_margin_pool_limit` 版本化 ceiling（同版本同事实幂等、改事实 ValueError、已用版本不可重放）；`_assert_margin_pool_limit` 在同一 BEGIN IMMEDIATE 内对 `reserve()` 与 `reserve_group_vector()` 每腿断言（等值允许、严格 `>` 拒绝）；四 fail-closed 码；加性护栏迁移（两可空列 + 两新表 + 索引，旧行 NULL 不进池计账）；resource=None 全路径与 HEAD 字节等价）、新增 `tests/test_margin_pool_reservations.py`（7 节点，真实 SQLite、双进程竞态恰一授予 durable 1,0,0,0、整向量回滚、池隔离、UNCONFIGURED 双路径、单发与组共享同池信用）、`pyproject.toml`（`bt_api_base>=0.15.5` → `>=0.15.8`：AccountResourceKey API 需要，PyPI 仅到 0.15.5、本机已装 0.15.8、与根仓要求一致；metadata-only，改后 `test_durable_risk_gate` 63 passed/15.94s）。提交 `e2bedb3`；父仓 `ee01865a` 更新 risk gitlink `c7fc809b → e2bedb3`。
- 验收（固定来源 r4 `D:/temp/it10dim03-fixed-source-20261016-r4`）：exit 0；114 passed（43.61s）；junit sha `56d92231…`；spec sha `085587e8…`；result sha `7826dd8f…`；144 sources unchanged；heads before root `d85ec636`、risk `c7fc809b`（diff base == HEAD 字节 `859a072c…`）。
- 独立复核（`.codex-tmp/dim03-review-status.md` sha `c761a2f8…`）：8 项全过。披露：两防御性码仅外来/篡改行可达且未被 7 测试覆盖；"同事实"按 `_decimal_text` 字符串比较（`300` vs `300.0` 拒绝，偏 fail-closed，D6）；旧格式 DB 行重读仅静态覆盖。
- 条款映射：DIM03 保证金池维度（第163轮登记"保证金池属 DIM03 AccountResourceKey 线"）在预留路径落地；DIM 组仍部分，不新增正式 PASS（28/68）。
- 证据等级 `FIXED_SOURCE_MARGIN_POOL_RESERVATION_LIMITS_UNITS_WITH_RACE_SCENARIO_ONLY`；证据见 evidence/dim03-margin-pool-reservation-20261016/root-adjudication.md。


## 第168轮：两个过期单测修复 + load01 边界守卫（提交 `72ebc681`，2026-10-16）

- 范围（3 个测试文件，+32/-4，纯测试修复无产品改动）：`tests/unit/test_service_config_scoped_execution_routes.py:407`（`close_clients(*_args, **_kwargs)`，arb02 清理 helper 传 `allowed_call_errors=`；原红为 TypeError）；`tests/unit/test_service_host_integration.py`（execution 资源 provider 补 b63000b2 起的四键 builtin `store/targets/dispatch/admission`，新增 `_UnusedDispatch` 桩；原红为 RESOURCE_KEYS_MISMATCH）；`tests/unit/test_load01_hundred_strategy_30min.py`（`_FULL_LOAD_SECONDS = 30*60`；重连窗口 guard `window >= 1 and window < _FULL_LOAD_SECONDS // 300`，window 6 名义起点恰为 1800 s 结束边界、会调度出第 51 次重连；`duration_seconds` 显式绑定 120/full）。
- 验收（`D:/temp/it10regfix-20261016-r1`，归档 19 件）：净 HEAD 导出版复现两红（red1 1f/20p、red2 1f）；10-attribution `b63000b2^` 1 passed → `b63000b2` 1 failed 且该提交未改测试（回归源锁定 service_components.py 四键 builtin）；修复后 20-red1 21 passed、30-red2 1 passed、40-final fresh basetemp 21 passed + 1 passed 全 exit 0；sha256 config_scoped `306258ae…`、host_integration `97330020…`、load01 `8291666106…`（提交 blob == 工作区）。load01 边界数值扫描证明恰 50 次重连、narrow `-k` not-sustained 4 passed。
- 独立复核：无产品字节、无条款声明，不需要独立前复核；作者侧复现-归因-修复-终验四步留档 + sibling-stub 全仓扫描。
- 条款映射：无正式条款变化；修复 dev HEAD 两个既有红节点（同时清除 reg32/ARB06 等轮 D3 披露）并收口 LOAD01 运行器时长边界。
- 证据等级 `TEST_ONLY_REPAIR_WITH_HEAD_EXPORT_ATTRIBUTION_AND_LOAD01_BOUNDARY_SWEEP`；证据见 evidence/regfix-stale-fixtures-20261016/root-adjudication.md。


## 第169轮：ARB06 组残差/未对冲 durable Monitor 中继（提交 `dcad4003`，2026-10-16）

- 范围（2 文件，+2251）：新增 `bt_api_py/service_group_monitor.py`（1524 行，sha `41ee954c…`：只读 SQLite reader（`mode=ro` + query_only 断言、全参数化 SQL）读不可变 order_group_events 的 GROUP_RECOVERY_REQUIRED 关联 request_json；独立 checkpoint DB 按 namespace CAS 游标、锚点重验、同文件/hardlink/symlink 拒绝；仅 opt-in `poll()`；durable Monitor 事件 `group.residual`（`sdk.group_monitor_projection.v1`），幂等身份 `service-event:<sha256>`）+ 新增 `tests/integration/test_arb06_group_monitor_relay_service.py`（727 行，sha `f939f3e6…`：三 Host 真实线节点，ARB03 组集群 + Monitor host + relay）。
- 验收（`D:/temp/it10arb06-20261016-r1`）：run1-baseline 25 passed/exit 0；run2a collection error 如实保留（tuple|set @ service_group_monitor.py:85，exit 2）；run2 1 passed / run3 1 passed（fresh basetemp）各 exit 0；run4 回归 25 passed/exit 0；268 件聚合 sha `022aeb66…`；mtime 链证明绿轮均在终稿字节之后。
- 独立复核 GO-with-disclosures（`.codex-tmp/arb06-review-status.md`）：哈希/日志逐项确认；披露：多 portfolio journal 上逐事件 scope 校验可能永久停摆（"one relay per scope" 缓解说法不准确）、新失败路径缺单测。
- 条款映射：ARB06 覆盖残差事件投影、幂等重放与只读源；ARB01–ARB06 仍部分，不新增正式 PASS（28/68）。
- 证据等级 `FIXED_SOURCE_SPAWNED_THREE_HOST_CURVE_MONITOR_RELAY_SYNTHETIC_PROVIDER_SCENARIO_ONLY`；证据见 evidence/arb06-group-monitor-relay-20261016/root-adjudication.md。


## 第170轮：ARB04 组提交失联与晚到成交（提交 `52127cba`，2026-10-16）

- 范围（2 新文件，+1214）：`tests/integration/test_arb04_group_reply_loss_service.py`（538 行，sha `40138c30…`）+ `tests/integration/_arb04_group_reply_loss_support.py`（678 行，sha `b508086d…`）。故障注入：coordinator 子进程 transport_factory 包装器转发真实 `orders.submit_group_leg`（account host 完整执行并应答）后丢弃真实回复、抛真实 `RequestOutcomeUnknownError`；两真实 account host + coordinator host、CURVE loopback、真实 SQLite 全栈，唯一合成件为外层 provider leaf。
- 验收：r1 `D:/temp/it10arb04-20261016-r1` run1 2 passed（17.8s）/ run2 2 passed（18.2s）junit 各 2/0/0/0、replay 确定性一致；回归 ARB03 2 passed、R121 1 passed；四 run exit 0；pins before==after（root `d85ec636`、base `b4aabd1e`、execution `dc8bd7a3`、risk `c7fc809b`、transport `a397fdb4`）。staging（F8，`D:/temp/it10arb04-staging-20261016-r1`，root `dcad4003`/risk `e2bedb3`）：run1 2 passed（18.42s）/ run2 2 passed（19.19s）/ ARB03 2 passed / R121 1 passed 全 exit 0，pins before==after。
- 独立复核 GO-with-disclosures（`.codex-tmp/arb04-review-status.md`）：F1–F6 全 GO（故障真实执行后弃回复、wire/durable/provider 三维印证不回发、断言非空洞、晚到冻结多轴 durable 证明、自包含）；F7 披露 socket-retire 保真限制等；F9 未证：撤单超时（design-only）、真实网络恢复、重复成交回报；晚到成交采纳按设计未实现。
- 条款映射（正式迭代计划.md:770）：提交失联不回发/不提前释放/按原业务 ID 恢复恰一次、晚到成交不采纳不补偿（拒绝半）覆盖；ARB 组仍部分，不新增正式 PASS（28/68）。
- 证据等级 `FIXED_SOURCE_SPAWNED_CURVE_CHAIN_SYNTHETIC_PROVIDER_ARB04_REPLY_LOSS_AND_LATE_FILL_REFUSAL_SCENARIO_ONLY`；证据见 evidence/arb04-group-reply-loss-20261016/root-adjudication.md。


## 第171轮：CFG06b 宿主组合3矩阵与公共访问拒绝负面（提交 `160c36b5`，2026-10-16）

- 范围（2 新文件，+1303）：`tests/integration/test_group_policy_host_combo3.py`（sha `d3e91b94…`）+ `tests/integration/_group_policy_host_fixtures.py`（sha `9ba0c856…`）。五节点：单闸门对象在子进程内逐部件 `is` 身份断言后经控制管道上报（测试对 5 元向量精确相等）；准入组到达 PAIRED（error_code None、residual 0、2 腿 1 预留、run 绑定、durable store == 快照、provider 写恰 2/计数器 {2,2}、claims resolved）；三拒绝码精确 dict + 零派发多维证明；公共访问拒绝 5 类（真实线 discover 不含门、raw register 两端口 CAPABILITY_UNAVAILABLE、真实 live 会话 raw call 拒绝、SDK 静态 INVALID_ACTION_REQUEST、实例固定客户端线发现拒绝）；policy-only host 在任何监听前 NO_SUPPORTED_PUBLIC_PORTS。
- 验收：r1 `D:/temp/it10cfghost-20261016-r1` run-1 smoke 1p；run-2 debug 1 failed（list/tuple 修复前）如实保留；run-3 5/5（20.43s）、run-4 5/5（20.57s）；run-5 回归 14/14（4.47s）。staging `D:/temp/it10cfghost-staging-20261016-r1`（root `dcad4003`）：run-a 与 ARB04 套件并发资源争抢下 1 failed/4 passed 如实保留（失败模式 `reservation_outcome_unknown`，非旧 list/tuple）；run-c/run-d 独立复跑各 5/5（20.43s/19.45s）；run-b 回归 14/14；pins before==after。
- 独立复核 GO-with-disclosures（`.codex-tmp/cfg06b-combo3-review-status.md`）：两文件与 15 件证据哈希复算一致；条款 (a)-(e) 全部有产品代码路径印证；披露 import 式耦合、临时端口 TOCTOU、run-2 单行修复披露、证据产出于现已提交字节（mtime 证明）。
- 条款映射：CFG06 第165轮缺口"宿主组合 3（真实 ServiceHost+CURVE 矩阵）"与"公共访问拒绝负面"关闭于本矩阵；仍缺 combo-3 固定来源 QA 轮与完整应用/analytics 矩阵，CFG06 仍部分，不新增正式 PASS（28/68）。
- 证据等级 `FIXED_SOURCE_SPAWNED_HOSTS_CURVE_GROUP_POLICY_COMBO3_AND_PUBLIC_DENIAL_SCENARIO_ONLY`；证据见 evidence/cfg06b-host-combo3-20261016/root-adjudication.md。


## 第172轮：遗留件归并—journal 十进制匹配测试与 r20 归档文档（2026-10-16）

- 范围（登记归并，无产品改动）：`tests/unit/test_service_risk_order_journal_decimal_match.py`（50 行，sha `10f24243…`；所测 `_decimal_text_matches` 由 `b3b2c6d6` 提交，本测试为第160轮披露"（未 pin）保留未提交"的遗留件，pin 尺度等价不重写、精确数值等值、畸形/非有限值/布尔拒否）+ `docs/迭代计划/迭代10-可选组件与可配置通信/risk-order-exposure-sdk-round-r20.md`（39 行，sha `578cc5b2…`，与已提交 evidence/risk-order-exposure-service-20261016/author-delivery-note.md 逐字节相同，收编顶层重复副本）。
- 验收（`D:/temp/it10decimalmatch-20261016-r1`）：12 passed / exit 0 / 0.88s / stderr 空 / 1 条既有配置 warning；固定树 root `6bafd206`、execution `dc8bd7a3`、risk `e2bedb3`。
- 条款映射：无正式条款变化；把已写测试与重复归档件并入历史，避免遗漏提交（多轮复核曾登记为 foreign 不得 staged，本轮正式归属收口）。
- 证据等级 `TEST_ONLY_LEFTOVER_ADOPTION_WITH_FIXED_TREE_RUN`；证据见 evidence/decimalmatch-leftover-adoption-20261016/root-adjudication.md。


## 第173轮：SCN02 014_2 空交易所修复落地与本机 dry/replay/live 观察 r2（Backtrader `eb03f91e0`，2026-10-16）

- 范围：`backtrader/stores/btapistore.py` 单文件修复（+43/−1，4 hunks；sha `9670cca7…` → `451b488f…`，diff `btapistore-fix.diff`）：订阅时保留每合约解析交易所，venue tick `ExchangeID` 为空时回退框架 CZCE 推断（含窄 CZCE 期权形态，DCE/SHFE 4 位月份显式排除）；venue 自带值不覆盖。经根复核（工作区 diff 与存档 diff 逐字节一致、文件 sha 与验证值一致、该文件不在 SCN02 基线 porcelain 内）后提交 Backtrader dev `eb03f91e0`（仅此一文件）。
- 验收（固定 HEAD `b002afa2d`，全程零写、`--allow-write` 未用、`order_write=0`）：dry exit 0 `status=DRY`；replay exit 0 `LOCAL_REPLAY_PASS`（run_id `replay-20261016T032158Z-062101ef`）；live 240s exit 1 `FAIL / no_complete_minute_window` 但 `run_error=null`——7 根封口分钟 bar 送达策略（pre-fix 每轮必现 `ValueError: exchange must be an exact non-empty string`），主修复判定 SUCCESS。stores 单测失败表与 pristine HEAD 程序化比对完全一致（两侧 38F/2E，40==40）→ 零新增失败；行为检查 30/30。
- 条款映射：014_2 主缺陷（空交易所崩溃）关闭；live 观察仍无 PASS——第二阻塞项在案（feed 封口身份为裸 contract code 而策略证据表按全称符号键控 → `FEED_CLOSED_BAR_PROVENANCE_REQUIRED`），留待独立轮次（owner 决策 btapifeed/run.py 侧）修复后重跑。不新增正式 PASS（28/68）。
- 证据等级 `BACKTRADER_SINGLE_FILE_EMPTY_EXCHANGE_FIX_WITH_IDENTICAL_UNIT_FAILURE_LISTS_AND_ZERO_WRITE_LIVE_OBSERVATION`；证据见 evidence/scn02-0142-livefix-20261016-r2/root-adjudication.md。


## 第174轮：DIM09 Step-1 — execution 子仓 v3 三腿组合同与分段协调器链（子仓 `6e89d30` + 父仓 gitlink `c4148e8c`，2026-10-16）

- 范围（execution 子仓 4 文件，+1430/-47）：`group_order_contracts.py`（sha `67b50a48…`，1584 行；v3 合同：`ratio` 字段、2..3 腿、快照字段 `residual_vector: tuple[Decimal,...] | None`（仅 v3 非 None；v2 标量 `first_base-second_base` 逐字节不变）、v3 残留标量=各分量绝对值之和（精确 Fraction→Decimal）、中途零成交 fail-closed `CHAIN_INTERRUPTED_ZERO_FILL`、同侧不变量、新增码均匹配 `^[a-z][a-z0-9_]{0,127}$`）、`group_coordinator.py`（sha `81e79337…`，1720 行；分段下腿链 + 整组归约迭代 ≤64 轮至公共 B*、残差向量收口、`advance_group` 上界 `2*len(legs)+2`）、`group_store.py`（sha `efba3cd1…`，929 行；仅 3 hunks，无 schema/DDL）、新增 `tests/test_group_coordinator_three_leg.py`（sha `4c48f71c…`，1033 行，13 节点）。父仓提交 `c4148e8c` 仅更新 execution gitlink `dc8bd7a3 → 6e89d30`。
- 验收（`D:/temp/it10dim09-20261016-r1`，10 run 全表）：基线与终态一致（coordinator 12p、budget 9p、risk_integration 3p）；新文件 13p；service_component 25p；`test_group_order_entry.py` 22F 为 CLEAN 基线既有外国红（`paper execution requires an explicit owner domain`），`^FAILED` 集合改动前后 diff 为空。
- 独立复核 ADOPT（`.codex-tmp/dim09-review-status.md`；证据 `D:/temp/it10dim09-review-20261016-r1`）：v1/v2 字节兼容探针 34=34 行、probe.diff 空；residual_vector 探针（v2 无键、非 None 拒绝、v3 往返）；store diff 仅 3 hunks 且无 SCHEMA/DDL；逐行读新测试与合同不变量。披露：3 个基线目录缺 exit.txt；cosmetic 文残留（v2 注释/receipt 消息）。
- 条款映射：DIM09 子条款 1/2/3/5 在纯协调器层落地；host wire（Step-2）与真实账户三腿另计（014_1 保持 observe-only）；DIM 组仍部分，不新增正式 PASS（28/68）。
- 证据等级 `FIXED_SOURCE_EXECUTION_SUBMODULE_V3_CONTRACT_UNITS_WITH_V1V2_BYTE_COMPAT_PROBES_ONLY`；证据见 evidence/dim09-step1-three-leg-contract-20261016/root-adjudication.md（事后固化归档；节选与排除清单见裁定文）。


## 第175轮：GW01 epoch 节点 ready 元组下标修复（提交 `d3a87fe4`，2026-10-16）

- 范围（1 测试文件，+2/-2）：`tests/unit/test_service_market_integration.py` 的 `test_market_epoch_change_requires_explicit_incomplete_resync`——`4d5cebf5` 在 ready 元组下标 2 插入 `account_ref` 时只修了十客户端节点，epoch 节点仍用 `ready[2:5]`/`ready[5]`；对齐为 `ready[3:6]`/`ready[6]`（根读节点后修正了复核仅发现的 :903 之外的 :915 同源）。
- 验收（`D:/temp/it10gw01fix-20261016-r1`）：整文件 exit 0，“2 passed, 1 warning in 42.43s”；修复前失败运行保留于 `D:/temp/it10dim02-20261016-r1/run3-gw01-regression`（exit 1，`'account:synthetic-market-gw01' != 'latest_event'`）。
- 条款映射：关闭 DIM02 批次复核披露的外国红；GW01 已为正式 PASS，保持。
- 证据等级 `TEST_ONLY_READY_TUPLE_INDEX_REPAIR_ON_CURRENT_TREE`；证据副本归档于 evidence/dim02-increments-20261016/gw01-epoch-node-fix/。


## 第176轮：DIM02 三增量批次 — 多键共享上游 / 历史→实时接缝 / 腿时间偏差就绪（提交 `03c5110a`，2026-10-16）

- 范围（145 文件，+4570）：`bt_api_py/service_market_legs.py`（240 行，sha `1d6456c2…`）+ 新测试 `tests/unit/test_service_market_legs.py`（339 行，sha `d99776ab…`）、`test_service_market_dim02_integration.py`（1349 行，sha `93812529…`）、`test_service_market_dim02_seam.py`（1129 行，sha `7c869043…`）、`test_service_market_dim02_legs.py`（703 行，sha `a9de557c…`），及证据目录 evidence/dim02-increments-20261016/（三增量 author/review/run 记录与第176轮根裁定）。
- 验收与复核：三增量各自 QA 轮 + 独立复核 ADOPT；incr-1 裁定修正：“逐字节相同”降级为语义等价（stdout 仅时长记号 10.91s/10.76s 不同；run2a 陈旧修订失败如实保留）；incr-3 含变异敏感度测试；GW01 外国红披露并已于第175轮关闭。
- 条款映射：DIM02 子缺口（多键共享上游、历史→实时接缝、腿时间偏差就绪）在模块+节点层落地；DIM 组仍部分，不新增正式 PASS（28/68）。
- 证据等级 `FIXED_SOURCE_MARKET_LEGS_READINESS_UNITS_AND_SPAWNED_FIXTURE_NODES_ONLY`；证据见 evidence/dim02-increments-20261016/root-adjudication.md（第176轮根裁定）。


## 第177轮：LOAD01 r3 试点阻塞登记（BLOCKED_STRATEGY_STARTUP_LEASE_STORM，2026-10-16）

- 范围（无仓库改动；QA 轮）：冻结 `72ebc681` 六 gitlink 的 v6 导出（exit 0；runner overlay `a4bbec0b…`、单路径自豁免、pin 继承记录 8291666106→a4bbec0b）；export-verify 37 pins PASS；dryrun LAUNCH_READY（bite 探针双通过）；collect-only 5 collected；内存门 PASS（available 10.936 GiB ≥ 10,603,200,512 B）；120 s pilot 启动后 exit 1（“1 failed in 214.57s”，state FAILED at load-strategy-processes）。
- 根因（系统级，非偶发）：启动边界 required-lease 续约在 ~2,000 市场客户端并发启动风暴下超时——维护/续约预算 5,000 ms = min(binding.timeout, remaining*0.5)，枢纽 RPC 峰值 market.subscribe 2219 ms；runtime 状态 failed（maintenance_failure_count=1），界限健康探针随即抛 CONTROL_CALL_FAILED（strategy-005，测试 :3855 ← :2982）；失败时 lease remaining 15.8-21.4 s、renewal_due 已逾期 3.6-5.5 s。pytest 回溯捕获 8 个同症策略子进程（005/086/050/001/007/054/013/057）；无孤儿、monitor exit 0、sources/heads 前后不变。
- 处置：1800 s 全程未启动（前置不满足；full spec/outdir 保持未消费，不原样重试）；工作区 runner overlay 已回退（字节==blob `5c1d6b14`，git diff 空；补丁保留于证据 10-export-runner-diff-r3.patch）。修复轮 r4 进行中：service_runtime 续期超时重试语义（超时可重试至租约到期、拒绝/到期仍 fail-closed；不降低负载/租约/资源门槛），随后新冻结重跑 pilot→full。
- 证据等级 `FIXED_SOURCE_ALL_GATES_PASSED_PILOT_FAILED_STARTUP_LEASE_STORM_FULL_RUN_NOT_LAUNCHED`；证据 D:/temp/it10load01-20261016-r3/（00 索引 + 20-pilot-attempt1 全包 + 99 汇总）。


## 第178轮：MIG03 增量A — 首写后拒绝回退的最小生产闸门（提交 `f0731ec2`，2026-10-16）

- 范围（3 文件，纯新增 + 单点接线）：`bt_api_py/service_migration_gate.py` 新增（sha `70700cd6…`，16721 B）：durable JSON 标记 `<state>.migration-cutover.json`（O_EXCL tmp+fsync+replace 原子写；损坏/外来标记 fail-closed `CUTOVER_MARKER_UNREADABLE`）、`arm_migration_cutover`（同 epoch 对幂等、冲突 `CUTOVER_MARKER_CONFLICT`）、`record_migration_first_write`（COMMITTED→SEALED 单向、首事实保留、无标记无害 no-op）、`enforce_migration_start`（SEALED 仅 destination 或已验收 reverse epoch 可通过，其余 `REVERSE_MIGRATION_REFUSED`）、`rollback_migration_cutover`（seal 前还原、seal 后拒绝除非 accepted reverse）、`accept_reverse_migration`；`bt_api_py/service_host.py` +24/-0（ctor kwarg `migration_deployment_epoch` 及校验；`start()` 首动作 `_enforce_migration_gate()` 先于 registry 打开等一切副作用；`MigrationGateError.code` → `ServiceHostError(code)` 机读保真；既有调用方 passthrough）；新增 `tests/unit/test_service_migration_gate.py` 12 节点（17406 B）。
- 验收：作者 run-01..20 全留档（新套件多轮 12p、collect-only 12、host 32/registry 21/spawned host-int 1/REG03 1/execution-int 1、ruff 全过；失败轮 exit 4/2/1 原样保留）；独立复核 GO（`.codex-tmp/mig03a-review-status.md`；三文件 hash + wiring diff 与作者逐字节一致；复现 r01–r07 全 exit 0；探针 A=78 项 11 损坏×7 操作全 fail-closed、B=seal/rollback、C-v2=跨新解释器持久验收、D=同对并发 40/40 干净（异对 30/40 双成功→F1）、E=宿主级 6/6 零副作用）。
- 披露 F1–F5：F1（中等）arm/冲突判定 check-then-write 非原子，异对并发双成功、同对返回值 18/40 与最终文件不一致；最终文件始终合法单文档、enforcement 按 epoch 不受影响；F2 旧二进制无闸门代码不可被协作拒绝；F3 当前无生产 arm/seal 调用者，闸门 incr-B 前 inert；F4 schema_version True==1 轻 nit；F5 post-seal rollback 未接宿主。
- 条款映射（正式迭代计划.md:784）：MIG03 子片段“首次新写之后无已验收反向迁移则拒绝回旧版”在闸门组件+宿主 start 强制层落地；受控迁移演练（drain→fence→导入守恒→新 epoch→重登记）与调用计数、双 owner/UNKNOWN 边界属 incr-B。MIG03 仍部分，不新增正式 PASS（28/68）。
- 证据等级 `FIXED_SOURCE_CUTOVER_GATE_UNITS_AND_HOST_WIRING_WITH_ADVERSARIAL_PROBES_ONLY`；证据见 evidence/mig03a-first-write-cutover-gate-20261016/root-adjudication.md（165 件，含双方全部 run 记录与探针；排除 basetemp 与探针 data 状态目录）。


## 第179轮：SCN02 R5 边界事实轮（012_1/012_2/007/015，2026-10-16，无仓库改动）

- 范围（事实采集，无仓库改动）：012_1/012_2 `--live` 观察缺口 `BLOCKED/live_observation_unavailable` 与 015 `--allow-write` 拒绝（`write_tier_not_implemented_for_decision_only_strategy`，拒绝先于 SDK/凭据/evidence 目录/网络，写计数 0）逐字节引用 R1+R2 已接受证据（未重跑）；007 新跑两组：`run_runtime.py` 四类历史旗标全部 `unrecognized arguments` exit 2（注册路由拒绝），10 个 `ctp_*_examples/{backtest,live}/run.py` as-invoked 全部 exit 1 `ModuleNotFoundError: backtrader_runtime`——围栏 `parents[3]` 越位（指向不存在的 examples/unified/runtime；正确 `parents[2]` 目标 007_ctp/runtime 存在）+ sys.path 插入 D:/source_code 而非 checkout root，由 iteration43 重定位 `db5ad2b21` 引入；补充环境（追加 repo root）下证实设计内拒绝完好（`PRESET_POLICY_VIOLATION(legacy_cli_arguments_not_supported / runtime_not_registered)`、in-process `legacy_direct_execution_not_supported`）。
- 裁定：事实轮不构成 SCN02 正式 PASS（评分留 R7）；007 围栏越位登记工作线 #50（R7 修复+裁定）。全部运行零写、零网络、无凭据读取；porcelain 与 11 入口 blob 前后一致；014_2 目录未触碰。
- 证据等级 `FACTS_ONLY_ZERO_WRITE_CITED_AND_FRESH_CAPTURES_WITH_LEGACY_FENCE_DEFECT_FLAGGED`；证据 D:/temp/it10scn02-r5-20261016-r1（86 件）→ 归档 evidence/scn02-r5-boundary-facts-20261016/（report.md + 根裁定 + 99 汇总）。
## 第180轮：REG04 多 worker 归属隔离（增量1 宿主级越权拒绝 + 增量2 AFI 真实双 worker 链，2026-10-16）

- 范围（纯测试新增，无生产改动；无既有文件被修改）：`tests/unit/test_service_reg04_worker_isolation.py`（新增 4 节点：spawned ServiceHost/真实 CURVE 上双 worker 与策略 claim 共存、第二策略 run DUPLICATE_ACTIVE_RUN、账户写/未知 book SCOPE_DENIED、无 TrustedGroupReservationPolicy 拒绝且零 handler 调用、monitor 转交错 scope/route/actor 全拒绝且合法冻结恰一次）；AFI 仓 `src/backend/tests/test_service_read_reg04_workers.py`（新增 2 节点：真实 uvicorn/生产 lifespan 双 app 进程 + 手工书 + 策略 run 同 Execution owner，恰一次派发/归属 durable 断言/跨会话单人工 book scope）。
- 验收：增量1 collect-only 4 collected；run2/run3 exit 0「4 passed」（4.74s）；run4 并发生产改动后复核「4 passed」（4.92s）；run1 修前失败原样保留。增量2 r9 同源 runner + 6 根冻结 PYTHONPATH + 8 env unset：2148 pins 重算一致；collect-only 2 collected；run1「2 passed」（60.86s）、run2「2 passed」（57.86s）；sources/heads 前后不变（AFI `794eab0c`）；失败尝试（syntaxerror/scopeassert/approvedcount）原样保留。
- 独立复核 GO×2（`.codex-tmp/reg04-incr1-review-status.md`、`.codex-tmp/reg04-incr2-review-status.md`）：两轮各自独立复跑全绿、哈希/pins 全对、真实机具逐项核验、无 skip/xfail/删断言。
- 条款映射（正式迭代计划.md:747）：多 worker 不占策略单活名额、actor 与策略/人工 book 归属分离、Monitor 转交不扩权、服务间越权预留拒绝 = 覆盖（宿主级 + AFI 真实链）；策略/人工 book 无双份额度 = 覆盖（披露 2）；旧 ID 映射 = 未实现未测。
- 披露（不阻塞）：(1) 增量1 worker 在策略 claim 存续期仅注册/续期、不提交订单（隔离性质为注册面）；(2) 增量2 账户簿 E/R 残差投影未挂载于该 owner fixture，无双计断言取最强可得机具（gate.reserved 每接受操作恰一次 + 组预算单 RESERVED + 单人工 book scope + journal/provider 恰一次）；(3) 节点2「adapter 未构造」为代码序推断、节点4 intruder 依赖 caller_bindings 身份检查；(4) 证据裁剪照实：仅排除运行 basetemp scratch 与运行期 SQLite 数据/锁文件（32 件）。
- 裁定：两增量 GO 并提交；旧 ID 映射（recon §3 INCR-3）既未实现也无 scope 决定 → PASS 前置未满足，**REG04 保持部分，28/68 不变**。
- 提交：AFI `e9c7ca1d`（父 `794eab0c`，1 file +1297）；父仓 `6448381f`（测试 1 文件 + 证据归档 132 件）。证据见 evidence/reg04-worker-isolation-and-afi-dual-worker-20261016/root-adjudication.md。

## 第181轮：MIG01-R2 破断矩阵 re-home（2 模块转绿 + 2 模块按设计保持红，2026-10-16）

- 范围（纯测试改动，无生产改动）：`tests/bt_api_contract/test_operation_dispatch.py`（sha `e9b670bb…`：`_direct_api()` 换真实 `BtApi(debug=False)` + RecordingBackend double；12 参数路由/旧撤单/显式能力失败节点断言逐字节保留）与 `tests/bt_api_contract/test_environment_guard.py`（sha `3beb5c45…`：3 节点落到文件既有 `direct_factory`，zmq 残差引用清零）；T3/T4 两模块（`test_execution_session.py`/`test_gateway_runtime_unknown_execution.py`，pins 未动）按设计保持红——需新 wire 的客户端写路径（intent/ack 投影），精确缺口报告随证据归档，转绿归属计划 wire round。
- 验收：rehomed r1/r2 各 exit 0「64 passed, 1 skipped」（determinism pair True）；collect exit 0；targets-and-regression exit 1 = 恰为预期 17 红节点（3 session + 14 gateway，unexpected_failures []），653 passed/20 skipped；残差扫描 168 hits/36 files → 166 hits/35 files（guard 文件消失、dispatch 1→2 为显式退役引用）；sources/heads 不变。
- 独立对抗复核 GO-with-disclosures（`.codex-tmp/mig01-r2-review-status.md`）：哈希起点/终点一致、断言逐字节保留、无新增 skip/xfail/mask、4 项 wire 缺口声明独立探针全部证实无一证伪；新鲜复现 pair 64P/1S + 红恰 3F/14E=17 节点；残差 delta 独立重算一致；序列化合规（等待外来 runner ~100s、0 kill）。披露：2 节点改显式退役断言（R1 已 GO 同类模式）；`_retired_zmq_api()` docstring「verbatim」措辞 nit（新增 `{"SIM___SPOT": {}}` 为防御性强化）；653 聚合与 R1 基线未由复核重跑。
- 条款映射（正式迭代计划.md:782）：MIG01 条款完整满足仍缺 wire 增量（正常安装/调用不依赖旧目录已由 R1+R2 覆盖；客户端写路径缺失即 T3/T4 红因）；本轮不新增正式 PASS。
- 裁定：两 re-home 模块 GO 并提交；MIG01 保持部分，28/68 不变。
- 提交：父仓 `1d01facb`（2 测试文件 + 证据归档 81 件）。证据见 evidence/mig01-r2-contract-matrix-rehome-20261016/root-adjudication.md。

## 第182轮：DIM01 遗留测试收养（risk `f56af2b`，2026-10-16）

- 背景：第160轮 DIM01 收尾遗留未提交新测试 `tests/test_trade_identity_claims.py`（878 行 9 节点，sha `c0d977ce…`，docstring 明确 DIM01 trade-identity declaration/mode binding/atomic occupancy；DIM03 独立复核曾登记 FOREIGN 保持不动）。收养先例 `ee189896`。
- 收养验证：`git archive e2bedb3` 提取（＝已提交风险生产态），测试文件放入后仅 `tree/src` PYTHONPATH + C:/anaconda3/python.exe 运行：EXIT=0「9 passed, 1 warning in 3.11s」，junit 9/0/0/0（唯一 warning 为 pyproject 未知配置键，无害）；工作区文件 sha 与运行件一致。→ 与已提交生产（DIM01 latch + 域占用）完全兼容，无未提交依赖。
- 提交：risk `f56af2b`（仅测试文件；DIM04 未提交 WIP `admission.py` 与 `.codex-tmp/` 原样保留）；父仓 `6f1b73dc` 更新 gitlink `e2bedb3 → f56af2b` + 证据归档 4 件。DIM01 保持正式 PASS，不新增 PASS（28/68）。
- 证据见 evidence/dim01-leftover-test-adoption-20261016/root-adjudication.md。


## 第183轮：DIM09 Step-2 SDK 三腿 v3 wire 闸门 + host 五节点（2026-10-16）

- 范围：`bt_api_py/service_execution_group.py`（sha `d6b37ccf…`：S1 v3 三腿白名单 `_parse_request` :797-839、S2 `_submit_declared_version` :1906-1921、S4 replay :613-658、S5 binding :592-602）、`service_group_reservations.py`（S7 成员 1..3 :661-662）、`service_execution_group_client.py`（S9 `AcceptedGroupBinding.__post_init__` :105-106、`_normalize_members` :1099-1100）；新增 `tests/integration/_dim09_three_leg_fixtures.py`（1064 行）+ `test_dim09_three_leg_group_service.py`（523 行，5 节点：三腿 PAIRED+残差(0,0,0)+预算 HELD、第二腿拒→第三腿零派发、第三腿 UNKNOWN+owner/协调器重启不重发、CFG06b 门拒零派发、S1/S2/S7/S9 白名单 fail-closed 负例）。
- 验收：作者轮 run-1「56 passed」47.50s + run-2「56 passed」49.92s + collect 56，全 exit 0；145 pins 三变体一致、sources/heads 不变；独立复核 GO-with-disclosures（起止 13:03:57/13:12:02 哈希一致、新文件单独 5 passed 10.18s、7 模块套件 56 passed 47.09s、S1/S2/S4/S5/S7/S9 wire 探针全证实、S6 与 HEAD 字节一致、无证伪）。
- 裁定：GO 提交（`c41843db`，52 件 +3825/-34 含归档）；DIM09 保持部分——v3 生产报价构建器拓宽（execution 仓 `group_budget.py:48` 仍拒绝 version!=1，真实 v3 请求 fail-closed 为 GROUP_BUDGET_QUOTE_INVALID）为 Step-1 follow-up，未落地前 DIM09 不进入收口轮。正式 28/68 不变。
- 披露（随裁定）：CFG06b r1 receipt 确认被取代（3 个 pin 文件 live 与旧 receipt 不同）→ **CFG06 正式轮必须重建 spec**；复核期一次 6s 探针与外来 python 突发重叠（bounded 120s wait、无 kill）；`_replicated_v3_quote` 偏差 immaterial；`_normalize_members` >3 成员负例仅代码级核对。
- 证据：evidence/dim09-step2-three-leg-wire-20261016/root-adjudication.md（author-r1/ + review-r1/，66 件 381K；裁剪 pytest-tmp/basetemp/sqlite/lock/pycache）。

## 第184轮：REG04 正式 PASS——INCR-3 scope 决定（旧 ID 映射转记 MIG03）+ 独立对抗审计（2026-10-16）

- 范围：REG04 验收轮。按 recon §3 INCR-3 路径 2 采用显式记录的 scope 决定（evidence/reg04-worker-isolation-and-afi-dual-worker-20261016/scope-decision-old-id-mapping.md，sha256 `ee1c673f…`）：旧 strategy_id→新 ref/book/账户键 显式迁移映射的**构建**归 MIG03 线（正式迭代计划.md:426/:854/:784），REG04 的映射**证据责任**（不产生双份额度）由已验收闸门承担——精确 scope 键（同 ref 第二 run→DUPLICATE_ACTIVE_RUN，`6448381f`/`e9c7ca1d`）与 MIG03 incr-A 首写后拒绝回退闸门（`f0731ec2`，fail-closed）；边界（改名不同 ref 无直接测试）显式披露。
- 独立对抗审计（acceptance-audit-r1/audit.md，sha256 `e1eb30bd…`，只读、未执行 python）：结论 GO-with-disclosures——引文逐行核对相符、四类证伪尝试均未成立；判定「split 仅在显式记录 scope 决定 + 披露随案时成立」，强制披露 4 点以原文引录进 addendum。
- 修正（提交前、同一提交）：片段(b) 补回「业务」；:784 引文改为全引文并以 ｜ 标注表格单元界；「EXE03（轮 67/76 已接受）」改为「轮 76 正式接受；轮 67 为组件轮、明确未 PASS」；(e) 行闸门作用域与边界披露对齐。
- 裁定：REG04 正式 PASS，累计 **29/68**；root-adjudication-addendum.md 载审计原文披露与验收轮核对结论；MIG03 义务已同步记入汇总 MIG03 行（MIG03 仍部分）；P0 组合「AFI 双 worker + 人工 book」登记簿记未发现载体（检索迭代10文档与 evidence），列待办、不阻塞。
- 同轮并行提交：LOAD01 r4 运行时修复 `336203d2`（service_runtime 续期超时单次重试 +15/-0、新测试 357 行 4 节点；独立复核 GO-with-disclosures——pre-fix 副本证伪修复必要性、r2 重叠 1s 以 r3 串行为准）；Backtrader BT-V2 fresh-process 恢复 `be07a50ed`（btapibroker +108、strategy/adapter +1/+1、新集成测试 1738 行；独立复核 GO——1 passed/169.31s、4 文件哈希相符、run10 证伪 revert、恰一次派发与 callback ACK 复现）。
- 证据：evidence/reg04-worker-isolation-and-afi-dual-worker-20261016/（root-adjudication-addendum.md、acceptance-audit-r1/audit.md、scope-decision-old-id-mapping.md，均随本轮提交）。

## 第185轮：DIM04 增量1——可平量归属台账与绑定平仓预留守卫（2026-10-16）

- 范围：DIM04（正式迭代计划.md:776）增量1。risk 子仓 `adb6ec5`：admission.py +432/-5——新增版本化 `risk_closable_positions`(+`_versions`) 每策略可平量声明台账（同版本同事实幂等/异事实 ValueError/历史重放拒绝，与 DIM03 保证金池同构）、`risk_reservations.close_position_version` 归属列与 `idx_risk_reservations_close_attribution` 索引（additive guarded ALTER）、6 个 fail-closed 错误码（CLOSE_POSITION_UNCONFIGURED / UNIT_MISMATCH / QUANTITY_EXHAUSTED / USAGE_UNAVAILABLE、SELF_TRADE_CONFLICT、STRATEGY_CLAIM_UNRESOLVED）、三个 API（`set_closable_position` / `get_closable_position` / `release_strategy_unclaimed`）；仅全绑定平仓（REDUCE 带 strategy_id+instrument+quantity+unit）入台账，legacy 无绑定 REDUCE 语义逐字不变；预留在前、不平他人仓（per-strategy used<=declared）、claimed 行不过期、晚到 settle 永久消耗、批量撤单只动本策略未认领行且未解决 claim 时拒绝；无新账户动词。父仓 `b06815a1` 更新 gitlink。
- 验收：新 `tests/test_dim04_close_reservations.py`（`065ceb57…`，7 节点）作者 r1/r2 7 passed ×2；回归 114 passed（7/63/15/16/10/3）；独立复核 GO——admission.py 三方字节一致（`ea43a9b3…` == live == source-before == source-after）、diff `55fc6b60…` +432/-5 与证据逐字节一致、t6 以运行期 head-source 证明执行 HEAD 代码（HEAD 库无新表 vs worktree 库有新表/列/索引）、无 mock/xfail/弱化断言；10 条非实质披露（status 行 HEAD 误记 e2bedb3、错误码优先级 SELF_TRADE_CONFLICT>UNCONFIGURED、get 读路径 raises UNCONFIGURED、snapshot 未 re-export 等）。
- 延期（显式披露，不做假设性达标）：双向（long/short bucket）与今昨仓（close-effect 分解）在 risk 层契约上不可表达（需 intent 侧维度）；组向量平仓、方向感知冲突规则、SDK mapper 接线与真实账户证据另计。DIM04 仍部分，正式 29/68 不变。
- 证据：D:/temp/it10dim04-20261016-r1（作者 r1/r2 原始输出保留）；D:/temp/it10dim04-review-20261016-r1/review.md 与 status `.codex-tmp/dim04-review-status.md`。

## 第186轮：RISK02 翻转——独立对抗审计 GO-with-disclosures 落账（2026-10-16）

- 范围：RISK02（正式迭代计划.md:760）翻转裁定轮；无源码改动。新增 evidence/risk02-pass-flip-20261016/（acceptance-audit-r1/audit.md 审计副本、root-adjudication.md 裁定、acceptance-round-sha256.txt）。
- 验收：独立对抗审计 r1（只读；未运行被测系统）判 GO-with-disclosures——8 片段（TTL/UNKNOWN/部分成交/撤单/重启/汇率/乘数/数据过期）与 3 证据单元（规则链、完整订单观察链、不凭模拟余额）全覆；证伪矩阵无矛盾；残差为披露级。翻转轮锚点复核：`b712a45e`（journal 转移修复恰一行）、`2f9d6a99`（r146）、`b3b2c6d6`（r134）存在；journal `RESERVED→ADMISSION_DENIED` 转移现于 service_risk_order_journal.py:3204 在线。
- 裁定：翻 正式 PASS（4 点披露逐字随落）；披露 3 的「现 HEAD 重跑 r134/r146/r150」不执行（用户规则「不为交付重复已接受 QA」+ 依赖路径等价逐项核验）；后续如实质修改上述路径须重开条款。正式 30/68。
- 证据：D:/temp/it10risk02-audit-20261016-r1/audit.md（sha256 `14ac2eba…`）；副本+裁定+sha256 清单见 evidence/risk02-pass-flip-20261016/。

## 第187轮：DIM09 生产报价构建器 v3 三腿拓宽 + SDK 夹具翻接（2026-10-16）

- 范围：DIM09 Step-1 follow-up。execution 子仓 `f5c0306`：`group_budget.py` 闸门自 `request.version != 1` 改为 `request.version not in {1, 3}`、v3 三腿逐腿走同一可信 registry 链 + `_exact_decimal_sum`；新 tests/test_group_budget_three_leg.py（`9925317f…`，4 节点）。父仓 `16665164`：`_dim09_three_leg_fixtures.py` `f387b950…`→`bbb9f698…`（删 `_replicated_v3_quote` 与 7 死导入，`_budget_binding` 直连 `partial(build_instrument_risk_group_budget_quote, registry=registry)`）；host 测试文件 `0827e05e…` 字节不动；gitlink execution→`f5c0306`。
- 验收：execution 侧 4p + canonical 48p×2；父仓 host 5 passed（exit 0）+ canonical 7 模块 56 passed（exit 0）、145 pins before==after、heads 稳定；grep 证 `_replicated_v3_quote` 零残留、运行期加载 builder 含 `request.version not in {1, 3}`；生产 builder 与旧夹具指纹等价（2063aab4…、gross 608.715、per-leg 202.905×3）。独立复核 GO-with-disclosures（冻结旁路不可达、等价性独立复现）。
- 披露：`GroupBudgetQuote.legs` 注释仍写两腿（非阻塞，未触冻结文件）；tests/test_group_order_entry.py 22 失败为 clean HEAD 既有（与本轮无关）。DIM09 仍部分，正式 30/68。
- 证据：D:/temp/it10dim09-quotewiden-20261016-r1、D:/temp/it10dim09-flip-20261016-r1/（run-host-2、run-canonical-3 主证据；superseded 轮保留+注记）、D:/temp/it10dim09-qb-review-20261016-r1/review.md；`.codex-tmp/dim09-quotewiden-status.md`、`.codex-tmp/dim09-flip-report.md`、`.codex-tmp/dim09-qb-review-status.md`。

## 第188轮：MIG03 incr-B 受控迁移演练（两 epoch 真实进程 + 回退/导入失败负例，2026-10-16）

- 范围（测试侧，生产零改动）：新增 `tests/unit/test_service_migration_drill.py`（sha256 `f5cb6610…`，87816 B，2 节点）。节点一：真实 spawn 进程/ZMQ-CURVE/SQLite 两 epoch 受控迁移——旧 epoch `STALE_EPOCH` 拒绝与重登记、跨进程真实锁 `ORDER_OWNER_ALREADY_ACTIVE` 双 owner 拒绝、UNKNOWN 跨 epoch 不删除、迁移后订单查询/结算/派发/ACK 回读、封存后 `REVERSE_MIGRATION_REFUSED`、改名 wire scope 依 REG04 转记义务被拒且无第二订单分区/无重复额度；节点二：回退窗口与导入失败负例（`CUTOVER_MARKER_CONFLICT`、`INTENT_CONFLICT`、封存前回退、旧部署重启）。
- 验收：run-00（fixture `CLIENT_ALIAS_MOUNT_MISMATCH`×2）/run-01（恰一次真实语义修正：首笔新 epoch 写入 `admission_denied` attempts 0、零 risk 行、quota 守恒、provider {1,0} 不重派）/run-02 原件保留；run-03-final `2passed/15.003s/exit0`、stderr 空、两 observation PASS；回归 6 套 68 tests 全绿 + ruff clean；pins before==after（`service_migration_gate.py 70700cd6…`/`service_host.py 07e95f92…`/`test_service_migration_gate.py afaca97a…`）。
- 独立复核 GO-with-disclosures（`.codex-tmp/mig03b-review-status.md`，零证伪矛盾；披露：无 result.json/stderr.txt、run-01 无 observation JSON 由 run-03 再证、既有脏文件不入提交）。
- 条款映射（正式迭代计划.md:784 + §11.3 :854）：受控迁移与调用计数、双 owner 拒绝、不删除 UNKNOWN、首写后拒绝回旧版、改名不产生第二分区/重复额度闭合于本测试；MIG03 持久映射构建审计待翻转轮 → MIG03 仍部分，正式 30/68 不变。
- 证据：evidence/mig03b-drill-20261016/（root-adjudication.md、review-r1/review.md、run-03-final/、regressions/、pins-before/after.txt、00-INDEX.md、acceptance-round-sha256.txt）。

## 第189轮：MIG01 R3 wire 客户端写路径 + T3/T4 re-home；MIG03 翻转审计 NO-GO（2026-10-16）

- 范围（父仓 SDK 5 文件）：新增 `bt_api_py/_gateway_wire.py`（客户端 DTO 投影 over `bt_api_gateway.command.v1`，严格 `to_dict/from_dict`；`GatewayWireConfig/Client`、`build_intent`〔MT5 lots/CTP contracts/其余 venue 明确拒绝〕、结果归一恰 6 契约键；零 gateway/forwarding import）；`bt_api_py/_direct_backend.py` 可选 `client=` 钩子（None⇒原语义；wire 分支 intent→`_send_command_sync`→ack 归一，失败探 `command_status` 并吞探错，异常文本不投影）；`bt_api_py/bt_api.py` `gateway_wire_config` kwarg（ZMQ 抛错条件 `ZMQ and gateway_wire_config is None`，与旧抛错字节等同）；T3/T4 re-home（仅 import+config kwarg 两 hunk，断言逐字节保留）。
- 验收：T4 `14passed`、T3 节点 `3passed`、combined `17passed/exit0`（恰 17 节点目标）；回归 A 76p+1S、B 64p+1S、C 184p+2S 全 exit0（skip 为禁用插件 autoload 既有工件）；`_normalization.py` 未动；pins before==after；首轮 T4 暴露 `_unknown_outcome` 缺 `execution_unknown=True` 真实缺陷并修复（报告 §3）。
- 独立对抗复核 GO-with-disclosures（`.codex-tmp/mig01-r3-review.md`，零证伪矛盾）：hash 全对、零 gateway import、6 键归一（含运行期抽查）、hunk 逐条核验；独立复现 combined 17p + regA 76p+1S。披露：T4 pre-edit pin `27f30fd7…` 为 recon 旧值不可复现（重构建证明==CRLF(HEAD)+恰两 hunk）；回归 B/C 为生产方证据；真实路由器（R4/R5）、dict-coercion、probe 非 None 行分支无测试。
- MIG03 翻转审计 NO-GO：F1 正向持久映射零实现零断言（§11.3:854；REG04 转记义务仍归 MIG03）→ 不翻转，30/68 不变；已派 incr-C（新文件 only）。
- 证据：evidence/mig01-r3-wire-20261016/（root-adjudication.md、review/、junit×3、pins-post-edit.txt、acceptance-round-sha256.txt、00-INDEX.md）；evidence/mig03-flip-audit-20261016/audit.md。

## 第190轮：ARB02 崩溃前派发负例 + ARB03 零/全成交与对冲部分成交节点（2026-10-16）

- 范围（测试侧，生产零改动）：`tests/integration/test_arb02_group_budget_service.py` +488/−0（`639d4d84…`，3124 行）——`test_all_reservations_submitted_crash_before_first_leg_no_oversell`：全部账户预留提交、account-b 扣留应答、协调器 deadline 前真实 terminate（exitcode≠0 断言，无 TTL 等待）、崩溃后放行应答、重开 PREPARING/RESERVED 双向量未 claim、provider 零副作用、精确 replay 续跑 PAIRED（恰一次 RESERVED→HELD、每腿一次派发、每账户一次写入、pending_holds 空、无 reject/recovery、恰 2 次 reserve RPC）。`tests/integration/test_arb03_dim05_group_partial_fill_service.py` +497/−0（`2f06291d…`，2357 行）——三节点：零成交 REJECTED→CLOSED/`GROUP_CLOSED_NO_EXPOSURE` 无对冲；全成交 2/2→对冲 6→`4.000` 恰一次派发→PAIRED；对冲 cancelled:2→RECOVERY_REQUIRED/`hedge_residual_unresolved` 残差 1。
- 验收：ARB02 producer r1 exit0 `5p/89.122s`（248 pins 一致）+ 独立复核 `5p/83.359s`（零证伪，反平凡性逐条核验）；ARB03 producer r1 exit0 `5p/47.48s`（353 pins 全量复算一致）+ 独立复核 `5p/49.93s`（零证伪，计数器经 provider 台账/risk 向量交叉验证）。
- 披露：ARB02 runner 仅门控 4 仓库 HEAD（execution/risk 由文件 pin 闭包覆盖）；零成交 CANCELLED 不可表达（生产 gate `service_execution_group_proofs.py:2291-2298` 记 UNKNOWN，REJECTED 为可表达形式）；ARB03 节点③ recovery 为 any() 非恰一次；生产方报告 2358 行笔误更正 2357。
- 两组仍部分（合成 provider、账户级拒绝负例/同瞬 SQLite 竞争/跨组合与真实账户矩阵仍缺），正式 30/68 不变。
- 证据：evidence/arb02-crashprefirstleg-20261016/、evidence/arb03-r3-fill-scenarios-20261016/（root-adjudication.md、review/、junit×2、stdout/exit 对、00-INDEX、acceptance-round-sha256）。

## 第191轮：DIM06 venue×订单类型/TIF 不兼容矩阵合同（测试侧，生产零改动，2026-10-16）

- 范围：新增 `tests/bt_api_contract/test_venue_order_type_tif_matrix.py`（sha256 `6f39ed54…`，43 节点）。矩阵覆盖：CTP 市价单 mapper 层 `CapabilityNotSupportedError`（0 提交）；CTP TIF 词表仅 GFD/DAY（GTC/IOC/FOK/post_only 于 feed 拒绝，0 提交）；CTP 订单类型守卫先于 TIF/request-id 分配；OKX 词表 GTC/IOC/FOK + post_only 需 GTC（`InvalidOrderError`，0 请求）；OKX 市价渲染无 `px`；Binance 限价 TIF 透传（无本地闸，NOT-asserted）；registry MAPPERS 含 CTP 前缀回退、未知 venue → None。
- 验收：固定来源 r1 一次性 exit0 `43 passed`（17.4s）、263 pins before==after 字节等同、五仓 heads 不变；R3-自由闭合（261 源探针 + in-test sys.modules 守卫）；stderr 空。独立复核 GO-with-disclosures（零证伪；nit：容器 `get_order_time_in_force()=="GFD"` 恒真、载荷在 wire `TimeCondition=="3"`；smoke#1 原件被覆盖不可复现）。
- 披露：合成 in-process 夹具（无真实账户/网络）；`BT_API_PY_LIGHT_IMPORT=1` 与 repo 版 `bt_api_ctp` PYTHONPATH 注入属环境偏离；Binance 无 TIF 闸、OKX 市价+post_only 无本地拒绝按 NOT-asserted 记录；provider 行为留 VENUE02（正式迭代计划.md:778）。DIM06 仍部分（保证金池归属裁定与会话路径节点另计），正式 30/68 不变。
- 证据：evidence/dim06-tif-matrix-20261016/（root-adjudication.md、review/、junit×2、exit×2、stdout×2、00-INDEX.md、acceptance-round-sha256.txt）；原始目录 D:\temp\it10dim06-tif-20261016-r1、D:\temp\it10dim06-tif-review-20261016-r1。

## 第192轮：MIG03 incr-C 正向持久映射组件（新模块+测试，生产零接线，2026-10-16）

- 范围：新增 `bt_api_py/service_migration_map.py`（sha256 `9267adac…`，560 行，stdlib-only SQLite WAL + `synchronous=FULL`）+ `tests/unit/test_service_migration_map.py`（sha256 `0836aac6…`，372 行，7 节点）。register-only API：五类旧键（strategy_id/symbol/order_id/进程内 run/账户配置）→ 新 ref/book/账户键；同键异目标重注册冲突拒绝（prior 保留）；单行不可变保留（replay 返回原记录、变更被拒）；typed `MigrationMapError` fail-closed。
- 验收：7p/exit0（1.41s）、真实落盘 SQLite + close/reopen 持久断言、冲突路径先留后证、变异分析证明各载荷不变量删除必有断言失败；独立复核 GO-with-disclosures（零交付缺陷证伪；WAL/FULL 独立重开确认；`-p no:asyncio` 下 7p/exit0 复现）。环境级说明：pytest 8.0.0 + pytest-asyncio 0.23.0 在 `-v` 下抛 `AttributeError: 'Package' object has no attribute 'obj'`（未触碰的 gate 模块同样复现，属环境 bug 非本轮缺陷）。
- 披露：组件未接生产调用方（grep 零引用）；「不产生第二份订单分区/双份额度」仅身份授予层语义，端到端订单分区测试仍缺；F2（待对账 journal 级保留）/F3（seal 无生产调用方）不变；MIG03 翻转复审（§11.3:854）需在生产接线或明确组件级裁定后另轮执行。正式 30/68 不变。
- 证据：evidence/mig03c-map-20261016/（root-adjudication.md、review/、junit×2、exit×2、stdout×2、00-INDEX.md、acceptance-round-sha256.txt）；原始目录 D:\temp\it10mig03c-map-20261016-r1、D:\temp\it10mig03c-review-20261016-r1。

## 第193轮：CFG06 正式 PASS 翻转（r2 固定来源 8 节点组合 3 矩阵，2026-10-16）

- 依据：缺口审计（`D:/temp/it10cfg06-gap-audit-20261016-r1/audit.md`）判 GO-with-disclosures，前置=在最终字节执行 r2 正式固定来源轮；root 采纳审计建议 2(a) 将 `tests/unit/test_service_portfolio_analytics_control_plane.py`（6 节点）并入节点集（8 节点）。
- 执行：builder 重建 spec（新 id `iteration10-cfg06-qa-20261016-r2`、输出目录事先不存在断言通过）；冻结 runner 一次性执行（无重试）`D:\temp\it10cfghost-formal-20261016-r2`——exit 0、`65 passed, 2 warnings in 40.87s`、junit 65/0/0/0、147 pins before==after（`7d7e373c…`）、五仓 heads 运行期定格（父 ee3b05c2=MIG01-R3 14:07:46）、stderr 0 字节、combo3 历史易飘节点 `..._admitted_group_reaches_paired_and_gate_is_not_public` 7.955s 真过。
- 独立翻 PASS 裁定（`.codex-tmp/cfg06-flip-adjudication.md`）：GO——35 核点全相符、零阻断；磁盘 147/147 复算 0 失配；spec 两副本 sha `e680476d…` 逐字节同；冻结 runner sha `8b7f470b…`；时间线自洽（command 14:10:06.54 → junit ts +40.864s → finished 14:10:48.19）；运行后 round-190 提交 e12a2880 与 pins 交集仅 1 文件且字节未变（注记随账本）。措辞级修正：stderr 实为 0 字节（比宣称更干净）；heads unchanged 限运行窗口内；builder exit 0 以 spec 哈希/runner 断言/status 互证。
- 落账：CFG06 → 正式 PASS；**正式 31/68**；六点披露块（含 analytics 8 节点措辞）+ 裁定级 round-190 注记随账本。
- 证据：evidence/cfg06-formal-r2-20261016/（spec.json、runner.py、source-before/after.json、result.json、junit.xml、stdout/stderr、exit/command/running、review/×3、root-adjudication.md、00-INDEX.md、acceptance-round-sha256.txt）。
## 第194轮：当前正式状态净零校正（ARB03 PASS、MIG04 重开、DIM02 保持待验，2026-10-16）

- 当前正式 PASS 为 31/68：CFG01–CFG06、REG01–REG04、MON01–MON03、TRN01–TRN03、GW01–GW04、EXE01–EXE04、RISK01–RISK03、MIG02、AFI07、DIM01、ARB03。相对第193轮新增 ARB03、撤回 MIG04，净变化为零。
- ARB03 按正式计划第769行正式 PASS。第164/190轮既有固定来源 QA 与独立审计覆盖条款场景；复核还确认有界 RECOVERY_REQUIRED、持久残差及订单/费用/占用/Risk 交叉证据，不以 any() 为唯一依据。见 evidence/resume-formal-reconciliation-20261016/dim02-arb03-independent-audit.md。
- MIG04 当前 PASS 重开：原日志 evidence/mig04-release-combo-20261016/logs/02c-build-certlib.log 记录 certlib build exit 1；消费者 venv 从 Backtrader archive extraction 导入，不是 wheel/sdist 安装，不能满足计划第785行的发行安装证据。第161轮历史裁定与原始包保留；最少下一步是提供可安装发行包并补对应安装/入口验收。
- DIM02 仍 HOLD：按第774行，缺同 open_time 冲突 bar 被生产 Backtrader consumer 实际消费并 fail-closed 的证据；真实 per-key heads 的测试侧稀疏链 join 已足以作投影 oracle，不另要求生产聚合器。最少下一步为固定来源的 SDK-to-Backtrader 冲突消费集成节点。见同目录独立审计。
- 新 evidence 目录保存两份原样只读审计副本及待 Root 核验稿。未改正式计划、产品源码或历史证据，未运行 QA/Host/账户；docs/AGENTS.md 的 active-document 生成检查不适用于本轮计划/状态记录。固定导出 LOAD pilot 使用 repositories={}，本次 docs-only 更新不影响该运行条件。当前未暂存、未提交。
## 第195轮：迁移标记跨进程原子性

SDK/dev：共享状态锁保护读取和四种迁移状态变化，消除 stale rollback/arm 覆盖及 Windows 读写竞争。首次7节点6通过1失败，修复后受影响新文件7通过、exit0、284 pins不变；原始失败和成功均保留。仅marker组件，MIG03仍部分，正式31/68不变。证据见[evidence/mig03-marker-atomicity-20261016/root-adjudication.md](evidence/mig03-marker-atomicity-20261016/root-adjudication.md)；提交SHA见本记录Git历史。

## 第196轮：AFI资金账本公开投影

AFI/dev `30797a3901060b7476ce5717d9ae218e5cd54c8d`：资金/费用/成本缺失和独立cut接入组合API/页面，保留账户总额不重复累计。Root后端2项、前端2项通过；类型检查仅修正fixture字面量后通过，已通过QA未重复。合成HTTP/组件证据，AFI02/03仍部分；正式31/68。证据 [afi-financial-projection-20261016](evidence/afi-financial-projection-20261016/round-record.md)。

## 第197轮：certlib独立wheel/sdist安装

Backtrader/dev `223d5b68a55bb167e2d310f9565b511093b01742`：新增最小发行配置。Root真实构建wheel/sdist、两个fresh venv离线安装、两个installed普通dry入口全部exit0，七模块来自site-packages，无网络/客户端启动。只修复certlib发行安装子项，待新增consumer组合兼容检查后裁定MIG04；正式31/68。证据 [certlib-package-20261016](evidence/certlib-package-20261016/round-record.md)。

## 第198轮：ARB01 正式验收

第158/152/190轮、CFG06 r2 与 GW02 既有接受证据共同闭合账户共享、账户/组越权、歧义路由和行情去重条款。四处历史源变更逐项语义核对，未重复 QA。ARB01 → 正式 PASS，当前32/68；ARB02仍待账户Risk确定拒绝负例。SDK/dev 提交哈希见本记录Git历史；证据 [arb01-formal-acceptance-20261016](evidence/arb01-formal-acceptance-20261016/root-adjudication.md)。

## 第199轮：DIM02生产冲突消费正式验收

Backtrader/dev `7a9c4453556a3c5d703d6b114d75aa2177f0659c`：真实SDK/CURVE→Store/Feed拒绝同open_time冲突bar且原投影不变，Root r2 1passed/13.43s/834pins不变/正常cleanup。r1初始化夹具失败保留。结合第176轮接受证据，DIM02正式PASS，当前33/68。原始两轮字节见 [dim02-production-consumer-20261016](evidence/dim02-production-consumer-20261016/root-adjudication.md)；SDK/dev归档提交见Git历史。

## 第200轮：MIG03生产写尝试屏障

现有SDK/dev三处生产接线及新边界测试：Root 12passed/1.75s/285 pins和HEAD不变，标记不可读和持久性重试不确定均先拒绝handler；稳定deployment epoch独立于进程epoch。只接受本机组件，完整MIG03仍部分，正式33/68。范围、限制与原始QA见 [本轮记录](evidence/mig03-write-attempt-barrier-20261016/root-adjudication.md)，提交SHA见Git历史。

## 第201轮：LOAD01 relay租约修复与r5性能失败

只接受运行器4行维护修复；实际112子进程ready后进入负载、租约仍健康。r5因已发送orders.cancel在5秒内无匹配应答失败，120秒pilot未完成、1800秒未启动；109次强制终止且112个记录PID复核无残留。下一步有限同message-id分段计时定位请求队列/handler/reply，不提高timeout或减负载。正式33/68不变。详见 [本轮证据](evidence/load01-relay-lease-r5-20261016/root-adjudication.md)，SDK/dev提交见Git历史。

## 第202轮：ARB02正式验收

新账户级拒绝链Root r3 1passed/10.84s/250pins与四HEAD不变，真实三Host/CURVE/SQLite，typed拒绝、A精确未派发释放、零provider调用、重启持久拒绝及新组预算复用。合并R144/R152/R190接受ARB02 formal PASS，34/68。r1/r2夹具错误保留；仅提交新test+证据/状态，SDK/dev提交见Git历史。见 [正式裁定](evidence/arb02-account-rejection-20261016/root-adjudication.md)。

## 第203轮：AFI授权/cut组件及AFI02正式验收

AFI/dev `0c8aa93c1ca83363f13bd2128d40808b481e9e61`接受live成员授权和独立账户cut披露，4新节点及修复fixture后的API1/Host2通过；失败原件保留，不重复已通过4项。逐条合并R110/R114/R116/30797a39，接受AFI02 formal PASS，当前35/68，AFI01/03仍部分。详见 [正式裁定](evidence/afi-auth-cuts-formal02-20261016/root-adjudication.md)，SDK本轮归档提交见Git历史。

## 第204轮：Backtrader 行情对齐修复与 BT01/BT02 正式验收

Backtrader/dev `edfb4ddb64ee42e0d1f90d7a111def63447ccd67` 已提交四路径，修复 tick 对应 quote/bar 的错位。Root R2 unit通过沿用，R3新正常 Store/Feed/Cerebro/Broker/Host 节点1passed/13.76s、819pins及五HEAD不变；R1/R2原失败保留。结合R82/R107/R120/R122/R184已有接受证据，BT01/BT02正式PASS，当前37/68。合成provider，不承诺任意回调exactly-once；详见[裁定与原始档案](evidence/bt01-bt02-store-feed-formal-20261016/root-adjudication.md)。SDK本轮五个文档/证据路径，提交SHA见Git历史。

## 第205轮：Execution 组恢复有界分页组件

Execution/dev `cb66b480b5cc9a2d56ab5c27f9cc6c9f87a81a2e`，Root 17passed/1.38s/exit0/零warning/139pins及两HEAD不变。新增稳定游标分页与真实SQL LIMIT，旧API不变；后续owner tick需接入并空页回绕，本轮不宣称自主恢复或DIM09完成，正式仍37/68。先提交子包再更新父gitlink；详见[证据](evidence/execution-recoverable-page-20261016/root-adjudication.md)，SDK提交SHA见Git历史。

## 第206轮：MIG03映射Store原子批量注册组件

SDK/dev：`bt_api_py/service_migration_map.py` 增加批量预检与单事务注册，新增 `tests/unit/test_service_migration_map_batch.py`。Root固定QA 5 passed、exit 0、stderr空，175个来源pin以及SDK父仓/`bt_api_base` HEAD运行前后稳定；仅接受 `LOCAL_SQLITE_BATCH`。此Store不证明旧新身份关系经核验或获授权，不是生产迁移；未实现importer。MIG03仍部分，F2 journal保留/F3生产首写封存仍待验，正式37/68不变。证据见[evidence/mig03-map-batch-20261016/root-adjudication.md](evidence/mig03-map-batch-20261016/root-adjudication.md)。

## 第207轮：LOAD01 cancel RPC 遥测合同固定来源验收（2026-10-16）

SDK/dev 父提交 03394ac3e37795f3f0e17a2f92effabd601affed。仅接受遥测合同的固定源码 fake QA：两个新节点 2 passed in 2.07s、pytest exit 0、零 warning、stderr 为空，3,726 个来源 pin 前后不变。导入闭包来自 D:\temp\iteration10-load01-telemetry-unit-source-20261016\source 与六个固定 package src 根；它不是 Git worktree。runner 和新测试均为显式 overlay，未误记为从冻结提交直接生成。独立 review 的初始 HOLD 与修正 GO 均保留，最终候选与 QA 精确 pin 见本轮 manifest。

本轮证据等级为 SOURCE_FAKE_RPC_TELEMETRY_CONTRACT_ONLY，不是 LOAD01 PASS；正式验收计数仍为 37/68。100 策略、10 owner、20 topic、行情 200 Hz、cancel 2 Hz、5 秒 RPC、30 秒 lease、120 秒 pilot、1,800 秒 full 及业务重试策略均未降低或改变。上一 r5 实际 pilot 仍为 CHILD_FAILED，原输出和失败裁定未修改；该 pilot 未完成 120 秒，full run 未启动。本轮未运行负载。待 Root 审查后按既定流程提交本轮 runner、合同测试与三份证据，再由 Root 串行安排新的固定来源 pilot。证据目录：[load01-rpc-telemetry-20261016](evidence/load01-rpc-telemetry-20261016/root-adjudication.md)。

## 第208轮：Risk离线投资组合数值指标组件（2026-10-16）

Risk/dev 6c81653e2a586f47c17cba5f898f23a247b1905d（父 adb6ec58308149faa93c02920b72f98ac3796056）增加基于严格类型化输入的 V1 离线现货净/总暴露、最大回撤、historical-loss VaR/ES 与现货价格/FX 情景函数。价格收益率 -100% 归零，更低的价格因子拒绝，FX 因子保持严格为正；报告记录验证过的共同 UTC cut。Root 唯一次固定源 QA 16 passed/0.52s/exit0，stderr 空、无 warning，137 pins 及 Risk/Base HEAD 前后不变；独立增量静态审查对当前源 pins 返回 GO_STATIC。证据等级 OFFLINE_SUPPLIED_FACTS_NUMERIC_METRICS_ONLY，不证明 FX 来源、账户完整性、SDK/AFI 接线或 AFI04 通过；正式仍 37/68。详见 [R208 裁定](evidence/risk-portfolio-metrics-20261016/root-adjudication.md)。父仓本轮按 ce1b678389456ed8e2b13a1bc710abeacb22605a 作为预期 parent，五路径交付未暂存或提交。


## 第209轮：DIM06 venue TIF 本地拒绝增量（2026-10-16）

Binance/dev 7d2270ceac3fa6ff2c41e5b8776bdd47ae01526 与 OKX/dev fb24657f4b7aa4834935c3dd0c819c1c51f9358f 分别提交单一 venue 源码和本轮记录；两提交范围各 2 路径、index 为空。SDK Root 固定来源节点 21 passed / 1.36s / exit 0，零 warning、stderr 空；221 个来源 pin 与运行时绑定的四仓 HEAD 前后不变。测试覆盖 Binance endpoint-scoped LIMIT TIF 本地拒绝与支持邻例、原生 SWAP GTD 日期，以及 OKX market+post_only 本地拒绝与合法邻例；正常 provider 边界为 synthetic request spy，无真实 provider/account/credentials/network。原始 spec/result 中 preparation-time evidence_level 的 UNEXECUTED 字段按字节保留，实际执行结果由 raw-evidence.zip 内的 exit/JUnit/stdout/stderr 和 result 字段证明。证据包：evidence/dim06-tif-guards-20261016/，raw-evidence.zip SHA-256 c3b5ef3c2aec8c1fa59a2b5f68015a372c64bd0c9ab3aba803bc072eb3ad2615，manifest.json SHA-256 4ea3fd459bf38c1605d446b96863ccf4f1d7eace30b2c66d6a73f0fe492438af，root-adjudication.md SHA-256 f25f5b261ed41fc38101cac2dcb4798f9404cb79ba3532e4f787dfe45c221013。
本轮仅接受 DIM06 本地 TIF 合同增量，不满足 DIM06 完整条款；R163/R191 留下的保证金池归属裁定与三个 session-path 节点仍待处置。DIM06 保持部分，正式总数 37/68 不变。

## 第210轮：MIG03 只读快照到映射目录的原子批登记

SDK 现有 dev 在父提交 `0302917dd50184a74cfa8d66c5e597cec904984c` 交付 importer、聚焦测试及三项证据。实际提交哈希以本记录 Git 历史与 `.codex-tmp/iteration10-r210-postcommit.json` 为准。

源 Execution v23 以只读事务读取指定 scope 的 records/outbox；行数、字段与总字节有界，五类 crosswalk 完整验证后通过既有 MapStore 单次事务登记。订单确认绑定真实 record_observation 事件字段、scope、状态、数量/均价，UNKNOWN 不推定成交；缺失或矛盾证据拒绝且目录不部分写入。

Root R1 的17项全部因夹具漏传 writer lease 失败，原始结果保留。仅修夹具使用实际 ManagedExecutionFacade 租约后，R2 17 passed / 3.71s / exit0，90个源码 pins 和 SDK/base/Execution HEAD 前后不变，stderr为空。独立静态复核覆盖 importer 与修夹具前版本，最终夹具由 Root R2 实测覆盖；没有重复已接受的 MapStore 5项检查。证据见 `evidence/mig03-map-importer-20261016/round-record.md`。

本轮仅接受映射导入组件：fence receipt 仍是调用者引用，源库与目录库不构成跨库原子事务，目标 catalog 不替代运行时授权。完整 MIG03 切换仍未通过，正式计数保持37/68。

## 第211轮：MIG04 固定发行组合正式验收

Root 汇总 R161 原发行组合、R197 certlib sdist/wheel 隔离安装和消费者 R9 最后一步成功结果，裁定 MIG04 正式 PASS，37/68 → 38/68。指定组合限 Windows/Python 3.11.5 与冻结 Binance wheel，当前未进入 wheel 的新开发不继承此结论。R9 exit0、stderr 空，同一消费者 site-packages 来源已核对；steps01–05 与旧构建未重跑，旧 HOLD 和 probe 事实完整保留。

交付范围：`evidence/mig04-formal-acceptance-20261016/` 三份证据及本进度、状态汇总，共5路径。Root 核对16项外部引用和45项ZIP payload；归档原字节保留。仓库/分支 `D:/bt_api_py` / `dev`，parent `937350b138ea952a14e1ab08539dc295efb1d0a4`；实际提交 SHA 见本轮 Git 历史及 `.codex-tmp/iteration10-r211-postcommit.json`。具体条款、发行版本矩阵与边界见该目录 `root-adjudication.md`。

## 第212轮：DIM06 保证金模式增量与正式验收

真实 BtApi readiness/venue normalizer、合成末端 feed 的9个节点一次运行全部通过，exit0，1条既有pytest配置warning，stderr空，17 source pins不变。runner 在 pytest 后封装报告时缺 `evidence_level` 报错；原结果不改写，Root additive reconciliation 单独核验原 JUnit/exit/来源，不补造 result.json，也不重跑。

结合 R163/R189/R191/R209 的既有证据，DIM06 的 adapter 合同及本地故障验证条款闭合，正式38/68 →39/68。真实provider归VENUE02，margin-pool归DIM03；本条不新增它们的完成声明。交付新增测试、3份证据、本进度及状态汇总，共6路径。仓库/分支 D:/bt_api_py / dev，parent `ebd6c1feb64dbabecfa401f128696349de7c7541`；实际提交 SHA 见 Git 历史及 `.codex-tmp/iteration10-r212-postcommit.json`。

## 第213轮：MIG01 旧 Gateway/BT 入口退役

SDK GatewayClient 的旧入口现明确抛出迁移错误，并在加载旧运行模块前拒绝；Root新增2项检查通过。Backtrader对应入口退役已先提交 dev `38f764dbf2d51adcba4c6a0901734639096365a3`，保留direct路径与私有CTP隔离。BT覆盖来自 R2 的88项通过与 R3修复夹具后的2项通过，共90个唯一用例，非一次90项全绿；R1 collection及R2失败原件保留。

本轮仅SDK四路径、三份证据和本进度共8路径；不改变独立BT仓库gitlink。MIG01旧目录/消费者/依赖整体清理仍未完成，正式维持39/68。

证据：`evidence/mig01-entry-retirement-20261016/`。仓库/分支 D:/bt_api_py / dev，parent `ab6d343c258e778e0cb275527f28792e5c59dfdd`；实际提交 SHA 见 Git 历史及 `.codex-tmp/iteration10-r213-postcommit.json`。归档中的创建时 pending 字段不改写，交付事实由本记录及postcommit收据建立；没有为归档重复已接受QA。

## 第214轮：AFI04 四项指标 V2 与独立服务进程

Risk子仓已提交 `dc30c1c118cf587538150fc5016c8956e30c60a9`：V2 typed facts/request/report、敞口/MDD/VaR-ES/stress四项指标、分数据集缺失/陈旧状态与V1兼容。Root单位及兼容6passed/1.11s，真实独立Risk Host与SDK client进程1passed/5.34s；零warning/stderr，24 source pins不变，正常关闭。使用离线合成输入，无provider/真实账户声明。

本轮更新Risk gitlink、一个SDK集成测试、三份证据及本进度，共6路径。运行中取消、执行deadline和AFI完整产品入口尚待补齐，AFI04仍部分；正式维持39/68。

证据：`evidence/afi04-portfolio-analytics-v2-20261016/`。仓库/分支 D:/bt_api_py / dev，parent `d8ca80226d94d2625a0f80759d0782858e2c4df1`；实际提交 SHA 见 Git 历史及 `.codex-tmp/iteration10-r214-postcommit.json`。归档中的创建时 pending 字段不改写，交付事实由本记录及postcommit收据建立；没有为归档重复已接受QA。

## 第215轮：LOAD01 submit/cancel 超时诊断保留

R6本机pilot失败原件完整保留：两次orders.submit在5秒响应期限内未返回，原cancel-only追踪不足以判定submit瓶颈；租约与内存指标无对应失败证据。异常清理记录108次terminate，全部112子进程最终closed，正常关闭未通过，因此不计LOAD01通过。

修复仅负载runner诊断：按精确请求ID捕获submit/cancel、在慢清理前先发送失败快照、父端有界非阻塞排空现有Pipe；保持100策略/10账户/20topic/200Hz/2Hz、5秒业务timeout及30分钟验收阈值不变。Root新增2项source-fake检查通过，stdout `2 passed, 1 warning in 2.26s`；JUnit独立计时1.929s，既有pytest配置warning如实保留，3723 pins不变。

本轮两测试路径、三份证据及本进度共6路径。下一步仅在无其他Host/QA争抢时运行修复后的120秒pilot，成功后再进行30分钟正式负载；本轮不构成负载验收，正式维持39/68。

证据：`evidence/load01-rpc-telemetry-submit-cancel-20261016/`。仓库/分支 D:/bt_api_py / dev，parent `c4dc07454d109504bca67ec15c737a1333a67cde`；实际提交 SHA 见 Git 历史及 `.codex-tmp/iteration10-r215-postcommit.json`。归档中的创建时 pending 字段不改写，交付事实由本记录及postcommit收据建立；没有为归档重复已接受QA。

## 第216轮：旧 forwarding_config 提前拒绝

旧配置不得随 direct 参数静默降级：BtApi 现在于创建 logger/EventBus/plugin/feed 前拒绝非 None forwarding_config，并保留 backend 防御检查和 ZMQ 原诊断。Root两个新增节点2passed/1.01s/exit0，无warning/stderr，46 source pins及两仓HEAD不变；无旧配置的DirectBackend正常查询/关闭邻例保留，插件初始化是受控叶端。

两源码/测试、三份证据及本进度共6路径提交SDK dev，parent `dfddff7fcc88a3a464757617d295dfb723cd5e88`，实际提交见Git历史及 `.codex-tmp/iteration10-r216-postcommit.json`。证据在 `evidence/mig01-forwarding-config-direct-20261016/`。MIG01整体目录/插件/发行闭包仍待完成，正式39/68。

## 第217轮：共享抵押品域 Risk 核心

Risk dev `71be56e29f867a5a5aaac60331f9eca46c7e09f0` 已提交三路径；跨账户/产品共享域预算、UNKNOWN与SETTLED不双计、revision冻结和隔离时REDUCE/CANCEL/终态释放获得本地SQLite组件验收。Root R1 6passed/1 fixture failed，修正不支持的关键字后R2仅该节点1passed；七个唯一用例分两轮，均147pins/两仓HEAD不变，各一条既有warning。证据 `evidence/dim03-shared-collateral-core-20261016/` 保留原失败。

本地ledger身份不能替代可信composer/部署唯一owner，下一轮接线，DIM03仍部分，正式39/68。父仓仅Risk gitlink、三份证据及进度共5路径；parent `f29db99b3bcee887b75603c5f3f1bce3692023e8`，实际提交见Git及 `.codex-tmp/iteration10-r217-postcommit.json`。

## 第218轮：分析任务独立 worker 与有界回收

Risk dev `ae9075ebd6f2bda2802edcb41a2dc66c859478fc` 提交三路径；V2独立spawn、任务限额/token、取消/deadline、cleanup后CAS终态及EOF修复。Root最终unit R5 6passed/6.32s、独立SDK/Risk Host/worker集成R3 1passed/7.20s，均无warning/stderr，163/345 pins与四HEAD不变。此前R2强制停止、R3/R4失败和process R2 preflight拒绝均保留；源码共同reader修复后验证受影响节点，不为交付重复QA。

仅离线合成事实与本机进程，AFI API/UI未接完，AFI04仍部分，正式39/68。证据 `evidence/afi04-worker-lifecycle-20261016/`。SDK parent `47f43e1ffb6db33bd8e6045b608e34b44920d43a`；本轮Risk gitlink、三份证据及进度共5路径，实际SHA见Git及 `.codex-tmp/iteration10-r218-postcommit.json`。

## 第219轮：跨账户静态预算编译与策略目录兼容

AFI dev `5be2e26c9cbb558187ed4ba7cce622989cb50c0e` 提交编译器、测试及记录三路径；严格金额守恒、单币种/指标、版本引用和成员集合绑定。Root 16passed/0.37s、0skip/0warning，145pins及四HEAD稳定；临时SQLite真实目录API通过。仅offline叶模块组件，未证明正常AFI启动或持续owner授权/激活，AFI05/06仍部分，正式39/68。

证据 `evidence/afi05-06-static-budget-20261016/`。SDK parent `a6f220b9b5bdeae313f7324a86ee7a2c53cd10ee`，本轮三证据及进度四路径；实际SHA见Git及 `.codex-tmp/iteration10-r219-postcommit.json`，不重复已接受QA。

## 第220轮：迁移查询屏障与本机交接

Registry 对 account.read_after 的精确 track_delivery=True 及 risk.snapshot 在handler进入前封存迁移屏障；保守记录写尝试，不声称下游事务已提交。Root R2两个屏障节点通过、同轮集成来源夹具失败；其两个函数AST与本轮源码一致，未重复已接受节点。R7单集成1passed/11.26s、无warning/stderr，372pins及五HEAD不变；验证两Host受控交接、持久状态与映射、UNKNOWN占用/freeze、游标重建及封存后拒绝回退。R6仅Base来源env误绑，R7只修此env和输出目录。

本轮是合成本机同路径交接，尚缺全生产边界/消费者清单及所有迁移类别守恒，MIG03仍部分、正式39/68。SDK parent `b9e70f24d28d9f95fc9242b36a98d9351a9069b7`；registry、integration测试、三证据及本进度六路径，实际提交见Git及 `.codex-tmp/iteration10-r220-postcommit.json`。证据 `evidence/mig03-handoff-query-barriers-20261016/`，R3–R6失败原目录保留，未做账户/provider操作。

## 第221轮：策略组合监控的只读 SDK 入口

新增 Strategy-only `broker.group_monitor` 挂载，要求 portfolio_ref，只注册 `monitor.read_after`；解析、部署映射与 Runtime 均保持策略/组合/run 身份和权限约束。R1 三个拒绝节点通过，正例仅因测试把冻结 mapping/tuple 与 dict/list 比较而失败；R2修正严格逐字段断言后正例通过（JUnit 0.787s；stdout 1.13s），三负例函数 AST 未变且未重跑。两次各301源码pin与SDK HEAD不变，零skip/error/warning，stderr为空。

真实 Runtime/SQLite Registry、合成传输，尚非 ZMQ/Host/Cerebro 完整验收。四个源码/测试、三证据及本进度共八路径提交现有 SDK dev；parent `719a2fe26cc32defc495ea138bce3f11f72ee934`，实际提交见 `.codex-tmp/iteration10-r221-postcommit.json`。证据 `evidence/sdk-strategy-group-monitor-r221-20261016/`。本轮不增加正式计数，仍39/68；下一步由 Backtrader 正常组合入口消费该挂载。

## 第222轮：授权账户观测进入 AFI 组合页面

AFI dev `ac52830cd66c8ca79547db5be56a971906ccef4c` 提交九个源码/测试路径：保留 provider 观测的原币种、时间与覆盖状态，经 ServiceRead worker、正常 HTTP/lifespan 和组合页面显示；缺失/陈旧/失败输入不补零或伪造估值。Root client/API 各1passed，Vue选中1passed/37filtered且vue-tsc通过；最新真实CURVE GatewayHost合成provider→AFI HTTP链R13为1passed/4.75s，一条既有Quandl警告，2772pins/五HEAD不变。正常关闭事实来自通过的测试断言，没有独立close-ack回执；R7及R9–R12失败原件保留。

Root复核43个归档条目，其中42个与原始输出逐字节一致，cleanup-assertions.json明确为源码断言汇总；九个当前路径均绑定R13验收源码。AFI提交后index为空、其他tracked改动保持不变。本SDK轮仅三证据与进度四路径，parent `55104dfa2701c2228410b3f57603a583658b15a3`，实际提交见 `.codex-tmp/iteration10-r222-sdk-postcommit.json`。证据 `evidence/afi03-authorized-account-observation-20261016/`。

FX/mark来源与时间、合约乘数、跨账户偏差和完整估值异常矩阵尚未验收；AFI03仍部分，正式39/68。后续分析任务和managed-paper链以本轮已提交的共享服务接口为基础。

## 第223轮：共享抵押品域的可信 Host 装配

Risk dev `647840a75b2071fcb5b4395f554190afe2fae082` 先提交单路径 instrument resource 映射；SDK将可信资源/账户/共享域绑定在启动注册前核对，缺 owner、遗漏成员/资源、不同ledger和未声明共享池均拒绝。真实本机Host中跨产品两账户共用额度，未声明共享域的隔离账户保留独立限额；授权请求、owner派生订单ID、持久PROOF_READY/ORDER_OBSERVATION和provider回执逐项绑定。

Root R6六个启动拒绝节点通过、两个正例因夹具错误比较原intent与owner派生ID失败；R7修正持久链验证后两个正例通过（3.81s，两条既有Proactor警告），各368pins/五HEAD不变。八个唯一通过节点分两轮；R6原失败保留，六负例函数AST未变且未为归档重跑。证据 `evidence/dim03-shared-collateral-host-20261016/`，27条归档pin及22条原始QA输出复核一致。

本轮四个SDK源码/测试、Risk gitlink、三证据及本进度共九路径，parent `00cd647b57defb533d43eeb8cca16be195d6489e`，实际提交见 `.codex-tmp/iteration10-r223-sdk-postcommit.json`。仅本机合成provider，完整DIM03金融风险条款仍需核对，正式仍39/68。

## 第224轮：单 owner 慢监控消费者与正常排空

修复LOAD01 runner的轮询公平性、清理记录与deadline重检；真实本机一个owner/十scope/独立Monitor短场景R7为1passed/24.06s、一条既有pytest配置警告，7502源码pin不变。40次RPC产生160条source事实，排空前88落库/72待处理，最终160唯一outbox与source一致；两进程normal-close ack、exit0、句柄关闭且无forced terminate。R6只完成32条即因提前15ms调度失败，原证据保留；不能把R6当160条通过。R2已有两unit通过，其函数AST不变且未重跑。

仅一个runner源码、三证据和本进度共五路径；parent `98648af2ea3a24394537c9fbd414fb897fb38f11`，实际提交见 `.codex-tmp/iteration10-r224-postcommit.json`。证据 `evidence/load01-single-owner-slow-sink-r224-20261016/`。该QA repositories为空，不宣称Git HEAD不变；固定运行源以导出哈希为准。本轮仍非100策略/30分钟LOAD01，正式39/68；下一步串行120秒全拓扑pilot，保持原负载和性能阈值。

## 第225轮：Backtrader 组合订单与正常 Cerebro 入口

Backtrader dev `438b127fcff2c0619b13835248ee3ef210cc0728` 已提交六路径，组合adapter经正常Strategy/Broker/Store/Cerebro读取组合状态、持久游标与Monitor outbox；当前为v1双腿，真实Registry/SQLite配合合成coordinator/transport/provider。Root R9主集成1passed/7.312s、一条既有Quandl警告，857pins及六HEAD稳定。复用R3两个ownership通过与R8 boolean-cursor通过，原失败保留；R9严格递归验证冻结mapping/tuple对应的wire树，没有放宽身份/游标断言。

本轮SDK仅三证据与进度四路径，parent `ac12f7c3ba3d642ee9e105c442c6987c78bae5d9`，实际提交见 `.codex-tmp/iteration10-r225-sdk-postcommit.json`。证据 `evidence/bt-p5a-group-cerebro-r225-20261016/`，40归档成员及原QA/postcommit字节已核对。证据级别BT_ADAPTER_CEREBRO_REGISTRY_ONLY；下一轮typed v3三腿和真实Host/CURVE仍待验收，DIM09/SCN02不新增PASS，正式39/68。

## 第226轮：受信预算审批目录与 Risk Host 操作

Risk dev `ede55dec5e8e7ad1c5376969eb54e9933ebf9e85` 提交两路径：预算generation/member目录、受信审批身份与owner确认回执，整代次容量占用、重叠成员及UNKNOWN保留；尚未被admission消费者激活时明确consumer_effective=false。SDK两路径接入13操作/10写操作及可选ConfirmedPolicyStore，保留R221组监控权限和R223共享抵押品装配。

Root R3五unit通过与原Host失败、R4不可变响应夹具失败均保留；R5 Host通过后，本轮R7只验证新源码组合，1passed/1.67s，一条既有Proactor警告，569pins/四HEAD不变。640归档成员及原始QA字节、Risk postcommit回执已核对。证据 `evidence/afi05-06-budget-authority-r226-20261016/`；仅本机合成SDK Host/Risk目录，正常AFI认证HTTP/页面和admission生效仍待补齐，AFI05/06部分、正式39/68。

SDK parent `0ffd260dd782143e02ffde7332f9bc59a67ad948`，本轮两source、Risk gitlink、三证据和进度共七路径，实际提交SHA见Git与 `.codex-tmp/iteration10-r226-sdk-postcommit.json`。已通过的五unit未为交付重复执行。

## 第227轮：MIG01 forwarding writers 与 provider loader 源码闭包（2026-10-16）

Root固定来源顺序轮的原始证据保留在 `evidence/mig01-forwarding-retirement-r227-20261016/raw-evidence.zip`：R3、R4、R5各11个输出文件，包含实际Root执行spec与runner。R3为74 passed/23 failed/1 skipped/21 warnings（exit 1，4603 pins）；R4重跑既有失败节点及一项新增回归，23 passed/1 failed/2 warnings（exit 1，4606 pins）；R5仅重跑R4剩余失败节点，1 passed/0 warnings（exit 0，4607 pins，16个HEAD稳定）。这些是顺序修复与重跑，不是一次98节点全绿运行。

静态 AST 对照证明R3的74个与R4的23个已通过函数，在最终R5导出上的完整函数AST均一致：97/97相同，无缺失或改写；R5通过了最后一个遗留失败节点。跨轮唯一覆盖为98 passed、保留1 skip。不合并成一次测试数量。67个overlay文件（SDK 35、Base 9、14个provider仓库23）逐项SHA-256列于归档的 `source/67-overlay-inventory-r227.json`，当前工作区字节与候选pins匹配。

Root串行提交仍待完成：Base及14个provider子仓提交SHA均为pending，SDK父仓随后gitlink/证据提交也pending；本记录不虚构commit。证据级别仅为本机源码/合成验证，不含Host、账户或真实provider验收。MIG01仍未完整完成：runtime_plugins第二writer、旧目录与发行/隔离安装闭包未闭合；正式用例总数保持39/68。

R227 Root交付核验：15个子包共32路径已各自提交dev，全部子包提交回执和当前HEAD已核对；父仓35个源码/测试、15 gitlink、3证据文件及本记录共54路径。Base为 `cc6036c89c534a17d93e6b793f930c576b4aa960`，完整15项见本轮manifest的root_delivery_verification。父仓实际提交SHA见Git及 `.codex-tmp/iteration10-r227-sdk-postcommit.json`。跨轮98 unique PASS / 1 skip，未重新执行已通过节点，MIG01尚未正式完成。

## 第228轮：已确认组合预算的账户解析器

Risk dev `ccac8818312c1474077c00bfe9d8f12521af39c9` 提交三路径：只读同一SQLite快照的整代次权威预算、确认回执与六字段RiskPolicy解析器及其两项回归。检查账户作用域、成员确认、版本/金额/政策内容绑定，缺失确认拒绝；重开数据库可解析同一权威版本。

Root固定源两节点2 passed/2.36s，无警告、跳过或错误，147输入和三仓HEAD不变。154归档成员与原始raw11字节已核对，证据 `evidence/afi05-06-budget-admission-resolver-r228-20261016/`。仅目录到resolver本机组件接受；consumer_effective=false，实际admission消费、认证AFI HTTP及页面控制尚待完成，正式AFI05/06不增加，仍39/68。

父仓parent `1e79ecfde28e13b95b60ec88b092783564b1ee24`，本轮Risk gitlink、三证据和进度五路径；实际父仓SHA见Git与 `.codex-tmp/iteration10-r228-sdk-postcommit.json`。子包已接受测试末尾的单空行原样保留，除该精确空白外Git whitespace检查通过；未为交付重复QA。

## 第231轮：MIG01 runtime_plugins Gateway旧writer入口退役边界（2026-10-16）

SDK父仓`dev`候选仅修改`runtime_plugins/__init__.py`、`runtime_plugins/gateway_dispatch.py`及定向合同测试。Root固定R2 focused QA一次，5 passed/2.10s、exit 0、无skip/error/warning；18个来源pin及SDK/Base HEAD前后不变。测试明确覆盖旧runtime/factory/submodule入口fail-closed和light-import下的普通包导入边界；没有启动Host、服务链、ZMQ、provider或账户调用。

证据目录`evidence/mig01-runtime-gateway-retirement-r231-20261016/`保存R2完整11项原始输出、Root spec/runner、manifest与本轮记录。证据级别`MIG01_RUNTIME_GATEWAY_WRITER_RETIREMENT_SOURCE_NO_HOST`；不构成wheel/隔离安装或MIG01正式验收。该SDK轮精确提交范围为三源码、三证据及本进度共7路径；验收前parent为`33c381007abcfc437044c67f4c752a788944846d`，实际提交SHA及index检查见`.codex-tmp/iteration10-mig01-runtime-gateway-retirement-r231-postcommit.json`。

MIG01仍未完成：SDK forwarding/Base gateway目录及旧wire发行闭包、五个provider adapter接口迁移、AFI相关Gateway消费者迁移/退役、离线配置转换与普通/ZMQ隔离wheel安装及正常服务入口回归尚待完成。正式用例总数保持39/68。

## 第232轮：DIM03 FX来源值通过共享抵押品Host链

Root固定来源R2的三个DIM03 FX Host节点通过，pytest exit 0，3 passed / 0 failed / 0 skipped，用时3.77秒；保留两条既有Windows Proactor warning，stderr为空。首节点验证20 EUR × 1.5 USD/EUR = 30 USD的持久共享池估值，并绑定授权请求、owner派生订单ID与RiskOrderJournal/provider回执；第二节点验证FX过期时拒绝且零provider写入；第三节点验证FX缺失时Host在registry创建前拒绝启动。

执行仅使用冻结的R223 SDK/Risk运行导出与本轮单测试覆盖；当前dev工作区新增代码不因本轮自动获得运行来源验收。证据级别为本机合成provider/本机Host，不证明真实账户、交易所行为或DIM03完整验收。正式PASS计数保持 39/68，DIM03仍部分。交付范围为一个测试、三份证据和本进度。仓库 `D:/bt_api_py` / `dev`，动态 parent `8e86867d155f3834a3ff6f1ce5d5ec2009c06e74`；实际提交SHA见 `.codex-tmp/iteration10-r232-sdk-postcommit-20261016.json`。

## 第230轮：DIM04 本机自成交 owner-path 场景

Root 在固定 R6 源码导出中运行 `tests/integration/test_dim04_strategy_account_isolation.py`，单节点 1 passed / 10.41s，无 warnings；362 个源码 pin 和六个仓库 HEAD 前后未变。真实 SDK ServiceHost、Risk/journal owner 与 SQLite 路径验证两策略相反 BTC 开仓均以 SELF_TRADE_CONFLICT 拒绝，查询保留 REJECTED 终态且零 dispatch；独立 ETH 意图 FILLED 并恰好 dispatch 一次，两个客户端和 Host 正常关闭。Provider 为本地 synthetic fixture，证据等级为 `LOCAL_SYNTHETIC_PROVIDER_SERVICEHOST_DIM04_SELFTRADE_OWNER_PATH`，不代表交易所/真实账户事实。

R4/R5 已消费失败原样保留；R6 只接受 DIM04 自成交冲突与 owner 保留场景，不代表 DIM04 完成，也不增加正式计数，当前仍为 39/68。R230 证据见 `evidence/dim04-strategy-account-isolation-r230-20261016/`。

## 第233轮：LOAD01启动波次固定源验收（2026-10-16）

Root在直接解压的七个冻结R5源码ZIP（parent `e08da3c58cb3b3b040f7799642de38523bbd3229`及六个精确gitlink）上完成R4固定源单节点QA：`tests/unit/test_load01_hundred_strategy_30min.py::test_load01_ten_strategy_twenty_topic_startup_wave_stays_healthy_and_closes`，stdout为1 passed / 1 warning in 28.48s，JUnit 1 test、0 failure/error/skip、case 25.123s；仅有既存`asyncio_default_fixture_loop_scope`配置警告，stderr为空。QA记录3717个来源pin，执行前后字节映射相同；spec的repositories为空，因此不声称HEAD稳定。candidate runner SHA-256为`507191ed6a4a678dd12f7a4089e4620bc9227487c2d5fff93367548acafa5b68`（319548字节），与运行spec及前后来源快照一致。独立静态审查结论GO_STATIC_ONLY，确认wave ready barrier、既有波次续租维护及负载/资源/时限门槛未弱化。R3的PYTHONPATH错指R2失败记录保留；R4将cwd、rootdir和六个PYTHONPATH根统一绑定R3导出。

验收范围仅是一组10策略/20 topic的本机Host/runtime启动波次与正常关闭断言，不是100策略120秒pilot、1800秒full profile、真实账户或LOAD01正式PASS；正式仍39/68。原始Root输出11文件已逐字节封存于`evidence/load01-startup-wave-r233-20261016/raw-evidence.zip`；同目录manifest及adjudication记录原始pin、源码来源和边界。Root的pytest PID为65436，但QA输出未保存11个Host/strategy子PID，因此没有独立的逐PID OS退出清单。

R233交付范围为runner、raw ZIP、manifest、adjudication和本进度五路径，parent `9e4ab501158cbd87730faa964ae487e6136ffc4a`；当前仅准备了精确scope spec，尚未stage/commit。下一步为R233提交后窄修sustained-load调用点的runner-overlay来源绑定，同时保留严格ZIP归档校验和唯一外部pin；先作无Host固定源preflight，再由Root重采资源并串行启动一次120秒pilot。100策略/10账户/20 topic/200Hz/每账户2订单每秒/5秒RPC/30秒lease/资源阈值/120秒pilot及1800秒full门槛全部保持。

## 第234轮：SCN01 SimNow normal factory fail-closed 源码验收（2026-10-16）

Backtrader dev 已提交 `57c9fc613f263877b08da11eacadcb5a8eaccaad`，parent `438b127fcff2c0619b13835248ee3ef210cc0728`。精确两路径为 certlib/__init__.py 与 test_scn01_simnow_certlib_fail_closed.py；不支持的 transport 与缺失 execution/risk/monitor backend 在 CTP client 导入及 SDK root 解析前明确拒绝，supported direct factory 路径不变。Root 固定来源 QA 为 4 passed / 0 failed、exit 0、0.40 秒；四个来源 pin 和 BT HEAD 前后不变，保留一条既有 pytest 配置 warning。

证据级别为 SOURCE_FAKE_SIMNOW_NORMAL_FACTORY_FAIL_CLOSED_ONLY，不构成 SCN01 正式 PASS，当前仍39/68。未运行 provider、账户、CTP 登录/查询/订单或双机验收。原始 Root 11 文件、manifest 与记录见 evidence/scn01-simnow-certlib-fail-closed-20261016-r1/。SDK 本轮仅提交三份证据和本进度；实际 SDK SHA 由本文件 Git 历史与 .codex-tmp/iteration10-r234-sdk-postcommit.json 查询。

补记 R233：已在 SDK dev `53f33158429f89fd9b4dce83c068056c99d6778f` 提交，实际 parent `d72d4b92ae0e5e44046ba8d08c850f79f4a4e15f`。该轮五路径/原始 pins 与空 index 已验证；历史准备措辞不代表当前未提交。

## 第235轮：MIG03全边界清点与原地交接守恒（2026-10-16）

SDK三候选与AFI两候选源文件固定pin见 `evidence/mig03-boundary-inventory-r235-20261016/manifest.json`。Root分轮复用已通过节点，不是单次汇总运行：R2 9P/6F，R3 4P/2F，R4 nodepath错误未收集/exit4，R5 typed节点2P/2F，R6 AFI守恒1P/SDK集成1F，R7 SDK集成1F，R8只跑SDK集成1P/12.85s/exit0/0 warning，2337 pins与六HEAD稳定；R2–R8原始输出与synthetic pytest-tmp数据库共160成员保存在raw ZIP。失败历史不改写、不重复已通过节点。

本轮增量覆盖8类边界参与者与AFI操作/审批/paper账本、实际本机spawn Host、同路径状态与五类映射readback、旧epoch拒绝、新epoch接管、UNKNOWN/reservation/freeze及金额/持仓/cursor守恒；数据和provider均为合成。groups在本配置经检查记N/A，consumer清单只穷尽fixture；`fence_reference`不是外部provider fence，未独立测试配置变更封窗或read-before-open门禁。最终R8已静态复核为GO：真实ServiceAccountConsumer.poll通过正常read/apply/ack验证server ACK 3后清除pending_ack；五个候选源码pin与manifest一致。原地保留同路径数据，不要求跨库复制/原子提交。MIG03仍部分，正式PASS计数保持39/68。证据 `evidence/mig03-boundary-inventory-r235-20261016/`。AFI两路径已在dev提交 `e4a007a244f8d408bbc098ae0956e19ff07f6088`；SDK本轮精确提交三源码、三证据及本进度，实际SHA与空index核对见 .codex-tmp/iteration10-r235-sdk-postcommit.json。
## 第236轮：AFI analytics HTTP、独立 Risk Host 与面板接线（2026-10-16）

AFI dev `ad9c8dcc7ba6bef1d2cbd915551fe95932e92ee1` 已精确提交18个源码路径，parent `4d11cffaee710e18ea48ee64430c80861aa7d3c2`。共享service-read文件仅提交analytics改动，PortfolioPage保留已接受AFI03并追加面板，其他Paper/AFI09工作区改动保留。修复SDK不可变wire结果到严格业务解析器的转换，以及前端已解包响应被再次读取data的问题。

作者原始后端HTTP到独立Risk Host节点1 passed/9.751s；新增面板4/4通过，定向vue-tsc exit0。Root已核对原始输出和18路径提交blob，未重复通过测试。SDK本轮仅归档三份证据和本进度；包中准备时的基线和未提交措辞作为历史保留，以AFI提交及Root postcommit记录为准。证据为本机合成输入、HTTP/服务与UI组件验收，尚未完成V1历史估值/现金流收益链，AFI04仍部分，正式40/68不变。证据见evidence/afi04-analytics-http-risk-r236-20261016/，SDK提交记录见.codex-tmp/iteration10-r236-sdk-postcommit.json。

## 第237轮：DIM03 集中度与来源绑定 Greeks 维度占用（2026-10-16）

Risk dev `503a0b351e309529a2e863aff9f57d0846d7d9cf` 精确提交五个来源文件，parent `ccac8818312c1474077c00bfe9d8f12521af39c9`。真实 SQLite 预留事务绑定集中度/Greeks 事实、版本与单位，拒绝缺失、过期、不匹配及缺少维度记录的旧占用；默认没有维度限额的兼容路径经静态复核。作者固定源 QA 6 passed / exit0 / 2.61s，142 pins 和三个 HEAD 稳定、stderr 空；Root核对原始 result/JUnit，未重复已通过测试。

SDK gitlink 与三份证据已在 `3549428bab2a500820e47fbc31bdfa7057384408` 提交，parent `3b58addb5d9511d53977c3cc83cf031591ca1302`。证据目录 evidence/dim03-concentration-greeks-r237-20261016/。两仓精确范围、提交blob和空index已验证，相关checkout WIP保留。证据为合成事实/SQLite组件验收；过滤快照完整性、当前持仓重估及CLOSE后维度释放仍未完成，不构成DIM03正式PASS，正式总数仍39/68。

## 第239轮：AFI03 市场输入、独立快照与数据质量正式验收（2026-10-16）

AFI dev `4d11cffaee710e18ea48ee64430c80861aa7d3c2` 已精确提交八路径，parent `e4a007a244f8d408bbc098ae0956e19ff07f6088`；所有提交blob与候选pin一致、index为空、analytics/Paper等未验收改动保留。HTTP正常JWT/lifespan/ServiceRead/MarketData查询构造链使用合成行情叶子，两个新增作者HTTP节点各1pass，UI目标1pass/其余38过滤，先前同产品来源vue-tsc单节点exit0。各轮原始失败结果保留，未重复已通过QA。

结合R110账户间2秒非原子快照偏差、R222账户currency/cursor/session来源，本轮覆盖多币种/合约乘数与单位、FX/价格event/cut/source、完整查询键/指纹、零/缺失/错误/陈旧/覆盖不足及未对账展示。账户总额950 USD未受市场输入混加影响，market_value仍not_calculated，估值另属AFI04。Root逐条裁定及独立静态复核通过；新增正式AFI03，当前40/68。证据和限制见 evidence/afi03-market-inputs-r239-20261016/root-adjudication.md；SDK提交SHA通过本文件历史及 .codex-tmp/iteration10-r239-sdk-postcommit.json 查询。

## 第240轮：AFI 应用进程故障与 owner 隔离（2026-10-16）

作者固定源真实本机进程节点1 passed / 43.72s / exit0，2894个源码pin与七个HEAD前后不变、stderr空，仅一条既有Quandl弃用warning。测试在独立AFI应用A关闭后，保持原策略会话及Execution owner；缺事实意图拒绝，一个合法合成订单成功且provider/session构造各一次，应用B另PID恢复并经HTTP读取两条持久结果，最后正常清理。Root核对原始result/JUnit/stdout及唯一测试pin，没有重复已通过节点。

本轮仅接受应用故障切片，不证明真实provider、Monitor或analytics-worker故障隔离，AFI11仍部分，正式40/68不变。SDK精确提交一个测试、三证据及本进度；原始运行11文件和失败历史引用见evidence/afi11-app-failure-r240-20261016/，实际commit与空index核对见.codex-tmp/iteration10-r240-sdk-postcommit.json。

## 第241轮：AFI 旧 live 下单路径退役与 Paper 回归（2026-10-16）

AFI dev `00cf38fd1dbcd3bd860972bda7f2a4be6f83f138` 精确提交五路径，parent `ac52830cd66c8ca79547db5be56a971906ccef4c`。移除旧raw-ZMQ live订单写路径，AI live请求明确返回service_v2_unavailable/submitted=false；17个保留Paper方法与HEAD的AST一致，已有Paper和订单类型测试保留。独立静态复核GO；作者固定源31/31通过后，仅补回的两种边界测试方法运行6参数例，6/6通过，没有重跑31项。Root核对两组原始结果和精确候选blob；当前Paper/analytics工作区修改均保留。

SDK本轮只归档三份证据和本进度，见evidence/afi10-live-order-retirement-r241-20261016/。旧manager与quote消费者仍待ServiceV2迁移；这是退役组件验收，不构成AFI10正式PASS或运行账户验收。正式40/68不变；SDK实际commit由.codex-tmp/iteration10-r241-sdk-postcommit.json及Git历史查询。
