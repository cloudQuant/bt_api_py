"""Root-only source origin and no-provider guards for the focused component QA."""
import importlib.abc
from pathlib import Path
import sys
import platform
import json
import os
import asyncio
import urllib3  # Root setup: completes local IPv6 capability probe before candidate guard.
DENIED = []
platform.node()  # Preload Windows metadata before candidate subprocess denial.
ROOT = Path(__file__).resolve().parent
EXCLUDED_CTP_NATIVE_IMPORTS = []
class NoCtpNativeBinary(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname == "bt_api_ctp.ctp._ctp" or fullname == "_ctp":
            EXCLUDED_CTP_NATIVE_IMPORTS.append(fullname)
            raise ImportError("CTP native extension excluded from fixed Python-source fixture")
        return None
sys.meta_path.insert(0, NoCtpNativeBinary())
def no_external_calls(event, args):
    if event in {"socket.connect", "socket.bind", "subprocess.Popen", "os.system", "os.exec", "os.posix_spawn", "_winapi.CreateProcess"}:
        DENIED.append(event)
        raise RuntimeError("external operation forbidden in callback component QA")
sys.addaudithook(no_external_calls)
def pytest_sessionfinish(session, exitstatus):
    expected = {
        "bt_api_ctp.ctp.client": ROOT / "ctp/src/bt_api_ctp/ctp/client.py",
        "bt_api_ctp.ctp._ctp_base": ROOT / "ctp/src/bt_api_ctp/ctp/_ctp_base.py",
        "bt_api_ctp.ctp.callback_ingress": ROOT / "ctp/src/bt_api_ctp/ctp/callback_ingress.py",
        "bt_api_py._ctp_credential_binding": ROOT / "bt_api_py/_ctp_credential_binding.py",
        "bt_api_py._ctp_execution_authorization": ROOT / "bt_api_py/_ctp_execution_authorization.py",
    }
    base = sys.modules.get("bt_api_ctp.ctp._ctp_base")
    fallback = base is not None and type(base._ctp) is base._FallbackCtpModule and base.is_ctp_native_loaded() is False
    origins = {name: getattr(sys.modules.get(name), "__file__", None) for name in expected}
    Path(os.environ["CTP_OBSERVATION_QA_OUTPUT"]).joinpath("guard.json").write_text(json.dumps({"origins": origins, "denied_events": DENIED, "excluded_ctp_native_imports": EXCLUDED_CTP_NATIVE_IMPORTS, "ctp_source_fallback": fallback, "guard_scope": "listed process/network audit events and CTP extension import rejection; fixed Python source fallback plus fake API factory, not general OS/native isolation"}, indent=2) + "\n")
    for name, source in expected.items():
        module = sys.modules.get(name)
        assert module is not None and Path(module.__file__).resolve() == source.resolve(), name
    assert fallback and EXCLUDED_CTP_NATIVE_IMPORTS
    ctp_root = (ROOT / "ctp/src/bt_api_ctp").resolve()
    for name, module in tuple(sys.modules.items()):
        if name == "bt_api_ctp" or name.startswith("bt_api_ctp."):
            origin = Path(module.__file__).resolve()
            assert origin.is_relative_to(ctp_root) and origin.suffix == ".py", name

    assert not DENIED, "candidate external operation was denied"
