"""Unexecuted, stdlib-only read-only audit of the R5 synthetic SQLite tail."""

from __future__ import annotations

import hashlib
import json
import sqlite3
import sys
from datetime import datetime
from decimal import Decimal
from pathlib import Path


ROOT = Path(r"D:\temp\afi13-imported-paper-managed-fill-root-r5-20261017")
DB_DIR = ROOT / "pytest-tmp" / "test_nonempty_import_explicit_0"
SOURCE_BEFORE = ROOT / "source-before.json"
RESULT = ROOT / "result.json"
ACCOUNT_ID = "af120000-0000-4000-8000-000000000001"
PAPER_SCOPE_REF = "paper-host-orders-scope-v1"

DB_PATHS = {
    "execution": DB_DIR / "afi12-http-host-execution.sqlite3",
    "app": DB_DIR / "afi13-imported-paper-app.sqlite3",
    "monitor": DB_DIR / "afi13-imported-paper-monitor-outbox.sqlite3",
}
PIN_PATHS = [SOURCE_BEFORE, RESULT]
for _db in DB_PATHS.values():
    PIN_PATHS.extend(Path(str(_db) + suffix) for suffix in ("", "-wal", "-shm", "-journal"))


def file_pin(path: Path) -> dict[str, object]:
    if not path.exists():
        return {"exists": False}
    h = hashlib.sha256()
    size = 0
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            size += len(chunk)
            h.update(chunk)
    return {"exists": True, "size": size, "sha256": h.hexdigest()}


def pin_set() -> dict[str, dict[str, object]]:
    return {str(path): file_pin(path) for path in PIN_PATHS}


def open_readonly(path: Path) -> sqlite3.Connection:
    conn = sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True, timeout=5)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA query_only=ON")
    return conn


def fetch_one(conn: sqlite3.Connection, sql: str, args: tuple[object, ...] = ()) -> dict[str, object]:
    row = conn.execute(sql, args).fetchone()
    if row is None:
        raise RuntimeError("expected synthetic row is absent")
    return dict(row)


def fetch_all(conn: sqlite3.Connection, sql: str, args: tuple[object, ...] = ()) -> list[dict[str, object]]:
    return [dict(row) for row in conn.execute(sql, args).fetchall()]


def dec(value: object) -> Decimal:
    return Decimal(str(value))


def main() -> int:
    before_pins = pin_set()
    checks: list[dict[str, object]] = []

    def check(name: str, ok: bool) -> None:
        checks.append({"check": name, "ok": bool(ok)})

    connections: dict[str, sqlite3.Connection] = {}
    try:
        connections = {name: open_readonly(path) for name, path in DB_PATHS.items()}
        app, execution, monitor = connections["app"], connections["execution"], connections["monitor"]

        app_import = fetch_one(app, "SELECT * FROM legacy_paper_import_receipts WHERE legacy_account_id=?", (ACCOUNT_ID,))
        cutover = fetch_one(app, "SELECT * FROM legacy_paper_cutover_receipts WHERE legacy_account_id=?", (ACCOUNT_ID,))
        account = fetch_one(app, "SELECT * FROM paper_trading_accounts WHERE id=?", (ACCOUNT_ID,))
        orders = fetch_all(app, "SELECT * FROM paper_trading_orders WHERE account_id=? ORDER BY id", (ACCOUNT_ID,))
        positions = fetch_all(app, "SELECT * FROM paper_trading_positions WHERE account_id=? ORDER BY id", (ACCOUNT_ID,))
        trades = fetch_all(app, "SELECT * FROM paper_trades WHERE account_id=? ORDER BY id", (ACCOUNT_ID,))

        source_snapshot = json.loads(str(app_import["source_snapshot_json"]))
        source_sha = hashlib.sha256(str(app_import["source_snapshot_json"]).encode("utf-8")).hexdigest()
        check("legacy snapshot bytes match source digest", source_sha == app_import["source_inventory_sha256"])
        check("legacy source rows remain 1 order / 1 position / 1 trade", (len(orders), len(positions), len(trades)) == (1, 1, 1))
        check("legacy account and source identity preserved", account["id"] == source_snapshot["account"]["id"] == app_import["legacy_account_id"] and account["user_id"] == source_snapshot["account"]["user_id"] == app_import["owner_subject"])
        check("legacy account values match imported source snapshot", dec(account["current_cash"]) == dec(source_snapshot["account"]["current_cash"]) and dec(account["initial_cash"]) == dec(source_snapshot["account"]["initial_cash"]))
        check("legacy order identifiers and state preserved", [r["id"] for r in orders] == [r["id"] for r in source_snapshot["orders"]] and orders[0]["status"] == source_snapshot["orders"][0]["status"])
        check("legacy position identifiers and quantity preserved", [r["id"] for r in positions] == [r["id"] for r in source_snapshot["positions"]] and dec(positions[0]["size"]) == dec(source_snapshot["positions"][0]["size"]))
        check("legacy trade identifiers and fee preserved", [r["id"] for r in trades] == [r["id"] for r in source_snapshot["trades"]] and dec(trades[0]["commission"]) == dec(source_snapshot["trades"][0]["commission"]))

        def canonical_row(actual, expected):
            result = {}
            for key, sample in expected.items():
                value = actual[key]
                if type(sample) is bool:
                    assert value in (0, 1)
                    value = bool(value)
                elif value is not None and (key.endswith("_at") or key.endswith("_time")):
                    value = datetime.fromisoformat(value).isoformat()
                result[key] = value
            return result
        current_inventory = {"schema": source_snapshot["schema"], "account": canonical_row(account, source_snapshot["account"])}
        for category, rows in (("orders", orders), ("positions", positions), ("trades", trades)):
            originals = {row["id"]: row for row in source_snapshot[category]}
            current_inventory[category] = [canonical_row(row, originals[row["id"]]) for row in rows]
        current_json = json.dumps(current_inventory, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        check("full current legacy inventory rehash matches imported source", current_inventory == source_snapshot and hashlib.sha256(current_json.encode()).hexdigest() == source_sha)

        e_import = fetch_one(execution, "SELECT * FROM paper_legacy_import_receipts WHERE source_account_id=?", (ACCOUNT_ID,))
        owner_domain = fetch_one(execution, "SELECT * FROM paper_owner_domains WHERE scope_key=? AND account_key=?", (e_import["scope_key"], e_import["account_key"]))
        e_payload = json.loads(str(e_import["import_json"]))
        domain = json.loads(str(e_import["domain_json"]))
        check("Execution import is ACTIVE imported_legacy", e_import["state"] == "ACTIVE" and e_payload.get("origin") == "imported_legacy")
        check("Execution import preserves source owner and digest", e_import["source_owner_id"] == app_import["owner_subject"] and e_import["source_sha256"] == app_import["source_inventory_sha256"])
        check("Execution import has zero residual and original opening book", dec(e_payload["unallocated_equity_residual"]) == 0 and dec(e_payload["opening_cash"]) == dec(app_import["opening_cash"]) and dec(e_payload["cumulative_fees"]) == dec(app_import["cumulative_fees"]) and dec(e_payload["opening_positions"][0]["quantity"]) == Decimal("1"))
        check("owner domain and imported target hashes match", owner_domain["domain_sha256"] == e_import["domain_sha256"] == app_import["target_domain_sha256"] and owner_domain["execution_domain_ref"] == domain["execution_domain_ref"])
        check("AFI import and cutover are the same confirmed binding", app_import["state"] == "ACTIVE" and cutover["state"] == "ACTIVE" and cutover["source_kind"] == "imported_legacy" and cutover["source_import_receipt_id"] == app_import["id"] and cutover["source_import_generation"] == app_import["generation"] and cutover["source_inventory_sha256"] == app_import["source_inventory_sha256"] and cutover["target_import_sha256"] == e_import["import_sha256"] and cutover["binding_sha256"] == app_import["binding_sha256"])
        check("cutover scope/account/strategy/domain match imported target", cutover["scope_ref"] == PAPER_SCOPE_REF and cutover["account_ref"] == domain["simulation_account_ref"] and cutover["execution_domain_ref"] == domain["execution_domain_ref"] and cutover["strategy_ref"] == domain["strategy_ref"] and app_import["target_scope_key"] == e_import["scope_key"] and app_import["target_account_key"] == e_import["account_key"])

        fills = fetch_all(execution, "SELECT * FROM paper_match_receipts WHERE scope_key=? AND account_key=?", (e_import["scope_key"], e_import["account_key"]))
        events = fetch_all(execution, "SELECT sequence,event_id,intent_id,scope_key,event_type,state,journal_incarnation_id FROM execution_outbox WHERE scope_key=? ORDER BY sequence", (e_import["scope_key"],))
        records = fetch_all(execution, "SELECT * FROM execution_records WHERE scope_key=?", (e_import["scope_key"],))
        check("one immutable managed fill is linked to one FILLED execution record", len(fills) == len(records) == 1 and fills[0]["intent_id"] == records[0]["intent_id"] and records[0]["state"] == "FILLED" and records[0]["dispatch_attempts"] == 1)
        fill = json.loads(str(fills[0]["receipt_json"]))
        check("V2 fill, event, generation, amount and fee agree", fill.get("schema") == "managed_paper_fill.v2" and fill["state"] == "FILLED" and fill["event_id"] == fills[0]["event_id"] and fill["event_sequence"] == fills[0]["event_sequence"] and fill["journal_generation"] == fills[0]["journal_generation"] and fill["intent_id"] == records[0]["intent_id"] and dec(fill["quantity"]) == dec(records[0]["filled_quantity"]) and dec(fill["fee_amount"]) == dec(records[0]["cumulative_commission"]) == Decimal("0.0025"))
        check("execution outbox has unique ordered source events for one intent/generation", len(events) == 4 and len({r["event_id"] for r in events}) == 4 and [r["sequence"] for r in events] == [1, 2, 3, 4] and all(r["intent_id"] == fills[0]["intent_id"] and r["scope_key"] == fills[0]["scope_key"] and r["journal_incarnation_id"] == fills[0]["journal_generation"] for r in events) and events[-1]["event_id"] == fills[0]["event_id"] and events[-1]["state"] == "FILLED")

        monitor_rows = fetch_all(monitor, "SELECT sequence,event_id,data_json FROM monitor_outbox_events ORDER BY sequence")
        monitor_payloads = [json.loads(str(r["data_json"]))["payload"] for r in monitor_rows]
        source_event_ids = [p["source_event_id"] for p in monitor_payloads]
        check("Monitor outbox uniquely projects every Execution event", len(monitor_rows) == 4 and len({r["event_id"] for r in monitor_rows}) == 4 and len(set(source_event_ids)) == 4 and source_event_ids == [r["event_id"] for r in events] and all(p["intent_id"] == fills[0]["intent_id"] and p["journal_generation"] == fills[0]["journal_generation"] and p["source_scope_key"] == fills[0]["scope_key"] for p in monitor_payloads))

        opening = e_payload["opening_positions"][0]
        cash_after = dec(e_payload["opening_cash"]) + dec(fill["cash_delta"])
        fees_after = dec(e_payload["cumulative_fees"]) + dec(fill["fee_amount"])
        quantity_after = dec(opening["quantity"]) + dec(fill["position_delta"])
        average_after = (dec(opening["quantity"]) * dec(opening["average_cost"]) + dec(fill["quantity"]) * dec(fill["fill_price"])) / quantity_after
        check("persisted opening book plus immutable fill reconstructs final ledger", cash_after == Decimal("87.3925") and fees_after == Decimal("0.1025") and quantity_after == Decimal("1.25") and average_after == Decimal("10.004"))

    finally:
        for conn in connections.values():
            conn.close()
    original_result = json.loads(RESULT.read_text())
    check("original failed R5 source-pinned result retained", original_result["pytest_exit"] == 1 and original_result["source_count"] == 3646 and original_result["sources_unchanged"] is True)
    exits = [json.loads(path.read_text()) for path in (ROOT / "runtime-receipts").glob("*process-exit.json")]
    check("five recorded workers closed normally", len(exits) == 5 and all(row["normal_close_ack"] is True and row["exit_code"] == 0 and row["closed"] is True and not row["fallback_cleanup_attempted"] and not row["termination_attempted"] for row in exits))
    after_pins = pin_set()
    check("R5 database/WAL/SHM and source evidence bytes unchanged by read-only audit", before_pins == after_pins)

    report = {
        "schema": "afi13.r5.readonly_tail_audit.v1",
        "execution": "READ_ONLY_ONLY",
        "r5_test_result": "FAILED_BEFORE_TAIL_COMPLETION: fill.fee attribute missing; actual DTO field is fee_amount",
        "checks": checks,
        "all_checks_pass": all(item["ok"] for item in checks),
        "derived_ledger": {
            "cash": str(cash_after),
            "cumulative_fees": str(fees_after),
            "BTC-USDT_quantity": str(quantity_after),
            "BTC-USDT_average_cost": str(average_after),
            "basis": "persisted imported opening book plus the one immutable V2 fill; this is a reconstruction, not a live PaperBook read",
        },
        "source_evidence_pins_before": before_pins,
        "source_evidence_pins_after": after_pins,
        "limitations": [
            "The in-memory replay_monitor tuple is not recoverable from these databases, so its equality is not asserted.",
            "Earlier R5 cutover projection value equality passed, but object identity and the unexecuted after-close ORM readback are not asserted here.",
            "This audit does not repair R5's pytest failure or retroactively turn its exit-1 run into a pass.",
        ],
    }
    print(json.dumps(report, sort_keys=True, separators=(",", ":")))
    return 0 if report["all_checks_pass"] else 1


if __name__ == "__main__":
    sys.exit(main())
