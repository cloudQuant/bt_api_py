from __future__ import annotations
import importlib.abc, importlib.metadata, json, os, socket, sys
from pathlib import Path
BLOCKED_PREFIXES=("zmq","bt_api_transport_zmq","bt_api_py.gateway","bt_api_base.gateway","bt_api_ctp.gateway","bt_api_binance.gateway","bt_api_okx.gateway","bt_api_ib_web.gateway","bt_api_mt5.gateway")
IMPORT_ATTEMPTS=[]
NETWORK_ATTEMPTS=[]
class ImportBlocker(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if any(fullname==p or fullname.startswith(p+".") for p in BLOCKED_PREFIXES):
            IMPORT_ATTEMPTS.append(fullname); raise ModuleNotFoundError("retired gateway or ZMQ runtime blocked",name=fullname)
        return None
sys.meta_path.insert(0,ImportBlocker())
def no_network(*args,**kwargs):
    NETWORK_ATTEMPTS.append("socket"); raise AssertionError("network attempted in local-only retirement smoke")
socket.create_connection=no_network; socket.socket.connect=no_network; socket.socket.connect_ex=no_network
for key in ("BT_STORE_PROVIDER","BT_GATEWAY_ACCOUNT_ID","BT_GATEWAY_COMMAND_ENDPOINT","BT_GATEWAY_MARKET_ENDPOINT"): os.environ.pop(key,None)
import backtrader
import backtrader.stores.btapistore as store_module
from backtrader.stores.btapistore import BtApiStore,BtApiStoreError,LegacyGatewayMigrationRequiredError
prefix=Path(sys.prefix).resolve(); bt_origin=Path(backtrader.__file__).resolve(); store_origin=Path(store_module.__file__).resolve()
assert bt_origin.is_relative_to(prefix),(bt_origin,prefix); assert store_origin.is_relative_to(prefix),(store_origin,prefix)
sdk=__import__("bt_api_py"); base=__import__("bt_api_base")
sdk_origin=Path(sdk.__file__).resolve(); base_origin=Path(base.__file__).resolve()
assert sdk_origin.is_relative_to(prefix),(sdk_origin,prefix); assert base_origin.is_relative_to(prefix),(base_origin,prefix)
construct_calls=[]
def api_factory(**kwargs): construct_calls.append(kwargs); raise AssertionError("retired route reached API construction")
retired_pairs=[("btapi","forwarding"),("btapi","gateway"),("forwarding","direct"),("gateway","direct"),("ctp_gateway","direct"),("mt5_gateway",None),("ib_web_gateway",None),("vendor_gateway",None)]
for provider,backend in retired_pairs:
    try: BtApiStore(provider=provider,backend=backend,api_cls=api_factory)
    except LegacyGatewayMigrationRequiredError as exc:
        assert exc.code=="MIGRATION_REVIEW_REQUIRED"; assert "ServiceClientRuntime" in str(exc); assert "ServiceExecutionSession" in str(exc)
    else: raise AssertionError(f"retired route unexpectedly constructed: {provider}/{backend}")
for env_provider in ("forwarding","gateway","ctp_gateway"):
    os.environ["BT_STORE_PROVIDER"]=env_provider
    try: BtApiStore(provider="ctp",api_cls=api_factory)
    except LegacyGatewayMigrationRequiredError as exc: assert exc.target==f"provider={env_provider!r}",(env_provider,exc.target)
    else: raise AssertionError(f"retired env route unexpectedly constructed: {env_provider}")
    finally: os.environ.pop("BT_STORE_PROVIDER",None)
assert construct_calls==[],construct_calls
try: store_module._resolve_bt_api_client("vendor_gateway")
except LegacyGatewayMigrationRequiredError as exc: assert exc.target=="provider='vendor_gateway'"
else: raise AssertionError("retired resolver unexpectedly succeeded")
mutated=BtApiStore(provider="okx",api=object()); assert mutated.backend=="direct"; mutated.backend="forwarding"
for label,invoke in (("start",mutated.start),("ensure_api_ready",mutated._ensure_api_ready),("create_forwarding_client",mutated._create_forwarding_client)):
    try: invoke()
    except LegacyGatewayMigrationRequiredError as exc: assert exc.target=="backend='forwarding'",(label,exc.target)
    else: raise AssertionError(f"mutated legacy backend reached {label}")
direct_api=object(); direct_store=BtApiStore(provider="okx",api=direct_api)
assert direct_store.backend=="direct" and direct_store.sdk_api is direct_api
class ReadOnlyServiceApi:
    service_read_only=True; exchange_kwargs={"BINANCE___SPOT":{}}
    def __init__(self): self.connect_calls=0; self.disconnect_calls=0; self.write_calls=0
    def connect(self): self.connect_calls+=1
    def disconnect(self): self.disconnect_calls+=1
    def get_balance(self): return {"cash":100.0,"value":100.0}
    def submit_order(self,*args,**kwargs): self.write_calls+=1
service_api=ReadOnlyServiceApi(); service_store=BtApiStore(provider="btapi",api=service_api)
assert service_store.backend=="direct" and service_store._service_read_only is True
assert service_store._ensure_api_ready() is service_api
balance=service_store.get_balance(); assert balance=={"cash":100.0,"value":100.0},balance
try: service_store.submit_order(object())
except BtApiStoreError as exc: assert "read-only service proxy cannot submit orders" in str(exc)
else: raise AssertionError("read-only service Store allowed an order")
assert service_api.write_calls==0
health=service_store.stop(); assert isinstance(health,dict)
assert (service_api.connect_calls,service_api.disconnect_calls,service_store._shutdown_state)==(1,1,"PASS")
source=store_origin.read_text(encoding="utf-8")
needles=("_create_ctp_gateway_wrapper_class","bt_api_py.gateway.client","_gateway_timeframe_str","_apply_env_gateway_overrides")
assert not [n for n in needles if n in source]
assert not IMPORT_ATTEMPTS,IMPORT_ATTEMPTS; assert not NETWORK_ATTEMPTS,NETWORK_ATTEMPTS; assert "zmq" not in sys.modules
installed={d.metadata.get("Name","").lower().replace("_","-") for d in importlib.metadata.distributions()}
for name in ("bt-api-gateway","bt-api-execution","bt-api-risk","bt-api-monitor","bt-api-transport-zmq"): assert name not in installed,name
print(json.dumps({"backtrader_origin":str(bt_origin),"store_origin":str(store_origin),"sdk_origin":str(sdk_origin),"base_origin":str(base_origin),"sys_prefix":str(prefix),"retired_constructor_routes_rejected":len(retired_pairs),"retired_environment_routes_rejected":3,"api_construction_calls_for_retired_routes":len(construct_calls),"mutated_forwarding_entrypoints_rejected":3,"direct_store_backend":direct_store.backend,"readonly_service_balance":balance,"readonly_service_connect_calls":service_api.connect_calls,"readonly_service_disconnect_calls":service_api.disconnect_calls,"readonly_service_write_calls":service_api.write_calls,"readonly_service_shutdown_state":service_store._shutdown_state,"retired_source_needles_absent":list(needles),"forbidden_distributions_absent":True,"zmq_loaded":"zmq" in sys.modules,"blocked_import_attempts":IMPORT_ATTEMPTS,"network_attempts":NETWORK_ATTEMPTS},sort_keys=True))