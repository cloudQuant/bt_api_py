"""Materialize committed public sources plus the four selected round candidates."""
import ast
import hashlib
import io
import json
import subprocess
import tarfile
from pathlib import Path

ROOT = Path('D:/bt_api_py')
META = ROOT / '.codex-tmp/cancel-claim-handoff-root-20261018'
FIXED = Path('D:/temp/iteration10-cancel-claim-handoff-r1-fixed-20261018/source')
OUTPUT = Path('D:/temp/iteration10-cancel-claim-handoff-r1-root-qa-20261018')
assert not OUTPUT.exists() and not (META/'qa-r1-spec.json').exists()
FIXED.mkdir(parents=True, exist_ok=True)
recipe = []
heads = {}
selected = {
    'bt_api/bt_api_execution/src/bt_api_execution/cancellation.py': 'execution/src/bt_api_execution/cancellation.py',
    'bt_api/bt_api_execution/tests/test_cancel_claim_handoff.py': 'execution/tests/test_cancel_claim_handoff.py',
    'bt_api_py/service_execution_risk_cancel.py': 'bt_api_py/service_execution_risk_cancel.py',
    'tests/unit/test_service_execution_risk_cancel_claim.py': 'tests/unit/test_service_execution_risk_cancel_claim.py',
}
selected_raw = {rel:(ROOT/source).read_bytes() for source,rel in selected.items()}
for repo, prefix, paths in [
    (ROOT, '', ['bt_api_py']),
    (ROOT / 'bt_api/bt_api_base', 'base', ['src']),
    (ROOT / 'bt_api/bt_api_execution', 'execution', ['src', 'tests/test_cancellation.py']),
    (ROOT / 'bt_api/bt_api_risk', 'risk', ['src']),
]:
    head = subprocess.check_output(['git','rev-parse','HEAD'], cwd=repo).decode().strip()
    heads[str(repo)] = head
    archive = subprocess.check_output(['git', 'archive', head, '--', *paths], cwd=repo)
    with tarfile.open(fileobj=io.BytesIO(archive)) as tf:
        for item in tf.getmembers():
            if not item.isfile() or not item.name.endswith('.py'):
                continue
            rel = Path(prefix) / item.name
            assert not rel.is_absolute() and '..' not in rel.parts
            raw = tf.extractfile(item).read()
            dest = FIXED / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            assert not dest.exists() or dest.read_bytes() == raw or dest.read_bytes() == selected_raw.get(rel.as_posix())
            if not dest.exists():
                dest.write_bytes(raw)
            recipe.append({'path':rel.as_posix(),'repository':str(repo),'commit':head,'git_path':item.name,'size':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
pins = {}
for source, rel in selected.items():
    raw = (ROOT/source).read_bytes()
    ast.parse(raw)
    dest = FIXED/rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    # Only the selected source overlay may differ from its committed export.
    if dest.exists() and rel not in {r['path'] for r in recipe}:
        assert dest.read_bytes() == raw
    dest.write_bytes(raw)
    pins[str(ROOT/source)] = hashlib.sha256(raw).hexdigest()
(FIXED/'pytest.ini').write_text('[pytest]\nmarkers =\n    unit: local unit acceptance\n',encoding='utf-8')
(FIXED/'cancel_claim_qa_checks.py').write_bytes((META/'cancel_claim_qa_checks.py').read_bytes())
for p in sorted(FIXED.rglob('*')):
    if p.is_file():
        pins[str(p)] = hashlib.sha256(p.read_bytes()).hexdigest()
spec = {
    'python':'C:/Anaconda3/python.exe', 'cwd':str(FIXED), 'output':str(OUTPUT),
    'repositories':heads,
    'source_sha256':pins,
    'environment':{
        'PYTHONPATH':';'.join(str(FIXED/p) for p in ['', 'base/src','execution/src','execution/tests','risk/src','tests/unit']),
        'BT_API_PY_LIGHT_IMPORT':'1','PYTHONDONTWRITEBYTECODE':'1','PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1','PYTHONUTF8':'1',
        'BT_API_LOG_DIR':str(OUTPUT/'logs'),'CANCEL_CLAIM_QA_OUTPUT':str(OUTPUT),
    },
    'unset_environment':['PYTEST_ADDOPTS','PYTEST_PLUGINS','PYTHONPATH'],
    'pytest_options':['-q','--noconftest','--import-mode=prepend','-p','no:cacheprovider','-p','no:debugging','-p','cancel_claim_qa_checks','-c',str(FIXED/'pytest.ini')],
    'nodes':['execution/tests/test_cancel_claim_handoff.py','tests/unit/test_service_execution_risk_cancel_claim.py','execution/tests/test_cancellation.py::test_cancel_provider_failure_after_risk_claim_keeps_permit_fenced'],
    'evidence_level':'LOCAL_REAL_RISK_CLAIM_HANDOFF_AND_READBACK_WITH_SYNTHETIC_PROVIDER_ONLY',
}
(META/'export-recipe.json').write_text(json.dumps(recipe,indent=2)+'\n',encoding='utf-8')
(META/'candidate-pins.json').write_text(json.dumps({k:v for k,v in pins.items() if k.startswith(str(ROOT))},indent=2)+'\n',encoding='utf-8')
(META/'qa-r1-spec.json').write_text(json.dumps(spec,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'public_source_pins':len(pins),'heads':heads,'candidates':{str(ROOT/k):pins[str(ROOT/k)] for k in selected}}))
