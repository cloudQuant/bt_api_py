"""
FastAPI application entrypoint.

Includes API routing, logging, rate limiting, security headers, and WebSocket
streaming for backtest progress updates.
"""

from collections.abc import Callable
from contextlib import asynccontextmanager
from typing import Concatenate, ParamSpec

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from slowapi import _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from starlette.responses import Response
from starlette.types import ASGIApp

from app.api.router import api_router, optional_router_status
from app.api.service_read import configure_service_read
from app.config import get_settings
from app.db.database import ensure_database_ready
from app.main_routes import register_runtime_routes
from app.middleware.exception_handling import register_exception_handlers
from app.middleware.logging import (
    AuditLoggingMiddleware,
    LoggingMiddleware,
    PerformanceLoggingMiddleware,
)
from app.middleware.rate_limit_headers import RateLimitHeadersMiddleware
from app.middleware.security_headers import add_security_headers
from app.rate_limit import limiter
from app.services.service_read.deployment import (
    ServiceReadDeploymentError,
    start_service_read_deployment,
)
from app.services.portfolio_valuation_bindings import PortfolioValuationBindingRegistry
from app.shutdown import GracefulShutdownManager
from app.startup import run_shutdown, run_startup
from app.telemetry import setup_telemetry
from app.utils.logger import setup_logger

settings = get_settings()
logger = setup_logger(__name__)

_MiddlewareArgs = ParamSpec("_MiddlewareArgs")


def _adapt_middleware_factory(
    constructor: Callable[Concatenate[ASGIApp, _MiddlewareArgs], ASGIApp],
) -> Callable[Concatenate[ASGIApp, _MiddlewareArgs], ASGIApp]:
    def create_middleware(
        app: ASGIApp,
        /,
        *args: _MiddlewareArgs.args,
        **kwargs: _MiddlewareArgs.kwargs,
    ) -> ASGIApp:
        return constructor(app, *args, **kwargs)

    return create_middleware


_rate_limit_headers_middleware_factory = _adapt_middleware_factory(RateLimitHeadersMiddleware)
_logging_middleware_factory = _adapt_middleware_factory(LoggingMiddleware)
_audit_logging_middleware_factory = _adapt_middleware_factory(AuditLoggingMiddleware)
_performance_logging_middleware_factory = _adapt_middleware_factory(PerformanceLoggingMiddleware)

APP_DESCRIPTION = """
# ai-for-investor API

ai-for-investor provides authenticated REST endpoints and WebSocket streams for
strategy management, backtests, optimization, portfolio workflows, and
monitoring, with AI-assisted quantitative research workflows.

## Runtime Notes

- Frontend: Vue 3 + TypeScript
- Backend: FastAPI + SQLAlchemy 2.x
- Database: SQLite / PostgreSQL / MySQL
- Long-running backtests are currently launched by the API process, while task
  status is persisted in the database for later queries.

## API Documentation

- Swagger UI: `/docs`
- ReDoc UI: `/redoc`
- OpenAPI Spec: `/openapi.json`
"""


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager."""
    previous_service_read = getattr(app.state, "service_read_deployment", None)
    if previous_service_read is not None and not previous_service_read.closed:
        raise ServiceReadDeploymentError("PRIOR_CLOSE_UNCERTAIN")
    app.state.service_read_deployment = None
    app.state.portfolio_valuation_bindings = None
    configure_service_read(None)
    logger.info("Starting ai-for-investor API...")
    app.state.startup_logger = logger
    app.state.ensure_database_ready = ensure_database_ready
    await run_startup(app, settings)
    service_read_deployment = None
    try:
        app.state.portfolio_valuation_bindings = PortfolioValuationBindingRegistry.from_json(
            settings.PORTFOLIO_VALUATION_BINDINGS_JSON.get_secret_value()
        )
        try:
            service_read_deployment = await start_service_read_deployment(
                getattr(settings, "SERVICE_READ_DEPLOYMENT_JSON", None)
            )
        except ServiceReadDeploymentError as error:
            partial_deployment = error.deployment
            if partial_deployment is not None and not partial_deployment.closed:
                app.state.service_read_deployment = partial_deployment
            raise
        if service_read_deployment is not None:
            configure_service_read(service_read_deployment.directory)
            app.state.service_read_deployment = service_read_deployment

        if settings.RAG_VECTOR_ENABLED:
            try:
                from app.api.rag import get_rag_service

                await get_rag_service().semantic_retriever.warm_up()
            except Exception:
                # The RAG service records a safe diagnostic state and retains
                # lexical retrieval as a fallback; startup must remain available.
                logger.warning(
                    "Semantic retrieval warm-up failed; lexical fallback remains available"
                )
        logger.info("Application ready - accepting requests")
        yield
    finally:
        # Remove request access before draining owner threads.  A second app
        # startup in this process remains unconfigured until its own workers
        # have all completed startup.
        configure_service_read(None)
        app.state.portfolio_valuation_bindings = None
        logger.info("Shutting down ai-for-investor API...")

        try:
            shutdown_mgr = GracefulShutdownManager()
            await shutdown_mgr.initiate(app)
        finally:
            if service_read_deployment is not None:
                try:
                    await service_read_deployment.aclose()
                except Exception:
                    # Keep the owner object attached when cleanup is uncertain
                    # so a later lifespan cannot silently start duplicate owners.
                    app.state.service_read_deployment = service_read_deployment
                    logger.exception("Failed to close the authorized service-read workers")
                else:
                    app.state.service_read_deployment = None

        await run_shutdown(app, settings)

        try:
            from app.services.quote_service import get_quote_service

            get_quote_service().shutdown()
        except Exception:
            logger.debug("Failed to shut down quote service cleanly", exc_info=True)

        # Reset the feature-flags cache so a subsequent in-process startup (e.g.
        # tests, ASGI reload) recomputes flags after router registration rather
        # than serving a stale snapshot. Computed once per process otherwise.
        reset_feature_flags = globals().get("_reset_feature_flags_cache")
        if callable(reset_feature_flags):
            try:
                reset_feature_flags()
            except Exception:
                logger.debug("Failed to reset feature-flags cache on shutdown", exc_info=True)


app = FastAPI(
    title="ai-for-investor API",
    description=APP_DESCRIPTION,
    version="2.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan,
)
app.state.limiter = limiter

# OpenTelemetry instrumentation (opt-in via OTEL_ENABLED=true)
setup_telemetry(app)
register_exception_handlers(app)
add_security_headers(app)
app.add_middleware(_rate_limit_headers_middleware_factory)


def _handle_rate_limit_exceeded(request: Request, exc: Exception) -> Response:
    """Adapt SlowAPI's specific handler to Starlette's broad handler type."""
    if not isinstance(exc, RateLimitExceeded):
        raise exc
    return _rate_limit_exceeded_handler(request, exc)


app.add_exception_handler(RateLimitExceeded, _handle_rate_limit_exceeded)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in settings.CORS_ORIGINS.split(",") if o.strip()],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.add_middleware(_logging_middleware_factory)
app.add_middleware(_audit_logging_middleware_factory)
app.add_middleware(_performance_logging_middleware_factory, slow_request_threshold=0.5)
app.include_router(api_router, prefix="/api/v1")

_route_handlers = register_runtime_routes(app, settings, logger, optional_router_status)
globals().update(_route_handlers)


if __name__ == "__main__":  # pragma: no cover
    import uvicorn

    uvicorn.run(
        "app.main:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=settings.DEBUG,
    )
