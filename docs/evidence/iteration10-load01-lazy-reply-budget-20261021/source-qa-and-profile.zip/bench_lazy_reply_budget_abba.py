"""Bounded fresh-process ABBA profile for the LOAD01 reply-budget candidate.

Requires an explicit ``--root-go`` after Root accepts the candidate correctness
check. The baseline uses the same pinned Host/Registry sources with only the
optional result-budget callback disabled, so the existing full-frame checker
is the sole path difference.
"""

from __future__ import annotations

import cProfile
import asyncio
import gc
import hashlib
import importlib
import importlib.util
import json
import os
import platform
import pstats
import subprocess
import sys
import tempfile
import time
from collections.abc import Mapping
from dataclasses import replace
from pathlib import Path
from statistics import mean, median
from types import SimpleNamespace
from typing import Any


REPO_ROOT = Path(__file__).resolve().parents[2]
CANDIDATE_ROOT = Path(__file__).resolve().parent
RESULT_PATH = CANDIDATE_ROOT / "abba-profile-result.json"
ROOT_HEAD = "fc5d384acc2bcf71e3c256f55fb890d259a4c4c4"
GATEWAY_HEAD = "fd83283ad789a241c432cf8f3f716707acd816d7"
TOTAL_CAP_SECONDS = 300
CHILD_CAP_SECONDS = 30
WORKER_CAP_SECONDS = 25
REPLY_BYTES = 262_144
NEAR_HEAD = 800
SMALL_PAGE_EVENTS = 20
QUARTET_ORDER = ("baseline", "candidate", "candidate", "baseline")

FILE_PINS = {
    # Applied candidate and its source-identical fixture copy.
    "bt_api_py/service_host.py": "4928fb0f12fa62f25a718f3e608399b0ca1d687d6887b2b5a5e1e78bcfb18dd7",
    "bt_api_py/service_registry.py": "298403b4284b25815421bc3896bbfbe97223705a33e5924939c653d3d61ceb27",
    "tests/unit/test_service_market_bounded_reply_integration.py": "a41d460b6461acaf0ffd75a0ada48202f667d62fe29c17ad80f6c42907dd186a",
    # Preserved pre-candidate source used to document the callback-only delta.
    ".codex-tmp/load01-lazy-reply-budget-20261021/baseline/bt_api_py/service_host.py": "46b14c10d10181a00471c39fc1cad15cd724284e18213d8a0cc45f3eae74e546",
    ".codex-tmp/load01-lazy-reply-budget-20261021/baseline/bt_api_py/service_registry.py": "d24f9a20aecdd97d20e9db6cea870834249ff2aa52efbe5386298f32e5f94187",
    # Exact request/topology fixture and runtime dependencies used by this script.
    "tests/unit/test_service_host.py": "36df3e6a58795586f78c722a8c7cbe7b4c15156b4271d0cdbbe06497ceec93f2",
    "tests/unit/test_load01_hundred_strategy_30min.py": "4404ce25b3ef8f6510b9c60b21116d5d1a45240c770c93b7417194136430a173",
    "tests/unit/_load01_profiles.py": "34cd3021017b37e5635c394b7a89cedd97f0e9c9e0cad1a6957711d698c8465d",
    "bt_api/bt_api_base/src/bt_api_base/service_protocol.py": "f0ed739ac98cda400bed07bf8487b79ee0a5ebe6842b9d0711b4b12e8af6b15a",
    "bt_api/bt_api_gateway/src/bt_api_gateway/market_hub.py": "b2c9762fd68f425558173257f04a6ff46ef52467eb28bb82bb339c87c4824a6a",
    "bt_api/bt_api_gateway/src/bt_api_gateway/service_component.py": "87dac9d8f62d271601ca3fa8bb370b46dfe3e812968e5ee7fe87e0b53ae34efb",
    "bt_api/bt_api_transport_zmq/src/bt_api_transport_zmq/service_v2.py": "ee4c143ed23a1cf3c4115bb2f294d347c25e11fe87abb4d46e31e80c0872e7df",
    "bt_api_py/service_components.py": "0bf0cc82e0d882ef3ff43d2dc76cfff91daf253a8db8aa274319ea1c25c9a492",
    "bt_api_py/service_config.py": "1f57e49356aa58fafac3b6ad5f1a4d43e049e2831bade1ebc76d0dd8ca28d386",
    "bt_api_py/service_deployment.py": "33dbe41ed35d8f20a04466fe8cf344ac19ffff748165fa2a5971a5c039c951da",
    "bt_api_py/service_migration_gate.py": "8fdaeed23e74e31c1b360dd6d4139af21805c0322467d7726bf469fceab8020e",
    "bt_api_py/service_runtime.py": "7a7678a63aee766f7a2652dda1e6435a3e4ba4d3e5b36f5ceef11765bd5758ea",
}


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _verify_file_pins() -> dict[str, str]:
    actual: dict[str, str] = {}
    for relative, expected in FILE_PINS.items():
        path = REPO_ROOT / relative
        value = _sha256(path)
        if value != expected:
            raise RuntimeError(f"source_pin_mismatch:{relative}")
        actual[relative] = value
    return actual


def _git_head(path: Path) -> str:
    completed = subprocess.run(
        ["git", "-C", str(path), "rev-parse", "HEAD"],
        check=True,
        capture_output=True,
        text=True,
        timeout=5,
    )
    return completed.stdout.strip()


def _plain(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {key: _plain(item) for key, item in value.items()}
    if type(value) in (tuple, list):
        return [_plain(item) for item in value]
    return value


def _canonical_bytes(value: Any) -> bytes:
    return json.dumps(
        _plain(value),
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8", errors="strict")


def _gc_snapshot() -> dict[str, Any]:
    return {
        "generation_counts": list(gc.get_count()),
        "collections": [int(row["collections"]) for row in gc.get_stats()],
    }


def _gc_delta(before: Mapping[str, Any], after: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "generation_counts_before": before["generation_counts"],
        "generation_counts_after": after["generation_counts"],
        "collections_delta": [
            end - start
            for start, end in zip(before["collections"], after["collections"], strict=True)
        ],
    }


def _load_file_module(name: str, path: Path) -> Any:
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError("candidate_module_spec_unavailable")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    parent_name, _, attribute = name.rpartition(".")
    parent = importlib.import_module(parent_name)
    setattr(parent, attribute, module)
    spec.loader.exec_module(module)
    return module


def _profile_counts(profile: cProfile.Profile) -> dict[str, Any]:
    selected = {
        "result_fits",
        "_fit_read_after_reply",
        "candidate",
        "fits",
        "_normalize_result",
        "service_reply_fits",
        "service_reply_result_budget",
        "encode_envelope",
        "dumps",
    }
    stats = pstats.Stats(profile)
    counts: dict[str, int] = {}
    details: list[dict[str, Any]] = []
    for (filename, line, name), (primitive, calls, self_s, cumulative_s, _callers) in stats.stats.items():
        if name not in selected:
            continue
        counts[name] = counts.get(name, 0) + calls
        try:
            path = Path(filename).resolve().relative_to(REPO_ROOT).as_posix()
        except (OSError, ValueError):
            path = filename
        details.append(
            {
                "path": path,
                "line": line,
                "function": name,
                "primitive_calls": primitive,
                "calls": calls,
                "self_ms": round(self_s * 1000, 3),
                "cumulative_ms": round(cumulative_s * 1000, 3),
            }
        )
    details.sort(key=lambda row: (-row["cumulative_ms"], row["path"], row["line"]))
    return {"calls_by_function": counts, "selected_functions": details[:40]}


def _page_fact(reply: Mapping[str, Any], client: int, topic: int) -> dict[str, Any]:
    plain = _plain(reply)
    result = plain.get("result", {}) if type(plain) is dict else {}
    events = result.get("events", ()) if type(result) is dict else ()
    sequences = [
        event.get("header", {}).get("sequence")
        for event in events
        if type(event) is dict and type(event.get("header")) is dict
    ]
    return {
        "client_index": client,
        "topic_index": topic,
        "code": plain.get("code") if type(plain) is dict else None,
        "ok": plain.get("ok") if type(plain) is dict else None,
        "event_count": len(events),
        "first_sequence": sequences[0] if sequences else None,
        "last_sequence": sequences[-1] if sequences else None,
        "sequence_sha256": hashlib.sha256(_canonical_bytes(sequences)).hexdigest(),
        "next_after": result.get("next_after") if type(result) is dict else None,
        "has_more": result.get("has_more") if type(result) is dict else None,
        "reply_sha256": hashlib.sha256(_canonical_bytes(plain)).hexdigest(),
    }


def _worker(variant: str) -> int:
    started_ns = time.perf_counter_ns()
    deadline_ns = started_ns + WORKER_CAP_SECONDS * 1_000_000_000
    phase = "source_pins"
    host = None
    provider = None
    registry = None
    cleanup_error = None
    try:
        pins = _verify_file_pins()
        sys.dont_write_bytecode = True
        os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
        os.environ["BT_API_PY_LIGHT_IMPORT"] = "1"
        if os.name == "nt" and hasattr(asyncio, "WindowsSelectorEventLoopPolicy"):
            asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
        package_roots = sorted((REPO_ROOT / "bt_api").glob("bt_api_*/src"))
        sys.path[:] = [str(REPO_ROOT), *(str(path) for path in package_roots), *sys.path]

        phase = "load_candidate_and_fixture_modules"
        import bt_api_py

        candidate_registry = _load_file_module(
            "bt_api_py.service_registry", REPO_ROOT / "bt_api_py/service_registry.py"
        )
        candidate_host = _load_file_module(
            "bt_api_py.service_host", REPO_ROOT / "bt_api_py/service_host.py"
        )
        host_fixtures = importlib.import_module("tests.unit.test_service_host")
        load_runner = importlib.import_module("tests.unit.test_load01_hundred_strategy_30min")
        market_fixture = _load_file_module(
            "tests.unit.test_service_market_bounded_reply_integration",
            REPO_ROOT / "tests/unit/test_service_market_bounded_reply_integration.py",
        )
        market_hub_module = importlib.import_module("bt_api_gateway.market_hub")
        from bt_api_base.service_protocol import WireScope
        from bt_api_gateway.market_hub import (
            MARKET_OPERATIONS_WITH_BOUNDED_READ_AFTER,
            MARKET_READ_AFTER_BOUNDED_OPERATION,
            GatewayMarketHub,
        )
        from bt_api_py.service_components import ComponentResources
        from bt_api_py.service_config import parse_service_config

        ctp_modules = sorted(name for name in sys.modules if "ctp" in name.casefold())
        if ctp_modules:
            raise RuntimeError("ctp_module_loaded")

        if candidate_host.ServiceHost is not bt_api_py.service_host.ServiceHost:
            raise RuntimeError("candidate_host_origin_binding_mismatch")
        if candidate_registry.ServiceRegistry is not bt_api_py.service_registry.ServiceRegistry:
            raise RuntimeError("candidate_registry_origin_binding_mismatch")
        if len(load_runner._market_keys("U0")) != 20:
            raise RuntimeError("u0_topic_count_not_20")

        origins = {
            "candidate_host": Path(candidate_host.__file__).resolve().relative_to(REPO_ROOT).as_posix(),
            "candidate_registry": Path(candidate_registry.__file__).resolve().relative_to(REPO_ROOT).as_posix(),
            "candidate_test_fixture": Path(market_fixture.__file__).resolve().relative_to(REPO_ROOT).as_posix(),
            "market_hub": Path(market_hub_module.__file__).resolve().relative_to(REPO_ROOT).as_posix(),
            "host_fixture": Path(host_fixtures.__file__).resolve().relative_to(REPO_ROOT).as_posix(),
            "load_runner": Path(load_runner.__file__).resolve().relative_to(REPO_ROOT).as_posix(),
        }

        setup_started_ns = time.perf_counter_ns()
        phase = "host_and_hub_setup"
        component = host_fixtures._market_hub_component()
        component["settings"]["options"]["bounded_read_after"] = True
        parsed = host_fixtures._service_config(
            {"gateway": component},
            service_id="load01-lazy-reply-budget-abba",
            market_endpoint=host_fixtures._endpoint(),
        )
        raw = parsed.to_public_dict()
        raw["communication"]["profiles"]["listener-v1"]["options"][
            "max_message_bytes"
        ] = REPLY_BYTES
        config = parse_service_config(raw)
        authority, grant_scope = host_fixtures._market_authority(config)
        original_grant = authority.grants[market_fixture._PRINCIPAL][0]
        original_resource = original_grant.resources[0]
        expanded = replace(
            original_resource,
            operations=MARKET_OPERATIONS_WITH_BOUNDED_READ_AFTER,
        )
        authority = replace(
            authority,
            grants={
                market_fixture._PRINCIPAL: (
                    replace(original_grant, resources=(expanded,)),
                )
            },
        )

        market_keys = load_runner._market_keys("U0")
        provider = load_runner._CountedMarketProvider(market_keys)
        hub = GatewayMarketHub(
            provider,
            key_universe=frozenset(market_keys),
            principal_allowed_keys=dict.fromkeys(
                authority.principals.values(), frozenset(market_keys)
            ),
            service_identity=authority.identity,
            service_scope=authority.scope,
            max_replay_events=load_runner._MARKET_REPLAY_EVENTS,
            max_replay_bytes=load_runner._MARKET_REPLAY_BYTES,
            epoch_factory=lambda: "e" * 32,
        )
        provider.hub = hub
        resources = ComponentResources.owned(
            {"hub": hub}, ready=lambda: hub.ready, close=hub.close
        )
        registration_scope = WireScope(
            grant_scope.execution_domain_ref,
            strategy_ref=grant_scope.strategy_ref,
            run_id="load01-lazy-reply-budget-abba",
        )
        with tempfile.TemporaryDirectory(prefix="load01-lrb-abba-") as temp_root:
            host = candidate_host.ServiceHost(
                config,
                authority,
                Path(temp_root) / "service-registry.sqlite3",
                lambda *_args: resources,
            )
            host.start()
            registry = host._registry
            if registry is None or not registry.ready:
                raise RuntimeError("candidate_registry_not_ready")
            original_budget_callback = registry._reply_result_budget_checker
            if not callable(registry._reply_size_checker) or not callable(
                original_budget_callback
            ):
                raise RuntimeError("host_budget_callbacks_not_wired")
            if variant == "baseline":
                registry._reply_result_budget_checker = None
            elif variant != "candidate":
                raise RuntimeError("unknown_abba_variant")
            if (registry._reply_result_budget_checker is not None) != (variant == "candidate"):
                raise RuntimeError("callback_only_arm_selection_failed")

            phase = "register_10_and_subscribe_200"
            identity = host_fixtures._CLIENT_IDENTITY
            registrations = []
            operations = tuple(sorted(MARKET_OPERATIONS_WITH_BOUNDED_READ_AFTER))
            for client_index in range(10):
                if time.perf_counter_ns() >= deadline_ns:
                    raise TimeoutError("worker_deadline:register")
                registration_reply = registry.handle(
                    market_fixture._PRINCIPAL,
                    host_fixtures._request(
                        "service.register",
                        {
                            "registration_key": f"load01-lrb-{client_index:02d}",
                            "client_session_id": f"load01-lrb-session-{client_index:02d}",
                            "instance_id": market_fixture._INSTANCE_ID,
                            "port": "service.market_source",
                            "scope_ref": "market-grant-v1",
                            "operations": operations,
                        },
                        schema_id="sdk.service.control",
                        identity=identity,
                        scope=registration_scope,
                    ),
                )
                if registration_reply.get("code") != "OK":
                    raise RuntimeError("synthetic_registration_failed")
                registrations.append(registration_reply["result"])

            subscribe_count = 0
            for registration in registrations:
                for key in market_keys:
                    if time.perf_counter_ns() >= deadline_ns:
                        raise TimeoutError("worker_deadline:subscribe")
                    subscribed = registry.handle(
                        market_fixture._PRINCIPAL,
                        host_fixtures._request(
                            "market.subscribe",
                            {
                                "registration_id": registration["registration_id"],
                                "service_epoch": registration["service_epoch"],
                                "instance_id": market_fixture._INSTANCE_ID,
                                "arguments": {"key": key.to_dict()},
                            },
                            schema_id="sdk.service.call",
                            identity=identity,
                            scope=registration_scope,
                        ),
                    )
                    if subscribed.get("code") != "OK":
                        raise RuntimeError("synthetic_subscribe_failed")
                    subscribe_count += 1
            if subscribe_count != 200 or len(provider.generations) != 20:
                raise RuntimeError("incomplete_10_by_20_market_topology")

            phase = "seed_u0_600_and_near_head_800"
            uuid_counter = 0
            old_hub_uuid = market_hub_module.uuid

            def stable_uuid() -> SimpleNamespace:
                nonlocal uuid_counter
                uuid_counter += 1
                return SimpleNamespace(hex=f"{uuid_counter:032x}")

            market_hub_module.uuid = SimpleNamespace(uuid4=stable_uuid)
            try:
                schedule = load_runner.load01_profile("U0").topic_publish_schedule()
                if len(schedule) != load_runner._MARKET_HZ:
                    raise RuntimeError("u0_publish_schedule_mismatch")
                publish_start_ns = 1_800_000_000_000_000_000
                interval_ns = 1_000_000_000 // load_runner._MARKET_HZ

                def publish(key, publish_ns: int) -> None:
                    provider.source_sequence[key.stream_id] += 1
                    ordinal = provider.source_sequence[key.stream_id]
                    data, payload_bytes = load_runner.market_payload_data(
                        key, ordinal, publish_ns
                    )
                    provider.source_payload_bytes += payload_bytes
                    provider.source_payload_bytes_by_topic[key.stream_id] += payload_bytes
                    hub.publish(
                        key,
                        data,
                        "2026-10-21T00:00:00Z",
                        generation=provider.generations[key.stream_id],
                    )

                for ordinal in range(600):
                    if ordinal % 50 == 0 and time.perf_counter_ns() >= deadline_ns:
                        raise TimeoutError("worker_deadline:publish_u0")
                    topic_index = schedule[ordinal % len(schedule)]
                    publish(
                        market_keys[topic_index],
                        publish_start_ns + ordinal * interval_ns,
                    )
                near_key = market_keys[0]
                before_head = int(hub.head(near_key)["head"])
                for ordinal in range(max(0, NEAR_HEAD - before_head)):
                    if ordinal % 50 == 0 and time.perf_counter_ns() >= deadline_ns:
                        raise TimeoutError("worker_deadline:publish_near")
                    publish(
                        near_key,
                        publish_start_ns + (600 + ordinal) * interval_ns,
                    )
            finally:
                market_hub_module.uuid = old_hub_uuid

            event_epochs = {key.stream_id: hub.head(key)["epoch"] for key in market_keys}
            near_head = dict(hub.head(near_key))
            oldest = near_head["oldest_sequence"]
            if type(oldest) is not int or int(near_head["head"]) != NEAR_HEAD:
                raise RuntimeError("nearcap_head_or_floor_invalid")
            near_after = oldest - 1
            topic_oldest_by_index = []
            for key in market_keys:
                topic_oldest = hub.head(key)["oldest_sequence"]
                if type(topic_oldest) is not int or topic_oldest < 1:
                    raise RuntimeError("small_topic_floor_invalid")
                topic_oldest_by_index.append(topic_oldest)
            small_after = topic_oldest_by_index[0] - 1
            small_requests = []
            for client_index, registration in enumerate(registrations):
                for topic_index, key in enumerate(market_keys):
                    request = market_fixture._request_read(
                        registration_scope,
                        registration,
                        key,
                        epoch=event_epochs[key.stream_id],
                        after=topic_oldest_by_index[topic_index] - 1,
                        limit=SMALL_PAGE_EVENTS,
                        reply_limit=REPLY_BYTES,
                    )
                    small_requests.append((client_index, topic_index, request))
            near_request = market_fixture._request_read(
                registration_scope,
                registrations[0],
                near_key,
                epoch=event_epochs[near_key.stream_id],
                after=near_after,
                limit=1_000,
                reply_limit=REPLY_BYTES,
            )
            small_warmup = market_fixture._request_read(
                registration_scope,
                registrations[0],
                market_keys[0],
                epoch=event_epochs[market_keys[0].stream_id],
                after=small_after,
                limit=SMALL_PAGE_EVENTS,
                reply_limit=REPLY_BYTES,
            )
            near_warmup = market_fixture._request_read(
                registration_scope,
                registrations[0],
                near_key,
                epoch=event_epochs[near_key.stream_id],
                after=near_after,
                limit=1_000,
                reply_limit=REPLY_BYTES,
            )
            small_profile_request = market_fixture._request_read(
                registration_scope,
                registrations[0],
                market_keys[0],
                epoch=event_epochs[market_keys[0].stream_id],
                after=small_after,
                limit=SMALL_PAGE_EVENTS,
                reply_limit=REPLY_BYTES,
            )
            near_profile_request = market_fixture._request_read(
                registration_scope,
                registrations[0],
                near_key,
                epoch=event_epochs[near_key.stream_id],
                after=near_after,
                limit=1_000,
                reply_limit=REPLY_BYTES,
            )

            def read(request):
                return registry.handle(market_fixture._PRINCIPAL, request)

            setup_elapsed_ns = time.perf_counter_ns() - setup_started_ns
            phase = "warmup_outside_timing"
            warmup_started_ns = time.perf_counter_ns()
            if read(small_warmup).get("code") != "OK":
                raise RuntimeError("small_warmup_failed")
            if read(near_warmup).get("code") != "OK":
                raise RuntimeError("nearcap_warmup_failed")
            warmup_elapsed_ns = time.perf_counter_ns() - warmup_started_ns

            phase = "wall_timing"
            gc.collect()
            small_gc_before = _gc_snapshot()
            small_started = time.perf_counter_ns()
            small_replies = [read(request) for _client, _topic, request in small_requests]
            small_elapsed = time.perf_counter_ns() - small_started
            small_gc_after = _gc_snapshot()

            gc.collect()
            near_gc_before = _gc_snapshot()
            near_started = time.perf_counter_ns()
            near_reply = read(near_request)
            near_elapsed = time.perf_counter_ns() - near_started
            near_gc_after = _gc_snapshot()

            phase = "output_fingerprints_and_exact_boundary_oracle"
            small_rows = [
                _page_fact(reply, client_index, topic_index)
                for reply, (client_index, topic_index, _request) in zip(
                    small_replies, small_requests, strict=True
                )
            ]
            if len(small_rows) != 200 or any(
                row["code"] != "OK" or row["event_count"] != SMALL_PAGE_EVENTS
                for row in small_rows
            ):
                raise RuntimeError("small_page_matrix_invalid")
            small_raw = dict(
                hub.read_after(
                    market_keys[0],
                    epoch=event_epochs[market_keys[0].stream_id],
                    after=small_after,
                    limit=SMALL_PAGE_EVENTS,
                )
            )
            small_raw["events"] = tuple(
                market_hub_module._envelope_mapping(event)
                for event in small_raw["events"]
            )
            small_exact_fit = market_fixture._reply_fits(
                authority.identity, small_requests[0][2], small_raw, REPLY_BYTES
            )
            if small_exact_fit is not True:
                raise RuntimeError("small_full_page_exact_fit_failed")

            near_row = _page_fact(near_reply, 0, 0)
            near_result = near_reply.get("result", {})
            if near_reply.get("code") != "OK" or not isinstance(near_result, Mapping):
                raise RuntimeError("nearcap_reply_failed")
            near_full = dict(
                hub.read_after(
                    near_key,
                    epoch=event_epochs[near_key.stream_id],
                    after=near_after,
                    limit=1_000,
                )
            )
            near_full["events"] = tuple(
                market_hub_module._envelope_mapping(event)
                for event in near_full["events"]
            )
            full_count = len(near_full["events"])
            prefix_count = len(near_result["events"])
            retained_count = int(near_head["head"]) - int(oldest) + 1
            if full_count != retained_count or not 0 < prefix_count < full_count:
                raise RuntimeError("nearcap_did_not_return_strict_nonempty_prefix")
            expected_prefix = market_fixture._prefix(near_full, prefix_count)
            next_prefix = market_fixture._prefix(near_full, prefix_count + 1)
            first_prefix = market_fixture._prefix(near_full, 1)
            prefix_matches = _canonical_bytes(near_result) == _canonical_bytes(expected_prefix)
            fit_actual = market_fixture._reply_fits(
                authority.identity, near_request, near_result, REPLY_BYTES
            )
            fit_full = market_fixture._reply_fits(
                authority.identity, near_request, near_full, REPLY_BYTES
            )
            fit_first = market_fixture._reply_fits(
                authority.identity, near_request, first_prefix, REPLY_BYTES
            )
            fit_next = market_fixture._reply_fits(
                authority.identity, near_request, next_prefix, REPLY_BYTES
            )
            if not prefix_matches or fit_actual is not True or fit_full is not False:
                raise RuntimeError("nearcap_exact_output_or_full_boundary_invalid")
            if fit_first is not True or fit_next is not False:
                raise RuntimeError("nearcap_winner_or_next_prefix_boundary_invalid")

            phase = "separate_profile_count_pass"
            profile_counts = {}
            for label, request in (
                ("small_one_page", small_profile_request),
                ("nearcap_head_800_page", near_profile_request),
            ):
                if time.perf_counter_ns() >= deadline_ns:
                    raise TimeoutError("worker_deadline:profile")
                profile = cProfile.Profile()
                profile.runcall(read, request)
                profile_counts[label] = _profile_counts(profile)

            ctp_modules = sorted(name for name in sys.modules if "ctp" in name.casefold())
            if ctp_modules:
                raise RuntimeError("ctp_module_loaded")

            result = {
                "status": "COMPLETE",
                "variant": variant,
                "phase": "done",
                "source_pins": pins,
                "source_origins": origins,
                "ctp_modules_loaded": ctp_modules,
                "topology": {
                    "synthetic_clients": len(registrations),
                    "accounts": 0,
                    "topics": len(market_keys),
                    "subscription_refs": subscribe_count,
                    "small_page_requests": len(small_requests),
                    "small_page_events": SMALL_PAGE_EVENTS,
                    "nearcap_page_requests": 1,
                    "nearcap_head_sequence": near_head["head"],
                    "nearcap_retained_events": retained_count,
                    "nearcap_head": near_head["head"],
                    "nearcap_oldest_sequence": oldest,
                    "reply_bytes": REPLY_BYTES,
                    "u0_publish_events": sum(provider.source_sequence.values()),
                },
                "arm": {
                    "optional_result_budget_callback_enabled": variant == "candidate",
                    "full_reply_size_checker_enabled": callable(registry._reply_size_checker),
                },
                "timing": {
                    "host_start_and_data_setup_ns": setup_elapsed_ns,
                    "warmup_ns": warmup_elapsed_ns,
                    "small_200_pages_ns": small_elapsed,
                    "small_ns_per_page": small_elapsed // len(small_requests),
                    "small_gc": _gc_delta(small_gc_before, small_gc_after),
                    "nearcap_head_800_page_ns": near_elapsed,
                    "nearcap_gc": _gc_delta(near_gc_before, near_gc_after),
                    "process_elapsed_ns": time.perf_counter_ns() - started_ns,
                },
                "exact_output": {
                    "small_pages": small_rows,
                    "small_full_page_exact_fit": small_exact_fit,
                    "small_matrix_fingerprint": hashlib.sha256(
                        _canonical_bytes(small_rows)
                    ).hexdigest(),
                    "nearcap_page": near_row,
                    "nearcap_prefix_matches_independent_prefix": prefix_matches,
                    "nearcap_full_result_fits": fit_full,
                    "nearcap_first_event_prefix_fits": fit_first,
                    "nearcap_winner_fits": fit_actual,
                    "nearcap_next_prefix_fits": fit_next,
                },
                "profile_counts": profile_counts,
                "shutdown": {},
            }
            phase = "host_cleanup"
            host.close()
            if host.state != "closed":
                raise RuntimeError("host_normal_close_not_confirmed")
            result["shutdown"] = {
                "host_state": host.state,
                "provider_active_generations": len(provider.generations),
                "provider_stopped_topics": sum(provider.stops.values()),
            }
            if provider.generations:
                raise RuntimeError("provider_generations_remained_after_close")
            result["phase"] = "done"
            result["source_origins"] = origins
            result["status"] = "COMPLETE"
            result["script_sha256"] = _sha256(Path(__file__).resolve())
            result["python"] = sys.version.split()[0]
            result["platform"] = platform.system()
            result["source_parent_commit"] = ROOT_HEAD
            result["gateway_commit"] = GATEWAY_HEAD
            print(json.dumps(result, ensure_ascii=False, sort_keys=True, separators=(",", ":")))
            return 0
    except BaseException as exc:
        result = {
            "status": "HOLD",
            "variant": variant,
            "phase": phase,
            "error_type": type(exc).__name__,
            "source_parent_commit": ROOT_HEAD,
            "gateway_commit": GATEWAY_HEAD,
            "script_sha256": _sha256(Path(__file__).resolve()),
            "elapsed_ns": time.perf_counter_ns() - started_ns,
        }
        if cleanup_error is not None:
            result["cleanup_error_type"] = cleanup_error
        print(json.dumps(result, ensure_ascii=False, sort_keys=True, separators=(",", ":")))
        return 2
    finally:
        if host is not None and host.state != "closed":
            try:
                host.close()
            except BaseException as exc:
                cleanup_error = type(exc).__name__


def _write_report(path: Path, value: Mapping[str, Any]) -> None:
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def _variant_summary(rows: list[Mapping[str, Any]], field: str) -> dict[str, Any]:
    grouped = {
        variant: [int(row["timing"][field]) for row in rows if row["variant"] == variant]
        for variant in ("baseline", "candidate")
    }


def _stream_facts(value: Any) -> dict[str, Any]:
    if value is None:
        raw = b""
    elif isinstance(value, bytes):
        raw = value
    else:
        raw = str(value).encode("utf-8", errors="replace")
    return {
        "bytes": len(raw),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "preview": raw[:512].decode("utf-8", errors="replace"),
        "preview_truncated": len(raw) > 512,
    }


def _worker_json(value: Any) -> dict[str, Any] | None:
    if value is None:
        return None
    raw = value.decode("utf-8", errors="replace") if isinstance(value, bytes) else str(value)
    try:
        parsed = json.loads(raw.strip())
    except (json.JSONDecodeError, TypeError):
        return None
    return parsed if type(parsed) is dict else None
    return {
        variant: {
            "samples_ns": values,
            "median_ns": median(values) if values else None,
            "mean_ns": round(mean(values), 1) if values else None,
            "min_ns": min(values) if values else None,
            "max_ns": max(values) if values else None,
        }
        for variant, values in grouped.items()
    }


def _orchestrate() -> int:
    if RESULT_PATH.exists():
        raise SystemExit("result path exists; preserving it and refusing a repeat")
    if _git_head(REPO_ROOT) != ROOT_HEAD:
        raise SystemExit("parent_head_changed; re-review source pins before profiling")
    if _git_head(REPO_ROOT / "bt_api/bt_api_gateway") != GATEWAY_HEAD:
        raise SystemExit("gateway_head_changed; re-review source pins before profiling")
    pins = _verify_file_pins()
    started_ns = time.perf_counter_ns()
    deadline_ns = started_ns + TOTAL_CAP_SECONDS * 1_000_000_000
    report: dict[str, Any] = {
        "schema_version": 1,
        "evidence_kind": "LOCAL_SYNTHETIC_REPLY_BUDGET_ABBA_PROFILE_ONLY",
        "status": "RUNNING",
        "source_parent_commit": ROOT_HEAD,
        "gateway_commit": GATEWAY_HEAD,
        "source_pins_pre": pins,
        "candidate_source_hashes": {
            "service_host.py": pins["bt_api_py/service_host.py"],
            "service_registry.py": pins["bt_api_py/service_registry.py"],
            "integration_fixture.py": pins[
                "tests/unit/test_service_market_bounded_reply_integration.py"
            ],
        },
        "comparison": {
            "baseline": "same pinned Host/Registry source with only _reply_result_budget_checker=None",
            "candidate": "same pinned Host/Registry source with Host-wired lazy result budget callback",
            "request_bytes": REPLY_BYTES,
            "quartets": 3,
            "order_per_quartet": list(QUARTET_ORDER),
            "startup_and_warmup_timed": False,
            "profile_pass_in_wall_timing": False,
            "account_processes": 0,
            "real_provider_calls": 0,
        },
        "runs": [],
    }
    _write_report(RESULT_PATH, report)
    run_number = 0
    for quartet in range(1, 4):
        for variant in QUARTET_ORDER:
            remaining = max(0.1, (deadline_ns - time.perf_counter_ns()) / 1_000_000_000)
            if remaining <= 0.1:
                report["status"] = "HOLD_TOTAL_WALL_CAP"
                break
            run_number += 1
            try:
                completed = subprocess.run(
                    [sys.executable, str(Path(__file__).resolve()), "--worker", variant],
                    cwd=REPO_ROOT,
                    capture_output=True,
                    text=True,
                    timeout=min(CHILD_CAP_SECONDS, remaining),
                )
                output = _worker_json(completed.stdout)
                stdout_facts = _stream_facts(completed.stdout)
                stderr_facts = _stream_facts(completed.stderr)
                if completed.returncode != 0 or output is None or output.get("status") != "COMPLETE":
                    if completed.returncode != 0:
                        reason = "worker_returncode_nonzero"
                    elif output is None:
                        reason = "worker_json_invalid"
                    else:
                        reason = "worker_status_not_complete"
                    report["status"] = "HOLD_RUN_FAILURE"
                    report["failed_run"] = {
                        "run": run_number,
                        "quartet": quartet,
                        "variant": variant,
                        "reason": reason,
                        "worker_returncode": completed.returncode,
                        "worker_json": output,
                        "stdout": stdout_facts,
                        "stderr": stderr_facts,
                    }
                    _write_report(RESULT_PATH, report)
                    return 2
                report["runs"].append(
                    {
                        "run": run_number,
                        "quartet": quartet,
                        "order": len(report["runs"]) % 4 + 1,
                        "variant": variant,
                        "worker": output,
                        "stdout": stdout_facts,
                        "stderr": stderr_facts,
                    }
                )
            except subprocess.TimeoutExpired as exc:
                report["status"] = "HOLD_CHILD_WALL_CAP"
                report["failed_run"] = {
                    "run": run_number,
                    "quartet": quartet,
                    "variant": variant,
                    "reason": "worker_timeout",
                    "timeout_seconds": min(CHILD_CAP_SECONDS, remaining),
                    "worker_json": _worker_json(exc.stdout),
                    "stdout": _stream_facts(exc.stdout),
                    "stderr": _stream_facts(exc.stderr),
                }
                _write_report(RESULT_PATH, report)
                return 2
            except (OSError, ValueError, TypeError) as exc:
                report["status"] = "HOLD_RUN_FAILURE"
                report["failed_run"] = {
                    "run": run_number,
                    "quartet": quartet,
                    "variant": variant,
                    "reason": "parent_subprocess_capture_failure",
                    "error_type": type(exc).__name__,
                }
                _write_report(RESULT_PATH, report)
                return 2
            report["elapsed_ns"] = time.perf_counter_ns() - started_ns
            _write_report(RESULT_PATH, report)
        if report["status"] != "RUNNING":
            break

    if len(report["runs"]) == 12:
        workers = [row["worker"] for row in report["runs"]]
        reference = workers[0]["exact_output"]
        output_equal = all(worker["exact_output"] == reference for worker in workers[1:])
        report["exact_output_equal_across_all_arms"] = output_equal
        report["timing_summary"] = {
            "small_200_pages": _variant_summary(workers, "small_200_pages_ns"),
            "nearcap_head_800_page": _variant_summary(workers, "nearcap_head_800_page_ns"),
        }
        report["profile_call_counts_by_arm"] = {
            variant: [
                worker["profile_counts"]
                for worker in workers
                if worker["variant"] == variant
            ]
            for variant in ("baseline", "candidate")
        }
        report["status"] = "COMPLETE_DIAGNOSTIC" if output_equal else "HOLD_OUTPUT_MISMATCH"
    else:
        report["status"] = "HOLD_INCOMPLETE"
    report["source_pins_post"] = _verify_file_pins()
    report["elapsed_ns"] = time.perf_counter_ns() - started_ns
    _write_report(RESULT_PATH, report)
    return 0 if report["status"] == "COMPLETE_DIAGNOSTIC" else 2


def main() -> int:
    if len(sys.argv) >= 3 and sys.argv[1] == "--worker":
        return _worker(sys.argv[2])
    if "--root-go" not in sys.argv[1:]:
        raise SystemExit("requires explicit --root-go after Root candidate correctness review")
    return _orchestrate()


if __name__ == "__main__":
    raise SystemExit(main())
