$env:PYTHONPATH = 'D:\bt_api_py\bt_api\bt_api_base\src;D:\bt_api_py\bt_api\bt_api_gateway\src;D:\bt_api_py\bt_api_py\src;D:\source_code\ai-for-investor\src\backend'
python -m pytest --noconftest -p no:asyncio -q tests/test_quote_service_market.py tests/integration/test_quote_service_market_host_integration.py
ruff check app/services/quote/service_market.py app/services/quote_service.py tests/test_quote_service_market.py tests/integration/test_quote_service_market_host_integration.py
git diff --check -- src/backend/app/services/quote_service.py