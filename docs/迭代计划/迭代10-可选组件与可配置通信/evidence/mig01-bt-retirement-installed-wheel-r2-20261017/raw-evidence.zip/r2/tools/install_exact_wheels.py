from __future__ import annotations
import hashlib, json, os, subprocess, sys
from datetime import datetime, timezone
from pathlib import Path
OUT=Path(r'D:\t\mig01-btapistore-retirement-r2')
PY=OUT/'venv'/'Scripts'/'python.exe'
WHEELHOUSE=Path(r'D:\source_code\ai-for-investor\.codex-tmp\afi10-local-release-candidate-r1\wheelhouse')
BT=OUT/'wheels'/'backtrader'/'backtrader-1.4.0-py3-none-any.whl'
SDK=Path(r'D:\t\m6\wheels\sdk\bt_api_py-0.15.5-py3-none-any.whl')
BASE=Path(r'D:\t\m6\wheels\base\bt_api_base-0.15.8-py3-none-any.whl')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
for p in (PY,WHEELHOUSE,BT,SDK,BASE):
    if not p.exists(): raise SystemExit(f'missing input: {p}')
argv=[str(PY),'-m','pip','install','--disable-pip-version-check','--no-index','--find-links',str(WHEELHOUSE),'--report',str(OUT/'build'/'pip-install-report.json'),str(BT),str(SDK),str(BASE)]
env=os.environ.copy(); env.pop('PYTHONPATH',None); env['PYTHONNOUSERSITE']='1'; env['PIP_NO_INDEX']='1'
start=datetime.now(timezone.utc).isoformat()
r=subprocess.run(argv,cwd=OUT,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=600)
(OUT/'build'/'pip-install.stdout.bin').write_bytes(r.stdout)
(OUT/'build'/'pip-install.stderr.bin').write_bytes(r.stderr)
receipt={'argv':argv,'cwd':str(OUT),'started_utc':start,'finished_utc':datetime.now(timezone.utc).isoformat(),'exit_code':r.returncode,'env':{'PYTHONPATH':'removed','PYTHONNOUSERSITE':'1','PIP_NO_INDEX':'1'},'inputs':[{ 'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)} for p in (BT,SDK,BASE)],'wheelhouse':str(WHEELHOUSE),'stdout':{'path':str(OUT/'build'/'pip-install.stdout.bin'),'bytes':len(r.stdout),'sha256':hashlib.sha256(r.stdout).hexdigest()},'stderr':{'path':str(OUT/'build'/'pip-install.stderr.bin'),'bytes':len(r.stderr),'sha256':hashlib.sha256(r.stderr).hexdigest()}}
(OUT/'build'/'pip-install.command.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt,indent=2))
if r.returncode: sys.exit(r.returncode)