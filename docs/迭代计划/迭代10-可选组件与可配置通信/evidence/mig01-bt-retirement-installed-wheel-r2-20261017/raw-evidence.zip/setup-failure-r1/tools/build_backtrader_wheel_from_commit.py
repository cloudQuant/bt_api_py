from __future__ import annotations
import hashlib, json, os, subprocess, tarfile, time
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from zipfile import ZipFile
import email.parser

OUT = Path(r"D:\t\mig01-btapistore-retirement-r1")
REPO = Path(r"D:\source_code\backtrader")
COMMIT = "6b25ee94ffec14cfad4b511eb6370eba38521c10"
PARENT = "b9b226be6a82d91bdcb94bf29dfc1ccdad0611c5"
PYTHON = Path(r"C:\anaconda3\python.exe")
SOURCE_ARCHIVE = OUT / "source" / "backtrader-6b25ee94.tar"
EXTRACT = OUT / "source" / "tree"
WHEEL_DIR = OUT / "wheels" / "backtrader"
BUILD_DIR = OUT / "build"

def sha_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def utc() -> str:
    return datetime.now(timezone.utc).isoformat()

def record_command(name: str, argv: list[str], cwd: Path, stdout_path: Path, stderr_path: Path, started: str, result: subprocess.CompletedProcess[bytes]) -> None:
    stdout_path.write_bytes(result.stdout or b"")
    stderr_path.write_bytes(result.stderr or b"")
    obj = {
        "argv": argv, "cwd": str(cwd), "started_utc": started,
        "finished_utc": utc(), "exit_code": result.returncode,
        "stdout": {"path": str(stdout_path), "bytes": stdout_path.stat().st_size, "sha256": sha_file(stdout_path)},
        "stderr": {"path": str(stderr_path), "bytes": stderr_path.stat().st_size, "sha256": sha_file(stderr_path)},
    }
    (BUILD_DIR / f"{name}.command.json").write_text(json.dumps(obj, indent=2) + "\n", encoding="utf-8")
    if result.returncode != 0:
        raise SystemExit(f"{name} failed with exit {result.returncode}; see captured output")

if not PYTHON.is_file(): raise SystemExit(f"builder interpreter missing: {PYTHON}")
head = subprocess.check_output(["git", "-C", str(REPO), "rev-parse", "HEAD"], text=True).strip()
if head != COMMIT: raise SystemExit(f"unexpected repo HEAD {head}")
parents = subprocess.check_output(["git", "-C", str(REPO), "rev-list", "--parents", "-n", "1", COMMIT], text=True).split()
if parents != [COMMIT, PARENT]: raise SystemExit(f"unexpected commit parent row {parents}")

archive_argv = ["git", "archive", "--format=tar", COMMIT]
started = utc()
with SOURCE_ARCHIVE.open("wb") as output:
    p = subprocess.run(["git", "-C", str(REPO), *archive_argv], stdout=output, stderr=subprocess.PIPE, timeout=120)
archive_stderr = BUILD_DIR / "git-archive.stderr.bin"
archive_stderr.write_bytes(p.stderr or b"")
archive_receipt = {
    "argv": ["git", "-C", str(REPO), *archive_argv], "cwd": str(REPO), "started_utc": started,
    "finished_utc": utc(), "exit_code": p.returncode,
    "archive": {"path": str(SOURCE_ARCHIVE), "bytes": SOURCE_ARCHIVE.stat().st_size, "sha256": sha_file(SOURCE_ARCHIVE)},
    "stderr": {"path": str(archive_stderr), "bytes": archive_stderr.stat().st_size, "sha256": sha_file(archive_stderr)},
    "source_commit": COMMIT, "parent": PARENT,
}
(BUILD_DIR / "git-archive.command.json").write_text(json.dumps(archive_receipt, indent=2) + "\n", encoding="utf-8")
if p.returncode != 0: raise SystemExit(f"git archive failed: {p.returncode}")

EXTRACT.mkdir(parents=True, exist_ok=False)
with tarfile.open(SOURCE_ARCHIVE, "r:") as tf:
    members = tf.getmembers()
    for member in members:
        rel = PurePosixPath(member.name)
        if rel.is_absolute() or ".." in rel.parts or not rel.parts:
            raise SystemExit(f"unsafe archive member {member.name!r}")
        target = EXTRACT.joinpath(*rel.parts)
        if member.isdir():
            target.mkdir(parents=True, exist_ok=True)
        elif member.isfile():
            target.parent.mkdir(parents=True, exist_ok=True)
            source = tf.extractfile(member)
            if source is None: raise SystemExit(f"cannot read archive member {member.name!r}")
            target.write_bytes(source.read())
        else:
            raise SystemExit(f"unexpected nonregular git archive member {member.name!r}")

archive_source = EXTRACT / "setup.py"
if not archive_source.is_file(): raise SystemExit("setup.py absent from selected Git archive")
build_argv = [str(PYTHON), "setup.py", "bdist_wheel", "--dist-dir", str(WHEEL_DIR)]
started = utc()
result = subprocess.run(build_argv, cwd=EXTRACT, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=600)
record_command("wheel-build", build_argv, EXTRACT, BUILD_DIR/"wheel-build.stdout.bin", BUILD_DIR/"wheel-build.stderr.bin", started, result)

wheels = list(WHEEL_DIR.glob("backtrader-*.whl"))
if len(wheels) != 1: raise SystemExit(f"expected one Backtrader wheel, found {wheels}")
wheel = wheels[0]
with ZipFile(wheel) as z, tarfile.open(SOURCE_ARCHIVE, "r:") as tf:
    wheel_names = [n for n in z.namelist() if not n.endswith("/")]
    package_names = [n for n in wheel_names if ".dist-info/" not in n]
    python_names = [n for n in package_names if n.endswith(".py")]
    archive_members = {m.name: m for m in tf.getmembers() if m.isfile()}
    matches, mismatches = [], []
    for name in package_names:
        member = archive_members.get(name)
        if member is None:
            mismatches.append({"path": name, "reason": "missing from selected Git archive"})
            continue
        f = tf.extractfile(member)
        if f is None or f.read() != z.read(name):
            mismatches.append({"path": name, "reason": "content differs"})
        else:
            matches.append(name)
    metadata_name = next(n for n in wheel_names if n.endswith(".dist-info/METADATA"))
    metadata_bytes = z.read(metadata_name)
    metadata = email.parser.Parser().parsestr(metadata_bytes.decode("utf-8"))
    forbidden_strings = [
        "_create_ctp_gateway_wrapper_class",
        "bt_api_py.gateway.client",
        "_gateway_timeframe_str",
        "_apply_env_gateway_overrides",
    ]
    scan_hits = []
    for name in python_names:
        text = z.read(name).decode("utf-8", errors="strict")
        for needle in forbidden_strings:
            if needle in text:
                scan_hits.append({"path": name, "needle": needle})
    retired_store = z.read("backtrader/stores/btapistore.py").decode("utf-8")
    if len(matches) != len(package_names) or mismatches or scan_hits:
        raise SystemExit(f"wheel audit mismatch: {len(matches)}/{len(package_names)}, {mismatches[:5]}, hits={scan_hits[:5]}")
    inspect = {
        "source_commit": COMMIT, "source_parent": PARENT,
        "source_archive": {"path": str(SOURCE_ARCHIVE), "bytes": SOURCE_ARCHIVE.stat().st_size, "sha256": sha_file(SOURCE_ARCHIVE), "member_count": len(members)},
        "wheel": {"path": str(wheel), "bytes": wheel.stat().st_size, "sha256": sha_file(wheel), "member_count": len(wheel_names), "package_member_count": len(package_names), "python_member_count": len(python_names), "matched_package_members": len(matches), "mismatches": mismatches},
        "metadata": {"member": metadata_name, "bytes": len(metadata_bytes), "sha256": digest(metadata_bytes), "name": metadata.get("Name"), "version": metadata.get("Version"), "requires_python": metadata.get("Requires-Python"), "requires_dist": metadata.get_all("Requires-Dist", [])},
        "retired_gateway_source_scan": {"python_member_count": len(python_names), "forbidden_needles": forbidden_strings, "hits": scan_hits, "store_contains_required_direct_read_only_api": all(s in retired_store for s in ["class LegacyGatewayMigrationRequiredError", "def _legacy_gateway_entrypoint", "def get_balance(", "def submit_order("])},
        "build_log": {"captured": True, "command_receipt": str(BUILD_DIR/"wheel-build.command.json"), "stdout": str(BUILD_DIR/"wheel-build.stdout.bin"), "stderr": str(BUILD_DIR/"wheel-build.stderr.bin")},
    }
    if inspect["retired_gateway_source_scan"]["store_contains_required_direct_read_only_api"] is not True:
        raise SystemExit("wheel does not retain expected Store direct/read-only API")
(BUILD_DIR / "wheel-inspection.json").write_text(json.dumps(inspect, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"archive": archive_receipt["archive"], "wheel": inspect["wheel"], "metadata": {k: inspect["metadata"][k] for k in ("name","version","bytes","sha256","requires_python")}, "scan": inspect["retired_gateway_source_scan"]}, indent=2))
