from pathlib import Path
import hashlib, json, psutil, subprocess, time

r=Path('D:/bt_api_py')
prepared=r/'.codex-tmp/iteration10-load01-pilot-spec-r13-current-dev-20261017.json'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(prepared)=='4a59fbf0e1e3c900635e072ae20abd13ba14189434820737b643e4ee1fe572c3'
old=json.loads(prepared.read_text(encoding='utf-8'))
source=old['current_source']; exp=source['export']; exe=old['execution']
root=Path(exe['working_directory']); output=Path(exe['output_root'])
assert not output.exists(), 'Do not reuse consumed pilot output'
assert sha(exp['source_manifest_path'])=='771002af64488806bb3f213f18cf7a0d8f4ab1962221ccd66b6aeb2ad0b128bf'
assert sha(exp['source_export_pins'])==exp['source_export_pins_sha256']
manifest=json.loads(Path(exp['source_manifest_path']).read_text())
assert len(manifest['files'])==1209
pins={str(root/p):h for p,h in manifest['files'].items()}
for name,meta in exp['archive_hashes'].items():
    path=Path(exp['root'])/name
    assert sha(path)==meta['sha256']
    pins[str(path)]=meta['sha256']
runner=r/'.codex-tmp/iteration10-focused-qa.py'
assert sha(runner)=='8b7f470be77270adeb9d72a83776b827c4653004b39835eeca0f43bf63cf24ed'
for path in [prepared,runner,Path(exp['source_manifest_path']),Path(exp['source_export_pins'])]:
    pins[str(path)]=sha(path)
assert all(sha(p)==h for p,h in pins.items())
def git(*a): return subprocess.check_output(['git','-C',str(r),*a]).decode().strip()
head=git('rev-parse','HEAD')
assert git('branch','--show-current')=='dev'
assert not git('diff','--cached','--name-only')
changed=git('diff','--name-only','-z',source['parent_commit'],head).split('\0')
assert all(not p or p.startswith('docs/') or p in {'mkdocs.yml','tests/integration/test_gateway_quota_session_owner.py'} for p in changed),changed
heads={str(r):head}
for path,commit in source['package_gitlinks'].items():
    heads[str(r/path)]=commit
environment=dict(exe['environment'])
environment.pop('BT_API_LOAD01_SOURCE_MANIFEST')
environment.update(BT_API_LOAD01_MODE='pilot',BT_API_LOAD01_OUTPUT=exe['pilot_output'],PYTHONPYCACHEPREFIX=str(output/'pilot-python-cache'))
spec={'schema_version':1,'label':'LOAD01_R13_FIXED_SOURCE_112_PROCESS_120_SECOND_PILOT','python':exe['python'],'cwd':str(root),'output':str(output),'environment':environment,'unset_environment':['BT_API_LOAD01_SOURCE_MANIFEST'],'nodes':[exe['node']],'pytest_options':exe['pytest_arguments'],'repositories':heads,'source_sha256':pins,'evidence_level':'LOCAL_SYNTHETIC_LOAD01_112_PROCESS_120_SECOND_PILOT_ONLY','source_parent':source['parent_commit'],'head_rebind_note':'Current checkout advanced only docs/navigation and separate reconnect regression/evidence since export. Runtime export and 7 runner provenance constants unchanged. User explicitly authorized Root to reclaim memory; fresh gate remains mandatory.','authorization':'User: 你帮我释放. Root reclaimed application working-set pages without terminating processes; Qoder and retained sessions untouched.'}
path=r/'.codex-tmp/iteration10-load01-r13-pilot-root-execution-20261017.json'
assert not path.exists()
path.write_text(json.dumps(spec,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
samples=[]
for i in range(3):
    samples.append({'time':time.time(),'available':psutil.virtual_memory().available})
    if i<2: time.sleep(5)
receipt={'spec':str(path),'spec_sha256':sha(path),'samples':samples,'threshold':10603200512,'ready':all(x['available']>=10603200512 for x in samples),'source_count':len(pins),'execution_head':head}
(r/'.codex-tmp/iteration10-memory-pre-load01-pilot-20261017.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
assert receipt['ready'],'Memory gate not met; pilot not started'
raise SystemExit(subprocess.call([exe['python'],'-X','utf8',str(runner),str(path)]))
