"""Committed packages plus the selected runtime, Store drain API, and local fixtures."""
import ast
import hashlib
import io
import json
import subprocess
import tarfile
from pathlib import Path

ROOT = Path('D:/bt_api_py')
META = ROOT / '.codex-tmp/ctp-risk-bridge-root-20261018'
FIXED = Path('D:/temp/iteration10-ctp-risk-bridge-r9-fixed-20261018/source')
OUT = Path('D:/temp/iteration10-ctp-risk-bridge-r9-root-qa-20261018')
selected = json.loads((META / 'selected-r9.json').read_text())
baseline = json.loads((META / 'qa-baseline-r9.json').read_text())
assert not FIXED.exists() and not OUT.exists() and not (META / 'qa-r9-spec.json').exists()
heads = {str(Path(v['repository'])): v['head'] for v in baseline.values()}
for repo, head in heads.items():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip() == head
recipe = []
for repo, prefix, roots in [
    (ROOT, '', ['bt_api_py']),
    (ROOT / 'bt_api/bt_api_base', 'base', ['src']),
    (ROOT / 'bt_api/bt_api_execution', 'execution', ['src']),
    (ROOT / 'bt_api/bt_api_risk', 'risk', ['src']),
    (ROOT / 'bt_api/bt_api_ctp', 'ctp', ['src']),
    (ROOT / 'bt_api/bt_api_gateway', 'gateway', ['src']),
    (ROOT / 'bt_api/bt_api_transport_zmq', 'transport', ['src']),
    (ROOT / 'bt_api/bt_api_monitor', 'monitor', ['src']),
]:
    raw = subprocess.check_output(['git', 'archive', heads[str(repo)], '--', *roots], cwd=repo)
    with tarfile.open(fileobj=io.BytesIO(raw)) as tar:
        for item in tar.getmembers():
            if not item.isfile() or not item.name.endswith('.py'):
                continue
            dest = Path(prefix) / item.name
            assert not dest.is_absolute() and '..' not in dest.parts
            data = tar.extractfile(item).read()
            file = FIXED / dest
            file.parent.mkdir(parents=True, exist_ok=True)
            file.write_bytes(data)
            recipe.append({'repository': str(repo), 'commit': heads[str(repo)],
                           'git_path': item.name, 'path': dest.as_posix(),
                           'sha256': hashlib.sha256(data).hexdigest()})
candidate_raw = {}
for entry in selected['overlays']:
    data = (ROOT / entry['source']).read_bytes()
    assert hashlib.sha256(data).hexdigest() == entry['sha256']
    ast.parse(data)
    file = FIXED / entry['destination']
    file.parent.mkdir(parents=True, exist_ok=True)
    file.write_bytes(data)
    candidate_raw[entry['destination']] = data

# Resolve every local helper module imported by a selected test, including
# underscore-prefixed schema fixtures. Never import a candidate during export.
test_roots = [
    (ROOT, 'tests/unit', 'tests/unit'),
    (ROOT, 'tests/integration', 'tests/integration'),
    (ROOT / 'bt_api/bt_api_execution', 'tests', 'execution/tests'),
    (ROOT / 'bt_api/bt_api_ctp', 'tests', 'ctp/tests'),
    (ROOT / 'bt_api/bt_api_risk', 'tests', 'risk/tests'),
    (ROOT / 'bt_api/bt_api_base', 'tests', 'base/tests'),
]
todo = [raw for path, raw in candidate_raw.items() if 'tests/' in path]
seen = set()
while todo:
    data = todo.pop()
    for node in ast.walk(ast.parse(data)):
        names = ([node.module] + [node.module + '.' + alias.name for alias in node.names]
                 if isinstance(node, ast.ImportFrom) and node.module
                 else [alias.name for alias in node.names] if isinstance(node, ast.Import) else [])
        for name in names:
            found = []
            if name.startswith(('tests.unit.', 'tests.integration.')):
                qualified = Path(name.replace('.', '/') + '.py')
                if (ROOT / qualified).is_file():
                    found.append((ROOT, qualified, qualified))
            for repo, directory, destination in test_roots:
                relative = Path(directory) / (name.replace('.', '/') + '.py')
                if (repo / relative).is_file():
                    found.append((repo, relative, Path(destination) / (name.replace('.', '/') + '.py')))
            assert len(found) <= 1, ('ambiguous local fixture', name)
            if not found:
                continue
            repo, relative, dest = found[0]
            key = (str(repo), relative.as_posix())
            if key in seen:
                continue
            seen.add(key)
            if dest.as_posix() in candidate_raw:
                todo.append(candidate_raw[dest.as_posix()])
                continue  # Never overwrite a selected test overlay with its HEAD fixture.
            raw = subprocess.check_output(['git', 'show', heads[str(repo)] + ':' + relative.as_posix()], cwd=repo)
            file = FIXED / dest
            file.parent.mkdir(parents=True, exist_ok=True)
            file.write_bytes(raw)
            todo.append(raw)
            recipe.append({'repository': str(repo), 'commit': heads[str(repo)],
                           'git_path': relative.as_posix(), 'path': dest.as_posix(),
                           'sha256': hashlib.sha256(raw).hexdigest()})
# Preserve the actual package initializers for qualified fixture imports.
for relative in ['tests/__init__.py', 'tests/unit/__init__.py', 'tests/integration/__init__.py']:
    result = subprocess.run(['git', 'show', heads[str(ROOT)] + ':' + relative], cwd=ROOT, capture_output=True)
    if result.returncode == 0:
        file = FIXED / relative
        file.parent.mkdir(parents=True, exist_ok=True)
        file.write_bytes(result.stdout)
        recipe.append({'repository': str(ROOT), 'commit': heads[str(ROOT)], 'git_path': relative,
                       'path': relative, 'sha256': hashlib.sha256(result.stdout).hexdigest()})

(FIXED / 'pytest.ini').write_text('[pytest]\nmarkers =\n    unit: local unit acceptance\n    integration: local component integration acceptance\n', encoding='utf-8', newline='\n')
(FIXED / 'ctp_service_qa_checks.py').write_bytes((META / 'ctp_runtime_qa_checks_r10.py').read_bytes())
pins = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in FIXED.rglob('*') if p.is_file()}
pins.update({str(ROOT / e['source']): e['sha256'] for e in selected['overlays']})
spec = {
    'python': 'C:/Anaconda3/python.exe', 'cwd': str(FIXED), 'output': str(OUT),
    'repositories': heads, 'source_sha256': pins,
    'environment': {
        'PYTHONPATH': ';'.join(str(FIXED / p) for p in ['', 'base/src', 'execution/src', 'execution/tests', 'risk/src', 'risk/tests', 'base/tests', 'ctp/src', 'ctp/tests', 'gateway/src', 'transport/src', 'monitor/src', 'tests/unit', 'tests/integration']),
        'BT_API_PY_LIGHT_IMPORT': '1', 'PYTHONDONTWRITEBYTECODE': '1',
        'PYTEST_DISABLE_PLUGIN_AUTOLOAD': '1', 'PYTHONUTF8': '1',
        'BT_API_LOG_DIR': str(OUT / 'logs'), 'CTP_OBSERVATION_QA_OUTPUT': str(OUT),
        'CTP_SERVICE_QA_SPEC': str(OUT / 'spec.json'),
    },
    'unset_environment': ['PYTEST_ADDOPTS', 'PYTEST_PLUGINS', 'PYTHONPATH'],
    'pytest_options': ['-q', '--noconftest', '--import-mode=prepend', '-p', 'no:cacheprovider', '-p', 'no:debugging', '-p', 'ctp_service_qa_checks', '-c', str(FIXED / 'pytest.ini')],
    'nodes': selected['nodes'],
    'expected_origins': {name: str(FIXED / path) for name, path in selected['expected_origins'].items()},
    'evidence_level': 'LOCAL_CTP_ORDER_RISK_COMPOSITION_WITH_SYNTHETIC_NATIVE_QUOTA_AND_CUTOVER_LEAVES_ONLY',
}
(META / 'export-recipe-r9.json').write_text(json.dumps(recipe, indent=2) + '\n', encoding='utf-8', newline='\n')
(META / 'qa-r9-spec.json').write_text(json.dumps(spec, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps({'source_pins': len(pins), 'nodes': spec['nodes'], 'local_test_dependencies': len(seen)}))
