"""Focused local QA boundaries, not a general OS sandbox."""
import asyncio
import builtins
import importlib
import json
import os
import platform
import socket
import subprocess
import sys
import unittest.mock
from pathlib import Path
platform.node()
_DENIED = []
_IMPORT = builtins.__import__
_IMPORT_MODULE = importlib.import_module
_EVENTS = {"subprocess.Popen", "_winapi.CreateProcess", "os.system", "socket.connect", "socket.bind"}
def _audit(event, args):
    if event in _EVENTS:
        _DENIED.append(event)
        raise PermissionError("focused QA forbids external process/network operations")
def _require_name(name):
    if type(name) is str and name.split(".", 1)[0] == "bt_api_ctp":
        _DENIED.append("bt_api_ctp import")
        raise ImportError("focused QA forbids CTP SDK import")
def _import(name, globals=None, locals=None, fromlist=(), level=0):
    _require_name(name)
    return _IMPORT(name, globals, locals, fromlist, level)
def _import_module(name, package=None):
    _require_name(name)
    return _IMPORT_MODULE(name, package)
sys.addaudithook(_audit)
builtins.__import__ = _import
importlib.import_module = _import_module
def pytest_sessionfinish(session, exitstatus):
    names = ("bt_api_execution", "bt_api_execution.store", "bt_api_base", "test_ctp_callback_session_router")
    if "bt_api_execution.service_order_entry" in sys.modules:
        names += ("bt_api_execution.service_order_entry",)
    origins = {name: getattr(sys.modules.get(name), "__file__", None) for name in names}
    root = Path(__file__).parent.resolve()
    origins_ok = all(value and Path(value).resolve().is_relative_to(root) for value in origins.values())
    if _DENIED or not origins_ok:
        session.exitstatus = 1
    result = {"python": sys.version, "executable": sys.executable, "denied_events": _DENIED, "origins": origins, "origins_ok": origins_ok, "guard_scope": "listed process/network audit events and bt_api_ctp imports only; not general OS/native isolation"}
    (Path(os.environ["CTP_SCOPE_QA_OUTPUT"]) / "guard.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
