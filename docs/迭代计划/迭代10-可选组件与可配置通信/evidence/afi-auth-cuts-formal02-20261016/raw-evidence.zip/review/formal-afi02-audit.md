# Iteration 10 AFI 剩余用例收口审计（2026-10-16）

只读核对 SDK 正式计划、现行验收汇总、AFI 当前已提交基线及已接受证据。初始核查时 SDK `dev`/`ba2eddbc`；本次 Root r2 证据固定 SDK `dev`/`a88edd28`，AFI `dev`/`30797a39`。正式汇总当前仍为 **33/68**；现行汇总中仅 AFI07 记为 formal PASS（本文件下方为AFI02合并裁定建议，尚未由Root更新tracker）。本审计未执行QA/Host/浏览器，仅复核Root已产生的r2证据；未读凭据或历史保留Host。

| 用例 | 已有最近正式入口/证据 | 仍未收口的核心项 |
|---|---|---|
| AFI02 | **条款证据已齐，建议正式 PASS**：本轮 Root 固定来源重验旧 API 节点 1/1、4.65s 与两个 Host 节点 2/2、13.66s；均为 2 条既有 warning，2135 pins 与 AFI/SDK HEAD 不变。旧 API、R110 已接受 dual-live、R114、R116 与 30797a39 分散证据按条款合并，无需新增全集矩阵或重跑 R110。 | 未发现真实字段/行为缺口。由 Root 将合并证据归档并更新正式裁定；本审计不改 tracker，现行累计仍按汇总文档。`paper` 的 `adapter_not_integrated` 是明确来源隔离结果，paper 执行接线属于 AFI13。 |
| AFI03 | R110 live 账户读取及 R116 financial DTO 已接受；本轮 Root 确认 cut3 的三个独立快照/可追溯新节点全 PASS，账户读取仍显式为独立 cut。 | 合约乘数、多个计价币、带日期的 FX 与价格时间仍无投影实现/证据；陈旧、错误、未对账等完整状态矩阵也未闭合。cut3 不构成 AFI03 整体 PASS。 |
| AFI04 | R148 有 cash+spot NAV/Modified Dietz 算法组件；R156 有 `portfolio_analytics` 角色与任务服务，但属同进程控制面。 | 缺正式条款要求的独立分析进程经正常 SDK 服务入口运行；还须将固定输入的版本化复现与 quota/cancel/timeout、零账户登录放进同一固定场景。 |
| AFI08 | `api/live_trading/api.py::stop_instance`、`api/risk_control.py` 有应用内控制入口。 | 没有授权 SDK owner 控制链及每动作终态结果；需覆盖越权、部分/UNKNOWN，并证明告警确认不解 Risk freeze。 |
| AFI09 | AFI 有 `connect_gateway` / `get_gateway_health` 与 `services/gateway/manual.py`。 | 仍由 AFI 直接连接；缺 credential-reference→Gateway session owner 的正常链和本机多 worker 复用/分离健康状态/无凭据投影证明。 |
| AFI10 | SDK MIG01 R1–R3 只完成 fail-closed 入口及部分 wire/re-home 增量。 | R3 仍报告旧目录/wheel 与 **166 hits / 35 files**，真实 durable Gateway router 未接；AFI 仍有 direct Gateway 与 `PaperTradingService` 路径。 |
| AFI11 | R180 有真实本机 HTTP/SDK 双 worker 的正常路径。 | 缺 AFI、analytics、Monitor 的本机进程故障/恢复注入；应证明既有 owner 按原政策继续、缺事实时拒绝新单、无 direct fallback/重复会话。此条不要求双机。 |
| AFI12 | R81 保留 imported 原始 JSON/source/hash，并有有限 owner 投影。 | 缺单一脱敏迁移/回退场景核对持仓/现金/费用、审批/规则/告警/游标；还需证明幂等恢复、GET 零写和导入记录不变成交。 |
| AFI13 | R123 是真实本机 SDK/Execution/CURVE/SQLite E-only managed-paper Host；R140 增加 V2 持久 fill 读取合同。 | AFI `api/paper_trading.py::submit_paper_order` 仍调用 `PaperTradingService`；缺迁移到 E managed-paper 的正常 AFI 入口，以及所选 R/M、旧状态守恒、多 worker/重启无双撮合、零 live-write 的固定场景。 |

## AFI02：合并裁定建议（Root R2 固定来源重验完成）

正式条款为“research/imported/paper/live 来源隔离；组合成员版本、账户总视图与策略归属视图不重复计数；重叠展示组合不得重复授信”，验收形态是确定性多账户/多策略数据集与实际 API 投影，并可核对汇总和叶事实。按条款合并已接受证据，不要求所有断言来自单个新场景。

| 条款子项 | 精确证据映射 |
|---|---|
| 来源隔离、版本与 live 汇总 | AFI 当前固定来源 Root r2 API 节点 `test_composition_membership_versions_and_live_overview_projection` 1/1：[`result.json`](</D:/temp/iteration10-afi-auth-cuts-root-20261016-r2-api/result.json>) SHA256 `EADF12A674AEDD3D5B4928FED93E585925E7574DFDFDF8086FF63EB3A43BF486`；[`junit.xml`](</D:/temp/iteration10-afi-auth-cuts-root-20261016-r2-api/junit.xml>) SHA256 `D6852F2A30457CDEA2AE91C39FBC1C6E59125F960AED743A0656E900A1A38DBF`；固定输入 spec SHA256 `31E703A0C2C172D42824558E4F5BCA3535F952E977A1BB28C4E322E9E02E2D13`。源码断言 `src/backend/tests/test_portfolio_compositions_api.py:571-641,644-689,692-790,956`：版本1/2及历史成员不变；live总值1500、account alias 去重；paper 的 `adapter_not_integrated`/无总值/incomplete、imported 的 source-material unavailable、research 的无 account/strategy/总值与敏感字段不泄露；4 次 account reads 与两次 live projection 对应，非 live projection 未产生额外 live read。 |
| 多账户/多策略叶事实与双视图不重复计数 | 已接受 R110 [`root-adjudication.md`](</D:/bt_api_py/docs/迭代计划/迭代10-可选组件与可配置通信/evidence/afi-dual-account-projection-20261016/root-adjudication.md>)：正常 AFI lifespan→HTTP→SDK，经两个 Gateway 和两个 Execution Host；账户总值160+790=950，策略持仓2.5/4、UNALLOCATED当前账3.5/5、基线后 residual0.5/1各自核对。策略值未被推算成账户权益，coverage/creditable 明确不完整/false。 |
| 重叠展示不可重复授信、访问边界 | 同一 R110 结果：共享账户重叠组合不累加、跨 owner 404。Host 支持节点本轮也在当前固定 source set 上通过；另有 `test_afi02_dual_live_projection_uses_gateway_and_execution_service_hosts` 的账户/策略叶事实、综合总值950与重叠视图160、两者均 `creditable=false` 且 `non_additive_display_only` 断言作为已接受 dual-live evidence 保留。 |
| 当前源码 helper 依赖与复核范围 | Root r2 Host：`test_live_composition_projects_only_trusted_strategy_books_from_sdk_host` 与 `test_afi01_read_authorization_matrix_keeps_http_identity_scope_and_replay_boundaries` 2/2；[`result.json`](</D:/temp/iteration10-afi-auth-cuts-root-20261016-r2-host/result.json>) SHA256 `C6B05209F0A0F12A9EDF8F3FAE80DADE2DAB5D1210E04CD806A0A5CA3886F4B2`；[`junit.xml`](</D:/temp/iteration10-afi-auth-cuts-root-20261016-r2-host/junit.xml>) SHA256 `85C7F651E0B4736C6004EA77C05352A1116BD961E5BF6BC0F84AF9730CFB1F1C`；spec SHA256 `7C2B62301F4632D79CE68FD913C5B69F18F74286DBD20F4DAB2094B055C36934`。两次固定来源运行各核对2135 pins、AFI `30797a3901060b7476ce5717d9ae218e5cd54c8d` 与 SDK `a88edd28f5cf560a285c829f45a6013266bd10df` HEAD before/after 不变，source snapshot SHA256 均为 `FDA86899A2FAFE55C272FE88EF97D04B82A97244810AEC8D44D0E1716B8B625B`。当前变更的 Host helper 只改 `_run_live_composition_projection` 用的 AFI01 legacy-unbound fixture/denial；R110 dual helper `_run_dual_live_composition_projection` 与其节点无 diff。当前 `portfolio_composition.py` 的 AFI03 cut3 添加公开 cut/skew/来源字段，账户 total 分组求和与策略/UNALLOCATED 计算未改变；故 R110 既有 dual-live 接受证据不因 helper/cut3 增量失效，也不要求重跑。 |

R114 UI、R116 financial contract 及 30797a39 FastAPI/ServiceReadWorker financial projection 是相关展示/HTTP契约补充，不替代上表 API/Host 证据。Root r2 API 为1 passed/4.65s、Host为2 passed/13.66s，各有2条既有 warning（Quandl/Starlette 弃用）；两次均 exit 0、2135 pins不变。测试数据为确定性合成事实，符合条款，不要求真实账户。未发现额外字段或行为缺口。**合并审查建议 AFI02 formal PASS**；此文件仅为裁定记录，不修改正式 tracker，也不自行变更33/68计数。

## certlib 与 AFI10/MIG01

certlib 发行修复**没有**把 AFI10/MIG01 缺口缩减成扫描/安装收口。MIG01-R3 的根裁定仍披露 166/35 残差、旧目录/wheel 和 durable Gateway router 未接；AFI10 还要求删除或迁出 AFI 的直发单、重复 risk/paper 和 raw-ZMQ 运行路径。certlib wheel/sdist 只能改善一个消费者的发行闭包，不会移除这些生产实现。

certlib 构建不是当前阻断：Backtrader `223d5b68` 与 SDK R197 `e08da3c5` 已有成功证据，包含 wheel/sdist 构建、两个 fresh venv 安装及正常 dry 入口覆盖；此前 `colorama` / `setup.cfg` HOLD 已被后续成功轮取代。当前只剩 MIG04 consumer combo step06 的固定组合验收，Root 正在修复本机系统 AutoRun 导致的递归 harness；不要据旧 HOLD 重新判定包构建失败，也不要把该子项算成 AFI10/MIG01 收口。用户仅延期双机；AFI11 等本机进程条款仍按原范围推进。

依据：正式条款 `正式迭代计划.md:793-805`；当前汇总 `迭代10验收状态汇总.md` AFI/MIG01/MIG04 行；R110/R114/R116、AFI07 R159、MIG01 R1–R3 与 certlib/MIG04 R194 记录。本文为只读审计，不新增正式 PASS。
