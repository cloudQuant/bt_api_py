"""Import-only comparison in newly spawned children, without Hosts or load."""
import hashlib
import importlib.util
import json
import multiprocessing
import os
from pathlib import Path
import sys
import time

def observe(source_path, expected_sha, fixed_root, output_path):
    root = Path(fixed_root)
    package_names = ("bt_api_base", "bt_api_execution", "bt_api_gateway", "bt_api_monitor", "bt_api_risk", "bt_api_transport_zmq")
    sys.path[:0] = [str(root)] + [str(root / "bt_api" / name / "src") for name in package_names]
    import psutil
    path = Path(source_path)
    raw = path.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == expected_sha
    process = psutil.Process()
    before = process.memory_info()
    start = time.perf_counter()
    name = "tests.unit.test_load01_hundred_strategy_30min"
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    after = process.memory_info()
    result = {
        "scope": "spawn child import-only; no manifest call, Host, strategy workload, or system RAM observation",
        "source_path": str(path), "source_sha256": expected_sha,
        "process_name": multiprocessing.current_process().name,
        "elapsed_seconds": time.perf_counter() - start,
        "rss_before": before.rss, "rss_after": after.rss,
        "private_before": getattr(before, "private", None),
        "private_after": getattr(after, "private", None),
        "module_count": len(sys.modules), "modules": sorted(sys.modules),
        "domain_modules": [n for n in sorted(sys.modules) if any(n == p or n.startswith(p + ".") for p in ("bt_api_gateway", "bt_api_execution", "bt_api_monitor", "bt_api_risk"))],
        "service_host_loaded": "bt_api_py.service_host" in sys.modules,
    }
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected_sha
    with Path(output_path).open("x", encoding="utf8") as handle:
        json.dump(result, handle, indent=2, sort_keys=True)
        handle.write("\n")

if __name__ == "__main__":
    spec_path = Path(sys.argv[1])
    plan = json.loads(spec_path.read_text(encoding="utf8"))
    context = multiprocessing.get_context("spawn")
    results = []
    for case in plan["cases"]:
        assert not Path(case["output_path"]).exists()
        child = context.Process(target=observe, args=(case["source_path"], case["sha256"], plan["fixed_root"], case["output_path"]), name="load01-import-" + case["name"])
        child.start()
        child.join(45)
        if child.is_alive():
            raise RuntimeError("Import-only child exceeded expected observation interval")
        code = child.exitcode
        child.close()
        assert code == 0, (case["name"], code)
        result = json.loads(Path(case["output_path"]).read_text(encoding="utf8"))
        results.append({k:v for k,v in result.items() if k not in ("modules", "domain_modules")})
        results[-1]["domain_module_count"] = len(result["domain_modules"])
    print(json.dumps(results, sort_keys=True))
