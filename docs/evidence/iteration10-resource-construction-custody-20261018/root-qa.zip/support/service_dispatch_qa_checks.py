"""Root origin checks and listed external-operation guards for local claim QA."""
import asyncio
import importlib.abc
import json
import os
from pathlib import Path
import platform
import sys
import urllib3

platform.node()
ROOT = Path(__file__).resolve().parent
DENIED = []

class NoProviderNative(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname == 'bt_api_ctp' or fullname.startswith('bt_api_ctp.') or fullname == '_ctp':
            DENIED.append('provider_import')
            raise ImportError('provider import is outside the cancellation claim QA')
        return None

sys.meta_path.insert(0, NoProviderNative())

def no_external_calls(event, args):
    if event in {'socket.connect','socket.bind','subprocess.Popen','os.system','os.exec','os.posix_spawn','_winapi.CreateProcess'}:
        DENIED.append(event)
        raise RuntimeError('external operation forbidden in local claim QA')

sys.addaudithook(no_external_calls)

def pytest_sessionfinish(session, exitstatus):
    expected = {name: Path(path) for name, path in json.loads(Path(os.environ['CTP_SERVICE_QA_SPEC']).read_text(encoding='utf-8'))['expected_origins'].items()}
    origins = {name:getattr(sys.modules.get(name),'__file__',None) for name in expected}
    result = {'origins':origins,'denied_events':DENIED,'guard_scope':'listed process/network audit events and CTP provider imports; not general OS isolation'}
    Path(os.environ['CTP_OBSERVATION_QA_OUTPUT']).joinpath('guard.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    for name,path in expected.items():
        assert origins[name] is not None and Path(origins[name]).resolve()==path.resolve(), name
    assert not DENIED
