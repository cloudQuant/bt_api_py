from pathlib import Path
import sys, json, platform, asyncio, importlib.abc
import pytest
platform.node()
phase = 'install_guard'
events = []
class NoCtpProvider(importlib.abc.MetaPathFinder):
 def find_spec(self, fullname, path=None, target=None):
  if fullname == 'bt_api_ctp' or fullname.startswith('bt_api_ctp.'):
   raise RuntimeError('provider import forbidden')
sys.meta_path.insert(0, NoCtpProvider())
def audit(event,args):
 if event in {'socket.connect','socket.bind','subprocess.Popen','os.system','os.exec','os.posix_spawn','_winapi.CreateProcess'}:
  stack=[]; frame=sys._getframe(1)
  for _ in range(24):
   if frame is None: break
   stack.append({'file':frame.f_code.co_filename,'function':frame.f_code.co_name,'line':frame.f_lineno})
   frame=frame.f_back
  events.append({'event':event,'phase':phase,'stack':stack})
  raise RuntimeError('external operation forbidden')
sys.addaudithook(audit)
sys.path.insert(0,str(Path.cwd()/'tests/unit'))
for name in ('test_ctp_provider_observation','test_ctp_callback_session_router'):
 phase='import:'+name
 try: __import__(name)
 except Exception as exc: events.append({'phase':phase,'exception_type':type(exc).__name__})
Path(sys.argv[1]).write_text(json.dumps({'events':events,'candidate_origin':sys.modules['bt_api_py.ctp_service_execution'].__file__},indent=2)+'\n')
