MIG03 partial source selection (2026-10-17)

Base: SDK D:/bt_api_py HEAD 1ee1c1ea9aefa961f0c555d0487f03bac2511521. The Host and Registry patches reconstruct only MIG03 start-lock, destination write-latch, internal-writer suppression, and pre-handler fencing hunks from the pinned base; they do not copy the mixed live files. The Group patch contains only the owner-confirmed `maintain_registrations(recover=...)` signature/type guard and conditional recovery call.

Apply order: service_execution_group.py, service_registry.py, service_host.py. `git apply --check` and application were performed against the exact base blobs in an isolated temporary directory; all selected overlays compiled. These patches are partial source payloads for Root review/partial staging, not complete replacement files.

QA provenance: R3 affected gate units, R4 restarted Host integration, and R7 two-epoch drill results are preserved unchanged from the earlier draft. R4/R7 used the live full Host/Registry bytes whose hashes are listed in the QA source map. The recovery=False group branch was not separately selected or asserted in those accepted QA nodes; inclusion is a compile-verified required runtime dependency only.

Excluded hunks: AFI08 STOP_NEW schema/method/dispatch and Monitor Host adapter; AFI12 Paper import; DIM04 compensation; DIM09 recovery/budget/roll-exit changes beyond the exact recover=False method delta. No provider/account operation, real external fence, formal MIG03 PASS, or tracker increment is claimed.
