# R6 pilot failure facts

The consumed R6 output remains unchanged. It ended FAILED in sustained-load with safe code CHILD_FAILED; formal_acceptance_eligible=false and normal_shutdown_complete=false.

The child result has 112 entries: exit -15 for 108, exit 0 for two, exit 1 for two. Root classifies the 108 termination requests as 10 owners plus 98 strategies; two other strategies exited 1. A read-only post-run query of only the 112 PIDs recorded in this R6 result found none present at 2026-10-16T09:33:04.7564703Z. This does not make forced termination a normal shutdown. No historical host or PID 81428 was queried or touched.

Same-call diagnosis found an orders.submit request sent by the client followed by the 5-second response timeout. Its outcome is UNKNOWN; these artifacts do not establish whether the server handler committed or rejected it.

The R6 outer result records 37 source pins unchanged. This is a failed pilot, not LOAD01 acceptance. The current candidate is bounded diagnostic instrumentation only and does not change production behavior or acceptance thresholds.
