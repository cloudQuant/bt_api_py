from __future__ import annotations
import hashlib, json, os, subprocess, sys
from datetime import datetime, timezone
from pathlib import Path
ROOT=Path(r'D:\t\mig01-btapistore-retirement-r2')
CHECKS=ROOT/'checks'; PY=ROOT/'venv'/'Scripts'/'python.exe'
NAMES=('direct_no_zmq_smoke.py','offline_cerebro_smoke.py','btapistore_retirement_smoke.py')
def sha(data:bytes)->str: return hashlib.sha256(data).hexdigest()
results=[]
env=os.environ.copy(); env.pop('PYTHONPATH',None); env['PYTHONNOUSERSITE']='1'; env['PYTHONUTF8']='1'
for name in NAMES:
    script=CHECKS/name; out=ROOT/'build'/f'{name}.stdout.bin'; err=ROOT/'build'/f'{name}.stderr.bin'
    argv=[str(PY),'-I',str(script)]
    started=datetime.now(timezone.utc).isoformat()
    proc=subprocess.run(argv,cwd=CHECKS,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60)
    out.write_bytes(proc.stdout); err.write_bytes(proc.stderr)
    row={'name':name,'argv':argv,'cwd':str(CHECKS),'started_utc':started,'finished_utc':datetime.now(timezone.utc).isoformat(),'exit_code':proc.returncode,'script':{'path':str(script),'bytes':script.stat().st_size,'sha256':sha(script.read_bytes())},'stdout':{'path':str(out),'bytes':len(proc.stdout),'sha256':sha(proc.stdout)},'stderr':{'path':str(err),'bytes':len(proc.stderr),'sha256':sha(proc.stderr)},'stdout_text':proc.stdout.decode('utf-8','replace'),'stderr_text':proc.stderr.decode('utf-8','replace')}
    results.append(row)
report={'python':str(PY),'python_version':subprocess.check_output([str(PY),'-I','-c','import sys; print(sys.version)'],cwd=CHECKS,env=env,text=True).strip(),'environment':{'PYTHONPATH':'removed','PYTHONNOUSERSITE':'1','PYTHONUTF8':'1','system_site_packages':False},'results':results}
( ROOT/'build'/'smoke-runner-result.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2))
if any(r['exit_code']!=0 for r in results): sys.exit(1)