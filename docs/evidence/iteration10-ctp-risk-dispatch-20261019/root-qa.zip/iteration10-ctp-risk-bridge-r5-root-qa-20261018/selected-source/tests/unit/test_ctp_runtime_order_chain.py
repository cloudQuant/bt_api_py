"""Runtime-built execution service chains over one synthetic CTP API leaf.

The built-in service component, Store, admission gates, bridge, TraderClient,
callback SPI/verifier, CTP owner, and managed ports are production objects.
The native API, owner-cancel quota callback, and OrderRef cutover proof are
synthetic leaves; native callbacks still enter through the already-registered
SPI. This is source-fake integration evidence, not actual cutover, quota,
account, or exchange acceptance.
"""

from __future__ import annotations

import traceback
from collections.abc import Mapping
from dataclasses import replace
from decimal import Decimal
from pathlib import Path
from types import SimpleNamespace

import pytest
import test_ctp_callback_evidence as callback_fixtures
import test_ctp_execution_runtime as runtime_fixtures
import test_ctp_order_target_query as query_fixtures
from bt_api_base.service_protocol import WireIdentity, WireRole, WireScope
from bt_api_execution import (
    CtpDispatchCallbackApplyResult,
    CtpDispatchTradeFactApplyResult,
    ExecutionState,
    OrderIntent,
    OrderType,
    PositionEffect,
    Side,
    TimeInForce,
)
from bt_api_execution.ctp_single_worker_candidate import stable_managed_command_id
from bt_api_risk import (
    CancelDispatchResolutionReceiptStatus,
    DispatchResolutionReceiptStatus,
)

from bt_api_py.service_registry import ServiceCallContext

_PRINCIPAL = "ctp-runtime-strategy-client"
_RUN_ID = "ctp-runtime-order-chain-run"
_INSTRUMENT = "rb2610"
_EXCHANGE = "SHFE"
_CUTOVER_ANCHOR_INTENT = "ctp-runtime-order-ref-cutover-anchor"


def _service_context(case) -> ServiceCallContext:
    identity = WireIdentity(
        WireRole.STRATEGY_CLIENT,
        _PRINCIPAL,
        case.execution_scope.strategy_id,
    )
    wire_scope = WireScope(
        case.service_scope.execution_domain_ref,
        account_ref=case.execution_scope.account_ref,
        strategy_ref=case.execution_scope.strategy_id,
        run_id=_RUN_ID,
    )
    return ServiceCallContext(
        identity,
        wire_scope,
        "ctp-runtime-order-chain-registration",
        _PRINCIPAL,
    )


def _owner_control_context(case) -> ServiceCallContext:
    identity = WireIdentity(
        WireRole.SERVICE,
        "execution-owner-service",
        case.execution_scope.strategy_id,
    )
    wire_scope = WireScope(
        case.service_scope.execution_domain_ref,
        account_ref=case.execution_scope.account_ref,
        strategy_ref=case.execution_scope.strategy_id,
        run_id=_RUN_ID,
    )
    return ServiceCallContext(
        identity,
        wire_scope,
        "ctp-runtime-owner-control-registration",
        identity.principal_ref,
    )


def _build_owner_control_execution_component(case, monkeypatch):
    """Use the real owner route with a synthetic no-op quota callback."""

    admission_calls = []
    original_factory = case.config.risk_admission_factory

    def risk_admission_factory(context):
        admission = dict(original_factory(context))

        def cancel_quota_admission(*args):
            admission_calls.append(args)
            return None

        admission["cancel_quota_admission"] = cancel_quota_admission
        return admission

    case.provider.config = replace(
        case.config, risk_admission_factory=risk_admission_factory
    )
    case.cancel_quota_calls = admission_calls

    # `_prepared()` normally asks the service-host fixture to bind a socket.
    # Keep this composed component test on the same fixed synthetic endpoint
    # as the runtime fixture so the socket guard remains in force.
    monkeypatch.setattr(
        runtime_fixtures.service_host_fixtures,
        "_endpoint",
        lambda: "tcp://127.0.0.1:17991",
    )
    service_components = runtime_fixtures.service_component_fixtures
    prepared = service_components._prepared(
        ports=(
            "service.order_entry",
            "service.order_query",
            "service.owner_control",
        )
    )
    monkeypatch.setattr(service_components, "_prepared", lambda: prepared)
    return runtime_fixtures._build_execution_component(case, monkeypatch)


def _submit_diagnostics(case, api, intent_id: str, reply) -> dict[str, object]:
    result = reply.get("result") if isinstance(reply, Mapping) else None
    record = result.get("record") if isinstance(result, Mapping) else None
    admission = case.resources.values.get("admission")
    bridge = admission.get("order_gate") if isinstance(admission, Mapping) else None
    binding = (
        bridge.read_dispatch_binding(_PRINCIPAL, intent_id)
        if bridge is not None
        else None
    )
    return {
        "response_ok": reply.get("ok") if isinstance(reply, Mapping) else None,
        "response_code": reply.get("code") if isinstance(reply, Mapping) else None,
        "record_state": record.get("state") if isinstance(record, Mapping) else None,
        "record_unknown_reason": (
            record.get("unknown_reason") if isinstance(record, Mapping) else None
        ),
        "native_counts": _counts(api),
        "risk_dispatch_binding_present": binding is not None,
        "submit_authorized_errors": getattr(
            case, "submit_authorized_errors", []
        ),
    }


def _seed_synthetic_order_ref_cutover(case):
    """Seed a separate anchor with the established synthetic proof fixture."""

    runtime = case.provider.last_runtime
    assert runtime is not None
    store = case.resources.values["store"]
    owner = runtime._execution_owner
    session_binding = store.read_ctp_callback_session_context_facts(
        owner._owner_handle
    )[0]
    assert session_binding.session_generation_id == owner._session_generation_id

    execution_fixtures = runtime_fixtures.ctp_owner_fixtures.execution_fixtures
    anchor_intent = replace(
        execution_fixtures._intent(case.execution_scope, quantity=Decimal("1")),
        intent_id=_CUTOVER_ANCHOR_INTENT,
        signal_id=_CUTOVER_ANCHOR_INTENT + "-signal",
    )
    store.admit_intent(anchor_intent, writer_lease=runtime._writer_lease)
    proof = replace(
        execution_fixtures._order_ref_proof(
            case.execution_scope, session_binding.session_generation_id
        ),
        native_front_id=session_binding.dispatch_front_id,
        native_session_id=session_binding.dispatch_session_id,
    )
    reservation = store.seed_ctp_order_ref_and_reserve_identity(
        case.execution_scope,
        proof,
        anchor_intent.intent_id,
        execution_fixtures._runtime_order_id(anchor_intent.intent_id),
        writer_lease=runtime._writer_lease,
    )
    assert reservation.managed_intent_id == _CUTOVER_ANCHOR_INTENT
    return proof, reservation


def _observe_authenticated_reserve(case, monkeypatch):
    """Observe finite bridge failures while preserving the real call path."""

    runtime = case.provider.last_runtime
    assert runtime is not None
    bridge = runtime._order_gate
    original = bridge.reserve_for_authenticated_execution
    errors: list[dict[str, object]] = []

    def observe(intent, *, admission_context, writer_lease, dispatch_port):
        try:
            return original(
                intent,
                admission_context=admission_context,
                writer_lease=writer_lease,
                dispatch_port=dispatch_port,
            )
        except Exception as exc:
            frames = traceback.extract_tb(exc.__traceback__)
            frame = frames[-1] if frames else None
            error_code = getattr(exc, "code", None)
            errors.append(
                {
                    "exception_type": type(exc).__name__,
                    "error_code": error_code if type(error_code) is str else None,
                    "filename": Path(frame.filename).name if frame is not None else None,
                    "line": frame.lineno if frame is not None else None,
                }
            )
            raise

    monkeypatch.setattr(
        bridge, "reserve_for_authenticated_execution", observe, raising=True
    )
    return errors


def _observe_submit_authorized(case, monkeypatch) -> None:
    """Capture finite exceptions from the real managed submit port call."""

    submit_port = case.resources.values["dispatch"]
    issuer = submit_port._issuer
    original_verify = issuer.verify_action
    authority_errors: list[dict[str, object]] = []

    def observe_verify(command, *, now_ns):
        try:
            return original_verify(command, now_ns=now_ns)
        except Exception as exc:
            frames = traceback.extract_tb(exc.__traceback__)
            frame = frames[-1] if frames else None
            error_code = getattr(exc, "code", None)
            authority_errors.append(
                {
                    "exception_type": type(exc).__name__,
                    "error_code": error_code if type(error_code) is str else None,
                    "filename": Path(frame.filename).name if frame is not None else None,
                    "line": frame.lineno if frame is not None else None,
                }
            )
            raise

    case.authority_verify_errors = authority_errors
    monkeypatch.setattr(issuer, "verify_action", observe_verify, raising=True)

    original = submit_port.submit_authorized
    errors: list[dict[str, object]] = []

    def observe(intent, authorization):
        try:
            return original(intent, authorization)
        except Exception as exc:
            frames = traceback.extract_tb(exc.__traceback__)
            frame = frames[-1] if frames else None
            error_code = getattr(exc, "code", None)
            errors.append(
                {
                    "exception_type": type(exc).__name__,
                    "error_code": error_code if type(error_code) is str else None,
                    "filename": Path(frame.filename).name if frame is not None else None,
                    "line": frame.lineno if frame is not None else None,
                }
            )
            raise

    case.submit_authorized_errors = errors
    monkeypatch.setattr(submit_port, "submit_authorized", observe, raising=True)


def _order_arguments(intent_id: str) -> dict[str, object]:
    return {
        "intent_id": intent_id,
        "signal_id": intent_id + "-signal",
        "instrument": _INSTRUMENT,
        "side": Side.BUY.value,
        "position_effect": PositionEffect.OPEN.value,
        "order_type": OrderType.LIMIT.value,
        "quantity": "2",
        "price": "100",
        "time_in_force": TimeInForce.DAY.value,
        "reduce_only": False,
        "metadata_version": "ctp-runtime-chain-v1",
        "deadline_ns": None,
        "tags": {},
    }


def _install_submit_callback(case, api, intent_id: str):
    runtime = case.provider.last_runtime
    assert runtime is not None
    owner = runtime._execution_owner
    facts = case.resources.values["store"].read_ctp_callback_session_context_facts(
        owner._owner_handle
    )
    session_binding = facts[0]
    callback_case = SimpleNamespace(
        trader=runtime._trader,
        scope=case.execution_scope,
        session_binding=session_binding,
    )

    def req_order_insert(field, request_id):
        api.calls.append(("ReqOrderInsert", field, request_id))
        store = case.resources.values["store"]
        intent = store.get_intent(intent_id, scope=case.execution_scope)
        reservation = store.read_ctp_order_identity(case.execution_scope, intent_id)
        assert type(intent) is OrderIntent
        assert reservation is not None
        assert field.OrderRef == reservation.order_ref
        callback_fixtures._emit_order_status(
            callback_case,
            intent,
            reservation,
            request_id,
            status="3",
            submit_status="3",
            traded=0,
            sequence=1,
        )
        return 0

    return callback_case, session_binding, req_order_insert


def _install_cancel_callbacks(case, api, monkeypatch, callback_case, intent_id):
    store = case.resources.values["store"]
    intent = store.get_intent(intent_id, scope=case.execution_scope)
    reservation = store.read_ctp_order_identity(case.execution_scope, intent_id)
    assert type(intent) is OrderIntent
    assert reservation is not None
    query_case = SimpleNamespace(
        api=api,
        scope=case.execution_scope,
        session_binding=callback_case.session_binding,
    )
    native_row = query_fixtures._native_order(
        query_case,
        intent=intent,
        reservation=reservation,
    )
    query_fixtures._install_native_query_rows(query_case, monkeypatch, (native_row,))
    submit_calls = [call for call in api.calls if call[0] == "ReqOrderInsert"]
    assert len(submit_calls) == 1
    submit_request_id = submit_calls[0][2]

    def req_order_action(field, request_id):
        api.calls.append(("ReqOrderAction", field, request_id))
        api.spi.OnRspOrderAction(
            field,
            SimpleNamespace(ErrorID=0, ErrorMsg="synthetic CTP action ACK"),
            request_id,
            True,
        )
        callback_fixtures._emit_order_status(
            callback_case,
            intent,
            reservation,
            submit_request_id,
            status="5",
            submit_status="3",
            traded=0,
            sequence=2,
        )
        return 0

    monkeypatch.setattr(api, "ReqOrderAction", req_order_action, raising=False)


def _counts(api) -> tuple[int, int, int]:
    names = [call[0] for call in api.calls]
    return (
        names.count("ReqOrderInsert"),
        names.count("ReqQryOrder"),
        names.count("ReqOrderAction"),
    )


def _submit_binding(case, intent_id: str):
    store = case.resources.values["store"]
    reservation = store.read_ctp_order_identity(case.execution_scope, intent_id)
    assert reservation is not None
    command_id = stable_managed_command_id(
        "submit", intent_id, reservation.runtime_order_id
    )
    command = store.read_ctp_dispatch_command(case.execution_scope, command_id)
    assert command is not None
    return reservation, command_id, command


@pytest.mark.unit
def test_runtime_built_service_submits_queries_and_cancels_once_on_the_same_ctp_owner(
    tmp_path, monkeypatch
):
    with runtime_fixtures._runtime_case(tmp_path, monkeypatch) as case:
        component = _build_owner_control_execution_component(case, monkeypatch)
        _seed_synthetic_order_ref_cutover(case)
        reserve_errors = _observe_authenticated_reserve(case, monkeypatch)
        _observe_submit_authorized(case, monkeypatch)
        resources = case.resources
        runtime = case.provider.last_runtime
        assert resources is not None and runtime is not None
        api = case.factory.instances[0]
        intent_id = "ctp-runtime-chain-cancel"
        callback_case, session_binding, req_order_insert = _install_submit_callback(
            case, api, intent_id
        )
        monkeypatch.setattr(api, "ReqOrderInsert", req_order_insert, raising=False)
        context = _service_context(case)

        submitted = component.handlers["orders.submit"](
            context, _order_arguments(intent_id)
        )
        assert reserve_errors == [], reserve_errors
        assert case.authority_verify_errors == [], (
            f"authority_verify_errors={case.authority_verify_errors!r}"
        )
        assert case.submit_authorized_errors == [], (
            f"submit_authorized_errors={case.submit_authorized_errors!r}"
        )
        assert submitted["ok"] is True, _submit_diagnostics(
            case, api, intent_id, submitted
        )
        assert submitted["result"]["record"]["state"] == ExecutionState.ACKED.value, (
            _submit_diagnostics(case, api, intent_id, submitted)
        )
        assert _counts(api) == (1, 0, 0)
        reservation, submit_command_id, submit_command = _submit_binding(case, intent_id)
        assert submit_command.operation == "SUBMIT"
        assert submit_command.status == "COMPLETED"
        assert submit_command.local_queue_receipt_queued is True

        queried = component.handlers["orders.query"](
            context, {"intent_id": intent_id}
        )
        assert queried["ok"] is True
        assert queried["result"]["record"]["state"] == ExecutionState.ACKED.value
        assert _counts(api) == (1, 0, 0)

        bridge = resources.values["admission"]["order_gate"]
        risk_binding_before = bridge.read_dispatch_binding(_PRINCIPAL, intent_id)
        assert risk_binding_before is not None
        assert risk_binding_before["submit_command_id"] == submit_command_id
        assert risk_binding_before["managed_intent_id"] == intent_id
        assert risk_binding_before["runtime_order_id"] == reservation.runtime_order_id
        assert risk_binding_before["order_ref"] == reservation.order_ref
        assert risk_binding_before["native_request_id"] == (
            submit_command.correlation_key.native_request_id
        )
        assert runtime._execution_owner is resources.values["dispatch"]._owner
        assert runtime._execution_owner is resources.values["cancel_dispatch"]._owner
        submit_risk_receipt = case.risk_gate.dispatch_resolution_receipt(
            risk_binding_before["permit_id"]
        )
        assert submit_risk_receipt.status is DispatchResolutionReceiptStatus.UNRESOLVED_ACTIVE
        assert submit_risk_receipt.dispatch_latch_active is True

        _install_cancel_callbacks(
            case, api, monkeypatch, callback_case, intent_id
        )
        cancelled = component.handlers["owner.cancel"](
            _owner_control_context(case),
            {"command_id": "ctp-runtime-owner-cancel-batch"},
        )
        assert cancelled["ok"] is True
        assert cancelled["result"]["outcome"] == "APPLIED"
        assert cancelled["result"]["total_count"] == 1
        item = cancelled["result"]["items"][0]
        assert item["intent_id"] == intent_id
        assert item["decision"] == "READY"
        assert item["cancel_state"] == ExecutionState.CANCELLED.value
        assert item["dispatch_attempts"] == 1
        assert len(case.cancel_quota_calls) == 1
        quota_args = case.cancel_quota_calls[0]
        assert quota_args[:5] == (
            case.execution_scope.account_ref,
            case.execution_scope.strategy_id,
            _RUN_ID,
            _INSTRUMENT,
            "CANCEL",
        )
        assert type(quota_args[5]) is int and quota_args[5] > 0
        assert _counts(api) == (1, 1, 1)
        cancel_id = item["cancel_id"]
        cancel_record = resources.values["store"].get_cancel(
            cancel_id, scope=case.execution_scope
        )
        assert cancel_record is not None
        assert cancel_record.dispatch_attempts == 1
        assert cancel_record.review_required is True
        cancel_command_id = stable_managed_command_id(
            "cancel", intent_id, reservation.runtime_order_id, cancel_id
        )
        cancel_command = resources.values["store"].read_ctp_dispatch_command(
            case.execution_scope, cancel_command_id
        )
        assert cancel_command is not None
        assert cancel_command.operation == "CANCEL"
        assert cancel_command.status == "COMPLETED"
        action_call = next(call for call in api.calls if call[0] == "ReqOrderAction")
        assert action_call[1].OrderActionRef == (
            cancel_command.correlation_key.native_action_ref
        )
        assert action_call[2] == cancel_command.correlation_key.native_request_id
        assert cancel_command.local_queue_receipt_queued is True
        cancel_risk_receipt = case.risk_gate.cancel_dispatch_resolution_receipt(
            cancel_record.permit_reference
        )
        assert cancel_risk_receipt.status is (
            CancelDispatchResolutionReceiptStatus.UNRESOLVED_ACTIVE
        )
        assert cancel_risk_receipt.dispatch_latch_active is True
        assert case.risk_gate.dispatch_resolution_receipt(
            risk_binding_before["permit_id"]
        ) == submit_risk_receipt
        assert risk_binding_before == bridge.read_dispatch_binding(_PRINCIPAL, intent_id)

        replay = component.handlers["owner.cancel"](
            _owner_control_context(case),
            {"command_id": "ctp-runtime-owner-cancel-batch"},
        )
        assert replay == cancelled
        assert _counts(api) == (1, 1, 1)
        assert len(case.cancel_quota_calls) == 1
        assert session_binding.dispatch_front_id == 7
        assert session_binding.dispatch_session_id == 19


@pytest.mark.unit
def test_runtime_built_service_persists_real_trade_callback_without_inventing_fees(
    tmp_path, monkeypatch
):
    with runtime_fixtures._runtime_case(tmp_path, monkeypatch) as case:
        component = runtime_fixtures._build_execution_component(case, monkeypatch)
        _seed_synthetic_order_ref_cutover(case)
        reserve_errors = _observe_authenticated_reserve(case, monkeypatch)
        _observe_submit_authorized(case, monkeypatch)
        resources = case.resources
        runtime = case.provider.last_runtime
        assert resources is not None and runtime is not None
        api = case.factory.instances[0]
        intent_id = "ctp-runtime-chain-partial-fill"
        callback_case, _session_binding, req_order_insert = _install_submit_callback(
            case, api, intent_id
        )
        monkeypatch.setattr(api, "ReqOrderInsert", req_order_insert, raising=False)
        context = _service_context(case)

        submitted = component.handlers["orders.submit"](
            context, _order_arguments(intent_id)
        )
        assert reserve_errors == [], reserve_errors
        assert case.authority_verify_errors == [], (
            f"authority_verify_errors={case.authority_verify_errors!r}"
        )
        assert case.submit_authorized_errors == [], (
            f"submit_authorized_errors={case.submit_authorized_errors!r}"
        )
        assert submitted["ok"] is True, _submit_diagnostics(
            case, api, intent_id, submitted
        )
        assert submitted["result"]["record"]["state"] == ExecutionState.ACKED.value, (
            _submit_diagnostics(case, api, intent_id, submitted)
        )
        reservation, command_id, command = _submit_binding(case, intent_id)
        intent = resources.values["store"].get_intent(
            intent_id, scope=case.execution_scope
        )
        assert type(intent) is OrderIntent

        callback_fixtures._emit_trade(
            callback_case,
            intent,
            reservation,
            trade_id="RUNTIMEFAKE-TRADE-001",
            sequence=1,
            volume=1,
        )
        callback_fixtures._emit_order_status(
            callback_case,
            intent,
            reservation,
            next(call[2] for call in api.calls if call[0] == "ReqOrderInsert"),
            status="1",
            submit_status="1",
            traded=1,
            sequence=2,
        )
        applied = runtime._execution_owner.pump_callbacks(32)
        assert len(applied) == 2
        assert type(applied[0]) is CtpDispatchTradeFactApplyResult
        assert applied[0].trade_quantity == 1
        assert applied[0].cumulative_trade_quantity == 1
        assert applied[0].duplicate is False
        assert type(applied[1]) is CtpDispatchCallbackApplyResult
        assert applied[1].projection_state == "PARTIALLY_FILLED"

        queried = component.handlers["orders.query"](
            context, {"intent_id": intent_id}
        )
        assert queried["ok"] is True
        # This is the public ExecutionRecord read path, not callback
        # reconciliation. Pumping the real CTP inbox updates the CTP Store
        # snapshot below; the service query does not mutate this record.
        assert queried["result"]["record"]["state"] == ExecutionState.ACKED.value
        assert _counts(api) == (1, 0, 0)

        facts = resources.values["store"].read_ctp_dispatch_trade_facts(
            case.execution_scope, command_id
        )
        assert len(facts.trades) == 1
        trade = facts.trades[0]
        assert trade.trade_id == "RUNTIMEFAKE-TRADE-001"
        assert trade.trade_quantity == 1
        assert trade.cumulative_trade_quantity == 1
        assert trade.trade_price == Decimal("100")
        assert trade.cumulative_commission is None
        assert trade.commission_quality == "INCOMPLETE"
        snapshot = resources.values["store"].read_ctp_owner_callback_observation_snapshot(
            case.execution_scope, command_id
        )
        assert snapshot.provider_state == "PARTIALLY_FILLED"
        assert snapshot.filled_quantity == 1
        assert snapshot.trade_fact_count == 1
        assert snapshot.trade_notional == Decimal("100")
        assert snapshot.cumulative_commission is None
        assert snapshot.commission_quality == "INCOMPLETE"

        bridge = resources.values["admission"]["order_gate"]
        risk_binding = bridge.read_dispatch_binding(_PRINCIPAL, intent_id)
        assert risk_binding is not None
        assert risk_binding["submit_command_id"] == command.command_id
        assert risk_binding["runtime_order_id"] == reservation.runtime_order_id
        assert risk_binding["order_ref"] == reservation.order_ref
        submit_risk_receipt = case.risk_gate.dispatch_resolution_receipt(
            risk_binding["permit_id"]
        )
        assert submit_risk_receipt.status is DispatchResolutionReceiptStatus.UNRESOLVED_ACTIVE
        assert submit_risk_receipt.dispatch_latch_active is True

        denied = component.handlers["orders.submit"](
            context, _order_arguments("ctp-runtime-chain-increase-while-latched")
        )
        assert denied["ok"] is False
        assert denied["code"] == "ADMISSION_REQUIRED"
        assert denied["result"]["record"]["state"] == ExecutionState.BLOCKED.value
        assert _counts(api) == (1, 0, 0)
        assert case.risk_gate.dispatch_resolution_receipt(
            risk_binding["permit_id"]
        ) == submit_risk_receipt

