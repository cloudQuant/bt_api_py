"""One fresh spawned client-source guard check; no Host or business runtime."""
import hashlib
import importlib
import json
import multiprocessing
import os
from pathlib import Path
import sys
from types import ModuleType


def check_guard(root, manifest, output):
    package_names = ("bt_api_base", "bt_api_execution", "bt_api_gateway", "bt_api_monitor", "bt_api_risk", "bt_api_transport_zmq")
    sys.path[:0] = [root] + [str(Path(root) / "bt_api" / name / "src") for name in package_names]
    runner = importlib.import_module("tests.unit.test_load01_hundred_strategy_30min")
    checked = runner._check_fixed_strategy_source_manifest(manifest, profile_id="U0")
    names = checked["loaded_client_modules"]
    expected_helpers = {"tests.unit._load01_profiles", "tests.unit._load01_metrics", "tests.unit._load01_recovery_timing", "tests.unit._load01_resource_diagnostics"}
    assert expected_helpers <= names.keys()
    assert "bt_api_transport_zmq.market_v2" in names
    assert "bt_api_py.service_host" not in sys.modules
    rejections = []
    for name in ("tests.unit._load01_group_probe", "tests.unit._load01_n5_probe"):
        assert name not in sys.modules
        sys.modules[name] = ModuleType(name)
        try:
            try:
                runner._check_fixed_strategy_source_manifest(manifest, profile_id="U0")
            except AssertionError as exc:
                assert "ordinary strategy imported server module" in str(exc)
                rejections.append(name)
            else:
                raise AssertionError("forbidden helper stem was accepted")
        finally:
            del sys.modules[name]
    name = "bt_api_gateway_neighbor"
    assert name not in sys.modules
    sys.modules[name] = ModuleType(name)
    try:
        runner._check_fixed_strategy_source_manifest(manifest, profile_id="U0")
    finally:
        del sys.modules[name]
    with Path(output).open("x", encoding="utf-8") as handle:
        json.dump({"scope": "spawned client-source guard only; no Host or business runtime", "bound_module_count": len(names), "required_helpers_bound": sorted(expected_helpers), "market_transport_bound": True, "forbidden_stems_rejected": rejections, "package_neighbor_not_misclassified": True, "service_host_absent": True}, handle, indent=2)


if __name__ == "__main__":
    spec = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    for key in spec.get("unset_environment", []):
        os.environ.pop(key, None)
    os.environ.update(spec["environment"])
    def verify():
        for name, expected in spec["source_sha256"].items():
            assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == expected, name
    verify()
    output = Path(sys.argv[3])
    assert not output.exists()
    child = multiprocessing.get_context("spawn").Process(target=check_guard, args=(spec["cwd"], sys.argv[2], str(output)), name="load01-client-source-guard")
    child.start()
    child.join(45)
    assert not child.is_alive(), "guard child exceeded 45 seconds"
    code = child.exitcode
    child.close()
    verify()
    assert code == 0, code
    print(json.dumps({"exit_code": code, "source_pins_unchanged": len(spec["source_sha256"]), "result": json.loads(output.read_text(encoding="utf-8"))}))
