"""Focused local QA guards with complete source-origin postflight metadata."""
import importlib.abc
import importlib.machinery
from pathlib import Path
import sys
import platform
import json
import os
import asyncio
import urllib3  # Complete the library's local IPv6 probe before candidate guards.

DENIED = []
platform.node()
ROOT = Path(__file__).resolve().parent
EXCLUDED_CTP_NATIVE_IMPORTS = []


class NoCtpNativeBinary(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname in {"bt_api_ctp.ctp._ctp", "_ctp"}:
            EXCLUDED_CTP_NATIVE_IMPORTS.append(fullname)
            raise ImportError("CTP native extension excluded from fixed Python-source fixture")
        return None


sys.meta_path.insert(0, NoCtpNativeBinary())


def no_external_calls(event, args):
    if event in {"socket.connect", "socket.bind", "subprocess.Popen", "os.system",
                 "os.exec", "os.posix_spawn", "_winapi.CreateProcess"}:
        DENIED.append(event)
        raise RuntimeError("external operation forbidden in callback component QA")


sys.addaudithook(no_external_calls)


def pytest_sessionfinish(session, exitstatus):
    spec = json.loads(Path(os.environ["CTP_SERVICE_QA_SPEC"]).read_text(encoding="utf-8"))
    expected = {name: Path(path).resolve() for name, path in spec["expected_origins"].items()}
    snapshot = dict(sys.modules)
    names = sorted(set(expected) | {"bt_api_ctp.ctp._ctp_base"} | {name for name in snapshot if name.startswith("bt_api_")})
    metadata = {}
    failures = []
    namespace_paths = {"bt_api_risk.containers": (ROOT / "risk/src/bt_api_risk/containers").resolve()}
    for name in names:
        module = snapshot.get(name)
        module_spec = getattr(module, "__spec__", None)
        loader = getattr(module_spec, "loader", None)
        origin = getattr(module, "__file__", None)
        locations = getattr(module_spec, "submodule_search_locations", None)
        paths = list(getattr(module, "__path__", ()))
        metadata[name] = {
            "present": module is not None, "file": origin,
            "spec_name": getattr(module_spec, "name", None),
            "spec_origin": getattr(module_spec, "origin", None),
            "loader_type": type(loader).__module__ + "." + type(loader).__qualname__,
            "path": paths, "search_locations": list(locations) if locations is not None else None,
            "loader_identity": getattr(module, "__loader__", None) is loader,
            "path_identity": getattr(module, "__path__", None) is locations,
        }
        problems = []
        if module is None:
            problems.append("missing_module")
        elif name in namespace_paths:
            directory = namespace_paths[name]
            if not (
                origin is None and module_spec is not None
                and module_spec.name == name and module.__name__ == name
                and module_spec.origin is None
                and type(loader) is importlib.machinery.NamespaceLoader
                and module.__loader__ is loader
                and module.__path__ is locations
                and [Path(p).resolve() for p in paths] == [directory]
                and directory.is_relative_to(ROOT)
                and not (directory / "__init__.py").exists()
                and (directory / "risk_metrics.py").is_file()
                and (directory / "risk_events.py").is_file()
            ):
                problems.append("namespace_binding_invalid")
        else:
            if not isinstance(origin, str) or not origin:
                problems.append("file_origin_missing")
            else:
                path = Path(origin).resolve()
                if not path.is_relative_to(ROOT) or path.suffix != ".py":
                    problems.append("file_outside_fixed_python_sources")
                if module_spec is None or module_spec.name != name or not isinstance(module_spec.origin, str) or Path(module_spec.origin).resolve() != path:
                    problems.append("spec_origin_mismatch")
                if type(loader) is not importlib.machinery.SourceFileLoader or getattr(module, "__loader__", None) is not loader:
                    problems.append("source_loader_mismatch")
        if name in expected and (not isinstance(origin, str) or Path(origin).resolve() != expected[name]):
            problems.append("expected_origin_mismatch")
        if name == "bt_api_ctp" or name.startswith("bt_api_ctp."):
            if not isinstance(origin, str) or not Path(origin).resolve().is_relative_to(ROOT / "ctp/src/bt_api_ctp"):
                problems.append("ctp_origin_mismatch")
        failures.extend({"module": name, "code": code} for code in problems)
    base = snapshot.get("bt_api_ctp.ctp._ctp_base")
    fallback = False
    try:
        fallback = base is not None and type(base._ctp) is base._FallbackCtpModule and base.is_ctp_native_loaded() is False
    except Exception as error:
        failures.append({"module": "bt_api_ctp.ctp._ctp_base", "code": "fallback_contract_error", "error_type": type(error).__name__})
    if not fallback or not EXCLUDED_CTP_NATIVE_IMPORTS:
        failures.append({"module": "bt_api_ctp", "code": "python_fallback_unproven"})
    if DENIED:
        failures.append({"module": "candidate", "code": "external_operation_denied"})
    report = {"origins": {name: metadata[name]["file"] for name in expected},
              "module_metadata": metadata, "failures": failures,
              "denied_events": DENIED, "excluded_ctp_native_imports": EXCLUDED_CTP_NATIVE_IMPORTS,
              "ctp_source_fallback": fallback,
              "guard_scope": "listed process/network audit events and CTP extension rejection; fixed Python source with fake API, not general OS isolation"}
    Path(os.environ["CTP_OBSERVATION_QA_OUTPUT"]).joinpath("guard.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    assert not failures, "source/operation postflight failed; see complete guard.json"
