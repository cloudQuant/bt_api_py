# 失败历史（只索引必要原始证据）

R1–R8 的原始 runner 和未复制工件仍保留于其原路径；本包只含失败 result/preflight/log 与清理收据。没有失败重试。

- R1：cmd AutoRun 引发 `cmd.exe /c ver → conda activate → python` 递归；Root 只终止本轮拥有的链，最终清理收据 `owned_remaining=0`。runner 17,489 B / `f59b44c1c4d854c5599893b62577c4a85fa09a893ff27d610b011f29dd3260bd`。
- R2：CPython `subprocess.py` 源 SHA 转录错误，Root preflight exit 2；无 child/result。runner 36,073 B / `d111dc1717419bd1b7c2cd06f1b29be290d2b804c9d7b3de40eaf109ba47ee0b`。
- R3：安装版 NumPy optional `lscpu` 本机探测被 harness process audit 拒绝。runner 36,074 B / `c793a8fe760cce94844721e3e8f666da50119a6c4f345de2d963eb9e10c0bd1c`。
- R4：preflight 的路径分隔符匹配未兼容 Windows 反斜杠，未创建 child。runner 57,179 B / `4960b4c3445dbffa02d1d5fb4baa7de714de308890fd503ab69dc009c21b25bc`。
- R5：child imports 前的 CRLF/LF 文本断言失败。runner 57,198 B / `accac6081e16256a933220bc71a3de868cfc9e4b4f33278555966e5a0b2fa036`。
- R6：安装版 `bt_api_base.event_clock` 的本机 `socket.gethostname` 元数据事件被误拦。runner 57,220 B / `d9780658566ea486e984d1d024de3c886b840e750d7a99d67aaa8c11b131d003`。
- R7：安装版 urllib3 IPv6 能力 probe 的 `socket.__new__` 事件尚未分类。runner 64,542 B / `4ef3c282640f69d697318f505dbbe8148d32b3010c2a4c460db635aff70ff2c7`。
- R8：36,776 字符 `-c` command line 超过 Windows 32,767 限制，WinError 206 在 child 启动前发生。runner 97,923 B / `cfa7fad48c8406de483263669891abbc816c5ff3875aefeb16fbea4a1e2de06d`。
- R9：仅以固定 child 文件启动同一 step06；没有重跑 consumer R1 steps01–05，没有重建/重装旧 wheels。