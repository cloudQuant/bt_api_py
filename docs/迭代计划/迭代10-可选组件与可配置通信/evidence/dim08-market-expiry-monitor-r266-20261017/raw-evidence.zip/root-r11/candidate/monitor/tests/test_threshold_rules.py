"""Focused windowed-count threshold rule tests over durable outbox consumption.

The real-chain node mirrors the MON01-era fixture pattern: a real production
producer (:class:`MonitorIngressService`) appends validated events to a real
SQLite durable outbox, and a rule consumer consumes them.  The consumer
"restart" is a fresh ``DurableOutbox``/loop pair over the same on-disk outbox,
standing in for a replacement process; no fixture is a synthetic provider.
"""

from __future__ import annotations

import ast
import dataclasses
import sys
from pathlib import Path

import pytest
from bt_api_base.service_protocol import WireIdentity, WireRole, WireScope

import bt_api_monitor.threshold_rules as threshold_rules_module
from bt_api_monitor.durable import DurableOutbox, OutboxDeliveryError, OutboxEvent
from bt_api_monitor.service_ingress import MonitorIngressService, MonitorIngressTarget
from bt_api_monitor.threshold_rules import (
    THRESHOLD_ALERT_ID_PREFIX,
    ScopedThresholdRuleLoop,
    ThresholdRule,
    ThresholdRuleError,
)

_SCOPE_A = "monitor:scope-a"
_SCOPE_B = "monitor:scope-b"
_CHAIN_SCOPE = "monitor:threshold-a"
_EVENT_TYPE = "order.status"


class MutableClock:
    def __init__(self, value: float = 1_700_000_000.0) -> None:
        self._value = value

    def __call__(self) -> float:
        return self._value

    def advance(self, seconds: float) -> None:
        self._value += seconds


def _rule(
    *,
    rule_id: str = "rule-a",
    outbox_scope: str = _SCOPE_A,
    event_type: str = _EVENT_TYPE,
    window_seconds: float = 60.0,
    threshold_count: int = 2,
) -> ThresholdRule:
    return ThresholdRule(
        rule_id=rule_id,
        outbox_scope=outbox_scope,
        event_type=event_type,
        window_seconds=window_seconds,
        threshold_count=threshold_count,
    )


def _event(
    event_id: str,
    *,
    scope: str = _SCOPE_A,
    event_type: str = _EVENT_TYPE,
    occurred_at: float = 1_700_000_000.0,
) -> OutboxEvent:
    return OutboxEvent(
        event_id=event_id,
        scope=scope,
        event_type=event_type,
        data={"status": "rejected"},
        occurred_at=occurred_at,
    )


def _chain_scope() -> WireScope:
    return WireScope(
        execution_domain_ref="paper:dim08",
        account_ref="account-a",
        strategy_ref="strategy-a",
    )


def _chain_identity() -> WireIdentity:
    return WireIdentity(
        role=WireRole.SERVICE,
        principal_ref="service:dim08-producer",
        actor_ref="producer-a",
        delegate_ref="delegate-a",
    )


def test_rule_configuration_is_scoped_bounded_and_fails_closed(tmp_path: Path) -> None:
    rule = _rule(window_seconds=60, threshold_count=3)
    assert rule.window_seconds == 60.0

    invalid_rule_kwargs = (
        {"rule_id": ""},
        {"rule_id": "wild*card"},
        {"rule_id": "spaced id"},
        {"rule_id": "r" * 129},
        {"outbox_scope": ""},
        {"outbox_scope": " padded "},
        {"outbox_scope": "*"},
        {"outbox_scope": "x" * 257},
        {"event_type": "bad\x01type"},
        {"event_type": "*"},
        {"window_seconds": 0},
        {"window_seconds": -1},
        {"window_seconds": float("inf")},
        {"window_seconds": float("nan")},
        {"window_seconds": True},
        {"window_seconds": 86_401.0},
        {"threshold_count": 0},
        {"threshold_count": True},
        {"threshold_count": 1_000_001},
    )
    for overrides in invalid_rule_kwargs:
        with pytest.raises(ThresholdRuleError):
            _rule(**{"window_seconds": 60.0, "threshold_count": 3, **overrides})

    database = tmp_path / "rules.sqlite"
    outbox = DurableOutbox(database, clock=MutableClock())
    read_only = DurableOutbox(database, read_only=True)
    valid = (_rule(),)

    with pytest.raises(ThresholdRuleError):
        ScopedThresholdRuleLoop(outbox, list(valid), lambda alert: None)  # type: ignore[arg-type]
    with pytest.raises(ThresholdRuleError):
        ScopedThresholdRuleLoop(outbox, (), lambda alert: None)
    with pytest.raises(ThresholdRuleError):
        ScopedThresholdRuleLoop(outbox, (valid[0], valid[0]), lambda alert: None)
    with pytest.raises(ThresholdRuleError):
        ScopedThresholdRuleLoop(outbox, ("not-a-rule",), lambda alert: None)  # type: ignore[arg-type]
    with pytest.raises(ThresholdRuleError):
        ScopedThresholdRuleLoop(read_only, valid, lambda alert: None)
    with pytest.raises(ThresholdRuleError):
        ScopedThresholdRuleLoop(outbox, valid, None)  # type: ignore[arg-type]
    with pytest.raises(ThresholdRuleError):
        ScopedThresholdRuleLoop(outbox, valid, lambda alert: None, consumer_id=" ")

    loop = ScopedThresholdRuleLoop(outbox, valid, lambda alert: None, clock=MutableClock())
    with pytest.raises(ThresholdRuleError):
        loop.run_once(limit=0)
    with pytest.raises(ThresholdRuleError):
        loop.run_once(limit=True)
    with pytest.raises(ThresholdRuleError):
        loop.checkpoint("monitor:not-configured")
    with pytest.raises(ThresholdRuleError):
        loop.rule_status("not-a-rule")


def test_windowed_threshold_fires_once_per_crossing_and_rearms(tmp_path: Path) -> None:
    clock = MutableClock()
    outbox = DurableOutbox(tmp_path / "rules.sqlite", clock=clock)
    for index in range(1, 4):
        outbox.append(_event(f"synthetic-{index}"))
    delivered = []
    loop = ScopedThresholdRuleLoop(
        outbox, (_rule(window_seconds=10.0, threshold_count=2),), delivered.append, clock=clock
    )

    first_pass = loop.run_once()
    assert [alert.rule_id for alert in first_pass] == ["rule-a"]
    first = first_pass[0]
    assert first.alert_id.startswith(THRESHOLD_ALERT_ID_PREFIX)
    assert first.observed_count == 2
    assert first.triggering_event_id == "synthetic-2"
    assert first.triggering_sequence == 2

    # The third event lands inside the (latched) window and must not re-fire.
    status = loop.rule_status("rule-a")
    assert status.window_count == 3
    assert status.alerts_emitted == 1
    assert status.armed is False
    assert len(delivered) == 1

    # After the window prunes empty, the next crossing re-arms and fires anew.
    clock.advance(11.0)
    for index in range(4, 6):
        outbox.append(_event(f"synthetic-{index}"))
    second_pass = loop.run_once()
    assert len(second_pass) == 1
    second = second_pass[0]
    assert second.triggering_event_id == "synthetic-5"
    assert second.observed_count == 2
    assert second.alert_id != first.alert_id
    assert second.triggered_at == clock()
    assert len(delivered) == 2


def test_redelivery_after_checkpoint_failure_does_not_double_count(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    clock = MutableClock()
    outbox = DurableOutbox(tmp_path / "rules.sqlite", clock=clock)
    for index in range(1, 6):
        outbox.append(_event(f"synthetic-{index}"))
    delivered = []
    loop = ScopedThresholdRuleLoop(
        outbox, (_rule(window_seconds=60.0, threshold_count=3),), delivered.append, clock=clock
    )

    original_acknowledge = outbox.acknowledge
    failing = {"armed": True}

    def flaky_acknowledge(consumer_id: str, scope: str, sequence: int) -> None:
        if sequence == 3 and failing["armed"]:
            failing["armed"] = False
            raise RuntimeError("checkpoint write lost")
        original_acknowledge(consumer_id, scope, sequence)

    monkeypatch.setattr(outbox, "acknowledge", flaky_acknowledge)
    with pytest.raises(OutboxDeliveryError):
        loop.run_once(limit=10)
    assert len(delivered) == 1
    assert delivered[0].observed_count == 3
    assert loop.checkpoint(_SCOPE_A) == 2
    status = loop.rule_status("rule-a")
    assert status.window_count == 3
    assert status.counted_events == 3
    assert status.last_counted_sequence == 3

    # The crossing event is redelivered; dedup by sequence watermark keeps the
    # window at five distinct events instead of six, and no second alert fires.
    monkeypatch.undo()
    assert loop.run_once(limit=10) == ()
    assert loop.checkpoint(_SCOPE_A) == 5
    status = loop.rule_status("rule-a")
    assert status.window_count == 5
    assert status.counted_events == 5
    assert status.last_counted_sequence == 5
    assert status.alerts_emitted == 1
    assert len(delivered) == 1


def test_ack_lost_at_crossing_redelivers_differently_anchored_alert_after_restart(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Review disclosure D1: a checkpoint lost AT the crossing re-alerts anew.

    Accepted advisory over-alerting semantics: the crossing alert is accepted,
    then the checkpoint write for that very event is lost.  After restart the
    replayed suffix is re-counted into a fresh window and re-derives a second
    alert anchored to a different event; sink de-duplication by ``alert_id``
    cannot collapse the two because the ids differ (durable rule state would
    be required, which this increment deliberately does not add).
    """

    clock = MutableClock()
    outbox = DurableOutbox(tmp_path / "rules.sqlite", clock=clock)
    for index in range(1, 6):
        outbox.append(_event(f"synthetic-{index}"))
    delivered = []

    def recording_sink(alert) -> None:
        delivered.append(alert)

    loop = ScopedThresholdRuleLoop(
        outbox, (_rule(window_seconds=60.0, threshold_count=3),), recording_sink, clock=clock
    )

    original_acknowledge = outbox.acknowledge
    failing = {"armed": True}

    def flaky_acknowledge(consumer_id: str, scope: str, sequence: int) -> None:
        if sequence == 3 and failing["armed"]:
            failing["armed"] = False
            raise RuntimeError("checkpoint write lost at the crossing")
        original_acknowledge(consumer_id, scope, sequence)

    monkeypatch.setattr(outbox, "acknowledge", flaky_acknowledge)
    with pytest.raises(OutboxDeliveryError):
        loop.run_once(limit=10)
    monkeypatch.undo()
    # Alert 1 is out, anchored to the crossing event; the cursor stayed at 2.
    assert [alert.triggering_event_id for alert in delivered] == ["synthetic-3"]
    assert delivered[0].triggering_sequence == 3
    assert delivered[0].observed_count == 3
    assert loop.checkpoint(_SCOPE_A) == 2

    # Restart on the same DB: the unacked suffix 3..5 is replayed and counted
    # into a fresh window; the crossing re-derives at seq 5, not at seq 3.
    restarted = ScopedThresholdRuleLoop(
        DurableOutbox(tmp_path / "rules.sqlite", clock=clock),
        (_rule(window_seconds=60.0, threshold_count=3),),
        recording_sink,
        clock=clock,
    )
    second_pass = restarted.run_once(limit=10)
    assert len(second_pass) == 1 and second_pass[0] is delivered[1]
    assert [alert.triggering_event_id for alert in delivered] == ["synthetic-3", "synthetic-5"]
    assert [alert.triggering_sequence for alert in delivered] == [3, 5]
    assert delivered[0].alert_id != delivered[1].alert_id
    assert restarted.checkpoint(_SCOPE_A) == 5
    status = restarted.rule_status("rule-a")
    assert status.window_count == 3
    assert status.counted_events == 3
    assert status.alerts_emitted == 1


def test_sink_failure_at_crossing_then_restart_below_threshold_does_not_reemit(
    tmp_path: Path,
) -> None:
    """Review disclosure D2: the crossing alert can be lost on restart.

    Accepted loss bound of the in-memory-only rule state: the sink call for
    the crossing fails, the event is never acknowledged, and the decided
    in-memory pending alert does not survive the restart.  Replaying a suffix
    shorter than the threshold re-counts below the threshold, so no alert is
    re-emitted; a later crossing alerts anew with its own anchor.
    """

    clock = MutableClock()
    outbox = DurableOutbox(tmp_path / "rules.sqlite", clock=clock)
    for index in range(1, 4):
        outbox.append(_event(f"synthetic-{index}"))
    attempts = []

    def failing_sink(alert) -> None:
        attempts.append(alert)
        raise RuntimeError("alert transport unavailable")

    loop = ScopedThresholdRuleLoop(
        outbox, (_rule(window_seconds=60.0, threshold_count=3),), failing_sink, clock=clock
    )
    with pytest.raises(OutboxDeliveryError):
        loop.run_once(limit=10)
    # The crossing was attempted once and never accepted; seq 3 was not acked.
    assert [alert.triggering_event_id for alert in attempts] == ["synthetic-3"]
    assert loop.checkpoint(_SCOPE_A) == 2

    # Restart on the same DB: only seq 3 is replayed (suffix < threshold), the
    # fresh window stays below the threshold, and no alert is re-emitted.
    accepted = []
    restarted = ScopedThresholdRuleLoop(
        DurableOutbox(tmp_path / "rules.sqlite", clock=clock),
        (_rule(window_seconds=60.0, threshold_count=3),),
        accepted.append,
        clock=clock,
    )
    assert restarted.run_once(limit=10) == ()
    assert accepted == []
    assert restarted.checkpoint(_SCOPE_A) == 3
    status = restarted.rule_status("rule-a")
    assert status.window_count == 1
    assert status.counted_events == 1
    assert status.alerts_emitted == 0

    # The loss is bounded to the lost crossing: a later crossing alerts anew
    # with a different anchor and alert id; the lost alert is not resurrected.
    for index in range(4, 6):
        outbox.append(_event(f"synthetic-{index}"))
    third_pass = restarted.run_once(limit=10)
    assert len(third_pass) == 1 and third_pass[0] is accepted[0]
    assert [alert.triggering_event_id for alert in accepted] == ["synthetic-5"]
    assert accepted[0].alert_id != attempts[0].alert_id
    assert len(attempts) == 1
    assert restarted.checkpoint(_SCOPE_A) == 5
    assert restarted.rule_status("rule-a").alerts_emitted == 1


def test_alert_sink_failure_replays_the_same_alert_once(tmp_path: Path) -> None:
    clock = MutableClock()
    outbox = DurableOutbox(tmp_path / "rules.sqlite", clock=clock)
    for index in range(1, 4):
        outbox.append(_event(f"synthetic-{index}"))
    calls = []
    failures = {"armed": True}

    def flaky_sink(alert) -> None:
        calls.append(alert)
        if failures["armed"]:
            failures["armed"] = False
            raise RuntimeError("alert transport unavailable")

    loop = ScopedThresholdRuleLoop(
        outbox, (_rule(window_seconds=60.0, threshold_count=3),), flaky_sink, clock=clock
    )
    with pytest.raises(OutboxDeliveryError):
        loop.run_once()
    # The alert was attempted but not accepted, and the event was not acked.
    assert loop.checkpoint(_SCOPE_A) == 2
    assert len(calls) == 1

    alerts = loop.run_once()
    assert [alert.alert_id for alert in alerts] == [calls[0].alert_id]
    assert len(calls) == 2
    assert calls[1].alert_id == calls[0].alert_id
    assert loop.checkpoint(_SCOPE_A) == 3
    assert loop.rule_status("rule-a").alerts_emitted == 1


def test_rules_stay_isolated_by_scope_and_event_type(tmp_path: Path) -> None:
    clock = MutableClock()
    outbox = DurableOutbox(tmp_path / "rules.sqlite", clock=clock)
    outbox.append(_event("a-1"))
    outbox.append(_event("a-2"))
    outbox.append(_event("a-cancelled", event_type="order.cancelled"))
    outbox.append(_event("b-1", scope=_SCOPE_B))
    outbox.append(_event("b-2", scope=_SCOPE_B))
    delivered = []
    loop = ScopedThresholdRuleLoop(
        outbox,
        (
            _rule(rule_id="rule-a", outbox_scope=_SCOPE_A, threshold_count=2),
            _rule(rule_id="rule-b", outbox_scope=_SCOPE_B, threshold_count=3),
        ),
        delivered.append,
        clock=clock,
    )
    assert loop.configured_scopes == (_SCOPE_A, _SCOPE_B)

    alerts = loop.run_once()
    assert [alert.triggering_event_id for alert in alerts] == ["a-2"]
    assert loop.rule_status("rule-a").window_count == 2
    assert loop.rule_status("rule-a").alerts_emitted == 1
    assert loop.rule_status("rule-b").window_count == 2
    assert loop.rule_status("rule-b").alerts_emitted == 0


def test_real_ingress_producer_restart_fires_threshold_once_without_risk_calls(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Real producer -> outbox -> rule consumer; consumer restart; read-only alerting."""

    database = tmp_path / "chain.sqlite"
    clock = MutableClock()
    modules_before = set(sys.modules)
    outbox = DurableOutbox(database, clock=clock)
    producer = MonitorIngressService(
        outbox,
        {
            _chain_scope(): MonitorIngressTarget(
                outbox_scope=_CHAIN_SCOPE, event_types=(_EVENT_TYPE,)
            )
        },
    )
    produced = []
    for index in range(1, 6):
        produced.append(
            producer.handle(
                "events.append",
                principal_ref="service:dim08-producer",
                identity=_chain_identity(),
                scope=_chain_scope(),
                arguments={
                    "schema_version": 1,
                    "event_id": f"source-{index}",
                    "event_type": _EVENT_TYPE,
                    "occurred_at": 1_800_000_000 + index,
                    "data": {"status": "rejected", "attempt": index},
                },
            )
        )
    durable_event_ids = [row["event_id"] for row in produced]
    assert len(set(durable_event_ids)) == 5

    calls = []
    distinct_alerts = {}

    def idempotent_sink(alert) -> None:
        calls.append(alert.alert_id)
        distinct_alerts.setdefault(alert.alert_id, alert)

    rule = ThresholdRule(
        rule_id="rule.ingress-status.v1",
        outbox_scope=_CHAIN_SCOPE,
        event_type=_EVENT_TYPE,
        window_seconds=600.0,
        threshold_count=3,
    )

    # Consumer lifetime 1: two acknowledged events and one lost checkpoint ack.
    outbox_one = DurableOutbox(database, clock=clock)
    loop_one = ScopedThresholdRuleLoop(outbox_one, (rule,), idempotent_sink, clock=clock)
    original_acknowledge = outbox_one.acknowledge
    failing = {"armed": True}

    def flaky_acknowledge(consumer_id: str, scope: str, sequence: int) -> None:
        if sequence == 2 and failing["armed"]:
            failing["armed"] = False
            raise RuntimeError("checkpoint write lost")
        original_acknowledge(consumer_id, scope, sequence)

    monkeypatch.setattr(outbox_one, "acknowledge", flaky_acknowledge)
    with pytest.raises(OutboxDeliveryError):
        loop_one.run_once(limit=10)
    assert calls == []
    assert loop_one.checkpoint(_CHAIN_SCOPE) == 1

    # Consumer lifetime 2 (restart): only the unacked suffix is replayed; the
    # threshold crosses exactly once over the whole producer stream.
    outbox_two = DurableOutbox(database, clock=clock)
    loop_two = ScopedThresholdRuleLoop(outbox_two, (rule,), idempotent_sink, clock=clock)
    alerts = loop_two.run_once(limit=10)
    assert len(alerts) == 1
    alert = alerts[0]
    assert calls == [alert.alert_id]
    assert list(distinct_alerts) == [alert.alert_id]
    assert alert.triggering_event_id == durable_event_ids[3]
    assert alert.observed_count == 3 == alert.threshold_count
    assert loop_two.checkpoint(_CHAIN_SCOPE) == 5
    status = loop_two.rule_status("rule.ingress-status.v1")
    # seq 2..5 replayed exactly once each: the acked seq 1 was not re-delivered
    # and no redelivered event was counted twice.
    assert status.window_count == 4
    assert status.counted_events == 4
    assert status.last_counted_sequence == 5
    assert status.alerts_emitted == 1
    assert status.armed is False

    # Alert data is frozen read-only.
    with pytest.raises(dataclasses.FrozenInstanceError):
        alert.observed_count = 99  # type: ignore[misc]

    # More events arrive while the window is latched: still exactly one alert.
    assert loop_two.run_once(limit=10) == ()
    producer_row = producer.handle(
        "events.append",
        principal_ref="service:dim08-producer",
        identity=_chain_identity(),
        scope=_chain_scope(),
        arguments={
            "schema_version": 1,
            "event_id": "source-6",
            "event_type": _EVENT_TYPE,
            "occurred_at": 1_800_000_006,
            "data": {"status": "rejected", "attempt": 6},
        },
    )
    assert producer_row["sequence"] == 6
    outbox_three = DurableOutbox(database, clock=clock)
    loop_three = ScopedThresholdRuleLoop(outbox_three, (rule,), idempotent_sink, clock=clock)
    assert loop_three.run_once(limit=10) == ()
    assert loop_three.checkpoint(_CHAIN_SCOPE) == 6
    assert loop_three.rule_status("rule.ingress-status.v1").alerts_emitted == 0
    assert len(calls) == 1

    # The alert path appended nothing: the outbox still holds only producer events.
    rows, has_more = DurableOutbox(database, read_only=True).read_page(
        _CHAIN_SCOPE, _EVENT_TYPE, 0, 10
    )
    assert [row.event.event_id for row in rows] == durable_event_ids + [producer_row["event_id"]]
    assert has_more is False

    # 告警不冒充硬风控: the whole chain runs with zero Risk/R-admission imports or calls.
    new_modules = set(sys.modules) - modules_before
    forbidden = sorted(
        module
        for module in new_modules
        if "risk" in module.lower() or "admission" in module.lower()
    )
    assert forbidden == []
    assert "bt_api_risk" not in sys.modules
    imported_modules = set()
    for node in ast.walk(
        ast.parse(Path(threshold_rules_module.__file__).read_text(encoding="utf-8"))
    ):
        if isinstance(node, ast.Import):
            imported_modules.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module is not None:
            imported_modules.add(node.module)
    assert not any(
        "risk" in name.lower() or "admission" in name.lower() for name in imported_modules
    )
    assert "subprocess" not in imported_modules
    public_surface = sorted(name for name in dir(loop_three) if not name.startswith("_"))
    assert public_surface == ["checkpoint", "configured_scopes", "rule_status", "run_once"]
