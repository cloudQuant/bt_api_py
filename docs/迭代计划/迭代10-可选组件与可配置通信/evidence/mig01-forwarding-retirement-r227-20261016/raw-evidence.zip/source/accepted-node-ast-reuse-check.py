from __future__ import annotations

import ast
import json
from pathlib import Path
from xml.etree import ElementTree


R3 = Path(r"D:\temp\iteration10-mig01-forwarding-retirement-root-20261016-r3-final2")
R4 = Path(r"D:\temp\iteration10-mig01-forwarding-retirement-root-20261016-r4")
R5 = Path(r"D:\temp\iteration10-mig01-forwarding-retirement-root-20261016-r5-single-node")


def load_run(root: Path):
    spec = json.loads((root / "spec.json").read_text(encoding="utf-8"))
    junit = ElementTree.parse(root / "junit.xml").getroot()
    cases = []
    for suite in junit.iter("testsuite"):
        for case in suite.findall("testcase"):
            state = "passed"
            if case.find("failure") is not None or case.find("error") is not None:
                state = "failed"
            elif case.find("skipped") is not None:
                state = "skipped"
            cases.append((case.attrib["classname"], case.attrib["name"], state))
    return Path(spec["cwd"]), cases


def test_func_ast(export: Path, module: str, case_name: str):
    function_name = case_name.split("[", 1)[0]
    parts = module.split(".")
    path = None
    class_parts = []
    for end in range(len(parts), 0, -1):
        if parts[0] == "tests":
            candidate = export.joinpath(*parts[:end]).with_suffix(".py")
        elif parts[0] == "bt_api":
            candidate = export.joinpath(*parts[:end]).with_suffix(".py")
        elif len(parts) > 1 and parts[1] == "tests":
            candidate = export / "bt_api" / parts[0] / Path(*parts[1:end]).with_suffix(".py")
        else:
            raise AssertionError(f"unmapped pytest class module: {module}")
        if candidate.is_file():
            path = candidate
            class_parts = parts[end:]
            break
    if path is None:
        raise AssertionError(f"no test module source found for pytest class: {module}")
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    body = tree.body
    for class_name in class_parts:
        classes = [node for node in body if isinstance(node, ast.ClassDef) and node.name == class_name]
        if len(classes) != 1:
            return None
        body = classes[0].body
    matches = [node for node in body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == function_name]
    if len(matches) != 1:
        return None
    return ast.dump(matches[0], include_attributes=False)


e3, c3 = load_run(R3)
e4, c4 = load_run(R4)
e5, c5 = load_run(R5)
p3 = {(m, n) for m, n, s in c3 if s == "passed"}
f3 = {(m, n) for m, n, s in c3 if s == "failed"}
s3 = {(m, n) for m, n, s in c3 if s == "skipped"}
p4 = {(m, n) for m, n, s in c4 if s == "passed"}
f4 = {(m, n) for m, n, s in c4 if s == "failed"}
p5 = {(m, n) for m, n, s in c5 if s == "passed"}

assert (len(p3), len(f3), len(s3)) == (74, 23, 1)
assert (len(p4), len(f4), len(c4)) == (23, 1, 24)
assert (len(p5), len(c5)) == (1, 1)
assert len(f4) == 1 and f4 == p5
assert f4.issubset(f3)

ast_checked = 0
ast_mismatches = []
missing_ast = []
for node in sorted(p3 | p4):
    # R3's 74 prior passes and R4's 23 passes are reused only if their complete
    # pytest test-function AST is unchanged in the final R5 source export.
    source_export = e3 if node in p3 else e4
    old_ast = test_func_ast(source_export, *node)
    final_ast = test_func_ast(e5, *node)
    if old_ast is None or final_ast is None:
        missing_ast.append(node)
    elif old_ast != final_ast:
        ast_mismatches.append(node)
    else:
        ast_checked += 1

assert not missing_ast, missing_ast
assert not ast_mismatches, ast_mismatches
unique_pass = p3 | p4 | p5
unique_skip = s3
assert len(unique_pass) == 98, len(unique_pass)
assert len(unique_skip) == 1
print(json.dumps({
    "R3": {"passed": len(p3), "failed": len(f3), "skipped": len(s3), "total": len(c3)},
    "R4": {"passed": len(p4), "failed": len(f4), "skipped": 0, "total": len(c4)},
    "R5": {"passed": len(p5), "total": len(c5)},
    "R4_failed_node_resolved_by_R5": [list(x) for x in f4],
    "unique_passed_cases": len(unique_pass),
    "unique_skipped_cases_preserved": len(unique_skip),
    "previously_passed_test_function_asts_identical": ast_checked,
    "missing_or_changed_passed_test_asts": len(missing_ast) + len(ast_mismatches),
    "production_source_scope_compared_separately": "The source export differs in exactly one test file; R3/R4 outputs remain original and unchanged.",
}, ensure_ascii=False, indent=2))
