import hashlib
import json
import os
import sys
from pathlib import Path

AUDIT_DIR = os.environ.get("DIM04_IMPORT_AUDIT_DIR")
PREFIXES = (
    "bt_api_py", "bt_api_base", "bt_api_risk", "bt_api_execution",
    "bt_api_transport_zmq", "tests.integration.",
    "tests.unit._spawned_process_helpers",
)

def _inside(name):
    return any(name == p or name.startswith(p + ".") or (p.endswith(".") and name.startswith(p)) for p in PREFIXES)

def _record(event, args):
    if event != "import" or not AUDIT_DIR or len(args) < 2:
        return
    name, filename = args[0], args[1]
    if not isinstance(name, str) or not _inside(name):
        return
    row = {"pid": os.getpid(), "module": name, "filename": filename if isinstance(filename, str) else None}
    if isinstance(filename, str) and os.path.isfile(filename):
        try:
            with open(filename, "rb") as source:
                data = source.read()
            row["size_bytes"] = len(data)
            row["sha256"] = hashlib.sha256(data).hexdigest()
        except OSError as exc:
            row["pin_error_type"] = type(exc).__name__
    line = (json.dumps(row, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")
    path = os.path.join(AUDIT_DIR, f"imports-{os.getpid()}.jsonl")
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
    try:
        os.write(fd, line)
    finally:
        os.close(fd)

if AUDIT_DIR:
    os.makedirs(AUDIT_DIR, exist_ok=True)
    startup = {
        "pid": os.getpid(), "cwd": os.getcwd(), "executable": sys.executable,
        "python": sys.version, "sys_path": list(sys.path),
        "pythonpath": os.environ.get("PYTHONPATH"),
    }
    with open(os.path.join(AUDIT_DIR, f"startup-{os.getpid()}.json"), "w", encoding="utf-8", newline="\n") as stream:
        json.dump(startup, stream, sort_keys=True, indent=2)
        stream.write("\n")
    sys.addaudithook(_record)
