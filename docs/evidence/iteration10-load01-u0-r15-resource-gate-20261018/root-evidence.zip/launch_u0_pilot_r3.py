from __future__ import annotations

import hashlib
import json
import psutil
import re
import subprocess
import sys
import time
from pathlib import Path


REPOSITORY = Path(r"D:\bt_api_py")
PREPARED = REPOSITORY / ".codex-tmp/load01-u0-r15-20261018/prepared-spec.json"
EXECUTION_RECEIPT = REPOSITORY / ".codex-tmp/load01-u0-r15-20261018/root-execution.json"
MEMORY_RECEIPT = REPOSITORY / ".codex-tmp/load01-u0-r15-20261018/memory-pre-pilot.json"
EXPECTED_PARENT = "1bfb517ebb115858683dafce39c3225cd068fcfa"
EXPECTED_PACKAGE_GITLINKS = {'bt_api/bt_api_base': 'fb47f3dd733613494aa1d86cfd94b2d6fe70314d', 'bt_api/bt_api_execution': '456eb3ce9a49fa8924a6f908d1a4e336e7120ce8', 'bt_api/bt_api_gateway': '12e8de6f9552f7974a450f3217d497fb9c89e33d', 'bt_api/bt_api_monitor': '02ee0c42a1e63a9cecbb666376e70c6f72b0d6e8', 'bt_api/bt_api_risk': 'b6e4a7bce74a5ae5dee4c8f514a9d95fd68073d9', 'bt_api/bt_api_transport_zmq': 'acd74ba03494615aeb2d60423ac853e06029cba7'}
EXPECTED_RUNNER_OVERLAY_SHA256 = "6a91654af3a6c05d2702bf728f6a037b81ff53f1308ea24113904868097c4bdb"
EXPECTED_THRESHOLD_BYTES = 10603200512
EXPECTED_RESERVE_BYTES = 2 * 1024**3
EXPECTED_BINDING_COUNT = 47
EXPECTED_PIN_COUNT = 49
ARCHIVE_CHECKOUT_EXCEPTIONS = {'bt_api/bt_api_monitor/src/bt_api_monitor/durable.py': {'committed_sha256': 'e1ca5c24a98fb85b6b6f6a78a6c38127a62c8655d0db12d6c63dbf581b178ba4', 'export_sha256': '8ea958088904948b2601af2ecf3417925df3a0132cdb0c9a88aeb21ae34de286', 'transformation': 'LF_TO_CRLF'}}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*args: str) -> str:
    return subprocess.check_output(["git", "-C", str(REPOSITORY), *args]).decode("ascii").strip()


def require_sha(value: object, label: str) -> str:
    if not isinstance(value, str) or re.fullmatch(r"[0-9a-f]{64}", value) is None:
        raise AssertionError(f"{label} must be an exact lowercase SHA-256")
    return value


if len(sys.argv) != 2 or sha(PREPARED) != sys.argv[1]:
    raise AssertionError("prepared R15 spec must be passed by its exact SHA-256")
document = json.loads(PREPARED.read_text(encoding="utf-8"))
source = document["current_source"]
export = source["export"]
execution = document["execution"]
contract = document["source_contract"]
smoke = document["u0_smoke_acceptance"]
if smoke.get("status") != "ROOT_ACCEPTED":
    raise AssertionError("Root-accepted U0 smoke evidence is required before launch preparation")
if smoke.get("accepted_commit") != source["parent_commit"]:
    raise AssertionError("accepted U0 smoke commit does not match the fixed-source parent")
smoke_sha = require_sha(smoke.get("qa_result_sha256"), "U0 smoke QA result")
if source["parent_commit"] != EXPECTED_PARENT or git("rev-parse", "HEAD") != EXPECTED_PARENT:
    raise AssertionError("Root HEAD differs from the exact R15 accepted-source binding")
if git("branch", "--show-current") != "dev" or git("diff", "--cached", "--name-only"):
    raise AssertionError("expected existing dev checkout with an empty index")
if source["package_gitlinks"] != EXPECTED_PACKAGE_GITLINKS:
    raise AssertionError("package gitlinks differ from exact R15 pins")
for package, commit in EXPECTED_PACKAGE_GITLINKS.items():
    package_root = REPOSITORY / package
    actual = subprocess.check_output(["git", "-C", str(package_root), "rev-parse", "HEAD"]).decode("ascii").strip()
    if actual != commit:
        raise AssertionError(f"package checkout does not match its fixed source pin: {package}")
if contract.get("profile_id") != "U0":
    raise AssertionError("source contract must be the U0 profile")
bindings = contract.get("runtime_bindings")
file_pins = contract.get("committed_file_sha256")
if not isinstance(bindings, dict) or len(bindings) != EXPECTED_BINDING_COUNT:
    raise AssertionError("U0 runtime source binding map is incomplete")
if not isinstance(file_pins, dict) or len(file_pins) != EXPECTED_PIN_COUNT:
    raise AssertionError("U0 committed source pin map is incomplete")
if contract.get("archive_checkout_exceptions") != ARCHIVE_CHECKOUT_EXCEPTIONS:
    raise AssertionError("fixed archive newline exception changed")
if source.get("committed_file_sha256") != file_pins:
    raise AssertionError("source contract and export committed pins differ")
overlay = source["runner_provenance_overlay"]
if overlay.get("candidate_raw_sha256") != EXPECTED_RUNNER_OVERLAY_SHA256:
    raise AssertionError("runner provenance overlay does not match the fixed R15 digest")
if overlay.get("exact_replacement_count") != 7 or len(overlay.get("exact_pairs", [])) != 7:
    raise AssertionError("runner provenance overlay must contain exactly seven fixed replacements")
if overlay.get("allowed_overlay") != {"tests/unit/test_load01_hundred_strategy_30min.py": EXPECTED_RUNNER_OVERLAY_SHA256}:
    raise AssertionError("runner provenance overlay allowlist is broader than the fixed runner")
if overlay["exact_pairs"][0][1] != EXPECTED_PARENT or [row[1] for row in overlay["exact_pairs"][1:]] != list(EXPECTED_PACKAGE_GITLINKS.values()):
    raise AssertionError("runner provenance overlay targets differ from exact source refs")
if document["resource_gate"].get("minimum_available_physical_bytes") != EXPECTED_THRESHOLD_BYTES:
    raise AssertionError("U0 available-memory threshold changed")
if document["resource_gate"].get("runtime_reserve_bytes") != EXPECTED_RESERVE_BYTES:
    raise AssertionError("U0 runtime reserve changed")
if execution.get("environment", {}).get("BT_API_LOAD01_PROFILE") != "U0":
    raise AssertionError("prepared execution profile is not U0")
if document["workload"] != {
    "pilot_seconds": 120, "full_seconds": 1800, "strategies": 100,
    "accounts": 10, "strategies_per_account": 10, "topics": 20,
    "upstream_messages_per_second": 200,
    "order_lifecycle_cycles_per_account_per_second": 2,
    "strategy_children": 100, "account_execution_owner_children": 10,
    "market_children": 1, "monitor_children": 1, "total_children": 112,
    "pytest_controller": 1, "total_processes_including_controller": 113,
}:
    raise AssertionError("prepared workload differs from the fixed U0 acceptance contract")
if Path(execution["python"]).resolve() != Path("C:/Anaconda3/python.exe").resolve():
    raise AssertionError("pilot must use the fixed project Python interpreter")
root = Path(execution["working_directory"])
output = Path(execution["output_root"])
if export.get("status") != "MATERIALIZED_AND_NOHOST_PREFLIGHTED" or len(export.get("archive_hashes", {})) != 7:
    raise AssertionError("exact seven-archive export and source preflight are required")
if output.exists():
    raise AssertionError("do not reuse a prior pilot output directory")

preflight_path = Path(export["preflight_path"])
if sha(preflight_path) != export["preflight_sha256"]:
    raise AssertionError("fixed-source preflight receipt changed")
preflight = json.loads(preflight_path.read_text(encoding="utf-8"))
if preflight.get("status") != "SOURCE_EXPORT_PREFLIGHT_PASS_WAITING_FOR_FRESH_MEMORY_GATE":
    raise AssertionError("fixed-source preflight is not the R15 no-Host state")
if preflight.get("profile_id") != "U0" or preflight.get("fixed_source_binding_count") != EXPECTED_BINDING_COUNT:
    raise AssertionError("preflight source/profile binding differs from U0")
if not preflight.get("resource_helper_parent_zip_member_verified") or not preflight.get("resource_helper_runtime_manifest_binding_verified"):
    raise AssertionError("resource-helper archive/source-manifest guards must pass")
if preflight.get("memory_gate", {}).get("available_memory_read_performed") is not False:
    raise AssertionError("preflight must defer memory sampling to this fresh Root launch gate")
if preflight.get("memory_gate", {}).get("minimum_available_bytes") != EXPECTED_THRESHOLD_BYTES:
    raise AssertionError("preflight memory threshold changed")
if preflight.get("memory_gate", {}).get("runtime_reserve_bytes") != EXPECTED_RESERVE_BYTES:
    raise AssertionError("preflight runtime reserve changed")
if any(preflight.get(key) for key in ("pilot_started", "full_started", "host_started", "pytest_collected_or_run")):
    raise AssertionError("preflight unexpectedly records execution")
if preflight.get("runner_overlay_sha256") != EXPECTED_RUNNER_OVERLAY_SHA256:
    raise AssertionError("preflight runner overlay does not match isolated R15 pin")

manifest_path = Path(export["source_manifest_path"])
if sha(manifest_path) != preflight.get("source_manifest_sha256"):
    raise AssertionError("source manifest changed after preflight")
manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
if manifest.get("parent_commit") != source["parent_commit"]:
    raise AssertionError("source manifest parent differs from the accepted source commit")
manifest_links = {row["path"]: row["commit"] for row in manifest.get("package_gitlinks", [])}
if manifest_links != source["package_gitlinks"]:
    raise AssertionError("source manifest package gitlinks differ from exact source pins")
if manifest.get("files", {}).get("tests/unit/test_load01_hundred_strategy_30min.py") != EXPECTED_RUNNER_OVERLAY_SHA256:
    raise AssertionError("source manifest does not bind the provenance-only runner overlay")
for path, expected in file_pins.items():
    manifest_expected = EXPECTED_RUNNER_OVERLAY_SHA256 if path == "tests/unit/test_load01_hundred_strategy_30min.py" else expected
    if path in ARCHIVE_CHECKOUT_EXCEPTIONS:
        manifest_expected = ARCHIVE_CHECKOUT_EXCEPTIONS[path]["export_sha256"]
    if manifest.get("files", {}).get(path) != manifest_expected:
        raise AssertionError(f"source manifest differs from exact committed pin: {path}")
expected_bindings = {name: dict(record) for name, record in bindings.items()}
expected_bindings["load_runner"]["sha256"] = EXPECTED_RUNNER_OVERLAY_SHA256
if preflight.get("archive_checkout_exceptions") != ARCHIVE_CHECKOUT_EXCEPTIONS:
    raise AssertionError("preflight archive newline exception changed")
if preflight.get("fixed_source_bindings") != expected_bindings:
    raise AssertionError("preflight runtime bindings differ from the exact U0 source contract")
if preflight.get("runner_archive_validation", {}).get("overlay_paths") != ["tests/unit/test_load01_hundred_strategy_30min.py"]:
    raise AssertionError("source archive overlay set is not the single provenance-only runner")

qa_runner = REPOSITORY / ".codex-tmp/iteration10-focused-qa.py"
if sha(qa_runner) != "8b7f470be77270adeb9d72a83776b827c4653004b39835eeca0f43bf63cf24ed":
    raise AssertionError("fixed focused QA launcher source changed")
pins = {str(root / path): (EXPECTED_RUNNER_OVERLAY_SHA256 if path == "tests/unit/test_load01_hundred_strategy_30min.py" else digest) for path, digest in manifest["files"].items()}
for name, row in export["archive_hashes"].items():
    archive_path = Path(export["root"]) / name
    if archive_path.stat().st_size != row["bytes"] or sha(archive_path) != row["sha256"]:
        raise AssertionError(f"source archive pin changed: {name}")
    pins[str(archive_path)] = row["sha256"]
pins_path = Path(export["source_export_pins"])
if sha(pins_path) != export["source_export_pins_sha256"]:
    raise AssertionError("source archive pin manifest changed")
for path in (PREPARED, qa_runner, manifest_path, preflight_path, pins_path):
    pins[str(path)] = sha(path)
if not all(sha(Path(path)) == digest for path, digest in pins.items()):
    raise AssertionError("a fixed source or export artifact changed after preflight")

current_links = {}
for package in EXPECTED_PACKAGE_GITLINKS:
    fields = subprocess.check_output(["git", "-C", str(REPOSITORY), "ls-tree", EXPECTED_PARENT, package]).decode("utf-8").strip().split()
    if len(fields) != 4 or fields[0] != "160000" or fields[1] != "commit" or fields[3] != package:
        raise AssertionError(f"invalid fixed source gitlink: {package}")
    current_links[package] = fields[2]
if current_links != EXPECTED_PACKAGE_GITLINKS:
    raise AssertionError("committed gitlinks differ from the exact package pin map")

environment = dict(execution["environment"])
environment.pop("BT_API_LOAD01_SOURCE_MANIFEST", None)
environment.update(
    BT_API_LOAD01_MODE="pilot",
    BT_API_LOAD01_PROFILE="U0",
    BT_API_LOAD01_OUTPUT=execution["pilot_output"],
    PYTHONPYCACHEPREFIX=str(output / "pilot-python-cache"),
    BT_API_LOAD01_RUNNER_OVERLAY_SHA256=EXPECTED_RUNNER_OVERLAY_SHA256,
)
if not all(isinstance(key, str) and isinstance(value, str) for key, value in environment.items()):
    raise AssertionError("pilot environment must contain only string keys and values")

execution_record = {
    "schema_version": 1,
    "label": "LOAD01_U0_R15_112_PROCESS_120_SECOND_PILOT",
    "profile_id": "U0",
    "python": execution["python"],
    "cwd": str(root),
    "output": str(output),
    "nodes": [execution["node"]],
    "pytest_options": execution["pytest_arguments"],
    "source_parent": EXPECTED_PARENT,
    "smoke_acceptance_sha256": smoke_sha,
    "source_count": len(pins),
    "execution_head": git("rev-parse", "HEAD"),
    "repositories": {str(REPOSITORY): EXPECTED_PARENT, **{str(REPOSITORY / path): commit for path, commit in EXPECTED_PACKAGE_GITLINKS.items()}},
    "source_sha256": pins,
    "environment": environment,
    "unset_environment": ["BT_API_LOAD01_SOURCE_MANIFEST"],
    "authorization": "Existing user continuation authorization applies.",
    "evidence_level": "LOCAL_SYNTHETIC_LOAD01_U0_112_PROCESS_120_SECOND_PILOT_ONLY",
}
if EXECUTION_RECEIPT.exists() or MEMORY_RECEIPT.exists():
    raise AssertionError("R15 Root execution receipts must be fresh")
EXECUTION_RECEIPT.write_text(json.dumps(execution_record, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")

samples = []
for index in range(3):
    samples.append({"sample_index": index + 1, "time_unix": time.time(), "available_physical_bytes": psutil.virtual_memory().available})
    if index < 2:
        time.sleep(5)
memory_record = {
    "execution_receipt": str(EXECUTION_RECEIPT),
    "execution_receipt_sha256": sha(EXECUTION_RECEIPT),
    "samples": samples,
    "minimum_available_physical_bytes": EXPECTED_THRESHOLD_BYTES,
    "runtime_reserve_bytes": EXPECTED_RESERVE_BYTES,
    "ready": all(row["available_physical_bytes"] >= EXPECTED_THRESHOLD_BYTES for row in samples),
    "sample_count": 3,
    "interval_seconds": 5,
    "execution_started": False,
}
MEMORY_RECEIPT.write_text(json.dumps(memory_record, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
print(json.dumps(memory_record, ensure_ascii=False, sort_keys=True), flush=True)
if not memory_record["ready"]:
    raise SystemExit("Fresh U0 pilot memory gate did not pass; pilot was not started")

raise SystemExit(subprocess.call([execution["python"], "-X", "utf8", str(qa_runner), str(EXECUTION_RECEIPT)], cwd=str(root)))
