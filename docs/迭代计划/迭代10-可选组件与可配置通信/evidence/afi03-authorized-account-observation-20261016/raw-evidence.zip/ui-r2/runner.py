import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

spec_path = Path(sys.argv[1])
spec = json.loads(spec_path.read_text(encoding='utf-8'))
cwd = Path(spec['cwd'])
out = Path(spec['output'])
repo = cwd.parents[1]
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def git(*a): return subprocess.check_output(['git', '-C', str(repo), *a]).decode().strip()
assert not out.exists()
assert git('branch', '--show-current') == 'dev'
assert git('rev-parse', 'HEAD') == spec['head']
assert all(sha(p) == h for p, h in spec['sources'].items())
env = os.environ.copy()
env.update(spec.get('environment', {'CI': '1', 'NO_COLOR': '1'}))
out.mkdir()
(out / 'spec.json').write_bytes(spec_path.read_bytes())
(out / 'runner.py').write_bytes(Path(__file__).read_bytes())
results = {}
for name, argv in spec['commands'].items():
    with (out / (name + '.stdout.log')).open('wb') as stdout, (out / (name + '.stderr.log')).open('wb') as stderr:
        p = subprocess.Popen(argv, cwd=cwd, env=env, stdout=stdout, stderr=stderr)
        print(json.dumps({'command': name, 'pid': p.pid}), flush=True)
        results[name] = p.wait()
after = {p: sha(p) for p in spec['sources']}
result = {'exit_codes': results, 'sources_unchanged': after == spec['sources'], 'source_count': len(after), 'head_unchanged': git('rev-parse', 'HEAD') == spec['head'], 'finished_utc': datetime.now(timezone.utc).isoformat(), 'evidence_level': spec['evidence_level']}
(out / 'source-after.json').write_text(json.dumps(after, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
(out / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result), flush=True)
assert result['sources_unchanged'] and result['head_unchanged']
raise SystemExit(0 if all(v == 0 for v in results.values()) else 1)
