"""智能风控和合规监控系统

Intelligent Risk Management and Compliance Monitoring System for 73+ exchanges.

核心功能:
1. 实时风险监控 - 交易前、交易中、交易后全流程风控
2. 智能风险评估 - 机器学习驱动的风险评分和预测
3. 合规监控 - 市场操纵检测、内幕交易监控、反洗钱
4. 动态限制管理 - 基于风险等级的动态调整和自动限制
5. 异常检测 - 行为分析、模式识别、异常交易检测
6. 实时监控仪表板 - 风险指标可视化、告警系统、决策支持

技术特性:
- 机器学习模型 (随机森林、神经网络、异常检测算法)
- 实时流处理 (异步事件处理)
- 复杂事件处理 (CEP) 引擎
- 图计算 (关系网络分析)
- 时间序列数据库 (风险指标存储)
- 规则引擎 (基于事件和模式的规则系统)

合规标准:
- 市场操纵检测 (spoofing、layering、front running)
- 反洗钱 (AML) 和了解你的客户 (KYC)
- 交易报告 (MiFID II、SEC Rule 606)
- 仓位限制和集中度限制
- 信用风险和保证金管理
"""

from __future__ import annotations

from importlib import import_module

from .containers.risk_events import RiskEvent, RiskEventType, RiskLevel
from .containers.risk_metrics import RiskMetrics
from .core.admission import (
    AccountScope,
    CancelDispatchResolutionProof,
    CancelDispatchSource,
    CancelDispatchTerminalState,
    CancelTargetPostcondition,
    DispatchClaimBinding,
    DispatchEvidenceClass,
    DispatchExposureResolutionProof,
    DispatchExposureResolutionReceipt,
    DispatchExposureResolutionReceiptStatus,
    DispatchRecoveryAttestation,
    DispatchResolutionProof,
    DispatchResolutionReceipt,
    DispatchResolutionReceiptStatus,
    DispatchTerminalProof,
    DispatchTerminalResolutionReceipt,
    DispatchTerminalResolutionReceiptStatus,
    DispatchTerminalState,
    DispatchTrackedOrderProof,
    DurableRiskGate,
    FreezeActivationResult,
    FreezeActivationStatus,
    FreezeResolution,
    FreezeResolutionStatus,
    IntentAction,
    PermitInvalidError,
    RiskDeniedError,
    RiskGateError,
    RiskGroupLegClaimReceipt,
    RiskGroupLegIntent,
    RiskGroupReservationLeg,
    RiskGroupReservationReceipt,
    RiskGroupReservationState,
    RiskIntent,
    RiskPermit,
    RiskPolicy,
    StrategyAllocationSnapshot,
    VerifiedCancelDispatchResolution,
    VerifiedCancellationJournalAuthority,
    VerifiedDispatchExposureJournalAuthority,
    VerifiedDispatchExposureResolution,
    VerifiedDispatchRecoveryResolution,
    VerifiedDispatchResolution,
    VerifiedExecutionJournalAuthority,
    VerifiedRecoveredExecutionJournalAuthority,
)
from .core.exposure import (
    ExposureAccountingMode,
    GrossExposureAuthority,
    GrossExposureBaselineProof,
    OrderExposureObservationProof,
    OrderExposureSnapshot,
    OrderExposureState,
    OrderFillFact,
    StrategyGrossBaseline,
    VerifiedGrossExposureBaseline,
    VerifiedOrderExposureObservation,
    fill_ids_sha256,
)
from .core.instrument import (
    INSTRUMENT_METADATA_DIGEST_TAG,
    InstrumentRiskAdmissionMapper,
    InstrumentRiskAssessment,
    InstrumentRiskFxRate,
    InstrumentRiskMetadata,
    InstrumentRiskOrder,
    InstrumentRiskRegistry,
)

_ANALYSIS_EXPORTS = {
    "RiskAssessor": ".core.risk_assessor",
    "RiskManager": ".core.risk_manager",
    "AnomalyDetector": ".ml_models.anomaly_detector",
    "RiskEnsembleModel": ".ml_models.ensemble_model",
}

_ADMISSION_EXPORTS = {
    "DurableRiskAdmissionAdapter": ".order_admission",
    "RiskAdmissionPolicyBinding": ".order_admission",
    "RiskAdmissionAdapterError": ".order_admission",
    "RiskAdmissionDeniedError": ".order_admission",
}

# Optional features whose implementation imports live outside the base
# dependency set. Requesting them without the extra must fail explicitly
# instead of surfacing a bare module-not-found from deep inside the package.
_OPTIONAL_EXTRAS = {
    "RiskManager": "analytics",
    "AnomalyDetector": "ml",
    "RiskEnsembleModel": "ml",
}


def __getattr__(name: str):
    """Load optional features only when explicitly requested by the caller."""
    module = _ANALYSIS_EXPORTS.get(name) or _ADMISSION_EXPORTS.get(name)
    if module is None:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    try:
        value = getattr(import_module(module, __name__), name)
    except ImportError as error:
        extra = _OPTIONAL_EXTRAS.get(name)
        if extra is None:
            raise
        raise ImportError(
            f"{name} requires the {extra!r} extra of bt_api_risk "
            f"(install bt_api_risk[{extra}]): {error}"
        ) from error
    globals()[name] = value
    return value


def __dir__() -> list[str]:
    """Keep the established public exports discoverable without loading them."""
    return sorted(set(globals()) | set(__all__))


__all__ = [
    # Core Risk Management
    "RiskManager",
    "RiskAssessor",
    # ML Models
    "RiskEnsembleModel",
    "AnomalyDetector",
    # Data Containers
    "RiskMetrics",
    "RiskEvent",
    "RiskEventType",
    "RiskLevel",
    # Durable execution-boundary admission
    "AccountScope",
    "CancelDispatchResolutionProof",
    "CancelDispatchSource",
    "CancelDispatchTerminalState",
    "CancelTargetPostcondition",
    "DispatchClaimBinding",
    "DispatchExposureResolutionProof",
    "DispatchExposureResolutionReceipt",
    "DispatchExposureResolutionReceiptStatus",
    "DispatchEvidenceClass",
    "DispatchRecoveryAttestation",
    "DispatchResolutionReceipt",
    "DispatchResolutionReceiptStatus",
    "DispatchResolutionProof",
    "DispatchTerminalProof",
    "DispatchTerminalResolutionReceipt",
    "DispatchTerminalResolutionReceiptStatus",
    "DispatchTerminalState",
    "DispatchTrackedOrderProof",
    "FreezeActivationResult",
    "FreezeActivationStatus",
    "FreezeResolution",
    "FreezeResolutionStatus",
    "ExposureAccountingMode",
    "GrossExposureAuthority",
    "GrossExposureBaselineProof",
    "OrderExposureObservationProof",
    "OrderExposureSnapshot",
    "OrderExposureState",
    "OrderFillFact",
    "StrategyGrossBaseline",
    "VerifiedGrossExposureBaseline",
    "VerifiedOrderExposureObservation",
    "fill_ids_sha256",
    "VerifiedDispatchResolution",
    "VerifiedDispatchExposureResolution",
    "VerifiedDispatchExposureJournalAuthority",
    "VerifiedDispatchRecoveryResolution",
    "VerifiedCancelDispatchResolution",
    "VerifiedCancellationJournalAuthority",
    "DurableRiskGate",
    "IntentAction",
    "PermitInvalidError",
    "RiskDeniedError",
    "RiskGateError",
    "RiskGroupLegClaimReceipt",
    "RiskGroupLegIntent",
    "RiskGroupReservationLeg",
    "RiskGroupReservationReceipt",
    "RiskGroupReservationState",
    "RiskIntent",
    "RiskPermit",
    "RiskPolicy",
    "StrategyAllocationSnapshot",
    "VerifiedExecutionJournalAuthority",
    "VerifiedRecoveredExecutionJournalAuthority",
    "INSTRUMENT_METADATA_DIGEST_TAG",
    "InstrumentRiskAdmissionMapper",
    "InstrumentRiskAssessment",
    "InstrumentRiskFxRate",
    "InstrumentRiskMetadata",
    "InstrumentRiskOrder",
    "InstrumentRiskRegistry",
    "DurableRiskAdmissionAdapter",
    "RiskAdmissionPolicyBinding",
    "RiskAdmissionAdapterError",
    "RiskAdmissionDeniedError",
]

# 版本信息
__version__ = "0.1.0"
__compliance_standards__ = [
    "MiFID II",
    "SEC Rule 606",
    "Market Abuse Regulation (MAR)",
    "Anti-Money Laundering (AML)",
    "KYC",
    "Basel III",
    "IOSCO Principles",
]

# 默认配置
DEFAULT_RISK_CONFIG = {
    "risk_thresholds": {
        "low": 0.3,
        "medium": 0.6,
        "high": 0.8,
        "critical": 0.9,
    },
    "monitoring": {
        "real_time_enabled": True,
        "batch_processing_interval": 60,  # seconds
        "alert_cooldown": 300,  # seconds
    },
    "ml_models": {
        "ensemble_weights": {"rf": 0.4, "nn": 0.4, "xgb": 0.2},
        "retraining_interval": 86400,  # 24 hours
        "min_samples": 1000,
    },
    "compliance": {
        "market_manipulation_detection": True,
        "aml_monitoring": True,
        "position_limits": True,
        "reporting_requirements": True,
    },
    "performance": {
        "max_processing_time_ms": 100,
        "memory_limit_mb": 1024,
        "concurrency_limit": 10,
    },
}
