"""Archive consumed public QA and construct one explicit SDK staging plan."""
import hashlib
import json
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

ROOT = Path('D:/bt_api_py')
META = Path(__file__).parent
config_path = Path(sys.argv[1])
config = json.loads(config_path.read_text())
selected = json.loads((META / config['selected']).read_text())
packet = ROOT / config['packet']
delivery = META / config['delivery']
assert not packet.exists() and not delivery.exists()

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

assert git('branch', '--show-current').strip() == b'dev'
assert git('rev-parse', 'HEAD').decode().strip() == config['parent']
assert not git('diff', '--cached', '--name-only').strip()
for row in selected['overlays']:
    assert digest((ROOT / row['source']).read_bytes()) == row['sha256']
    if row['source'] != row['destination']:
        assert digest((ROOT / row['destination']).read_bytes()) == row['checkout_sha256']

final = Path(config['final_run'])
result = json.loads((final / 'result.json').read_text())
guard = json.loads((final / 'guard.json').read_text())
assert result['pytest_exit'] == 0 and result['sources_unchanged'] and result['heads_unchanged']
assert not guard['failures'] and not guard['denied_events']
assert (final / 'stderr.log').read_bytes() == b''
cases = ET.parse(final / 'junit.xml').findall('.//testcase')
assert len(cases) >= len(selected['nodes'])
assert all(not any(c.find(tag) is not None for tag in ('failure', 'error', 'skipped')) for c in cases)
case_names = {c.attrib['name'] for c in cases}
node_names = {n.split('::')[-1] for n in selected['nodes']}
assert all(name in node_names or name.split('[')[0] in node_names for name in case_names)
assert all(any(name == case or name == case.split('[')[0] for case in case_names) for name in node_names)

members = {}
for run in config['runs']:
    p = Path(run)
    for f in sorted(p.iterdir()):
        if f.is_file():
            members['runs/' + p.name + '/' + f.name] = f.read_bytes()
for relative in config['metadata']:
    p = META / relative
    assert p.is_file()
    members['metadata/' + relative.replace('\\', '/')] = p.read_bytes()
for row in selected['overlays']:
    members['accepted-source/' + row['destination']] = (ROOT / row['source']).read_bytes()
members['metadata/build-focused-delivery.py'] = Path(__file__).read_bytes()
members['metadata/delivery-config.json'] = config_path.read_bytes()
packet.mkdir(parents=True)
with zipfile.ZipFile(packet / 'root-qa.zip', 'x', compression=zipfile.ZIP_DEFLATED) as z:
    for name, data in members.items():
        z.writestr(name, data)
with zipfile.ZipFile(packet / 'root-qa.zip') as z:
    assert set(z.namelist()) == set(members)
    assert all(z.read(k) == v for k, v in members.items())
record = {
    'repository': str(ROOT), 'branch': 'dev', 'parent': config['parent'],
    'scope': [r['destination'] for r in selected['overlays']],
    'summary': config['summary'], 'evidence_level': result['evidence_level'],
    'accepted_nodes': selected['nodes'], 'accepted_test_count': len(cases),
    'accepted_case_names': sorted(case_names),
    'accepted_run': str(final), 'preserved_runs': config['runs'],
    'warnings': 'Expected CTP native extension exclusion warning; synthetic native leaf only.',
    'limitations': config['limitations'], 'formal_pass': 62, 'formal_total': 68,
    'source_pins': selected['overlays'],
    'archive_sha256': digest((packet / 'root-qa.zip').read_bytes()),
    'archive_members': {k: digest(v) for k, v in members.items()},
    'commit': 'Recorded by exact scoped postcommit verification and the iteration tracker.',
}
(packet / 'round-record.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
paths = record['scope'] + [(packet / n).relative_to(ROOT).as_posix() for n in ['root-qa.zip', 'round-record.json']]
outside = ['--', '.', *[':(exclude)' + p for p in paths]]
plan = {'sdk': {
    'repository': str(ROOT), 'parent': config['parent'],
    'entries': [{'path': row['destination'], 'mode': '100644', 'source': str(ROOT / row['source']),
                 'sha256': row['sha256'],
                 'checkout_sha256': digest((ROOT / row['destination']).read_bytes())}
                for row in selected['overlays']] +
               [{'path': p, 'mode': '100644', 'source': str(ROOT / p),
                 'sha256': digest((ROOT / p).read_bytes()),
                 'checkout_sha256': digest((ROOT / p).read_bytes())}
                for p in paths[len(selected['overlays']):]],
    'outside_exclusions': paths,
    'outside_diff_sha256': digest(git('diff', '--binary', *outside)),
    'outside_status_sha256': digest(git('status', '--porcelain=v1', '-z', '--untracked-files=no', *outside)),
}}
delivery.mkdir()
(delivery / 'delivery-plan.json').write_text(json.dumps(plan, indent=2) + '\n', encoding='utf-8')
stager = ROOT / '.codex-tmp/ctp-zero-fill-proof-root-20261018/reader-delivery/stage-scoped.py'
(delivery / 'stage-scoped.py').write_bytes(stager.read_bytes())
print(json.dumps({'scope': paths, 'accepted_tests': len(cases), 'archive_bytes': (packet / 'root-qa.zip').stat().st_size}))
