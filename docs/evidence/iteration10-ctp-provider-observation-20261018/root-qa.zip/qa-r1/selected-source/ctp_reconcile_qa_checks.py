"""Root-only source origin and no-provider guards for the focused component QA."""
import importlib.abc
from pathlib import Path
import sys
import platform
import json
import os
import asyncio
DENIED = []
platform.node()  # Preload Windows metadata before candidate subprocess denial.
ROOT = Path(__file__).resolve().parent
class NoCtpProvider(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname == "bt_api_ctp" or fullname.startswith("bt_api_ctp."):
            DENIED.append("provider_import")
            raise RuntimeError("provider import forbidden in callback component QA")
        return None
sys.meta_path.insert(0, NoCtpProvider())
def no_external_calls(event, args):
    if event in {"socket.connect", "socket.bind", "subprocess.Popen", "os.system", "os.exec", "os.posix_spawn", "_winapi.CreateProcess"}:
        DENIED.append(event)
        raise RuntimeError("external operation forbidden in callback component QA")
sys.addaudithook(no_external_calls)
def pytest_sessionfinish(session, exitstatus):
    expected = {
        "bt_api_py.ctp_service_execution": ROOT / "bt_api_py/ctp_service_execution.py",
        "bt_api_execution.store": ROOT / "execution/src/bt_api_execution/store.py",
        "bt_api_execution.ctp_callback_session": ROOT / "execution/src/bt_api_execution/ctp_callback_session.py",
        "bt_api_base": ROOT / "base/src/bt_api_base/__init__.py",
    }
    expected["bt_api_execution.ctp_native_callbacks"] = ROOT / "execution/src/bt_api_execution/ctp_native_callbacks.py"
    expected["bt_api_execution.ctp_single_worker_candidate"] = ROOT / "execution/src/bt_api_execution/ctp_single_worker_candidate.py"
    origins = {name: getattr(sys.modules.get(name), "__file__", None) for name in expected}
    Path(os.environ["CTP_OBSERVATION_QA_OUTPUT"]).joinpath("guard.json").write_text(json.dumps({"origins": origins, "denied_events": DENIED, "guard_scope": "listed process/network audit events and bt_api_ctp imports only; not general OS/native isolation"}, indent=2) + "\n")
    for name, source in expected.items():
        module = sys.modules.get(name)
        assert module is not None and Path(module.__file__).resolve() == source.resolve(), name
    assert not any(name == "bt_api_ctp" or name.startswith("bt_api_ctp.") for name in sys.modules)
