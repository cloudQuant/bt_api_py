# SCN02 — unified 9 目录读写能力说明（R1，2026-10-16）

> SCN02 条款（`D:/bt_api_py/docs/迭代计划/迭代10-可选组件与可配置通信/正式迭代计划.md` 第 787 行）：
> **9 个 unified 目录逐一说明读/写能力；012 两腿、013_1/013_2 同账户多合约、013_3 单合约观察/受准入演练、014_1 三腿、014_2/015 观察、007 历史入口边界 ｜ 实际正常 SDK/Backtrader 路径验证，保留批准/研究/同钟证据条件；不凭名称宣称 HFT**
>
> 本文档完成条款的"逐一说明"半场（设计/合同级，底稿为 `场景覆盖与旧转发迁移清单.md` §4 与各目录 README/run.py，
> 并与 `D:/bt_api_py/.codex-tmp/scn02-recon.md` 能力表对齐）。**本文档本身不是 SCN02 正式 PASS**；
> 正式裁定须待 R3–R7（SimNow 零写观察、受准入演练、demo 引用/重跑、root-adjudication）后另行归并。
> R2 零 I/O 本地扫（2026-10-16，证据 `D:/temp/it10scn02-r12-20261016-r1/`）为增量证据，同样不构成正式 PASS。
>
> 目录根：`D:/source_code/backtrader/examples/unified/`；解释器 `C:/anaconda3/python.exe`(3.11.5)；
> 凭据只按名读 `D:/source_code/backtrader/.env`（不注入进程环境）；各目录 `evidence/` 均 git-ignored。

## 0. 汇总表（读写合同分类）

| # | 目录 | 通道（读/写） | 零 I/O dry/replay | 写通道 | 本地现状 |
|---|---|---|---|---|---|
| 1 | `007_ctp` | 无 live 读写（历史入口边界） | 登记 `run_runtime.py`（LOCAL_REPLAY_ONLY）+ doctor | 无（历史下单/撤单不恢复；production 未登记 fail-closed） | 零 I/O 全可跑 |
| 2 | `012_1_midfreq_cross_exchange` | 读：无独立零写观察（如实声明缺口）；写：OKX+Binance **Demo** 有界机械配对（两腿） | `run.py` / `run.py --replay` | `--live --allow-write --mechanical-smoke`（外部 demo 端点） | dry/replay 可跑；demo 冒烟需外部端点 |
| 3 | `012_2_event_driven_cross_exchange` | 同 012_1（事件驱动 IOC taker-taker） | 同上 | 同上（HFT 证据级保持 `HFT_FAILED/NOT_ADMITTED`） | 同 012_1 |
| 4 | `013_1_midfreq_cross_arbitrage` | 读：`run_live_observe()` 零写观察；写：同账户 m/RM **两腿** registered-sim 窄口径准入 drill | `run.py` / `run.py --replay` | `--live --allow-write`（SimNow 模拟账户、时段+洁净账户） | dry/replay 可跑；observe/drill 需 SimNow 网络 |
| 5 | `013_2_highfreq_calendar_arbitrage` | 同 013_1（rb 主力/次主力跨期；SHFE `close_today`） | 同上 | 同上 | 同 013_1 |
| 6 | `013_3_sa_midfreq_simnow` | 读：单合约零写观察；写：单合约**受准入演练**（`--drill`、`policy.max_actions` 有界、结束平仓+对账） | `run.py` / `run.py --replay` | `--live --allow-write` | dry/replay 可跑；observe/drill 需 SimNow 网络 |
| 7 | `014_1_ctp_options_lowfreq` | 读：三腿零写观察；写：**三腿** C/P/F 严格写 drill（逐腿 arm 切换、一次性 drill） | `run.py` / `run.py --replay` | `--live --allow-write`（交易时段标准前置） | dry/replay 可跑；首成交往返待时段内验收 |
| 8 | `014_2_ctp_options_midfreq` | 读：live 层即观察层（决策专用、无下单路径）；写：无（合同禁止） | `run.py` / `run.py --replay` | `--live --allow-write` = BLOCKED `write_tier_not_implemented_for_decision_only_strategy` | dry/replay 可跑；observe 需 SimNow 网络 |
| 9 | `015_ctp_options_highfreq` | 读：零写 tick 观察层（`dispatch_ticks=True`）；写：无（合同禁止） | `run.py` / `run.py --replay` | `--live --allow-write` = BLOCKED（同码） | dry/replay 可跑；observe 需 SimNow 网络 |

## 1. 逐目录说明

### 1. 007_ctp — 历史入口边界
- 路径：`D:/source_code/backtrader/examples/unified/007_ctp/`
- 展示内容：历史 CTP 直连示例（下单/撤单/认证案例）的**迁移边界**：唯一登记档案=本地零 I/O `simulation/replay` 迁移报告；`ctp_*_examples/{backtest,live}/run.py` 均为 fail-closed 壳（live `main()` 直接 raise `legacy_direct_execution_error`）；`runtime-production/` 未登记（schema-only，legacy）。
- 读：无（登记路由不导入 Backtrader/CTP/provider/凭据）。写：无（历史执行面 `NOT_SUPPORTED`；production switch 未登记、保持 fail-closed）。
- 入口：`run_runtime.py`（注册表 `backtrader_runtime/inventory.py`，`bt-runtime` 控台未装入 anaconda 3.11，用脚本或 `-m backtrader_runtime.cli`）；`runtime/config.yaml` 已存在（schema v4, simulation/replay，勿 bootstrap 覆盖）。
- 当前证据状态：无归档运行报告（runtime/ 仅 config）。R2（2026-10-16）：`run_runtime.py` → `LOCAL_REPLAY_PASS`（`admission_status=LOCAL_REPLAY_ONLY`，network 0/order_write 0，全部写路径 false）+ `doctor` 离线诊断 exit 0（增量证据）。
- SCN02 条款映射：**007 历史入口边界**（"保留历史为源码/回归、不恢复执行面"）。

### 2. 012_1_midfreq_cross_exchange — 两腿（跨所 demo 机械配对）
- 路径：`D:/source_code/backtrader/examples/unified/012_1_midfreq_cross_exchange/`
- 展示内容：OKX+Binance 跨所中频两腿机械配对（先/后腿真实成交往返），仅 demo 端点、有界（`max_actions/max_round_trips/run_seconds`）。
- 读：**无独立零写观察通道**——`--live` 无写授权显式返回 `BLOCKED/live_observation_unavailable`（能力缺口如实声明，只读前置只在写演练内）。写：`--live --allow-write --mechanical-smoke`（operator 确认、canonical manifest 绑定；候选保持 `RESEARCH_REJECTED`，报告带 `MECHANICAL_DEMO_SMOKE_NOT_RESEARCH`；`hft_label=not_applicable`；无授权一律 fail-closed）。
- 当前证据状态：历史 `MECHANICAL_DEMO_SMOKE_PASS` ×2（2026-10-10，git-ignored），replay report 至 2026-10-11。R2：dry `DRY` / replay `FORMULA_CHECK_PASS`（`R0_FORMULA_FIXTURE_NOT_MARKET_OR_PROFITABILITY_EVIDENCE`）/ `--live` → `BLOCKED` 缺口事实（增量证据）。未验收：demo 冒烟重跑（需外部 demo 端点）——可引用历史 PASS 或 R5 决定重跑。
- SCN02 条款映射：**012 两腿**。

### 3. 012_2_event_driven_cross_exchange — 两腿（事件驱动）
- 路径：`D:/source_code/backtrader/examples/unified/012_2_event_driven_cross_exchange/`
- 展示内容：同 012_1 但为事件驱动 IOC taker-taker 两腿（`--run-seconds` 上限 180）。
- 读/写：同 012_1（观察通道缺口 `live_observation_unavailable`；写仅 demo 机械冒烟）。HFT 证据级保持 `HFT_FAILED/NOT_ADMITTED`（`hft_label=event_driven`）；`INCOMPLETE_INSUFFICIENT_SAMPLE` 诊断链保留。
- 当前证据状态：历史 `MECHANICAL_DEMO_SMOKE_PASS` ×1（2026-10-10）。R2：dry `DRY` / replay `FORMULA_CHECK_PASS` / `--live` → `BLOCKED`（增量证据）。
- SCN02 条款映射：**012 两腿**。

### 4. 013_1_midfreq_cross_arbitrage — 同账户多合约（m/RM 两腿）
- 路径：`D:/source_code/backtrader/examples/unified/013_1_midfreq_cross_arbitrage/`
- 展示内容：DCE m × CZCE RM 跨品种价差套利；**同一 SimNow 账户两条腿**（不同交易所），前端 1–8 组 MD/TD pair 新鲜选择、双腿逐次 disarm→arm。
- 读：`run_live_observe()` 零写观察——原生登录→账户/持仓/委托/成交+两腿合约元数据只读查询→正常关闭，`LIVE_OBSERVE_PASS`+`write_health`；从不 arm、不建 Broker/Cerebro，脏账户只上报。写：registered-sim 窄口径准入两腿 drill（前端白名单、一次性武装、逐笔 capability、账户无持仓无委托前置、本机单调时钟）。
- 当前证据状态：历史 `PASS / fill_round_trip`（live-20261011T030536Z）。**`LIVE_OBSERVE_PASS` 全仓零命中**（观察通道从未产证）。R2：dry `DRY` / replay `LOCAL_REPLAY_PASS`（profitable，pair_actions 4，network 0/order_write 0）（增量证据）。待 R3：SimNow 零写观察产证。
- SCN02 条款映射：**013_1 同账户多合约**；同钟条件=订单/持有计时用本机单调时钟（不依赖数据钟）。

### 5. 013_2_highfreq_calendar_arbitrage — 同账户多合约（rb 跨期两腿）
- 路径：`D:/source_code/backtrader/examples/unified/013_2_highfreq_calendar_arbitrage/`
- 展示内容：SHFE rb 主力/次主力跨期价差；同账户两腿；`close_today` 平仓语义；auto 按日历+到期保护选腿。
- 读/写：同 013_1 模式。**"highfreq 名称不构成 HFT 证据**；auto≠成交量主力识别/自动换月。
- 当前证据状态：历史 `PASS / fill_round_trip`（live-20261010T075431Z）。R2：dry `DRY` / replay `LOCAL_REPLAY_PASS`（profitable）（增量证据）。注：README 第 26 行 bt-runtime 示例误写 013_1 路径（注册表正确，归档时注明）。
- SCN02 条款映射：**013_2 同账户多合约**。

### 6. 013_3_sa_midfreq_simnow — 单合约观察/受准入演练
- 路径：`D:/source_code/backtrader/examples/unified/013_3_sa_midfreq_simnow/`
- 展示内容：CZCE 纯碱 SA 中频单合约示例；研究状态 `RESEARCH_NOT_ESTABLISHED`（技术贯通非收益）。
- 读：`run_live_observe()` 单合约零写观察（同模板）。写：单合约**受准入演练**（`--drill` 工程窗口、`policy.max_actions` 有界、结束自动平仓+对账；drill 只在"无自然尝试、无未决/UNKNOWN、预检通过"下成立）。
- 当前证据状态：历史 `PASS / fill_round_trip`（live-20261009T175637Z）；其后多条 `FAIL lifecycle_only` 原样保留。`runtime-ctp-private` 受保护；`env.broker-production.NOT-SUPPORTED`。R2：dry `DRY` / replay `LOCAL_REPLAY_PASS`（no_signal 与 trend 两个场景，orders 0，sdk_write_requests 0）（增量证据）。
- SCN02 条款映射：**013_3 单合约观察/受准入演练**（条款点名对象）。

### 7. 014_1_ctp_options_lowfreq — 三腿
- 路径：`D:/source_code/backtrader/examples/unified/014_1_ctp_options_lowfreq/`
- 展示内容：C/P/F（Call/Put/Future）三腿转换-反转平价残差套利，15 分钟闭合 K 线。
- 读：`run_live_observe()` 三腿零写观察（要求 3 distinct legs、单交易所）。写：**三腿严格写 drill**，必须 `--live --allow-write`（三腿逐腿 arm 切换、一次性 drill 触发与逐腿成交核算）；7x24 前置无涨跌停数据 → `exchange_limits_unavailable` 干净拒绝、零写。
- 当前证据状态：历史仅 1 条 live `BLOCKED strict_feed_sealed_evidence`（2026-10-09）；三腿真实成交往返**未验收**。回放保留 `FILL_TIMING_UNKNOWN`、0 confirmed fills、`LOCAL_BASKET_FLAT_UNVERIFIED`；真实账户归零/token 属 SDK/CTP owner，保持 `NOT_RUN`。R2：dry `DRY`（`live_tier.status=STRICT_ADAPTER`）/ replay `LOCAL_REPLAY_PASS`（eligible）（增量证据）。
- SCN02 条款映射：**014_1 三腿**；同钟=显式 monotonic `ClockMapping`。

### 8. 014_2_ctp_options_midfreq — 观察（决策专用）
- 路径：`D:/source_code/backtrader/examples/unified/014_2_ctp_options_midfreq/`
- 展示内容：一分钟 FQ2 特征三腿套利（决策专用）。
- 读：**live 层即观察层**——registered-sim 直连→Store 只读查询→3×`BtApiFeed` 分钟桶（`closed_bar_quote_capture`）→feed 密封 `BarEvidence` 决策；PASS=观察窗内 ≥1 完成分钟特征窗（WARMUP/ORDINARY_DECISION）且 `feed_evidence_fault=null`、`order_write=0`。写：无——`--allow-write` 明确 BLOCKED（`write_tier_not_implemented_for_decision_only_strategy`；token `ENGINEERING_WRITE_DISABLED`）。
- 当前证据状态：历史 4 条 live 观察（UNKNOWN×2/BLOCKED×2，2026-10-09），**无 PASS**；7x24 前置事件钟曾观测 ~47.9h 陈旧 → `BLOCKED/live_event_clock_outside_run_mapping`（不降级伪造）。R2：dry `DRY`（`live_tier.status=OBSERVATION_ONLY`、`write_tier=NOT_IMPLEMENTED_DECISION_ONLY_STRATEGY`）/ replay `LOCAL_REPLAY_PASS`（no_edge）/ `--live --allow-write` → `BLOCKED`（增量证据）。
- SCN02 条款映射：**014_2 观察**。

### 9. 015_ctp_options_highfreq — 观察（tick，HFT 不宣称）
- 路径：`D:/source_code/backtrader/examples/unified/015_ctp_options_highfreq/`
- 展示内容：C/P/F 三腿 tick-only cohort 示例。
- 读：零写 **tick 观察层**（`dispatch_ticks=True`，每腿 ≥1 真实 tick 经标准入口进策略即 `OBSERVATION_PASS`）。写：无——`--allow-write` 直接 BLOCKED（同码）。
- 当前证据状态：历史 `OBSERVATION_PASS / observation_only_tick_arrival`（live-20261009T213253Z）。**HFT 保持 `FAIL/NOT_ADMITTED`**（不凭名称宣称 HFT；翻转=生产 `ctp.quote.v2` 专用适配轮，本迭代不做）；cohort 资格要求 `ctp.quote.v2`+同钟域决策边界，直连 tick 源尚不产出 → tick 记 `TRUSTED_NOW_INVALID` 等拒绝事实、不伪造合格 cohort；L2 上游 `BLOCKED_BY_UPSTREAM_QUALIFICATION` 属 SDK 工作项。R2：dry `DRY`（自带 `hft_status=FAIL/NOT_ADMITTED`）/ replay `LOCAL_REPLAY_PASS`（valid_cohort，`hft_status=FAIL/NOT_ADMITTED` 保持）/ `--live --allow-write` → `BLOCKED`（增量证据）。
- SCN02 条款映射：**015 观察**；"不凭名称宣称 HFT"标注。

## 2. 条款-证据条件速查（保留批准/研究/同钟）

| 目录 | 批准条件 | 研究状态 | 同钟证据条件 |
|---|---|---|---|
| 007 | 无批准=只能 replay；production switch 未登记 fail-closed | 不适用 | 本地 no-action，不涉时钟 |
| 012_1/012_2 | 写批准=`--allow-write`+`--mechanical-smoke`（operator 确认+manifest 绑定） | `RESEARCH_REJECTED`（qualification-v3 已过期） | 不适用 HFT（`hft_label` 标注）；同钟=两所成交量往返按本机运行窗口 |
| 013_1/013_2 | SimNow registered-sim 窄口径准入（精确前置白名单）；drill 需时段+洁净账户 | 技术贯通非收益 | 订单/持有计时用本机单调时钟（不依赖数据钟）；成交判定按会话归属 |
| 013_3 | registered-sim 窄口径；`--drill` 工程窗口 | `RESEARCH_NOT_ESTABLISHED` | 同上 |
| 014_1 | 三腿逐腿 arm 切换+一次性 drill 触发 | 非收益结论 | 显式 monotonic `ClockMapping`；回放保留 `FILL_TIMING_UNKNOWN` |
| 014_2 | 观察层无写批准概念（写合同禁止） | 非收益结论 | 时钟域决策边界；7x24 陈旧钟如实 BLOCKED |
| 015 | 观察层无写批准概念（写合同禁止） | HFT 保持 `FAIL/NOT_ADMITTED` | `cohort_decision_now_*` 同钟域要求 |

## 3. R2 增量证据边界声明

- R2 零 I/O 扫（2026-10-16）在 `C:/anaconda3/python.exe`(3.11.5) 下运行，`PYTHONPATH=D:/bt_api_py/bt_api_py;D:/bt_api/bt_api_base/src;D:/bt_api/bt_api_execution/src;D:/bt_api/bt_api_transport_zmq/src`；全部 run 由目录自身计数器/拒绝码自证 `network=0、order_write=0`；无 SimNow/OKX/Binance 连接、无写演练。
- 证据目录：`D:/temp/it10scn02-r12-20261016-r1/`（逐目录子文件夹：命令行、exit code、stdout/stderr、回放 report.json；顶层 `SUMMARY.md` 汇总表；git-baseline/post-sweep 快照）。
- **dry/replay 通过属 SCN02 增量证据，不构成 SCN02 正式 PASS**；`LIVE_OBSERVE_PASS`/写往返/demo 冒烟仍待 R3–R6，正式裁定待 R7。
