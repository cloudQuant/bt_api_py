# Extracted exact MIG03 methods/blocks only; rest of shared service_registry.py excluded.

    def _record_migration_write_attempt(self, *, fact_kind: str) -> bool:
        """Seal before an authorized write, bound to the deployment epoch."""

        if not self._migration_writes_enabled:
            raise MigrationGateError(_MIGRATION_WRITE_DISABLED)
        state_path = self._migration_state_path
        if state_path is None:
            return False
        return record_migration_write_attempt(
            state_path,
            deployment_epoch=self._migration_deployment_epoch,
            fact_kind=fact_kind,
        )

    def migration_writes_enabled(self) -> bool:
        """Whether this process has passed the explicit MIG03 write enable."""

        with self._lock:
            return self._migration_writes_enabled

    def enable_migration_writes(
        self,
        *,
        migration_id: str,
        deployment_epoch: str,
        readiness_sha256: str,
    ) -> None:
        """Enable a committed destination only after operator readback checks.

        The readiness digest binds the operator's checked read/projection,
        policy and local readiness evidence. This method verifies that the
        active durable marker is still the same unsealed destination and that
        this Registry is ready; it does not treat an arbitrary reference as
        proof of external fencing.
        """

        if (
            type(migration_id) is not str
            or not migration_id
            or type(deployment_epoch) is not str
            or not deployment_epoch
            or type(readiness_sha256) is not str
            or len(readiness_sha256) != 64
            or any(character not in "0123456789abcdef" for character in readiness_sha256)
        ):
            raise MigrationGateError(_MIGRATION_WRITE_ENABLEMENT_INVALID)
        with self._lock:
            self._ensure_open()
            if (
                not self._ready
                or self._migration_state_path is None
                or deployment_epoch != self._migration_deployment_epoch
            ):
                raise MigrationGateError(_MIGRATION_WRITE_ENABLEMENT_INVALID)
            try:
                marker = read_migration_marker(self._migration_state_path)
            except MigrationGateError:
                raise
            if (
                marker is None
                or marker.status != STATUS_COMMITTED
                or marker.migration_id != migration_id
                or marker.destination_epoch != deployment_epoch
            ):
                raise MigrationGateError(_MIGRATION_WRITE_ENABLEMENT_INVALID)
            self._migration_writes_enabled = True
            self._migration_write_enablement_sha256 = readiness_sha256

        self._migration_writes_enabled = True
        self._migration_write_enablement_sha256: str | None = None
        self._capabilities = capability_map
        self._grants = trusted_grants
        self._trusted_group_write_policies = trusted_group_write_policies
        self._trusted_group_reservation_policies = trusted_group_reservation_policies
        self._trusted_group_resolution_policies = trusted_group_resolution_policies
        self._trusted_paper_owner_write_policies = trusted_paper_owner_write_policies
        self._handlers: dict[
            tuple[str, str], Callable[[ServiceCallContext, Mapping[str, Any]], Mapping[str, Any]]
        ] = {}
        self._ready = ready
        self._lock = threading.RLock()
        self._closed = False
        self._epoch = uuid.uuid4().hex
        db_path = str(path)
        self._migration_state_path = None if db_path == ":memory:" else Path(db_path)
        if self._migration_state_path is not None and migration_deployment_epoch is not None:
            marker = read_migration_marker(self._migration_state_path)
            if (
                marker is not None
                and marker.status == STATUS_COMMITTED
                and marker.destination_epoch == migration_deployment_epoch
            ):
                # The destination can start and serve reads, but no business
                # writer or persistent background task may proceed until the
                # operator explicitly enables it after target-side checks.
                self._migration_writes_enabled = False

        write_fact_kind = None
        if operation in write_ops:
            write_fact_kind = "dispatch"
        elif capability.port == "service.account_read" and (
            operation == "account.ack"
            or (
                operation == "account.read_after"
                and arguments.get("track_delivery", False) is True
            )
        ):
            # Tracked reads durably advance offered_cursor just like an ACK is
            # a durable cursor transition. Fence both before entering Gateway.
            write_fact_kind = "cursor"
        elif capability.port == "service.risk_query" and operation == "risk.snapshot":
            # The public Risk snapshot runs policy initialization and expiry
            # updates in its SQLite transaction, despite being a query route.
            write_fact_kind = "reservation"
        if write_fact_kind is not None:
            try:
                self._record_migration_write_attempt(fact_kind=write_fact_kind)
            except MigrationGateError as error:
                if error.code == _MIGRATION_WRITE_DISABLED:
                    return self._failure(_MIGRATION_WRITE_DISABLED)
                # Marker/epoch/lock uncertainty must prevent handler entry.
                return self._failure("UNAVAILABLE")
            except OSError:
                # Marker/epoch/lock uncertainty must prevent handler entry.
                return self._failure("UNAVAILABLE")
