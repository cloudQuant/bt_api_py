# LOAD01 r5 resume failure diagnosis

Date: 2026-10-16 (Asia/Shanghai). Evidence scope is the single completed r5 pilot and a read-only static review of its frozen public-source export. This is a failure diagnosis, not a LOAD01 pass. No r6, pytest, QA, Host, collection, or new load was run. No production or canonical test source was changed. Prior r1–r4 outputs remain preserved.

## Run and source identity

The runner session was 4436 and ended with exit 1. Output: `D:\temp\iteration10-load01-pilot-e08da3c5-20261016-r5-resume`. Frozen public-source export: `D:\temp\it10load01-20261016-r5-resume\source` (public files only; not a Git worktree). The result binds parent commit `e08da3c58cb3b3b040f7799642de38523bbd3229` and its six exact package gitlinks below. Current checkout HEAD `e75ef358134df0069f2873625ff69313133c9a0c` is recorded as docs-only context and is not the source of the export.

The parent archive is 14,994,406 bytes / 3,877 members / SHA-256 `3e32218bd459810130d33559aebbd51524f275deb9e834fe3025bfe89d103bb7`. Package archives and gitlinks:

| Package | Gitlink commit | Archive bytes / members | Archive SHA-256 |
| --- | --- | ---: | --- |
| `bt_api_base` | `b4aabd1e17b9c7252fa7b4d266932087d99b5517` | 310,519 / 261 | `cc6053eb2b8d0186c6b1d98ded521454bb374f39183a4d27176326847daaae60` |
| `bt_api_transport_zmq` | `a397fdb460d2deb22e67ceb4963992ef63dbbb0e` | 54,830 / 23 | `07f8cd6b0c8308e22555fcfc196efc14b85a332c2ba5b679a3bfa6fad25f8c41` |
| `bt_api_gateway` | `59b164ab7f89c6428ae6546103aad6058dab4c16` | 154,707 / 41 | `03ba4df4643054c275dc8df1e074050a125ca4e806af648d32d324d815ddd686` |
| `bt_api_monitor` | `536a4f04747182749fabdac5e28624f80465bc53` | 145,856 / 53 | `041d3908de1f8039268ee72d58695149bc1da2deba50fdb170839980f1d2896d` |
| `bt_api_execution` | `f5c030644dea06ce91afbaacf94e11e353538186` | 501,701 / 76 | `14efac09b8bf8073826e85a8c37c9750689f3b12c20a9764b4614a8d0bd961aa` |
| `bt_api_risk` | `adb6ec58308149faa93c02920b72f98ac3796056` | 310,232 / 65 | `5ad071e3a8fc20034e3003c15999cf7afeaeb5bacf9a81ac2f7ae23ebad4bf7e` |

`source-export-pins.json` is 5,309 bytes / SHA-256 `0c32eee4f2add4f594b052506ff7afe2c2a339a6df702159f7b071a432e802e8`. The parent and six package archives were emitted from their frozen commits, not working-tree sources. The sole candidate working-tree source was `tests/unit/test_load01_hundred_strategy_30min.py`. Its candidate overlay SHA-256 is `489ff6a97d01ebeacca3c0b2022151c7c54805679ed85651b8773656d67d59af`; this is explicitly **not commit-derived**. It adds four lines and deletes none over parent runner blob `8291666106e7fc3aff97b3661e88705fa88b96090751ae5548ce2705014157bf` (candidate patch SHA `63c1b687c3504e1bcd31c91529760eb0b5516754b7a84617060d50ef6fb1d7be`). Freeze metadata was then applied as a distinct patch (11 insertions / 4 deletions; SHA `507e31efdf967ba9db2d104f1e2d51ee436b97fc96af5846b280627e4e889d2a`); the combined base-to-final patch SHA is `cecd7b7487eb7075062e941f8c2657312364e6a3110eddfbd20fa18731d970fd`. Frozen runner SHA-256 is `7b5201ca5704afd77538c103f393b2c49c8b0947aa0e581277ee0264c845c321`. Thus the four-line candidate source is not misrepresented as a commit or as the final frozen file.

`source-before.json` and `source-after.json` each contain the complete 37-entry selected-source map, are both 6,171 bytes, and have the same SHA-256 `fc2a5290edafe1660b731e597d74e352844b804e4064a3f6885f94a2bcaac36c`. The raw maps compare equal: 37 entries, zero mismatches. The runner result reports `source_count=37`, `sources_unchanged=true`, empty `heads_before` and `heads_after`, and `formal_acceptance_eligible=false`. Full pinned rows follow; each value is SHA-256.

### Complete 37-entry selected-source map

- D:\bt_api_py\.codex-tmp\iteration10-focused-qa.py — `8b7f470be77270adeb9d72a83776b827c4653004b39835eeca0f43bf63cf24ed`
- D:\temp\it10load01-20261016-r5-resume\bt_api_base.zip — `cc6053eb2b8d0186c6b1d98ded521454bb374f39183a4d27176326847daaae60`
- D:\temp\it10load01-20261016-r5-resume\bt_api_execution.zip — `14efac09b8bf8073826e85a8c37c9750689f3b12c20a9764b4614a8d0bd961aa`
- D:\temp\it10load01-20261016-r5-resume\bt_api_gateway.zip — `03ba4df4643054c275dc8df1e074050a125ca4e806af648d32d324d815ddd686`
- D:\temp\it10load01-20261016-r5-resume\bt_api_monitor.zip — `041d3908de1f8039268ee72d58695149bc1da2deba50fdb170839980f1d2896d`
- D:\temp\it10load01-20261016-r5-resume\bt_api_risk.zip — `5ad071e3a8fc20034e3003c15999cf7afeaeb5bacf9a81ac2f7ae23ebad4bf7e`
- D:\temp\it10load01-20261016-r5-resume\bt_api_transport_zmq.zip — `07f8cd6b0c8308e22555fcfc196efc14b85a332c2ba5b679a3bfa6fad25f8c41`
- D:\temp\it10load01-20261016-r5-resume\parent.zip — `3e32218bd459810130d33559aebbd51524f275deb9e834fe3025bfe89d103bb7`
- D:\temp\it10load01-20261016-r5-resume\source-export-pins.json — `0c32eee4f2add4f594b052506ff7afe2c2a339a6df702159f7b071a432e802e8`
- EXPORT\bt_api_py\service_account.py — `d7aee3c00d1d9fe2bd8219f8e35898d0f7620df2999ca4de6082a23544e8008f`
- EXPORT\bt_api_py\service_components.py — `9625f9ce73189e1c8ed8a2d220fa29ddba7f3c151246556a6def01e6c3effbc3`
- EXPORT\bt_api_py\service_config.py — `5023a98ebdfb0ca9285616b3ce0107904ed81640e3bde49823217d773343d17c`
- EXPORT\bt_api_py\service_execution_monitor.py — `6e10bc4bb3978d9011d796e903639ac7896168719a9f6e442302895787f4537d`
- EXPORT\bt_api_py\service_host.py — `509a710b1292cb42d70aa9f1a995fd5c77394dfc6d172adf36de83a8d4ba5ef0`
- EXPORT\bt_api_py\service_market.py — `5b7a357693ef4ddc50ef397f4bfc67ca7116ab2809850c03ee07f05a18bc75b6`
- EXPORT\bt_api_py\service_runtime.py — `64d4e873888c118bc4fc55cae3f90f0e1983a5dff97354718326f7ee7ffbcd93`
- EXPORT\bt_api_py\service_telemetry.py — `89a8d82e51f2cbb70dcde4bb069053b4d340778b0aeb222343a9183b14175489`
- EXPORT\bt_api\bt_api_base\src\bt_api_base\account_protocol.py — `dc25caae8cb3a7e2ac8851958a60a15a2a6c264f4b3419a3d5f50a5d76fa116c`
- EXPORT\bt_api\bt_api_base\src\bt_api_base\market_protocol.py — `9ad1a16842dfee03587a815ecf4a9915559287c9ce995f6cff8df15c00309108`
- EXPORT\bt_api\bt_api_base\src\bt_api_base\service_protocol.py — `f0ed739ac98cda400bed07bf8487b79ee0a5ebe6842b9d0711b4b12e8af6b15a`
- EXPORT\bt_api\bt_api_execution\src\bt_api_execution\contracts.py — `95a36b917fdb0ba07f2e4c6bdc0c959812e7bdab269e06f531a10e05ae59e477`
- EXPORT\bt_api\bt_api_execution\src\bt_api_execution\journal_reader.py — `d032cf69ade5e4869af5a0b523526b87d230029b4d9a24dabd3a99d4e7429500`
- EXPORT\bt_api\bt_api_execution\src\bt_api_execution\service_order_entry.py — `f2a1eb3664962a322a8df8d2f36f32fd482390b994511d873aa4faf80c7166a0`
- EXPORT\bt_api\bt_api_execution\src\bt_api_execution\store.py — `51ba6a71d18bd8c213d2ede1af3023087889d3e07425561502bf82b3a4fed180`
- EXPORT\bt_api\bt_api_gateway\src\bt_api_gateway\account_session_worker.py — `0006b8a9cfe014d881e8bd8efabebe943ae301af2d5f167211d29cf4cc8545e1`
- EXPORT\bt_api\bt_api_gateway\src\bt_api_gateway\market_hub.py — `68066602191877afc24c72623eb8f81d4defe7f093fbdb53d104cc68153675d3`
- EXPORT\bt_api\bt_api_gateway\src\bt_api_gateway\service_component.py — `d5e3d4e7814413885672484a11c666dd1603ebfeeb39e412916bab430821fc0c`
- EXPORT\bt_api\bt_api_monitor\src\bt_api_monitor\durable.py — `35b1aa96c834baf540bda1b45b08e33204570374be386a4715b9a29e55d68557`
- EXPORT\bt_api\bt_api_monitor\src\bt_api_monitor\service_ingress.py — `0b65d791cd92ddd8d05e33a17e0b9b0ead1033340fcdd71719fa5f91eb7b3bd3`
- EXPORT\bt_api\bt_api_monitor\src\bt_api_monitor\service_telemetry.py — `e5d9063f7f1eba84d48e500bfb273869ab7039e56f31981bd3083ea039463c2b`
- EXPORT\bt_api\bt_api_transport_zmq\src\bt_api_transport_zmq\client.py — `3c42842494bb5a28245aebcce0afdd500943cc6a8d7677f080c69551377ec354`
- EXPORT\bt_api\bt_api_transport_zmq\src\bt_api_transport_zmq\events.py — `5e8fb7c9f4481b2f1386c5f197e3b563a079acf84d47ba8f0c90c694bb56e999`
- EXPORT\bt_api\bt_api_transport_zmq\src\bt_api_transport_zmq\market_v2.py — `051cb114a41300d9f94630f95ee9a773ce252f36a9f01d94e0d99561db36ac91`
- EXPORT\bt_api\bt_api_transport_zmq\src\bt_api_transport_zmq\service_v2.py — `bc17344835fcd80409cdcfd8037345ccf92b5ece5f57817aeb1eda33af17b280`
- EXPORT\bt_api\bt_api_transport_zmq\src\bt_api_transport_zmq\wire.py — `60ef5ea0ea89ff11d1e62c65865a39256cf91c31981553a301f7687394f6372b`
- EXPORT\tests\unit\test_load01_hundred_strategy_30min.py — `7b5201ca5704afd77538c103f393b2c49c8b0947aa0e581277ee0264c845c321`
- EXPORT\tests\unit\test_service_gateway_hundred_strategy_integration.py — `70126a7135297ab42df279c4d9156adb2b14d197b46f03a7fe20e43edac258a2`

## Frozen source files statically inspected

Hashes below are of files in the frozen export and pin the exact code reviewed here. Line numbers refer to those bytes; no file was written or executed.

| File | Bytes | SHA-256 | Relevant source lines |
| --- | ---: | --- | --- |
| `bt_api_py/service_host.py` | 65,066 | `509a710b1292cb42d70aa9f1a995fd5c77394dfc6d172adf36de83a8d4ba5ef0` | 727–762 |
| `bt_api_py/service_registry.py` | 100,410 | `2003091ad28031db7deb2ca85f336e66252207fd43c28c6bdf8300edfc23a20e` | 1002–1085, 2090–2237 |
| `bt_api_py/service_runtime.py` | 77,513 | `64d4e873888c118bc4fc55cae3f90f0e1983a5dff97354718326f7ee7ffbcd93` | 1605–1643 |
| `bt_api_py/service_components.py` | 99,728 | `9625f9ce73189e1c8ed8a2d220fa29ddba7f3c151246556a6def01e6c3effbc3` | 1966–1993, 1995–2037 |
| `bt_api_py/service_execution.py` | 26,972 | `90ae00c99ba2ec2ee24a5a367b47ad73db456590c33913c838591d130d0b4318` | 317–336 |
| `bt_api_py/service_execution_account_books.py` | 62,932 | `e9b0fb0ac7e96b1c9fdcbe6bd649346b3fa5d2a7a8ff0c7c1323eaf77c013eea` | included in execution composition archive; no direct handler timing found |
| `bt_api/bt_api_transport_zmq/src/bt_api_transport_zmq/service_v2.py` | 29,701 | `bc17344835fcd80409cdcfd8037345ccf92b5ece5f57817aeb1eda33af17b280` | 263–324, 435–523 |
| `bt_api/bt_api_execution/src/bt_api_execution/service_order_entry.py` | 43,599 | `f2a1eb3664962a322a8df8d2f36f32fd482390b994511d873aa4faf80c7166a0` | 273–337, 782–824 |
| `bt_api/bt_api_execution/src/bt_api_execution/cancellation.py` | 19,657 | `68ffd8e790fca9309896075633193f9198e00ee8e8da545efa9ac011e083d4d5` | 129–232 |
| `bt_api/bt_api_execution/src/bt_api_execution/store.py` | 864,265 | `51ba6a71d18bd8c213d2ede1af3023087889d3e07425561502bf82b3a4fed180` | 2054–2071, 15540–15548 |
| `bt_api/bt_api_execution/src/bt_api_execution/paper_execution.py` | 57,364 | `d6009b51da22b2431d5646cb640a2d974bf345a84172514a2e060ae738c93731` | inspected only as frozen dispatch dependency |

## r5 observed outcome

The one test `test_load01_hundred_strategy_sustained` failed: pytest exit 1, state `FAILED`, last phase `sustained-load`, failure `CHILD_FAILED`, child safe code `UNEXPECTED_ERROR`. The strategy-046 traceback ends in `RequestOutcomeUnknownError(..., "response_timeout")` from frozen `service_v2.py:477`; its public transport message ID is `0e70b5943a0a4d4b8b1a28b7ffb2c02e`. That client had already queued the request (`sent=True`) and exhausted its 5,000 ms reply poll. Runtime source explicitly disables automatic retry for uncertain writes (`service_runtime.py:1629`). This is a real sustained-load failure, not a launch/setup failure and not a lease-expiry failure.

The requested profile remained unchanged: 100 strategies, 10 accounts, 20 topics, 200 market events/s, 2 order-lifecycle operations/s/account, 30-second lease, 120-second pilot, 1,800-second full profile, 2 GiB free-memory reserve, 95% system-CPU stop threshold. The barrier reached 100/100 strategies ready and 112/112 children alive; active registry counts included ten strategy sessions per account, 100 market registrations, 100 monitor durable scopes and 100 monitor telemetry scopes. Lease was 30 seconds and client RPC timeout 5 seconds. Recorded load start is `2026-10-16T07:33:30.636222Z`; result completion is `2026-10-16T07:34:30.786996Z`, 60.151 seconds later. The result lacks the exact child-failure timestamp, so the requested 120 seconds cannot be claimed completed. JUnit records one failed test, 203.205 seconds for the test body (204.368 seconds suite total), zero setup errors and zero skips. Parent `stderr.log` is empty; pytest reports one known `PytestConfigWarning` for `asyncio_default_fixture_loop_scope`. Captured child stderr in `stdout.log` also contains repeated pyzmq Proactor/add_reader selector-thread `RuntimeWarning`s; this is a resource/scheduling confound, not proof of cause.

The same-call child diagnostic reports cancel RPC max 5,000 ms, submit max about 78 ms, account snapshot max 31 ms, market head/read_after/snapshot/subscribe maxima of about 1,219–1,641 ms, maintenance max 2,875 ms, last maintenance delay about 2.047 seconds, zero maintenance failures, and `UNEXPECTED_ERROR`. At failure the runtime was registered and required leases remained healthy: `runtime_lease_at_failure` recorded a 22,047 ms minimum; the account-read and market-loop snapshots recorded 23,937 ms and 23,968 ms, respectively. No lease lapse, remote inactive lease, cleanup failure or unregister uncertainty was reported.

The run had actual market and order activity: top-level progress projected 26 market events, 23 order cycles, and progress for 13 strategies; the result also records 20 active market providers, first/last publish timestamps and per-stream sequences. Those partial progress projections are not a 100-strategy aggregate or a 120-second completion receipt. At the all-ready barrier free memory was 5,091,356,672 bytes, above the 2 GiB reserve. The last recorded resource sample was 35.078 seconds after load start: free memory 2,905,272,320 bytes (still above reserve), system CPU 40.8% (below the 95% stop), child RSS 11,230,158,848 bytes versus an 8,455,716,864-byte projection, and database tree about 96.8 MB. There is no resource sample at the exact failure; memory/RSS pressure remains a plausible contributor, not an established cause.

## Durable business rows and transport correlation limit

The prior diagnosis queried the synthetic SQLite files using a read-only connection; no database is opened in this current diagnosis. The row facts below are transcribed from that prior read-only observation; no separate SQLite query transcript/hash is claimed. That inspection found 133 execution intents and 119 cancellation rows across ten execution databases; all 119 cancellation rows were `ACKED`, with zero `UNKNOWN` or review-required rows. Monitor outbox had 1,008 rows across 100 scopes (532 lifecycle and 476 cancellation rows); the account-04 business ID `cancel-load01-04-06-0000001` was `ACKED`, and a `strategy-046` cancellation outbox projection was present. The execution cancellation payload and monitor outbox do not carry transport message ID `0e70b5943a0a4d4b8b1a28b7ffb2c02e`. Therefore the durable `ACKED` facts show business-side progress for those business IDs, but do **not** prove that this exact transport RPC received a reply or that the row belongs to this exact message ID. A response may have been late or dropped after the business write, and the observed rows do not distinguish those cases.

**SQLite sidecar caveat:** the prior read-only SQLite inspection may have created or advanced the WAL shared-memory `-shm` sidecar; its observed modification times advanced to about 15:41/15:42 local, while the main DB/WAL modification times remained around 15:34. This sidecar was not deleted or restored, and no claim is made that the full DB tree remained byte- or metadata-identical after that read-only query. The account-04 main DB observation was 4,096 bytes / SHA-256 `31b0f6669e49303bea772658c76cd8557d01840c6b7b51f2eed54c4c0a44d4ff` with a WAL around 2,892,272 bytes; the monitor DB observation was 1,617,920 bytes / SHA-256 `a59d99a19dba2c93bdb9cb432c5ce3a47fc262829ce2056b1609f9e4c443a173`. WAL and `-shm` hashes were not established. No further DB access is part of this diagnosis.

## Cleanup and child-process observation

Cleanup was abnormal and is not a pass: `normal_shutdown_complete=false`; 109 termination requests were issued; 109 strategy/owner children have exit code `-15`; strategy-046 exited 1; `market-hub` and `monitor` exited 0. All 112 child records say handles were closed, but every child has `normal_exit=false`. Cleanup recorded `strategy-046:close-send:BrokenPipeError`. This appears secondary to strategy-046 already failing, but the sequence is not proven. At 2026-10-16 15:52:21 +08:00, a read-only `Get-Process -Id` check against exactly the 112 distinct child PIDs in this r5 result found zero present. PID 81428 was excluded and not queried; no historical host PID was queried, killed, or otherwise touched. “No child PID residue at this sample” is the claim; abnormal cleanup remains recorded.

## Static scheduling path and leading hypothesis

The frozen export shows a single-threaded, synchronous request path. `ServiceHost.serve_once` is owner-thread-only and, for each pass, may run upstream maintenance, readiness refresh and `_maintain_components`, calls the transport once, then runs component maintenance and readiness refresh again (`service_host.py:727–762`). The ROUTER `ZmqServiceServer.serve_once` polls and receives at most one message, decodes/authenticates it, invokes `self._handler(...)` inline, builds/seals the reply, and calls `send_multipart(..., NOBLOCK)` before returning (`service_v2.py:263–324`). There is no request executor in this path. If a handler or maintenance step stalls, later messages wait behind it.

`ServiceHost._dispatch_request` refreshes readiness and calls `registry.handle` inline (`service_host.py:1269–1281`). Registry `_dispatch` checks session/policy/scope/handler bindings and calls the registered business handler synchronously (`service_registry.py:2090–2237`). The registry transaction used for request authorization ends before `handler(context, arguments)` is called (the transaction block ends at 2181; handler starts at 2211), so a long business call should not be described as the registry transaction being held through the handler.

`orders.cancel` follows the registered execution adapter into `ExecutionOrderEntryService.handle` then `_cancel` (`service_components.py:1966–1993`; `service_order_entry.py:273–337, 782–824`). `_cancel` reads the target order and synchronously calls the cancellation facade. The facade performs durable admission, claims the one-shot dispatch, validates the writer lease, optionally claims risk admission, calls the injected dispatcher, persists the provider observation and settles the record (`cancellation.py:129–232`). The execution SQLite store uses a per-instance `RLock`, `BEGIN IMMEDIATE` transactions, WAL, `synchronous=FULL`, and a 5,000 ms busy timeout (`store.py:2054–2071, 15540–15548`). These operations make the cancel handler’s durable admission/dispatch/recording sequence the strongest handler-local candidate for a slow path; possible writer-lock waits and full-sync commits must be timed before being called causal.

The response path has a separate concrete hazard: server `send_multipart` is nonblocking, and `zmq.Again` is caught and silently treated as handled (`service_v2.py:311–314`). If output HWM/backpressure is hit after the business operation commits, the client sees exactly an uncertain `response_timeout`. This code path is compatible with the ACK observations but was not observed in r5. The leading common-cause hypothesis is therefore owner-thread head-of-line blocking across the synchronous maintenance/handler/reply chain, with cancellation’s multi-stage durable write path the leading handler cost; nonblocking reply drop is the leading alternative for “business ACK exists, client has no reply.” The current evidence does not select one.

## Minimal next diagnostic and repair boundary

For the next Root-authorized acceptance attempt, add timing-only structured records for `orders.cancel`, keyed by existing transport `message_id` **and** business `cancel_id`; keep them distinct. Use one local monotonic clock domain and record: client send/deadline; host `serve_once` entry; pre-maintenance begin/end; server dequeue; registry/handler entry; handler return; post-maintenance end; server reply encode/seal and `send_multipart` outcome (`queued`, `Again`, unreachable); and client reply receive or timeout. Also include the previous request’s completion time and, if cheaply available, bounded listener in-flight/backlog indicators. The key spans are send→dequeue (pre-handler transport/queue age), dequeue→handler-enter (host/authorization work), handler-enter→handler-return (execution work), handler-return→server-send-result (reply construction/send), and server-send→client-receive (delivery). Since the current server discards `zmq.Again`, count it explicitly; send returning successfully still is not proof of client receipt. If handler time dominates, add only a small subspan around target lookup, cancellation facade, risk claim, dispatcher and final durable observation to identify the dominant work.

This diagnostic preserves the fixed 100/10/20/200 Hz/2 Hz/30 s lease/5 s RPC/120 s pilot/1,800 s full profiles and all resource/cleanup assertions. It does not raise the timeout, lower load, retry an uncertain write, or use an `ACKED` row as the transport reply receipt. One cause-specific repair should follow the measured dominant span: request-loop scheduling/maintenance if queue age dominates, the durable cancel subpath if handler dominates, or a bounded owner-thread reply queue/retry design if send backpressure is observed. Keep the socket on its owner thread and preserve the current idempotency/reconciliation rules while repairing whichever single common cause the trace proves.

No r6 preparation, QA, Host, collection, pilot or full run is authorized by this diagnosis. The frozen r5 output and source export are left intact.

## r5 output artifact pins

All SHA-256 values below were checked from the preserved output. `pytest-tmp` was not inspected or modified.

| Artifact | Bytes | SHA-256 |
| --- | ---: | --- |
| `command.json` | 1,497 | `f0f984a249a694334d6c39db1c61f54aa56e2fd95f3eb3f541c149f4d5cbb668` |
| `exit.txt` | 3 | `f1b2f662800122bed0ff255693df89c4487fbdcf453d3524a42d4ec20c3d9c04` |
| `junit.xml` | 912 | `807a92b80930fc7ad0ad99329014067e98258cc9230a61b5ada99ba176afe6c6` |
| `load01-pilot-result.json` | 1,283,975 | `d688326440e93d6494c253a942994baf171318ef38f9f2042fba4285d12a423a` |
| `result.json` | 519 | `e09eb0ebf002262ef0950bca2056e2fbe2ef4351468d53fc90999379150bb496` |
| output `runner.py` (Root QA harness copy) | 3,204 | `8b7f470be77270adeb9d72a83776b827c4653004b39835eeca0f43bf63cf24ed` |
| `running.json` | 76 | `43fbd245ae1474ae40d1c65574156ba2a61d7e25f2340538a7b98dd3c4f22009` |
| `source-after.json` | 6,171 | `fc2a5290edafe1660b731e597d74e352844b804e4064a3f6885f94a2bcaac36c` |
| `source-before.json` | 6,171 | `fc2a5290edafe1660b731e597d74e352844b804e4064a3f6885f94a2bcaac36c` |
| `spec.json` | 11,533 | `d5e24680ebf2568eb3034d98e646a833698fa5c9f4e787b27199af8bc6199e48` |
| `stderr.log` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `stdout.log` | 7,542 | `24c9e380721951ae3b933627d609569766c036819ab901d5715034e2b6220c64` |
