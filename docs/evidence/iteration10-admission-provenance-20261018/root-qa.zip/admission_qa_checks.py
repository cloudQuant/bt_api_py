"""Root QA guard for the local admission provenance component."""
import asyncio
import importlib.abc
import json
import os
import platform
import sys
from pathlib import Path

import urllib3  # Finish its localhost IPv6 feature probe before candidate guards.

platform.node()
ROOT = Path(__file__).resolve().parent
DENIED = []


class NoProviderImport(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname == "bt_api_ctp" or fullname.startswith("bt_api_ctp."):
            DENIED.append("import:" + fullname)
            raise ImportError("CTP provider imports are forbidden in admission QA")
        return None


sys.meta_path.insert(0, NoProviderImport())


def audit(event, args):
    if event in {"socket.connect", "socket.bind", "subprocess.Popen", "os.system",
                 "os.exec", "os.posix_spawn", "_winapi.CreateProcess"}:
        DENIED.append(event)
        raise RuntimeError("external operation forbidden in admission QA")


sys.addaudithook(audit)


def pytest_sessionfinish(session, exitstatus):
    expected = {
        "bt_api_execution.basic_admission": ROOT / "execution/src/bt_api_execution/basic_admission.py",
        "bt_api_execution.store": ROOT / "execution/src/bt_api_execution/store.py",
        "bt_api_base.service_protocol": ROOT / "base/src/bt_api_base/service_protocol.py",
    }
    origins = {name: getattr(sys.modules.get(name), "__file__", None) for name in expected}
    Path(os.environ["ADMISSION_QA_OUTPUT"]).joinpath("guard.json").write_text(
        json.dumps({"origins": origins, "denied_events": DENIED,
                    "guard_scope": "listed process/network events and CTP provider import; not general OS/native isolation"}, indent=2) + "\n"
    )
    for name, path in expected.items():
        assert origins[name] is not None and Path(origins[name]).resolve() == path.resolve(), name
    assert not DENIED
