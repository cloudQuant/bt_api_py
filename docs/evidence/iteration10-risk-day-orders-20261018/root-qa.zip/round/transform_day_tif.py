from __future__ import annotations

import hashlib
import json
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
META = Path(__file__).resolve().parent
RELATIVE = "bt_api_py/service_risk_order_entry.py"
SELECTED = json.loads((META / "selected-baseline.json").read_text(encoding="utf-8"))
BASELINE = json.loads((META / "baseline.json").read_text(encoding="utf-8"))
PIN = SELECTED[RELATIVE]
HEAD_BACKUP = META / PIN["backup_prefix"]
HEAD_BACKUP = HEAD_BACKUP.with_name(HEAD_BACKUP.name + ".head-before")
CHECKOUT_BACKUP = META / PIN["backup_prefix"]
CHECKOUT_BACKUP = CHECKOUT_BACKUP.with_name(CHECKOUT_BACKUP.name + ".checkout-before")
CHECKOUT = ROOT / RELATIVE
HEAD_OUTPUT = META / "selected" / RELATIVE


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _apply(data: bytes) -> tuple[bytes, tuple[tuple[str, int], ...]]:
    newline = b"\r\n" if b"\r\n" in data else b"\n"
    newline_text = newline.decode("ascii")
    text = data.decode("utf-8")
    counts: list[tuple[str, int]] = []

    def replace(label: str, old: str, new: str, expected: int = 1) -> None:
        nonlocal text
        old_text = old.replace("\n", newline_text)
        new_text = new.replace("\n", newline_text)
        count = text.count(old_text)
        if count != expected:
            raise RuntimeError(f"{label}: expected {expected} source match(es), found {count}")
        text = text.replace(old_text, new_text)
        counts.append((label, count))

    replace(
        "finite_tif_profiles",
        '_SUPPORTED_PROVIDER_TIME_IN_FORCE = frozenset(\n    {("GTC",), ("IOC",), ("GTC", "IOC")}\n)',
        '_SUPPORTED_PROVIDER_TIME_IN_FORCE = frozenset(\n'
        '    {("GTC",), ("DAY",), ("GTC", "DAY"), ("IOC",), ("GTC", "IOC")}\n'
        ')',
    )
    replace(
        "normal_order_readiness",
        '    @property\n'
        '    def risk_only_write_ready(self) -> bool:\n'
        '        """Whether the normal risk-only dispatcher can use its fixed GTC path."""\n'
        '\n'
        '        return self.write_ready and "GTC" in self.supported_time_in_force\n',
        '    @property\n'
        '    def risk_only_write_ready(self) -> bool:\n'
        '        """Whether GTC-only internal group dispatch is supported."""\n'
        '\n'
        '        return self.write_ready and "GTC" in self.supported_time_in_force\n'
        '\n'
        '    @property\n'
        '    def risk_only_order_write_ready(self) -> bool:\n'
        '        """Whether a normal LIMIT order can use an advertised GTC or DAY TIF."""\n'
        '\n'
        '        return self.write_ready and any(\n'
        '            value in {"GTC", "DAY"} for value in self.supported_time_in_force\n'
        '        )\n',
    )
    replace(
        "service_constructor_readiness",
        "if not contract.risk_only_write_ready:",
        "if not contract.risk_only_order_write_ready:",
    )
    replace(
        "submit_capability_projection",
        "contract is not None and contract.risk_only_write_ready",
        "contract is not None and contract.risk_only_order_write_ready",
    )
    replace(
        "submit_readiness",
        "if contract is None or not contract.risk_only_write_ready:",
        "if contract is None or not contract.risk_only_order_write_ready:",
    )
    replace(
        "group_runtime_requires_gtc",
        '                or not contract.exposure_ready\n'
        '                or "CLOSE" not in contract.supported_position_effects',
        '                or not contract.exposure_ready\n'
        '                or "GTC" not in contract.supported_time_in_force\n'
        '                or "CLOSE" not in contract.supported_position_effects',
    )
    replace(
        "group_composition_requires_gtc",
        '            or not contract.exposure_ready\n'
        '            or "CLOSE" not in contract.supported_position_effects',
        '            or not contract.exposure_ready\n'
        '            or "GTC" not in contract.supported_time_in_force\n'
        '            or "CLOSE" not in contract.supported_position_effects',
        expected=3,
    )
    replace(
        "normal_parser_tif",
        '    if (\n'
        '        type(arguments["order_type"]) is not str\n'
        '        or type(arguments["time_in_force"]) is not str\n'
        '        or arguments["order_type"] != "LIMIT"\n'
        '        or arguments["time_in_force"] != "GTC"\n'
        '    ):\n'
        '        raise RiskOrderEntryError("LIMIT_GTC_ONLY")',
        '    supported_time_in_force = (\n'
        '        contract.supported_time_in_force if contract is not None else ("GTC",)\n'
        '    )\n'
        '    if (\n'
        '        type(arguments["order_type"]) is not str\n'
        '        or type(arguments["time_in_force"]) is not str\n'
        '        or arguments["order_type"] != "LIMIT"\n'
        '        or arguments["time_in_force"] not in {"GTC", "DAY"}\n'
        '        or arguments["time_in_force"] not in supported_time_in_force\n'
        '    ):\n'
        '        raise RiskOrderEntryError("LIMIT_GTC_ONLY")',
    )
    replace(
        "canonical_payload_preserves_tif",
        '        "signal_id": arguments["signal_id"],\n'
        '        "tags": {},\n'
        '        "time_in_force": "GTC",',
        '        "signal_id": arguments["signal_id"],\n'
        '        "tags": {},\n'
        '        "time_in_force": arguments["time_in_force"],',
    )
    replace(
        "parsed_request_preserves_tif",
        '        "quantity_unit": request_quantity_unit,\n'
        '        "request_position_side":',
        '        "quantity_unit": request_quantity_unit,\n'
        '        "time_in_force": arguments["time_in_force"],\n'
        '        "request_position_side":',
    )
    replace(
        "typed_request_preserves_tif",
        '            price=parsed["price"],\n'
        '            time_in_force="GTC",',
        '            price=parsed["price"],\n'
        '            time_in_force=parsed["time_in_force"],',
    )
    replace(
        "recovery_tif_binding",
        '    expected_reduce_only = position_effect == "CLOSE"\n',
        '    expected_reduce_only = position_effect == "CLOSE"\n'
        '    time_in_force = command.canonical_payload.get("time_in_force")\n',
    )
    replace(
        "recovery_request_tif",
        '        or request.time_in_force != "GTC"',
        '        or request.time_in_force != time_in_force',
    )
    replace(
        "recovery_canonical_tif",
        '        or command.canonical_payload.get("time_in_force") != "GTC"',
        '        or type(time_in_force) is not str\n'
        '        or time_in_force not in {"GTC", "DAY"}\n'
        '        or time_in_force not in contract.supported_time_in_force',
    )
    return text.encode("utf-8"), tuple(counts)


def main() -> None:
    if subprocess.run(
        ["git", "-C", str(ROOT), "rev-parse", "HEAD"],
        check=True,
        capture_output=True,
        text=True,
    ).stdout.strip() != BASELINE["sdk"]["head"]:
        raise RuntimeError("SDK HEAD changed since the selected baseline")

    head = HEAD_BACKUP.read_bytes()
    checkout_before = CHECKOUT_BACKUP.read_bytes()
    checkout_now = CHECKOUT.read_bytes()
    selected_head = subprocess.run(
        ["git", "-C", str(ROOT), "show", f"HEAD:{RELATIVE}"],
        check=True,
        capture_output=True,
    ).stdout
    if _sha(head) != PIN["head_sha256"] or selected_head != head:
        raise RuntimeError("saved HEAD source differs from the selected baseline")
    if (
        _sha(checkout_before) != PIN["checkout_sha256"]
        or checkout_now != checkout_before
        or _sha(checkout_now) != PIN["checkout_sha256"]
    ):
        raise RuntimeError("checkout source differs from the selected baseline")

    head_candidate, head_counts = _apply(head)
    checkout_candidate, checkout_counts = _apply(checkout_before)
    if head_counts != checkout_counts:
        raise RuntimeError("HEAD and checkout did not receive the same finite transform")
    if HEAD_OUTPUT.exists():
        raise RuntimeError(f"selected HEAD output already exists: {HEAD_OUTPUT}")

    HEAD_OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    HEAD_OUTPUT.write_bytes(head_candidate)
    CHECKOUT.write_bytes(checkout_candidate)
    result = {
        "sdk_head": BASELINE["sdk"]["head"],
        "path": RELATIVE,
        "head_before_sha256": _sha(head),
        "head_candidate_bytes": len(head_candidate),
        "head_candidate_sha256": _sha(head_candidate),
        "checkout_before_sha256": _sha(checkout_before),
        "checkout_candidate_bytes": len(checkout_candidate),
        "checkout_candidate_sha256": _sha(checkout_candidate),
        "transform_counts": list(head_counts),
        "selected_head_path": str(HEAD_OUTPUT),
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
