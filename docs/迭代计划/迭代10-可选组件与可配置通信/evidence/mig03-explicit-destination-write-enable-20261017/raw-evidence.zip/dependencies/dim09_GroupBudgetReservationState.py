class GroupBudgetReservationState(StrEnum):
    """Durable state of the coordinator-local gross group-budget hold."""

    RESERVED = "RESERVED"
    HELD = "HELD"
    RELEASED = "RELEASED"
    DENIED = "DENIED"
