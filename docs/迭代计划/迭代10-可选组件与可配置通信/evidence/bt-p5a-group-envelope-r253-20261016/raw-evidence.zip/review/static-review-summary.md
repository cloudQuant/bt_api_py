# Independent static review summary — R249b

Reviewer: /root/review_bt_v3_cpf; verdict: GO_STATIC.

- Fixed SDK coordinator source returns GROUP_ACCEPTANCE_REJECTED only when coordinator acceptance fails before advance_group; it is the sole definitive pre-dispatch submit rejection in the accepted source.
- GROUP_ORDER_OUTCOME_UNPROVEN, GROUP_ORDER_UNAVAILABLE, malformed replies, and all non-allowlisted submit business errors map to REQUEST_OUTCOME_UNKNOWN, preserving the original group ID. Recovery queries that same ID and does not resubmit.
- The final-source plan-binding node covers v3 wire plan fields and independent tamper cases for base_units_per_order_unit, quantity_step, and metadata_valid_until_ns; it also covers v1 wire payload normalization to a v2 server reply.
- R249b's 1,440 exported source pins and current specs/results match. The old pre-rebind spec was not preserved because its first run stopped at preflight before producing an output; a read-only check found the successor script changed repository/source-binding HEAD metadata and status only.
- This is static review only. It does not assert external provider/account, monitor.read_after RPC, formal DIM09, or all SCN02 directories.

No tests or Host were run by the reviewer.
