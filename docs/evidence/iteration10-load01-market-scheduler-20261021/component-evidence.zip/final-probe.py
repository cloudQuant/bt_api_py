from __future__ import annotations
import json, os, sys, time, statistics, traceback, zipfile
from pathlib import Path

SOURCE = Path(r"D:/temp/load01-10x2-20261020/market-component-probe-patch-1e8a/source-fixed").resolve()
PINS = Path(r"D:/temp/load01-10x2-20261020/market-component-probe-patch-1e8a/source-export-pins.json").resolve()
WORK = Path(r"D:/temp/load01-10x2-20261020/market-component-probe-patch-1e8a-loopdiag-results").resolve()
SOURCE_ROOTS = (SOURCE, SOURCE / "bt_api_py", SOURCE / "bt_api/bt_api_base/src", SOURCE / "bt_api/bt_api_execution/src", SOURCE / "bt_api/bt_api_gateway/src", SOURCE / "bt_api/bt_api_monitor/src", SOURCE / "bt_api/bt_api_risk/src", SOURCE / "bt_api/bt_api_transport_zmq/src")
SITE_PACKAGES = Path(r"C:/Anaconda3/Lib/site-packages")
import sysconfig
stdlib = Path(sysconfig.get_paths()["stdlib"])
platstdlib = Path(sysconfig.get_paths()["platstdlib"])
dlls = Path(sys.base_prefix) / "DLLs"
zipstdlib = Path(sys.base_prefix) / f"python{sys.version_info.major}{sys.version_info.minor}.zip"
# python -S avoids .pth/site hooks; keep only the fixed source, interpreter, and dependency roots.
sys.path[:] = [str(p) for p in (*SOURCE_ROOTS, stdlib, platstdlib, dlls, zipstdlib, SITE_PACKAGES) if p.exists()]
os.environ["BT_API_LOAD01_SOURCE_ROOT"] = str(SOURCE)
os.environ["BT_API_LOAD01_EXPORT_PINS"] = str(PINS)
import tests.unit.test_load01_hundred_strategy_30min as m


def _summary(samples):
    values = sorted(int(x) for x in samples)
    def pct(f):
        return values[min(len(values)-1, max(0, int((len(values)*f)+0.999999)-1))] if values else 0
    return {"count": len(values), "mean_ns": int(sum(values)/len(values)) if values else 0,
            "p50_ns": pct(.50), "p95_ns": pct(.95), "max_ns": max(values, default=0)}


def _instrumented_host(control, diag, *args):
    import inspect

    m._load_load01_server_imports()
    load_event = args[5]
    load_start_value = args[6]
    stop_event = args[7]
    stats = {
        "serve_load_ns": [], "publish_load_ns": [], "publish_stamps": [],
        "batch_wall_ns": [], "batch_sizes": [], "debt_before": [], "debt_after": [],
        "sleep_requested_ns": [], "sleep_actual_ns": [],
    }
    original_serve = m.ServiceHost.serve_once
    original_publish = m._CountedMarketProvider.publish_one
    original_batch = m._load01_run_due_market_publish_batch
    original_sleep = m.time.sleep

    def load_active():
        return (load_event.is_set() and time.monotonic() >= float(load_start_value.value)
                and not stop_event.is_set())

    def due_slots(now_ns, next_ns, interval_ns):
        return 0 if now_ns < next_ns else 1 + (now_ns - next_ns) // interval_ns

    def serve(self, *call_args, **call_kwargs):
        sampled = load_active()
        start_ns = time.perf_counter_ns()
        try:
            return original_serve(self, *call_args, **call_kwargs)
        finally:
            elapsed_ns = time.perf_counter_ns() - start_ns
            if sampled:
                stats["serve_load_ns"].append(elapsed_ns)

    def publish(self, key, publish_ns, *call_args, **call_kwargs):
        sampled = load_active()
        start_ns = time.perf_counter_ns()
        try:
            return original_publish(self, key, publish_ns, *call_args, **call_kwargs)
        finally:
            if sampled:
                stats["publish_load_ns"].append(time.perf_counter_ns() - start_ns)
                stats["publish_stamps"].append(int(publish_ns))

    def run_batch(publish_one, *call_args, **call_kwargs):
        sampled = load_active()
        next_before = call_kwargs.get("next_publish_ns")
        interval_ns = call_kwargs.get("interval_ns")
        start_ns = time.perf_counter_ns()
        if sampled and type(next_before) is int and type(interval_ns) is int:
            stats["debt_before"].append(due_slots(start_ns, next_before, interval_ns))
        result = original_batch(publish_one, *call_args, **call_kwargs)
        end_ns = time.perf_counter_ns()
        if sampled:
            stats["batch_wall_ns"].append(end_ns - start_ns)
            published = int(result[2])
            stats["batch_sizes"].append(published)
            next_after = int(result[1])
            if type(interval_ns) is int:
                stats["debt_after"].append(due_slots(end_ns, next_after, interval_ns))
        return result

    def sleep(seconds):
        caller = inspect.currentframe().f_back
        is_market_loop = caller is not None and caller.f_code.co_name == "_market_host_process"
        sampled = is_market_loop and load_active()
        requested_ns = int(max(0.0, float(seconds)) * 1_000_000_000) if sampled else 0
        start_ns = time.perf_counter_ns() if sampled else 0
        try:
            return original_sleep(seconds)
        finally:
            if sampled:
                stats["sleep_requested_ns"].append(requested_ns)
                stats["sleep_actual_ns"].append(time.perf_counter_ns() - start_ns)

    m.ServiceHost.serve_once = serve
    m._CountedMarketProvider.publish_one = publish
    m._load01_run_due_market_publish_batch = run_batch
    m.time.sleep = sleep
    try:
        m._market_host_process(control, *args)
    finally:
        m.ServiceHost.serve_once = original_serve
        m._CountedMarketProvider.publish_one = original_publish
        m._load01_run_due_market_publish_batch = original_batch
        m.time.sleep = original_sleep
        gaps = [b-a for a,b in zip(stats["publish_stamps"], stats["publish_stamps"][1:])]
        sizes = {}
        for size in stats["batch_sizes"]:
            sizes[str(size)] = sizes.get(str(size), 0) + 1
        diag.send({
            "measurement_scope": "load-window-only; sampled while load active and before stop",
            "serve_once_load_window": _summary(stats["serve_load_ns"]),
            "publish_call_load_window": _summary(stats["publish_load_ns"]),
            "publish_start_gap_load_window": _summary(gaps),
            "batch_wall_load_window": _summary(stats["batch_wall_ns"]),
            "host_loop_sleep_requested_load_window": _summary(stats["sleep_requested_ns"]),
            "host_loop_sleep_actual_load_window": _summary(stats["sleep_actual_ns"]),
            "publish_batches": {
                "count": len(stats["batch_sizes"]),
                "size_histogram": sizes,
                "max_batch_size": max(stats["batch_sizes"], default=0),
                "batch_limit_hit_count": sum(size >= m._MARKET_PUBLISH_BATCH_MAX
                                              for size in stats["batch_sizes"]),
            },
            "due_slot_debt": {
                "samples": len(stats["debt_after"]),
                "batches_with_debt_before": sum(value > 0 for value in stats["debt_before"]),
                "batches_with_debt_after": sum(value > 0 for value in stats["debt_after"]),
                "total_due_slots_before_samples": sum(stats["debt_before"]),
                "total_due_slots_after_samples": sum(stats["debt_after"]),
                "max_before": max(stats["debt_before"], default=0),
                "max_after": max(stats["debt_after"], default=0),
            },
        })
        diag.close()

def _market_client_worker(index, market_rpc, market_pub, server_keys, client_keys,
                          market_keys, control, run_event, abort_event,
                          target_ready_event, targets, drain_deadline):
    runtime = None
    clients = {}
    report = {"index": index, "pid": os.getpid(), "poll_count": 0,
              "poll_total_ns": 0, "poll_max_ns": 0, "received_by_stream": {},
              "last_sequence_by_stream": {}, "gap_count": 0, "duplicate_count": 0,
              "caught_up": False, "runtime_state": None, "close_failures": []}
    try:
        m._check_fixed_strategy_source_manifest(os.environ["BT_API_LOAD01_SOURCE_MANIFEST"], profile_id="U0")
        profile = m.load01_profile("U0")
        account_index = profile.accounts_for_strategy(index)[0]
        strategy_ref = m._strategy_ref(index)
        principal_ref = m._principal_ref(index)
        raw_config = m._market_wave_strategy_config(index, market_rpc, market_pub)
        config = m.parse_client_config(raw_config)
        security = m.ClientCurveKeys(server_keys[0], client_keys[0], client_keys[1])
        runtime = m.ServiceClientRuntime(
            config,
            identity=m.WireIdentity(m.WireRole.STRATEGY_CLIENT, principal_ref, strategy_ref),
            scope_resolver=lambda _scope_ref: m.WireScope(
                m._DOMAIN, account_ref=m._ACCOUNT_REFS[account_index], strategy_ref=strategy_ref),
            peer_resolver=lambda _service_id: m.WireIdentity(
                m.WireRole.SERVICE, m._MARKET_PRINCIPAL, m._MARKET_ID),
            transport_factory=m.ZmqTransportFactory({m._MARKET_SECURITY_REF: security}),
            requested_operations={"store.market": m._MARKET_OPS},
        )
        runtime_probe = m._StartupRuntimeMaintenanceProbe(runtime)
        runtime.start()
        subscriber_factory = m.ZmqMarketTransportFactory({m._MARKET_SECURITY_REF: security})
        pending = []
        for key in market_keys:
            client = m.ServiceMarketClient(
                runtime, "store.market", key, subscriber_factory=subscriber_factory,
                stream_scope=m.WireScope(m._DOMAIN), queue_capacity=256,
                queue_max_bytes=512*1024, head_check_interval_seconds=1.0)
            pending.append(client)
        m.ServiceMarketClient.start_many(pending)
        clients = {key.stream_id: client for key, client in zip(market_keys, pending, strict=True)}
        stream_ids = tuple(sorted(clients))
        control.send(("ready", index, os.getpid(), len(runtime.bindings), len(clients)))
        while not run_event.wait(0.025):
            if abort_event.is_set():
                return
            runtime_probe._maintain_if_due("probe-ready-barrier")
        cursors = {stream_id: 0 for stream_id in stream_ids}
        received = {stream_id: 0 for stream_id in stream_ids}
        poll_index = 0
        report["queue_max_count_by_stream"] = {sid: 0 for sid in stream_ids}
        report["queue_max_bytes_by_stream"] = {sid: 0 for sid in stream_ids}
        def poll_one(*, pause):
            nonlocal poll_index
            if pause:
                return
            stream_id = stream_ids[poll_index]
            poll_index = (poll_index + 1) % len(stream_ids)
            started = time.perf_counter_ns()
            event = clients[stream_id].poll(timeout_ms=0)
            elapsed = time.perf_counter_ns() - started
            report["poll_count"] += 1
            report["poll_total_ns"] += elapsed
            report["poll_max_ns"] = max(report["poll_max_ns"], elapsed)
            if event is not None:
                sequence = event.header.sequence
                previous = cursors[stream_id]
                if sequence <= previous:
                    report["duplicate_count"] += 1
                elif sequence > previous + 1:
                    report["gap_count"] += sequence - previous - 1
                cursors[stream_id] = sequence
                received[stream_id] += 1
            client = clients[stream_id]
            report["queue_max_count_by_stream"][stream_id] = max(
                report["queue_max_count_by_stream"][stream_id], client.queue_count)
            report["queue_max_bytes_by_stream"][stream_id] = max(
                report["queue_max_bytes_by_stream"][stream_id], client.queue_bytes)
        while not abort_event.is_set():
            terminal = target_ready_event.is_set()
            poll_budget = m._load01_terminal_market_poll_budget(
                stop_requested=terminal,
                terminal_request_active=terminal,
                stream_count=len(stream_ids),
            )
            deadline_ns = (
                int(float(drain_deadline.value) * 1_000_000_000)
                if terminal
                else time.monotonic_ns() + m._STRATEGY_MARKET_POLL_BATCH_BUDGET_NS
            )
            m._load01_run_bounded_market_poll_batch(
                poll_one,
                poll_budget=poll_budget,
                poll_pause=False,
                deadline_monotonic_ns=deadline_ns,
                monotonic_ns=time.monotonic_ns,
            )
            if terminal:
                if all(cursors[sid] >= int(targets[pos]) for pos, sid in enumerate(stream_ids)):
                    report["caught_up"] = True
                    break
                if time.monotonic() >= float(drain_deadline.value):
                    break
        report["received_by_stream"] = received
        report["last_sequence_by_stream"] = cursors
        report["queue_count_by_stream"] = {sid: client.queue_count for sid, client in clients.items()}
        report["queue_bytes_by_stream"] = {sid: client.queue_bytes for sid, client in clients.items()}
        report["runtime_state_before_close"] = runtime.state
    except BaseException as exc:
        report["error_code"] = m._safe_diagnostic_code(exc)
        report["traceback_tail"] = traceback.format_exc()[-2000:]
        abort_event.set()
    finally:
        for client in clients.values():
            try:
                client.close()
            except BaseException as exc:
                report["close_failures"].append(m._safe_diagnostic_code(exc))
        if runtime is not None and runtime.state != "closed":
            try:
                runtime.close()
            except BaseException as exc:
                report["close_failures"].append(m._safe_diagnostic_code(exc))
            report["runtime_state"] = runtime.state
        try:
            control.send(("closed", report))
        except BaseException:
            pass
        control.close()


def _receive_tag(conn, expected, timeout, label):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if conn.poll(min(0.1, max(0.0, deadline-time.monotonic()))):
            msg = conn.recv()
            if isinstance(msg, tuple) and msg and msg[0] == expected:
                return msg
            if isinstance(msg, tuple) and msg and msg[0] == "error":
                raise RuntimeError(f"{label} child error: {msg!r}")
            if isinstance(msg, tuple) and msg and msg[0] == "progress":
                continue
            raise RuntimeError(f"{label} unexpected message: {msg!r}")
    raise TimeoutError(f"timed out waiting for {label}:{expected}")


def main():
    import hashlib, multiprocessing as mp, zmq
    WORK.mkdir(parents=True, exist_ok=True)
    pins = json.loads(PINS.read_text(encoding="utf-8"))
    runner_path = SOURCE / "tests/unit/test_load01_hundred_strategy_30min.py"
    if hashlib.sha256(runner_path.read_bytes()).hexdigest() != pins["runner_sha256"]:
        raise RuntimeError("fixed 4cc runner hash mismatch")
    os.environ["BT_API_LOAD01_RUNNER_OVERLAY_SHA256"] = pins["runner_sha256"]
    os.environ["BT_API_LOAD01_RUNNER_SOURCE"] = str(runner_path)
    overlay_specs = {
        "tests/unit/_load01_profiles.py": m._N6_PROFILE_OVERLAY_SHA256,
        "tests/unit/test_load01_profiles.py": m._N6_PROFILE_TEST_OVERLAY_SHA256,
        "tests/unit/_load01_resource_diagnostics.py": m._LOAD01_RESOURCE_DIAGNOSTICS_OVERLAY_SHA256,
        "tests/unit/test_load01_resource_diagnostics.py": m._LOAD01_RESOURCE_DIAGNOSTICS_TEST_OVERLAY_SHA256,
        "tests/unit/_load01_group_topology.py": m._LOAD01_GROUP_TOPOLOGY_OVERLAY_SHA256,
        "tests/unit/test_load01_runner_metrics.py": m._LOAD01_RUNNER_METRICS_TEST_OVERLAY_SHA256,
    }
    allowed = {"tests/unit/test_load01_hundred_strategy_30min.py": pins["runner_sha256"]}
    with zipfile.ZipFile(PINS.parent / "parent.zip") as archive:
        for relative, digest in overlay_specs.items():
            path = SOURCE / relative
            if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
                raise RuntimeError(f"fixed overlay hash mismatch: {relative}")
            if path.read_bytes() != archive.read(relative):
                allowed[relative] = digest
    os.environ["BT_API_LOAD01_SOURCE_MANIFEST"] = str(
        m._write_source_run_manifest(SOURCE, WORK, profile_id="U0", allowed_overlays=allowed))
    m._check_fixed_source_manifest(os.environ["BT_API_LOAD01_SOURCE_MANIFEST"], profile_id="U0")
    ctx = mp.get_context("spawn")
    endpoints = m._free_endpoints(2)
    market_server_keys = zmq.curve_keypair()
    market_keys = m._market_keys("U0")
    strategy_keys = {i: zmq.curve_keypair() for i in range(m._STRATEGIES)}
    audience = m._market_authority_audience(strategy_keys, "U0")
    load_start_event = ctx.Event()
    load_start_value = ctx.Value("d", 0.0)
    stop_event = ctx.Event()
    run_event = ctx.Event()
    abort_event = ctx.Event()
    target_ready_event = ctx.Event()
    targets = ctx.Array("q", [0] * len(market_keys), lock=False)
    drain_deadline = ctx.Value("d", 0.0)
    parent_host, child_host = ctx.Pipe(duplex=True)
    parent_diag, child_diag = ctx.Pipe(duplex=False)
    host = ctx.Process(target=_instrumented_host, args=(child_host, child_diag,
        m._market_service_config(*endpoints), str(WORK/"market-registry.sqlite3"),
        market_server_keys, audience, market_keys, load_start_event,
        load_start_value, stop_event), name="load01-market-probe-host")
    host.start(); child_host.close(); child_diag.close()
    workers = {}
    status = None
    worker_reports = {}
    host_closed = None
    host_instrumentation = None
    try:
        ready = _receive_tag(parent_host, "ready", 60, "market host")
        for wave in m._strategy_startup_waves("U0"):
            for index in wave:
                parent, child = ctx.Pipe(duplex=True)
                proc = ctx.Process(target=_market_client_worker, args=(
                    index, endpoints[0], endpoints[1], market_server_keys,
                    strategy_keys[index], market_keys, child, run_event, abort_event,
                    target_ready_event, targets, drain_deadline),
                    name=f"load01-market-consumer-{index:02d}")
                proc.start(); child.close()
                workers[index] = {"conn": parent, "proc": proc}
            for index in wave:
                msg = _receive_tag(workers[index]["conn"], "ready", 60, f"consumer-{index}")
                if msg[1:] != (index, workers[index]["proc"].pid, 1, len(market_keys)):
                    raise RuntimeError(f"unexpected ready facts: {msg!r}")
        parent_host.send(("status",))
        active = _receive_tag(parent_host, "status", 10, "market active status")[1]
        if active["hub_readiness"]["active_registrations"] != m._STRATEGIES * m._TOPICS:
            raise RuntimeError(f"expected 200 market registrations, got {active['hub_readiness']}")
        load_start_value.value = time.monotonic()
        load_start_event.set()
        run_started = time.perf_counter_ns()
        run_event.set()
        time.sleep(6.0)
        run_window_ended = time.perf_counter_ns()
        stop_event.set()
        parent_host.send(("terminal-watermark", 1))
        terminal = _receive_tag(parent_host, "terminal-watermark", 15, "market terminal status")
        status = terminal[2]
        stream_ids = tuple(sorted(status["source_sequences"]))
        for pos, stream_id in enumerate(stream_ids):
            targets[pos] = status["source_sequences"][stream_id]
        drain_deadline.value = time.monotonic() + 10.0
        target_ready_event.set()
        for index in sorted(workers):
            message = _receive_tag(workers[index]["conn"], "closed", 12, f"consumer-{index}")
            worker_reports[index] = message[1]
        for item in workers.values():
            item["proc"].join(5)
        parent_host.send(("close",))
        host_closed = _receive_tag(parent_host, "closed", 10, "market host close")
        host.join(10)
        host_instrumentation = parent_diag.recv() if parent_diag.poll(5) else None
        elapsed_ns = run_window_ended - run_started
        sequence_exact = all(
            status["source_sequences"].get(stream_id) == row.get("sequence")
            for stream_id, row in status["hub_watermarks"].items()
        )
        strategy_exact = all(
            worker_reports[i].get("caught_up")
            and worker_reports[i].get("last_sequence_by_stream") == {
                sid: int(targets[pos]) for pos, sid in enumerate(stream_ids)
            }
            for i in sorted(worker_reports)
        )
        all_zero_gaps = all(r.get("gap_count") == 0 and r.get("duplicate_count") == 0
                            for r in worker_reports.values())
        process_clean = host.exitcode == 0 and all(
            item["proc"].exitcode == 0 for item in workers.values()
        )
        runtime_clean = all(
            r.get("runtime_state") == "closed" and not r.get("close_failures")
            for r in worker_reports.values()
        )
        host_clean = bool(host_closed and host_closed[2] == "closed" and not host_closed[3]
                          and host.exitcode == 0)
        source_total = sum(status["source_sequences"].values())
        source_rate = source_total/(elapsed_ns/1e9)
        source_topic_rates = [v/(elapsed_ns/1e9) for v in status["source_sequences"].values()]
        summary = {
            "evidence_level": "DIAGNOSTIC_LOCAL_COMPONENT_ONLY_SCHEDULER_CANDIDATE",
            "source_export_parent": pins["parent_commit"],
            "runner_sha256": pins["runner_sha256"],
            "duration_seconds": elapsed_ns/1e9,
            "measured_load_window_seconds": elapsed_ns/1e9,
            "source_rate_per_second": source_rate,
            "source_rate_per_topic_per_second_min": min(source_topic_rates),
            "source_rate_per_topic_per_second_max": max(source_topic_rates),
            "source_target_rate_per_second": m._MARKET_HZ,
            "source_target_per_topic_per_second": m._MARKET_HZ/len(market_keys),
            "source_target_within_registered_plus_minus_5_percent": (
                0.95*m._MARKET_HZ <= source_rate <= 1.05*m._MARKET_HZ
                and all(9.5 <= rate <= 10.5 for rate in source_topic_rates)
            ),
            "source_sequences": status["source_sequences"],
            "hub_watermarks": status["hub_watermarks"],
            "source_sequence_matches_hub_watermarks": sequence_exact,
            "hub_readiness_at_capture": status["hub_readiness"],
            "publish_schedule_hz_target": m._MARKET_HZ,
            "strategy_count": len(worker_reports),
            "market_delivery_target_per_second": m.load01_profile("U0").total_delivery_target_per_second,
            "total_received_event_count": sum(sum(r.get("received_by_stream", {}).values()) for r in worker_reports.values()),
            "per_strategy": {str(i): r for i,r in worker_reports.items()},
            "all_strategies_exactly_caught_up": strategy_exact,
            "all_strategy_gap_and_duplicate_counts_zero": all_zero_gaps,
            "all_runtime_close_facts_clean": runtime_clean,
            "normal_process_exitcodes_zero": process_clean,
            "market_host_normal_close_clean": host_clean,
            "host_instrumentation": host_instrumentation,
            "host_close_state": host_closed[2] if host_closed else None,
            "host_close_failures": host_closed[3] if host_closed else None,
            "host_process_exitcode": host.exitcode,
            "strategy_process_exitcodes": {str(i): workers[i]["proc"].exitcode for i in workers},
        }
        output = WORK / "market-component-probe-result.json"
        output.write_text(json.dumps(summary, sort_keys=True, indent=2, allow_nan=False), encoding="utf-8")
        print(json.dumps({"output":str(output),"summary":{k:v for k,v in summary.items() if k not in {"per_strategy","source_sequences","hub_watermarks"}}},sort_keys=True))
        if not (sequence_exact and strategy_exact and all_zero_gaps and process_clean and runtime_clean and host_clean):
            raise AssertionError("local component probe did not close or conserve exact market sequences")
    finally:
        if not host_closed and host.is_alive():
            stop_event.set(); abort_event.set(); run_event.set(); target_ready_event.set()
            with m.suppress(Exception): parent_host.send(("close",))
            if parent_host.poll(12):
                with m.suppress(Exception): host_closed = parent_host.recv()
            host.join(10)
        for item in workers.values():
            proc = item["proc"]
            if proc.is_alive():
                abort_event.set(); run_event.set(); target_ready_event.set()
                proc.join(10)
            item["conn"].close()
        parent_host.close(); parent_diag.close()
        if host.exitcode is None:
            host.join(2)

if __name__ == "__main__":
    main()

