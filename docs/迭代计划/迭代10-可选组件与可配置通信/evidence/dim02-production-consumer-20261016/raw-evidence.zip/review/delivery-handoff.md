# DIM02 Root delivery evidence handoff — 2026-10-16

## Formal ruling

**DIM02: formal PASS**, based on Round 176’s accepted increments, the independent DIM02 clause audit, the reviewed production-consumer node, and Root’s corrected r2 acceptance run. The formal clause is the DIM02 row in `docs/迭代计划/迭代10-可选组件与可配置通信/正式迭代计划.md`: same-contract multi-channel/timeframe, backfill-to-live, bar correction, sparse option chain, and group-leg time skew; evidence is the real subscription/projection path with deterministic data and no duplicate upstream or fabricated freshness. The acceptance summary’s PASS rule is that the case’s own evidence is complete; real-account, cross-machine and load conditions apply only when specified by that case. DIM02 does not require a real venue account.

Round 176 (`evidence/dim02-increments-20261016/root-adjudication.md`) accepted the multi-key/sparse-chain, historical-to-live seam/correction-policy, and leg-time-skew increments, but explicitly did not declare formal PASS. The independent clause audit at `.codex-tmp/resume-dim02-arb03-independent-20261016.md` initially held DIM02 on one remaining point: no evidence that a conflicting live bar traversed the actual SDK stream and was rejected by production `ServiceReadProxy`. The new Backtrader node covers that point. Reviewer `resume_pass_audit_reg_risk_cfg` returned incremental static GO, and Root r2 then passed the node. No requirement for a real account, real provider, cross-machine run, production chain aggregator, or full Cartesian matrix was added.

The Backtrader delivery record is `D:\source_code\backtrader\docs\iteration10-dim02-conflict-20261016.md`. It includes the full 25-path source pin table and the cleanup assertions. The new node is 13,111 bytes, SHA-256 `21eedae40e122c2977e4f3a01b563274f11f29291f6d32106e0d6d31d3e1f2b9`. Root accepted it at Backtrader `dev` HEAD `223d5b68a55bb167e2d310f9565b511093b01742`; the exact acceptance-delivery commit is to be read from Git history after Root’s scoped commit, not inferred here.

## Root r2 acceptance

The fixed output directory is `D:\temp\iteration10-dim02-conflict-root-20261016-r2`. Root’s `result.json` records pytest exit 0, one test, 834 fixed source pins unchanged, and all six repository HEADs unchanged. JUnit reports 1 passed in 13.436 seconds. Console output reports the one existing Quandl `DeprecationWarning`; stderr is empty. Evidence level: `REAL_SDK_HOST_STORE_FEED_LIVE_BAR_CONFLICT_REJECTION_LOCAL_SYNTHETIC`.

The r2 heads before and after are Backtrader `223d5b68a55bb167e2d310f9565b511093b01742`, SDK `e75ef358134df0069f2873625ff69313133c9a0c`, base `b4aabd1e17b9c7252fa7b4d266932087d99b5517`, execution `f5c030644dea06ce91afbaacf94e11e353538186`, transport-zmq `a397fdb460d2deb22e67ceb4963992ef63dbbb0e`, and gateway `59b164ab7f89c6428ae6546103aad6058dab4c16`. The full 25 fixed path pins appear in the Backtrader delivery record; Root’s `source-before.json` and `source-after.json` each contain the wider 834-source inventory and match exactly.

The test uses two spawned synthetic ServiceHosts, actual SDK runtime and account/market facades over CURVE/ZMQ, production `ServiceReadProxy`, `BtApiStore`, and `BtApiFeed`. A deterministic bar with the same open time as the last history bar and a different close reaches the live consumer. The expected `HISTORY_LIVE_CONFLICT` is raised; Feed lines/length and proxy history/emitted/pending projections remain unchanged, while the consumed stream sequence advances once. Passing cleanup checks require normal Feed/Store/facade shutdown, a closed SDK runtime with zero cleanup/unregister uncertainty, zero active market upstreams/registrations, one source start/stop, both Hosts closed and their processes joined with exit code zero. Forced cleanup or any cleanup failure fails the test.

## Preserved first attempt

Root r1 remains preserved at `D:\temp\iteration10-dim02-conflict-root-20261016-r1`. It failed before the first `feed.load()` because the fixture used `feed.start()` without Cerebro environment binding and the normal DataBase `_start()` lifecycle; `_tzinput` was therefore not initialized. This was a test-fixture lifecycle gap. It does not indicate a production conflict-path failure. R1 records 1 failed in 13.829 seconds, with unchanged source pins/HEADs and empty stderr. The corrected r2 run is the accepted evidence; neither r1 nor earlier accepted Round07B/R176 suites were rerun as delivery checks.

## Exact Root-output copy inventory

The original files currently remain at the two Root output paths above. This table is the exact byte-preserving copy manifest for later SDK evidence archiving; no raw output file was copied or rewritten in this documentation-only step. Destination folder names below are proposed archive locations. `pytest-tmp/` contents are intentionally excluded as transient basetemp state.

### r1 preserved failure — source `D:\temp\iteration10-dim02-conflict-root-20261016-r1`; proposed destination `.codex-tmp/iteration10-dim02-conflict-root-20261016-r1/`

| File | Bytes | SHA-256 |
|---|---:|---|
| `command.json` | 975 | `08c7ccd05400665eea49323abd836f172023c6d932572d109a298aeab5379aff` |
| `exit.txt` | 3 | `f1b2f662800122bed0ff255693df89c4487fbdcf453d3524a42d4ec20c3d9c04` |
| `junit.xml` | 12,548 | `690fa6cfd61ab488038fbb5c65d746711d02a6662630929810641bf8adf406e1` |
| `result.json` | 1,505 | `5a44a38ed477bd83ce71490d0dc29ef79ec39f8750412f7e2324ed2a15f936dd` |
| `runner.py` | 3,204 | `8b7f470be77270adeb9d72a83776b827c4653004b39835eeca0f43bf63cf24ed` |
| `running.json` | 76 | `a841b610902c488d6cc89cbe148e53949187cb1f3720ea6d6e7bc2370873bafa` |
| `source-after.json` | 120,317 | `7434e6920fdbab71b843d7e8f7ec6aaa37112a4189e0a4c930c8a78e2d047b0e` |
| `source-before.json` | 120,317 | `7434e6920fdbab71b843d7e8f7ec6aaa37112a4189e0a4c930c8a78e2d047b0e` |
| `spec.json` | 123,468 | `134ae2a9b37757973a98bb5e62043606c11d4c4253a4cc11d696475be6d87afe` |
| `stderr.log` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `stdout.log` | 13,829 | `fec3d1e81a1f131d3be2874ebb24b0409ebc0165af9cec0b39f3b7b483f89586` |

### r2 accepted run — source `D:\temp\iteration10-dim02-conflict-root-20261016-r2`; proposed destination `.codex-tmp/iteration10-dim02-conflict-root-20261016-r2/`

| File | Bytes | SHA-256 |
|---|---:|---|
| `command.json` | 975 | `27f27f85e652cb5e968ebcf94c338bfffe3084d33ea8c030de2d6fedfc99fd26` |
| `exit.txt` | 3 | `13bf7b3039c63bf5a50491fa3cfd8eb4e699d1ba1436315aef9cbe5711530354` |
| `junit.xml` | 323 | `38c5c0e01bc4c4fb97458c5feffc85ab429ef81c2a80ba0571dbce87c52210ba` |
| `result.json` | 1,505 | `72732730af611e36911164db9c161dd356798683914c28f0d6486ba18b26e44b` |
| `runner.py` | 3,204 | `8b7f470be77270adeb9d72a83776b827c4653004b39835eeca0f43bf63cf24ed` |
| `running.json` | 76 | `34508f36e7c3fe6d433b8379753a3c1ee1d7ad55f2ed15908d2faa7527407ae6` |
| `source-after.json` | 120,317 | `44c834e38924363dd530f543205c89f5382dd0fe2fdc692e5efc640a49eae34a` |
| `source-before.json` | 120,317 | `44c834e38924363dd530f543205c89f5382dd0fe2fdc692e5efc640a49eae34a` |
| `spec.json` | 123,468 | `2eb52a878610ac234718aba74ad445e799990b3f2b5629dc854ec4e187338b00` |
| `stderr.log` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `stdout.log` | 622 | `3581b373bf5904eb3fc0651d632c947a058c8cd6a44ec2b797b15663b4159b53` |

The matching SDK execution-spec files are preserved at `.codex-tmp/iteration10-dim02-conflict-exec-spec-r1.json` (123,468 bytes, SHA-256 `134ae2a9b37757973a98bb5e62043606c11d4c4253a4cc11d696475be6d87afe`) and `.codex-tmp/iteration10-dim02-conflict-exec-spec-r2.json` (123,468 bytes, SHA-256 `2eb52a878610ac234718aba74ad445e799990b3f2b5629dc854ec4e187338b00`). The r1 exec spec remains immutable. Planning-only `.codex-tmp/iteration10-dim02-conflict-root-spec-r2.json` is 10,692 bytes, SHA-256 `1d261623370da619c02e4826f293e603e7b0babcd6258cb4e453ea6cf434aab6`.

## Repository-state boundary

This handoff records the current DIM02 PASS and the exact evidence inventory. It does not edit `正式迭代计划.md`, `开发与验收进度.md`, or `迭代10验收状态汇总.md`; the existing tracker/progress wording is left for Root to reconcile after the scoped Backtrader commit. No test, production source, tracker, or historical result was modified; no QA/Host was run and no commit was created for this handoff.
