"""Prepare (but do not stage or commit) the CTP late-cancel SDK delivery."""
import hashlib
import io
import json
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

ROOT = Path("D:/bt_api_py")
META = ROOT / ".codex-tmp/ctp-late-cancel-root-20261018"
SDK_PARENT = "9d4efaf81afd6c70db751d97bf94a6b8a75fab44"
EXECUTION_PARENT = "a1ad9aab194e94bd80f790bb78f87fe048fcc4e4"
RUNNER_SHA256 = "8b7f470be77270adeb9d72a83776b827c4653004b39835eeca0f43bf63cf24ed"

RECORD = ROOT / "docs/ITERATION10_CTP_LATE_CANCEL_RECONCILIATION_20261018.md"
ARCHIVE = ROOT / "docs/evidence/iteration10-ctp-late-cancel-reconciliation-20261018/root-qa.zip"
TRACKERS = [
    ROOT / "docs/迭代计划/迭代10-可选组件与可配置通信/迭代10验收状态汇总.md",
    ROOT / "docs/迭代计划/迭代10-可选组件与可配置通信/开发与验收进度.md",
]

R1_SOURCES = {
    "bt_api/bt_api_execution/src/bt_api_execution/cancellation.py",
    "bt_api_py/ctp_managed_cancel_port.py",
    "bt_api_py/ctp_service_execution.py",
    "tests/unit/test_ctp_cancel_terminal_callback_readback.py",
}
R2_TEST_SOURCE = "tests/unit/test_managed_cancel_late_risk_reconciliation.py"
FINAL_SOURCES = R1_SOURCES | {R2_TEST_SOURCE}


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def _git(repo: Path, *args: str) -> str:
    return subprocess.check_output(["git", *args], cwd=repo).decode("utf-8").strip()


def _origin_pin_check(spec: dict, guard: dict, *, expected_count: int | None = None,
                      expected_origins: dict[str, str] | None = None) -> None:
    origins = guard["origins"]
    if expected_origins is not None:
        assert set(origins) == set(expected_origins), (set(origins), set(expected_origins))
        assert all(isinstance(path, str) and path for path in expected_origins.values())
        for name, expected_path in expected_origins.items():
            actual_path = Path(origins[name]).resolve()
            assert actual_path == Path(expected_path).resolve(), (name, actual_path, expected_path)
    if expected_count is not None:
        assert len(origins) == expected_count, (len(origins), expected_count)
    pins = {str(Path(path).resolve()).casefold(): value
            for path, value in spec["source_sha256"].items()}
    for name, origin in origins.items():
        path = Path(origin).resolve()
        assert str(path).casefold() in pins, (name, origin)
        assert _sha(path.read_bytes()) == pins[str(path).casefold()], name


def _round(number: int, selection: dict, spec: dict, expected_cases: int,
           *, expected_origin_count: int | None = None,
           expected_origins: dict[str, str] | None = None,
           require_ctp_source_fallback: bool = False,
           expected_exit: int = 0,
           expected_denied_events: list[str] | None = None,
           expect_all_failed: bool = False,
           require_empty_stderr: bool = True) -> dict:
    output = Path(spec["output"])
    result = _json(output / "result.json")
    guard = _json(output / "guard.json")
    junit_path = output / "junit.xml"
    tree = ET.parse(junit_path)
    cases = list(tree.iter("testcase"))
    failures = [case.get("name") for case in cases
                if any(case.find(tag) is not None for tag in ("failure", "error", "skipped"))]
    assert result["pytest_exit"] == expected_exit
    assert result["sources_unchanged"] and result["heads_unchanged"]
    assert result["source_count"] == len(spec["source_sha256"])
    assert result["heads_before"] == spec["repositories"]
    assert result["heads_after"] == spec["repositories"]
    assert len(cases) == expected_cases, (number, len(cases), expected_cases)
    if expect_all_failed:
        assert len(failures) == expected_cases, (number, failures)
        assert all(case.find("error") is None and case.find("skipped") is None for case in cases)
    else:
        assert not failures, (number, failures)
    expected_denied_events = expected_denied_events or []
    assert guard["denied_events"] == expected_denied_events
    if require_ctp_source_fallback:
        assert guard["ctp_source_fallback"] is True
    _origin_pin_check(
        spec, guard, expected_count=expected_origin_count,
        expected_origins=expected_origins,
    )
    stderr = output / "stderr.log"
    stdout = output / "stdout.log"
    if require_empty_stderr:
        assert not stderr.read_bytes()
    assert _sha(stdout.read_bytes()) == result["stdout_sha256"]
    assert _sha(stderr.read_bytes()) == result["stderr_sha256"]

    fixed_root = Path(spec["cwd"])
    candidates = {}
    for entry in selection["overlays"]:
        raw_path = fixed_root / entry["destination"]
        raw = raw_path.read_bytes()
        assert len(raw) == entry["size"]
        assert _sha(raw) == entry["sha256"]
        assert spec["source_sha256"][str(raw_path)] == entry["sha256"]
        candidates[entry["destination"]] = raw
    return {
        "round": number,
        "output": output,
        "result": result,
        "guard": guard,
        "junit": junit_path,
        "cases": cases,
        "failure_names": failures if expect_all_failed else [],
        "seconds": float(tree.getroot().find("testsuite").get("time")),
        "candidates": candidates,
    }


def _add(members: dict[str, bytes], name: str, raw: bytes) -> None:
    assert name not in members, name
    members[name] = raw


def main() -> None:
    baseline = _json(META / "baseline.json")
    selected_r1 = _json(META / "selected-r1.json")
    selected_r2 = _json(META / "selected-r2.json")
    selected_r3 = _json(META / "selected-r3.json")
    selected = _json(META / "selected.json")
    execution = _json(META / "execution-postcommit.json")
    r1_spec = _json(META / "qa-r1-spec.json")
    r2_spec = _json(META / "qa-r2-spec.json")
    r3_spec = _json(META / "qa-r3-spec.json")

    sdk = Path(baseline["sdk"]["repository"])
    execution_repo = Path(baseline["execution"]["repository"])
    assert baseline["sdk"]["head"] == SDK_PARENT
    assert baseline["execution"]["head"] == EXECUTION_PARENT
    assert _git(sdk, "rev-parse", "HEAD") == SDK_PARENT
    assert execution["parent"] == EXECUTION_PARENT
    child_commit = execution["commit"]
    assert _git(execution_repo, "rev-parse", "HEAD") == child_commit

    r1_sources = {item["source"] for item in selected_r1["overlays"]}
    r2_sources = {item["source"] for item in selected_r2["overlays"]}
    final_sources = {item["source"] for item in selected["overlays"]}
    assert r1_sources == R1_SOURCES, r1_sources
    assert r2_sources == {"bt_api/bt_api_execution/src/bt_api_execution/cancellation.py", R2_TEST_SOURCE}
    assert final_sources == FINAL_SOURCES, final_sources
    assert set(r1_spec["repositories"].values()) == set(baseline[key]["head"] for key in baseline)
    assert set(r2_spec["repositories"].values()) == set(baseline[key]["head"] for key in baseline)
    assert set(r3_spec["repositories"].values()) == set(baseline[key]["head"] for key in baseline)
    assert not RECORD.exists() and not ARCHIVE.exists()

    # R2 is preserved as a failed attempt. R3 reruns the same four generic
    # Risk/Execution cases with the corrected fixture and the same eight
    # logical origins; neither round requires the independent CTP fallback.
    assert r2_spec["nodes"] and r3_spec["nodes"]
    assert {node.split("::", 1)[0].replace("\\", "/") for node in r2_spec["nodes"]} == {
        R2_TEST_SOURCE
    }
    assert {node.split("::", 1)[0].replace("\\", "/") for node in r3_spec["nodes"]} == {
        R2_TEST_SOURCE
    }
    assert len(r2_spec["expected_origins"]) == 8
    assert len(r3_spec["expected_origins"]) == 8
    assert set(r2_spec["expected_origins"]) == set(r3_spec["expected_origins"])
    r1 = _round(
        1, selected_r1, r1_spec, 3,
        expected_origin_count=13, require_ctp_source_fallback=True,
    )
    r2_failed = _round(
        2, selected_r2, r2_spec, 4,
        expected_origins=r2_spec["expected_origins"],
        expected_exit=1, expected_denied_events=["provider_import"],
        expect_all_failed=True, require_empty_stderr=False,
    )
    r3 = _round(
        3, selected_r3, r3_spec, 4,
        expected_origins=r3_spec["expected_origins"],
    )
    assert sorted(case.get("name", "") for case in r2_failed["cases"]) == sorted(
        case.get("name", "") for case in r3["cases"]
    )

    final_source = {}
    for entry in selected["overlays"]:
        source = ROOT / entry["source"]
        raw = source.read_bytes()
        assert len(raw) == entry["size"] and _sha(raw) == entry["sha256"]
        if entry["source"].startswith("bt_api/bt_api_execution/"):
            git_path = entry["source"].removeprefix("bt_api/bt_api_execution/")
            committed = subprocess.check_output(
                ["git", "show", f"{child_commit}:{git_path}"], cwd=execution_repo
            )
            assert _sha(committed) == execution["committed_blob_sha256"][git_path]
            assert _sha(raw) == execution["payload_sha256"][git_path]
            assert committed == raw or (git_path == "src/bt_api_execution/cancellation.py" and committed == raw.replace(b"\r\n", b"\n"))
        final_source[entry["source"]] = raw

    runner = ROOT / ".codex-tmp/iteration10-focused-qa.py"
    runner_raw = runner.read_bytes()
    assert _sha(runner_raw) == RUNNER_SHA256

    r1_adjudication = {
        "result": "PASS_READBACK_ONLY_NO_RISK_RESOLUTION",
        "passed_cases": 3,
        "source_count": r1["result"]["source_count"],
        "origin_count": len(r1["guard"]["origins"]),
        "denied_events": [],
        "correction": "The original spec label was broader than this reader-only test; no Risk claim resolution was exercised.",
    }
    r2_adjudication = {
        "result": "FAILED_PRESERVED_ATTEMPT",
        "passed_cases": 0,
        "failed_cases": len(r2_failed["failure_names"]),
        "case_names": [case.get("name") for case in r2_failed["cases"]],
        "source_count": r2_failed["result"]["source_count"],
        "origin_count": len(r2_failed["guard"]["origins"]),
        "denied_events": r2_failed["guard"]["denied_events"],
        "reported_failure": "Root diagnosed the shared fixture actor mismatch; the raw JUnit is preserved. One provider_import denial is also recorded.",
    }
    r3_adjudication = {
        "result": "PASS_LOCAL_GTC_RISK_EXECUTION_LATE_CANCEL_RECONCILIATION",
        "passed_cases": 4,
        "case_names": [case.get("name") for case in r3["cases"]],
        "source_count": r3["result"]["source_count"],
        "origin_count": len(r3["guard"]["origins"]),
        "denied_events": [],
        "limitations": [
            "The normal GTC ExecutionFacade/RiskEntry/Gate/Journal path is exercised with synthetic feed and cancel observation leaves; it does not traverse the CTP callback/native chain.",
            "DAY-order CTP-to-Risk reconciliation remains a separate unimplemented business path.",
            "No real provider, account, ServiceHost composition, borrowed-session lifecycle, or cutover is accepted.",
            "No formal Iteration10 pass is added.",
        ],
    }
    adjudication = {
        "formal_iteration10_passes": 62,
        "formal_iteration10_total": 68,
        "formal_passes_added": 0,
        "accepted_component_checks": 7,
        "failed_attempt_cases_preserved": 4,
        "r1": r1_adjudication,
        "r2": r2_adjudication,
        "r3": r3_adjudication,
        "future_acceptance": "DAY-order CTP-to-Risk proof, borrowed-session service composition, lifecycle, account cutover, and real-provider acceptance remain pending.",
    }

    members: dict[str, bytes] = {}
    for name, round_data in (("r1", r1), ("r2-failed", r2_failed), ("r3", r3)):
        out = round_data["output"]
        for path in sorted(p for p in out.iterdir() if p.is_file()):
            _add(members, f"qa/{name}/raw/{path.relative_to(out).as_posix()}", path.read_bytes())
        for dest, raw in round_data["candidates"].items():
            _add(members, f"qa/{name}/candidate/{dest}", raw)

    metadata = [
        "baseline.json", "assembly-audit.json", "selected-r1.json", "selected-r2.json",
        "selected-r3.json", "qa-r1-spec.json", "qa-r2-spec.json", "qa-r3-spec.json",
        "export-recipe.json", "export-recipe-r2.json", "export-recipe-r3.json",
        "execution-postcommit.json", "prepare-qa.py", "prepare-qa-r2.py",
        "prepare-qa-r3.py", "ctp_callback_qa_checks.py", "cancel_replay_qa_checks.py",
        "r2-failure-r3-fixture-repair.json", "static-generic-risk-r3-review.json",
        "day-risk-integration-blocker.json", "user-account-use-confirmation.json",
    ]
    metadata = list(dict.fromkeys(metadata + sorted(path.name for path in META.glob("static-*.json"))))
    for name in metadata:
        _add(members, f"round/{name}", (META / name).read_bytes())
    _add(members, "round/root-adjudication.json",
         (json.dumps(adjudication, indent=2, ensure_ascii=False) + "\n").encode("utf-8"))
    _add(members, "round/deliver-sdk.py", Path(__file__).read_bytes())
    _add(members, "round/focused-qa-runner.py", runner_raw)
    for path, raw in final_source.items():
        _add(members, f"final-source/{path}", raw)
    final_manifest = {
        "execution_commit": child_commit,
        "execution_parent": EXECUTION_PARENT,
        "sdk_parent": SDK_PARENT,
        "sources": {path: {"size": len(raw), "sha256": _sha(raw)}
                    for path, raw in final_source.items()},
    }
    _add(members, "round/final-source-manifest.json",
         (json.dumps(final_manifest, indent=2, ensure_ascii=False) + "\n").encode("utf-8"))

    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, raw in sorted(members.items()):
            archive.writestr(name, raw)
    zip_raw = zip_buffer.getvalue()
    with zipfile.ZipFile(io.BytesIO(zip_raw)) as archive:
        assert set(archive.namelist()) == set(members)
        assert all(archive.read(name) == raw for name, raw in members.items())
    zip_sha = _sha(zip_raw)

    record_text = f"""# Iteration10 cancel readback and Risk reconciliation component checks

本轮聚焦的行为是：撤单先返回 ACK/UNKNOWN 等未决结果后，后续读取到原撤单的终态时，Risk claim 仅解析一次，系统不重新派发撤单；重复请求只读并返回已持久化结果。R3 的 4 个 GTC 用例通过了这条路径，feed 和撤单观察为合成输入。

R1 的 3 项检查单独验证生产 CTP 撤单回调读取器，只证明回调读回，不证明 Risk claim 已解锁。R2 的 4 项检查曾全部失败：Root 定位为共享 fixture actor mismatch，另记录 1 次 `provider_import` denial；原始结果和候选字节作为失败历史保留，不计通过。两轮分别覆盖不同组件行为。

R3 在 {r3['seconds']:.2f}s 内通过，校验 {r3['result']['source_count']} 个固定输入、8 个精确模块来源且无 denial。它走真实 ExecutionFacade、RiskEntry、RiskGate 和 RiskJournal 路径，但不经过 CTP 回调或 native CTP 链。R1 与 R3 合计 7 项本地组件检查，不增加正式通过数，正式状态保持 **62/68**。Execution 依赖提交为 `{child_commit}`，SDK 基线为 `{SDK_PARENT}`。

账户使用确认、DAY→Risk 缺口说明、R1/R2/R3 原始结果及候选、各轮固定源码 spec/recipe、Root adjudication 和最终源码均保存在 [root-qa.zip](evidence/iteration10-ctp-late-cancel-reconciliation-20261018/root-qa.zip)。压缩包 {len(zip_raw)} bytes，SHA-256 `{zip_sha}`，共 {len(members)} 个成员并逐字节校验。

DAY 合约从 CTP 到 Risk 的撤单证明仍是明确业务缺口；借用会话的服务组合与生命周期、账户切换及真实 provider 验收也未完成。用户确认可在指定后续测试中使用现有 SimNow 7×24 账户；该确认不证明历史上未使用、没有既有订单/持仓或 retained host 已终止。未重跑已接受 QA；正式通过数不变。
    """

    scoped = {
        "bt_api/bt_api_execution",
        "bt_api_py/ctp_managed_cancel_port.py",
        "bt_api_py/ctp_service_execution.py",
        "tests/unit/test_ctp_cancel_terminal_callback_readback.py",
        R2_TEST_SOURCE,
        RECORD.relative_to(ROOT).as_posix(), ARCHIVE.relative_to(ROOT).as_posix(),
        *(path.relative_to(ROOT).as_posix() for path in TRACKERS),
    }
    outside_args = ["git", "diff", "--binary", "--", "."] + [
        ":(exclude)" + path for path in sorted(scoped)
    ]
    outside_before = subprocess.check_output(outside_args, cwd=ROOT, stderr=subprocess.PIPE)
    index_before = _git(ROOT, "diff", "--cached", "--binary").encode("utf-8")
    assert not index_before
    tracker_prefixes = {path: path.read_bytes() for path in TRACKERS}
    for path in TRACKERS:
        assert path.read_bytes() == tracker_prefixes[path]

    (META / "sdk-unrelated-before.bin").write_bytes(outside_before)
    ARCHIVE.parent.mkdir(parents=True, exist_ok=True)
    with ARCHIVE.open("xb") as stream:
        stream.write(zip_raw)
    with RECORD.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(record_text)
    tracker_suffix = (
        "\n\n## 2026-10-18：CTP 延迟撤单 Risk 对账\n\n"
        f"本地固定源码验收：R1 {len(r1['cases'])} 项为 CTP 回调读回；R2 {len(r2_failed['cases'])} 项失败并保留历史；"
        f"R3 {len(r3['cases'])} 项为独立 normal GTC Risk/Execution 撤单对账。R1+R3 共 7 项组件检查，"
        f"不构成完整 CTP→Risk/DAY 链路；SDK 父提交 `{SDK_PARENT}`，"
        f"Execution 源提交 `{child_commit}`。证据为本地 synthetic 组件检查，未增加正式通过数；"
        f"DAY→Risk 仍待实现，状态仍为 **62/68**。证据包 SHA-256 `{zip_sha}`。\n"
    ).encode("utf-8")
    for path, prefix in tracker_prefixes.items():
        path.write_bytes(prefix + tracker_suffix)

    assert outside_before == subprocess.check_output(outside_args, cwd=ROOT, stderr=subprocess.PIPE)
    assert index_before == _git(ROOT, "diff", "--cached", "--binary").encode("utf-8")
    assert all(path.read_bytes().startswith(prefix) for path, prefix in tracker_prefixes.items())
    with zipfile.ZipFile(ARCHIVE) as archive:
        assert _sha(ARCHIVE.read_bytes()) == zip_sha
        assert all(archive.read(name) == raw for name, raw in members.items())
    prefixes = {path.relative_to(ROOT).as_posix(): {"size": len(raw), "sha256": _sha(raw)} for path, raw in tracker_prefixes.items()}
    for name, value in [("sdk-doc-prefixes.json", prefixes), ("sdk-delivery-paths.json", sorted(scoped)), ("root-adjudication.json", adjudication)]:
        (META / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"archive_bytes": len(zip_raw), "archive_sha256": zip_sha,
                      "members": len(members), "formal_passes": 62,
                      "changed_paths": sorted(scoped)}, indent=2))


if __name__ == "__main__":
    main()
