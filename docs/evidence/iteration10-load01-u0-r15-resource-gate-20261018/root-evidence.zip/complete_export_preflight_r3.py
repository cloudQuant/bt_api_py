from __future__ import annotations

import hashlib
import importlib
import importlib.util
import json
import os
import subprocess
import sys
import zipfile
from datetime import UTC, datetime
from pathlib import Path, PurePosixPath


REPOSITORY = Path(r"D:\bt_api_py")
SPEC_PATH = REPOSITORY / ".codex-tmp/load01-u0-r15-20261018/prepared-spec.json"
EXPECTED_PARENT = "1bfb517ebb115858683dafce39c3225cd068fcfa"
EXPECTED_PACKAGE_GITLINKS = {'bt_api/bt_api_base': 'fb47f3dd733613494aa1d86cfd94b2d6fe70314d', 'bt_api/bt_api_execution': '456eb3ce9a49fa8924a6f908d1a4e336e7120ce8', 'bt_api/bt_api_gateway': '12e8de6f9552f7974a450f3217d497fb9c89e33d', 'bt_api/bt_api_monitor': '02ee0c42a1e63a9cecbb666376e70c6f72b0d6e8', 'bt_api/bt_api_risk': 'b6e4a7bce74a5ae5dee4c8f514a9d95fd68073d9', 'bt_api/bt_api_transport_zmq': 'acd74ba03494615aeb2d60423ac853e06029cba7'}
EXPECTED_RUNNER_BASE_SHA256 = "4739d9ac8f5bf9e65961ec44dfce75b46d3301a7e76a9d4844b34f861d0c5fad"
EXPECTED_RUNNER_OVERLAY_SHA256 = "6a91654af3a6c05d2702bf728f6a037b81ff53f1308ea24113904868097c4bdb"
EXPECTED_PROVENANCE_PAIRS = [['43415645a84f2c5b88333a0292a02aa68777cf13', '1bfb517ebb115858683dafce39c3225cd068fcfa'], ['fb47f3dd733613494aa1d86cfd94b2d6fe70314d', 'fb47f3dd733613494aa1d86cfd94b2d6fe70314d'], ['456eb3ce9a49fa8924a6f908d1a4e336e7120ce8', '456eb3ce9a49fa8924a6f908d1a4e336e7120ce8'], ['12e8de6f9552f7974a450f3217d497fb9c89e33d', '12e8de6f9552f7974a450f3217d497fb9c89e33d'], ['02ee0c42a1e63a9cecbb666376e70c6f72b0d6e8', '02ee0c42a1e63a9cecbb666376e70c6f72b0d6e8'], ['b6e4a7bce74a5ae5dee4c8f514a9d95fd68073d9', 'b6e4a7bce74a5ae5dee4c8f514a9d95fd68073d9'], ['acd74ba03494615aeb2d60423ac853e06029cba7', 'acd74ba03494615aeb2d60423ac853e06029cba7']]
EXPORT_ROOT = Path(r"D:\temp\l01u0r15")
SOURCE_ROOT = EXPORT_ROOT / "source-fixed"
RUNNER_RELATIVE = Path("tests/unit/test_load01_hundred_strategy_30min.py")
HELPER_RELATIVE = Path("tests/unit/_load01_resource_diagnostics.py")
OUTPUT_ROOT = Path(r"D:\temp\l01u0r15qa")
PYCACHE_ROOT = Path(r"D:\temp\l01u0r15qa\pycache")
EXPECTED_SOURCE_BINDING_COUNT = 47
EXPECTED_PIN_COUNT = 49
EXPECTED_PACKAGE_COUNT = 6
EXPECTED_PROFILE_ID = "U0"


def git(*args: str, cwd: Path = REPOSITORY) -> bytes:
    return subprocess.run(
        ["git", *args], cwd=cwd, capture_output=True, check=True
    ).stdout


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def archive_commit(cwd: Path, commit: str, destination: Path, target_root: Path) -> dict:
    # Resume only the completed original export; never regenerate or extract it.
    if sha256_file(destination) != EXISTING_PINS[str(destination)]:
        raise RuntimeError("completed export archive changed")
    with zipfile.ZipFile(destination) as archive:
        if archive.comment.decode("ascii") != commit or archive.testzip() is not None:
            raise RuntimeError("completed Git archive commit or CRC mismatch")
        members = archive.infolist()
    return {"sha256": sha256_file(destination), "bytes": destination.stat().st_size,
            "members": len(members), "files": sum(not item.is_dir() for item in members)}


def committed_bytes(path: str, parent: str, package_gitlinks: dict[str, str]) -> bytes:
    parts = path.split("/")
    package = "/".join(parts[:2]) if len(parts) > 2 and parts[0] == "bt_api" else None
    if package:
        commit = package_gitlinks[package]
        relative = "/".join(parts[2:])
        return git("-C", package, "cat-file", "blob", f"{commit}:{relative}")
    return git("cat-file", "blob", f"{parent}:{path}")


EXISTING_PINS = {'D:\\temp\\l01u0r15\\bt_api_base.zip': '012f77d5c27f84d7a5639baca8abeaf12ee2792dd312dbe4e116f9cc7d13382e', 'D:\\temp\\l01u0r15\\bt_api_execution.zip': '799ea766d9ba695532b3fa42d73cfee060eef01362f3b1f5956b64bea3675ac2', 'D:\\temp\\l01u0r15\\bt_api_gateway.zip': '392fa48f6dcb631c00b46999add6b2d5d6b93688b8188d53bd739d5cb1343c17', 'D:\\temp\\l01u0r15\\bt_api_monitor.zip': 'f305273f8cdaf53200867e07569338fc5c3cfacb09de79a44e7f3dbdd9d76d0d', 'D:\\temp\\l01u0r15\\bt_api_risk.zip': 'fd65341831d9866c8e53b0b0dec635d40c9705ce6d947d27dcd7ba4d920d5c98', 'D:\\temp\\l01u0r15\\bt_api_transport_zmq.zip': '13e70cef513825054ac1c37dfdc286b51ce9d6ba62f879086d94a745f96f7109', 'D:\\temp\\l01u0r15\\parent.zip': '173909e311c630f13c4cf8dd80c3fdd9a75c1dd51e4d1db0f180e124f4b49eb8', 'D:\\temp\\l01u0r15\\source-export-pins.json': 'bb1eef796142cc19af474eda0791f2df8a812e20dc068d3ec1c8ced142dd22a3', 'D:\\temp\\l01u0r15\\preflight-manifest-work\\fixed-source-run-manifest.json': '819ca50a3067ac5fd4044742dc0598d081eb25202449eb8518e454f869d95ca0'}
for _path, _sha in EXISTING_PINS.items():
    if sha256_file(Path(_path)) != _sha:
        raise RuntimeError("existing completed export input changed")
if (EXPORT_ROOT / "preflight.json").exists():
    raise RuntimeError("preflight completion already consumed")
spec = json.loads(SPEC_PATH.read_text(encoding="utf-8"))
spec["source_contract"]["runtime_bindings"]["load01_threshold_registration"]["status"] = "ROOT_PROPOSED_ENGINEERING_CONTRACT_NOT_USER_SLA"
smoke = spec.get("u0_smoke_acceptance", {})
if (smoke.get("status") != "ROOT_ACCEPTED" or smoke.get("accepted_commit") != EXPECTED_PARENT
        or not isinstance(smoke.get("qa_result_sha256"), str)
        or len(smoke["qa_result_sha256"]) != 64
        or any(ch not in "0123456789abcdef" for ch in smoke["qa_result_sha256"])):
    raise RuntimeError("Root-accepted U0 smoke result and exact accepted commit are required before export")
current = spec["current_source"]
parent = git("rev-parse", "HEAD").decode("ascii").strip()
if parent != EXPECTED_PARENT or current.get("parent_commit") != parent:
    raise RuntimeError(f"Root HEAD/source spec changed during preparation: {parent}")
if git("cat-file", "-t", parent).decode("ascii").strip() != "commit":
    raise RuntimeError("current parent Git object is unavailable")
if not EXPORT_ROOT.is_dir() or not SOURCE_ROOT.is_dir() or OUTPUT_ROOT.exists() or PYCACHE_ROOT.exists():
    raise FileExistsError("refusing to overwrite an existing R15 export/output/pycache")

package_gitlinks = dict(current["package_gitlinks"])
if package_gitlinks != EXPECTED_PACKAGE_GITLINKS:
    raise RuntimeError("prepared package gitlinks differ from isolated R15 pins")
if len(package_gitlinks) != EXPECTED_PACKAGE_COUNT:
    raise RuntimeError(f"expected six package gitlinks, got {len(package_gitlinks)}")
for package, expected in package_gitlinks.items():
    fields = git("ls-tree", parent, package).decode("utf-8").strip().split()
    if len(fields) != 4 or fields[2] != expected or fields[3] != package:
        raise RuntimeError(f"current parent gitlink mismatch: {package}: {fields}")
    if git("-C", package, "cat-file", "-t", expected).decode("ascii").strip() != "commit":
        raise RuntimeError(f"package commit object is unavailable: {package}@{expected}")

file_pins = current["committed_file_sha256"]
expected_pin_paths = spec["source_contract"]["committed_pin_paths"]
if set(file_pins) != set(expected_pin_paths):
    raise RuntimeError("committed source pin path set differs from exact U0 source contract")
if len(file_pins) != EXPECTED_PIN_COUNT:
    raise RuntimeError(f"expected {EXPECTED_PIN_COUNT} committed source pins, got {len(file_pins)}")
pin_mismatches = []
for path, expected in file_pins.items():
    actual = sha256_bytes(committed_bytes(path, parent, package_gitlinks))
    if actual != expected:
        pin_mismatches.append({"path": path, "expected": expected, "actual": actual})
if pin_mismatches:
    raise RuntimeError(f"committed source pins mismatch: {pin_mismatches}")


ARCHIVE_CHECKOUT_EXCEPTIONS = {'bt_api/bt_api_monitor/src/bt_api_monitor/durable.py': {'committed_sha256': 'e1ca5c24a98fb85b6b6f6a78a6c38127a62c8655d0db12d6c63dbf581b178ba4', 'export_sha256': '8ea958088904948b2601af2ecf3417925df3a0132cdb0c9a88aeb21ae34de286', 'transformation': 'LF_TO_CRLF'}}
for _relative, _row in ARCHIVE_CHECKOUT_EXCEPTIONS.items():
    _committed = committed_bytes(_relative, parent, package_gitlinks)
    _exported = (SOURCE_ROOT / _relative).read_bytes()
    if (sha256_bytes(_committed) != _row["committed_sha256"]
        or sha256_bytes(_exported) != _row["export_sha256"]
        or b"\r\n" in _committed
        or _committed.replace(b"\n", b"\r\n") != _exported):
        raise RuntimeError("exact committed-to-archive newline exception changed")
spec["source_contract"]["archive_checkout_exceptions"] = ARCHIVE_CHECKOUT_EXCEPTIONS
spec["source_contract"]["runtime_bindings"]["bt_api_monitor.durable"]["sha256"] = ARCHIVE_CHECKOUT_EXCEPTIONS["bt_api/bt_api_monitor/src/bt_api_monitor/durable.py"]["export_sha256"]

overlay = current["runner_provenance_overlay"]
runner_base = git("cat-file", "blob", f"{parent}:{RUNNER_RELATIVE.as_posix()}")
runner_base_sha = sha256_bytes(runner_base)
if runner_base_sha != overlay["base_raw_sha256"] or runner_base_sha != EXPECTED_RUNNER_BASE_SHA256:
    raise RuntimeError(f"committed runner base mismatch: {runner_base_sha}")
pairs = [list(pair) for pair in overlay["exact_pairs"]]
if pairs != EXPECTED_PROVENANCE_PAIRS or len(pairs) != 7:
    raise RuntimeError("prepared provenance pairs differ from isolated R15 pins")
if pairs[0][1] != parent:
    raise RuntimeError("runner provenance parent target differs from the exact R15 parent")
if [new for _old, new in pairs[1:]] != list(package_gitlinks.values()):
    raise RuntimeError("runner package provenance targets differ from exact gitlinks")
runner_candidate = runner_base
replacement_counts = []
for old, new in pairs:
    old_bytes = old.encode("ascii")
    count = runner_candidate.count(old_bytes)
    if count != 1:
        raise RuntimeError(f"provenance source value must occur exactly once: {old} count={count}")
    runner_candidate = runner_candidate.replace(old_bytes, new.encode("ascii"), 1)
    replacement_counts.append(count)
runner_sha = sha256_bytes(runner_candidate)
if runner_sha != EXPECTED_RUNNER_OVERLAY_SHA256 or runner_sha != overlay["candidate_raw_sha256"]:
    raise RuntimeError("provenance-only runner overlay differs from isolated R15 pin")
if len(runner_candidate) != overlay["candidate_bytes"]:
    raise RuntimeError("provenance-only runner overlay changed byte count")

# Only now update the R15 document to bind the newly verified current HEAD.
current["parent_commit"] = parent
overlay["exact_pairs"] = pairs
overlay["candidate_raw_sha256"] = runner_sha
overlay["candidate_bytes"] = len(runner_candidate)
overlay["status"] = "MATERIALIZED_FROM_COMMITTED_RUNNER_BYTES"
overlay["allowed_overlay"][RUNNER_RELATIVE.as_posix()] = runner_sha
spec["formal_status"]["iteration10_passes"] = "62/68"
spec["execution"]["working_directory"] = str(SOURCE_ROOT)
spec["execution"]["output_root"] = str(OUTPUT_ROOT)
spec["execution"]["pilot_output"] = str(OUTPUT_ROOT / "load01-pilot-result.json")
spec["execution"]["full_output"] = str(OUTPUT_ROOT / "load01-full-result.json")
spec["execution"]["pycache_prefix_by_stage"] = {
    "pilot": str(PYCACHE_ROOT / "pilot"),
    "full": str(PYCACHE_ROOT / "full"),
}
spec["execution"]["environment"]["PYTHONPYCACHEPREFIX"] = str(PYCACHE_ROOT / "{stage}")
spec["execution"]["environment"]["BT_API_LOAD01_RUNNER_OVERLAY_SHA256"] = runner_sha
source_paths = [
    SOURCE_ROOT / "bt_api" / package / "src"
    for package in (
        "bt_api_base",
        "bt_api_execution",
        "bt_api_gateway",
        "bt_api_monitor",
        "bt_api_risk",
        "bt_api_transport_zmq",
    )
]
spec["execution"]["environment"]["PYTHONPATH"] = ";".join(map(str, source_paths))
spec["resource_gate"]["reported_available_bytes"] = None
spec["resource_gate"]["reported_available"] = None
spec["resource_gate"]["status"] = "WAITING_FOR_FRESH_ROOT_LAUNCH_GATE"
spec["execution_blockers"] = [
    "Root must accept the U0 smoke result and its scoped dev commit; rebind this R15 source contract to that exact accepted descendant before export if HEAD changes.",
    "Freshly require three available-physical-memory samples, five seconds apart, each >= 10,603,200,512 bytes immediately before the 112-child 120-second pilot.",
    "Recheck the same memory gate before any separate 1,800-second full run.",
    "A passing pilot, Root review, and all existing acceptance checks remain prerequisites for a full run.",
]
spec["status"] = "SOURCE_EXPORT_PREFLIGHT_PASS_WAITING_FOR_FRESH_MEMORY_GATE"

assert EXPORT_ROOT.is_dir() and SOURCE_ROOT.is_dir()
archive_rows = []
parent_zip = EXPORT_ROOT / "parent.zip"
parent_archive = archive_commit(REPOSITORY, parent, parent_zip, SOURCE_ROOT)
with zipfile.ZipFile(parent_zip) as archive:
    try:
        archived_helper = archive.read(HELPER_RELATIVE.as_posix())
    except KeyError:
        raise RuntimeError("R15 resource helper is absent from parent.zip") from None
if sha256_bytes(archived_helper) != file_pins[HELPER_RELATIVE.as_posix()]:
    raise RuntimeError("R15 resource helper parent.zip member differs from its source pin")
archive_rows.append(
    {
        "name": "parent.zip",
        "frozen_source_path": ".",
        "commit": parent,
        **parent_archive,
    }
)
package_rows = []
for package, commit in package_gitlinks.items():
    package_root = REPOSITORY / package
    target_root = SOURCE_ROOT / package
    assert target_root.is_dir()
    archive_path = EXPORT_ROOT / f"{Path(package).name}.zip"
    archive = archive_commit(package_root, commit, archive_path, target_root)
    row = {
        "path": package,
        "commit": commit,
        "archive_sha256": archive["sha256"],
        "archive_bytes": archive["bytes"],
        "archive_member_count": archive["members"],
    }
    package_rows.append(row)
    archive_rows.append({"name": archive_path.name, "frozen_source_path": package, **archive})

runner_target = SOURCE_ROOT / RUNNER_RELATIVE
assert runner_target.read_bytes() == runner_candidate
if sha256_file(runner_target) != runner_sha:
    raise RuntimeError("materialized provenance overlay did not match its new digest")

# Compare every archived Python member with extracted committed bytes. The one
# intentional difference is the seven-constant provenance-only runner overlay.
extract_missing = []
extract_mismatches = []
python_members_checked = 0
for row in archive_rows:
    archive_path = EXPORT_ROOT / row["name"]
    target_root = SOURCE_ROOT / row["frozen_source_path"] if row["frozen_source_path"] != "." else SOURCE_ROOT
    with zipfile.ZipFile(archive_path) as archive:
        for member in archive.infolist():
            if member.is_dir() or not member.filename.endswith(".py"):
                continue
            python_members_checked += 1
            extracted = target_root / Path(member.filename)
            if not extracted.is_file():
                extract_missing.append({"archive": row["name"], "member": member.filename})
                continue
            archived_sha = sha256_bytes(archive.read(member))
            if sha256_file(extracted) != archived_sha:
                extract_mismatches.append({"archive": row["name"], "member": member.filename})
if extract_missing:
    raise RuntimeError(f"archived Python members are missing after extraction: {extract_missing}")
expected_delta = [{"archive": "parent.zip", "member": RUNNER_RELATIVE.as_posix()}]
if extract_mismatches != expected_delta:
    raise RuntimeError(f"unexpected extracted-vs-archive differences: {extract_mismatches}")

pins = {
    "schema_version": 1,
    "artifact_id": "iteration10-load01-r15-current-dev-20261018",
    "parent_commit": parent,
    "source_checkout_head": parent,
    "source_checkout_head_note": "All archive content came from committed Git objects; dirty worktree bytes were excluded.",
    "parent_archive_sha256": parent_archive["sha256"],
    "parent_archive_bytes": parent_archive["bytes"],
    "parent_archive_member_count": parent_archive["members"],
    "package_gitlinks": package_rows,
    "runner_path": RUNNER_RELATIVE.as_posix(),
    "runner_sha256": runner_sha,
    "runner_bytes": len(runner_candidate),
    "resource_helper_path": HELPER_RELATIVE.as_posix(),
    "resource_helper_sha256": file_pins[HELPER_RELATIVE.as_posix()],
    "working_tree_sources_used": False,
    "source_materialization": {
        "parent_and_package_archives_from_git_objects": True,
        "extracted_root": str(SOURCE_ROOT),
        "python_archive_members_checked": python_members_checked,
        "extracted_python_member_mismatches": extract_mismatches,
        "sole_expected_overlay": expected_delta,
    },
    "runner_overlay_provenance": {
        "base_parent_commit": parent,
        "base_raw_sha256": runner_base_sha,
        "candidate_raw_sha256": runner_sha,
        "candidate_bytes": len(runner_candidate),
        "exact_replacement_count": len(pairs),
        "replacement_occurrences": replacement_counts,
        "exact_pairs": pairs,
        "scope": "Seven fixed parent/gitlink provenance constants only; workload and assertions are unchanged.",
        "committed": False,
    },
}
pins_path = EXPORT_ROOT / "source-export-pins.json"
assert json.loads(pins_path.read_text(encoding="utf-8")) == pins

# Lightweight no-Host preflight through the exact pinned runner helpers. This
# imports source modules and checks archive/manifest bindings; it does not call
# pytest, a load test, multiprocessing spawn, Host, provider, or account APIs.
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
sys.dont_write_bytecode = True
sys.path[:0] = [str(SOURCE_ROOT), *(str(path) for path in source_paths)]
os.environ["BT_API_LOAD01_SOURCE_ROOT"] = str(SOURCE_ROOT)
os.environ["BT_API_LOAD01_EXPORT_PINS"] = str(pins_path)
os.environ["BT_API_LOAD01_RUNNER_OVERLAY_SHA256"] = runner_sha
runner = importlib.import_module("tests.unit.test_load01_hundred_strategy_30min")
if Path(runner.__file__).resolve() != runner_target.resolve():
    raise RuntimeError(f"runner import escaped the fixed export: {runner.__file__}")
overlay_map = {RUNNER_RELATIVE.as_posix(): runner_sha}
archive_check = runner._verify_fixed_archives(SOURCE_ROOT, pins_path, allowed_overlays=overlay_map)
manifest_work = EXPORT_ROOT / "preflight-manifest-work"
assert manifest_work.is_dir()
manifest_path = manifest_work / "fixed-source-run-manifest.json"
assert sha256_file(manifest_path) == EXISTING_PINS[str(manifest_path)]
source_bindings = runner._check_fixed_source_manifest(manifest_path)
if len(source_bindings) != EXPECTED_SOURCE_BINDING_COUNT:
    raise RuntimeError(f"expected {EXPECTED_SOURCE_BINDING_COUNT} fixed source bindings, got {len(source_bindings)}")
manifest_document = json.loads(Path(manifest_path).read_text(encoding="utf-8"))
helper_sha = file_pins[HELPER_RELATIVE.as_posix()]
helper_binding = source_bindings.get("tests.unit._load01_resource_diagnostics")
if helper_binding != {"path": HELPER_RELATIVE.as_posix(), "sha256": helper_sha}:
    raise RuntimeError("R15 resource helper did not pass runtime source-manifest validation")
if manifest_document["files"].get(HELPER_RELATIVE.as_posix()) != helper_sha:
    raise RuntimeError("R15 resource helper is absent from the fixed-source manifest")
expected_bindings = {name: dict(record) for name, record in spec["source_contract"]["runtime_bindings"].items()}
expected_bindings["load_runner"]["sha256"] = runner_sha
if source_bindings != expected_bindings:
    raise RuntimeError("fixed-source runtime bindings differ from exact U0 contract")
manifest_files = manifest_document["files"]
for path, expected in file_pins.items():
    expected_overlay = runner_sha if path == RUNNER_RELATIVE.as_posix() else expected
    if path in ARCHIVE_CHECKOUT_EXCEPTIONS:
        expected_overlay = ARCHIVE_CHECKOUT_EXCEPTIONS[path]["export_sha256"]
    if manifest_files.get(path) != expected_overlay:
        raise RuntimeError(f"fixed-source manifest does not bind committed source pin: {path}")
for name, record in source_bindings.items():
    path = (SOURCE_ROOT / record["path"]).resolve()
    if not path.is_relative_to(SOURCE_ROOT.resolve()):
        raise RuntimeError(f"source binding escaped fixed export: {name} -> {path}")
spec["source_contract"]["status"] = "RUNTIME_SOURCE_PREFLIGHT_VERIFIED"

required_memory = 112 * 72 * 1024**2 + 2 * 1024**3
pytest_available = importlib.util.find_spec("pytest") is not None
preflight = {
    "status": "SOURCE_EXPORT_PREFLIGHT_PASS_WAITING_FOR_FRESH_MEMORY_GATE",
    "created_at_utc": datetime.now(UTC).isoformat(timespec="seconds"),
    "formal_load_started": False,
    "pilot_started": False,
    "full_started": False,
    "host_started": False,
    "provider_or_account_api_called": False,
    "pytest_collected_or_run": False,
    "root_head": parent,
    "verified_committed_file_pin_count": len(file_pins),
    "verified_package_gitlink_count": len(package_gitlinks),
    "archive_count": len(archive_rows),
    "archive_rows": archive_rows,
    "archive_python_members_checked": python_members_checked,
    "archive_extraction_missing": extract_missing,
    "archive_extraction_mismatches": extract_mismatches,
    "runner_base_sha256": runner_base_sha,
    "runner_overlay_sha256": runner_sha,
    "resource_helper_path": HELPER_RELATIVE.as_posix(),
    "resource_helper_sha256": helper_sha,
    "resource_helper_parent_zip_member_verified": True,
    "resource_helper_runtime_manifest_binding_verified": True,
    "runner_overlay_bytes": len(runner_candidate),
    "runner_overlay_replacements": pairs,
    "runner_archive_validation": archive_check,
    "source_manifest_path": str(manifest_path),
    "source_manifest_sha256": sha256_file(Path(manifest_path)),
    "fixed_source_binding_count": len(source_bindings),
    "pytest_import_available": pytest_available,
    "profile_id": EXPECTED_PROFILE_ID,
    "fixed_source_bindings": source_bindings,
    "archive_checkout_exceptions": ARCHIVE_CHECKOUT_EXCEPTIONS,
    "memory_gate": {
        "available_bytes_at_preflight": None,
        "minimum_available_bytes": required_memory,
        "passed": None,
        "status": "DEFERRED_TO_FRESH_ROOT_LAUNCH_GATE",
        "available_memory_read_performed": False,
        "fresh_samples_required": 3,
        "sample_interval_seconds": 5,
        "runtime_reserve_bytes": 2 * 1024**3,
    },
}
preflight_path = EXPORT_ROOT / "preflight.json"
preflight_path.write_text(json.dumps(preflight, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")

current["export"]["status"] = "MATERIALIZED_AND_NOHOST_PREFLIGHTED"
current["export"]["parent_archive_sha256"] = parent_archive["sha256"]
current["export"]["archive_hashes"] = {
    row["name"]: {key: row[key] for key in ("sha256", "bytes", "members")}
    for row in archive_rows
}
current["export"]["source_export_pins_sha256"] = sha256_file(pins_path)
current["export"]["preflight_sha256"] = sha256_file(preflight_path)
current["runner_provenance_overlay"]["candidate_raw_sha256"] = runner_sha
current["runner_provenance_overlay"]["status"] = "MATERIALIZED_AND_VERIFIED_FROM_COMMITTED_BASE"
current["runner_provenance_overlay"]["allowed_overlay"][RUNNER_RELATIVE.as_posix()] = runner_sha
spec["resource_gate"]["reported_available_bytes"] = None
spec["resource_gate"]["reported_available"] = None
spec["resource_gate"]["status"] = "WAITING_FOR_FRESH_ROOT_LAUNCH_GATE"
spec["execution_blockers"] = [
    "Root must accept the U0 smoke result and its scoped dev commit; rebind this R15 source contract to that exact accepted descendant before export if HEAD changes.",
    f"Freshly require three available-physical-memory samples, five seconds apart, each >= {required_memory} bytes immediately before the 112-child 120-second pilot.",
    "Recheck the same memory gate before any separate 1,800-second full run.",
    "A passing pilot, Root review, and all existing acceptance checks remain prerequisites for a full run.",
]
spec["status"] = "SOURCE_EXPORT_PREFLIGHT_PASS_WAITING_FOR_FRESH_MEMORY_GATE"
SPEC_PATH.write_text(json.dumps(spec, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

print(json.dumps({
    "status": preflight["status"],
    "export_root": str(EXPORT_ROOT),
    "pins_path": str(pins_path),
    "pins_sha256": sha256_file(pins_path),
    "preflight_path": str(preflight_path),
    "preflight_sha256": sha256_file(preflight_path),
    "parent_archive_sha256": parent_archive["sha256"],
    "package_archive_hashes": {row["name"]: row["sha256"] for row in archive_rows[1:]},
    "runner_overlay_sha256": runner_sha,
    "runner_overlay_bytes": len(runner_candidate),
    "archive_python_members_checked": python_members_checked,
    "source_bindings": len(source_bindings),
    "pytest_import_available": pytest_available,
    "memory_gate": preflight["memory_gate"],
}, ensure_ascii=False, sort_keys=True, indent=2))
