# LOAD01 r5-resume pilot preparation

Status: PREPARED / NOT LAUNCHED. This record covers a fixed-source candidate pilot export and spec only. No pytest collection, QA suite, Host, pilot, full run, or load operation was run.

## Frozen archive and source provenance

- Parent source commit: `e08da3c58cb3b3b040f7799642de38523bbd3229`.
- Current SDK checkout HEAD at export time: `e75ef358134df0069f2873625ff69313133c9a0c`, a docs-only descendant; these later docs are not archived.
- The seven archives are generated from the pinned parent commit and its six exact gitlinks. `archive_sources_from_worktree=false`; the only worktree-derived runtime member is the explicitly overlaid public runner. All archives are public source; no Git worktree is exported.
- Six gitlinks: `bt_api/bt_api_base` `b4aabd1e17b9c7252fa7b4d266932087d99b5517`; `bt_api/bt_api_execution` `f5c030644dea06ce91afbaacf94e11e353538186`; `bt_api/bt_api_gateway` `59b164ab7f89c6428ae6546103aad6058dab4c16`; `bt_api/bt_api_monitor` `536a4f04747182749fabdac5e28624f80465bc53`; `bt_api/bt_api_risk` `adb6ec58308149faa93c02920b72f98ac3796056`; `bt_api/bt_api_transport_zmq` `a397fdb460d2deb22e67ceb4963992ef63dbbb0e`.
- Accepted production service-runtime retry fix `336203d2` is included through frozen `e08da3c5`; its previously accepted QA was not repeated.

## Runner overlay

- Candidate worktree runner raw SHA-256: `489ff6a97d01ebeacca3c0b2022151c7c54805679ed85651b8773656d67d59af`; explicitly `candidate_source_commit_derived=false`.
- Candidate delta against the e08da3c5 committed runner: exactly 4 insertions, 0 deletions. Patch `09-runner-candidate-four-line.patch`: 948 bytes, SHA-256 `63c1b687c3504e1bcd31c91529760eb0b5516754b7a84617060d50ef6fb1d7be`.
- The only subsequent candidate-to-export runner changes are fixed-source freeze metadata and the one runner-member archive exemption. Metadata-only patch: 11 insertions, 4 deletions, SHA-256 `507e31efdf967ba9db2d104f1e2d51ee436b97fc96af5846b280627e4e889d2a`; combined base-to-overlay patch: 15 insertions, 4 deletions, SHA-256 `cecd7b7487eb7075062e941f8c2657312364e6a3110eddfbd20fa18731d970fd`.
- Final exported runner raw SHA-256: `7b5201ca5704afd77538c103f393b2c49c8b0947aa0e581277ee0264c845c321`.

## Export and spec pins

- Export root: `D:\temp\it10load01-20261016-r5-resume`.
- Parent archive: 3,877 members, 14,994,406 bytes, SHA-256 `3e32218bd459810130d33559aebbd51524f275deb9e834fe3025bfe89d103bb7`.
- Seven archives contain 1,075 Python members. Source export preflight reports `SOURCE_EXPORT_PREFLIGHT_PASS`; all three source gates passed and 28/28 imports resolved inside the export. The export verifier reports `verification_ok=true`, 37 source pins, no errors. The reused launch dry run reports `LAUNCH_READY`; seven archives and 28 import bindings passed, fixed-source provenance passed, superseded-source/tamper probes tripped, and `_free_endpoints(34)` passed.
- Spec: `D:\temp\it10load01-20261016-r5-resume\pilot-spec-r5-resume.json`, 11,533 bytes, SHA-256 `d5e24680ebf2568eb3034d98e646a833698fa5c9f4e787b27199af8bc6199e48`.
- All 37 spec source pins were checked against exported files; 37/37 match. Exported runner pin is the final overlay SHA above. The spec contains one node: `tests/unit/test_load01_hundred_strategy_30min.py::test_load01_hundred_strategy_sustained`.
- Pilot output path is `D:\temp\iteration10-load01-pilot-e08da3c5-20261016-r5-resume`; it did not exist when the spec was built and remains uncreated. The result file `load01-pilot-result.json` is also absent.
- Pilot mode is set in the spec; intended duration remains 120s. Runtime thresholds and lease/resource guards are source-pinned and unchanged: 100 strategies, 10 accounts, 20 topics, 200 Hz market, 2 order lifecycles/account/sec, 30s lease, the existing resource thresholds, and the 1800s full profile. No threshold or cleanup assertion was lowered.

## Reused preparation artifacts

- Exporter `08-source-export-prep-r5-resume.py`: 32,393 bytes, SHA-256 `7c856e606729a392d96aa14ecdfd9dd1e6df27ebeea4924dd486e430d2427b88`.
- Dry run `11c-dryrun-r5-resume.py`: 14,985 bytes, SHA-256 `ef618e86ffc0788a2c8e73d5c6829837edda779e336475f9a51981d8e0e23569`.
- Verifier `12b-export-verify-r5-resume.py`: 10,974 bytes, SHA-256 `8b804cabbfcca919ce30e096a7a878c3fbd4207851ca79592dec11006500705f`.
- Spec builder `13-build-pilot-spec-r5-resume.py`: 5,311 bytes, SHA-256 `b5f78d7e47b6eb127b5940a0679b41b00d9de333dc1cd5af79029f5e19c0ce08`.

## Root-only launch gate

Do not run the command below until Root independently reviews the package and freshly samples free memory at or above `10,603,200,512` bytes, then performs the serialized process check:

```powershell
Set-Location D:\bt_api_py
& 'C:\anaconda3\python.exe' '.codex-tmp\iteration10-focused-qa.py' 'D:\temp\it10load01-20261016-r5-resume\pilot-spec-r5-resume.json'
```

This is only the prepared 120s pilot command; this record does not authorize or claim execution. Any full 1800s spec remains unused unless a separate pilot passes and Root explicitly schedules it.