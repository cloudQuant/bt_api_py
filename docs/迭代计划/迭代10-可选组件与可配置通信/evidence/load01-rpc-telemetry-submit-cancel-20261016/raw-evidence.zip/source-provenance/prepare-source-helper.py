from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
import zipfile
from pathlib import Path, PurePosixPath

REPO = Path(r"D:\bt_api_py")
R5 = Path(r"D:\temp\it10load01-20261016-r5-resume")
R6 = Path(r"D:\temp\it10load01-20261016-r6-resume")
ARTIFACT = Path(r"D:\temp\iteration10-load01-rpc-telemetry-source-20261016-r1")
SOURCE = ARTIFACT / "source"
MANIFEST = ARTIFACT / "source-provenance.json"
SPEC_PATH = REPO / ".codex-tmp/iteration10-load01-rpc-telemetry-focused-qa-spec-r1.json"
OUTPUT = Path(r"D:\temp\iteration10-load01-rpc-telemetry-focused-qa-root-20261016-r1")
ARCHIVES = (
    "parent.zip",
    "bt_api_base.zip",
    "bt_api_transport_zmq.zip",
    "bt_api_gateway.zip",
    "bt_api_monitor.zip",
    "bt_api_execution.zip",
    "bt_api_risk.zip",
)


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def file_digest(path: Path) -> str:
    return digest(path.read_bytes())


def safe_member(name: str) -> PurePosixPath:
    member = PurePosixPath(name)
    assert not member.is_absolute()
    assert member.parts and all(part not in {"..", "."} for part in member.parts)
    assert ":" not in member.parts[0]
    return member


def extract(archive: Path, destination: Path) -> int:
    count = 0
    with zipfile.ZipFile(archive) as bundle:
        for info in bundle.infolist():
            member = safe_member(info.filename)
            target = destination.joinpath(*member.parts)
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(bundle.read(info))
            count += 1
    return count


assert R5.is_dir() and R6.is_dir()
assert not ARTIFACT.exists() and not SPEC_PATH.exists() and not OUTPUT.exists()
r6_pins = json.loads((R6 / "source-export-pins.json").read_text(encoding="utf-8"))
r6_spec = json.loads(
    (REPO / ".codex-tmp/iteration10-load01-pilot-spec-r6-resume.json").read_text(
        encoding="utf-8"
    )
)
ARTIFACT.mkdir(parents=True)
archives = []
for name in ARCHIVES:
    source_zip = R5 / name
    if name == "parent.zip":
        expected_sha = r6_pins["parent_archive_sha256"]
        expected_bytes = r6_pins["parent_archive_bytes"]
        expected_members = r6_pins["parent_archive_member_count"]
    else:
        package = next(
            row for row in r6_pins["package_gitlinks"]
            if Path(row["path"]).name + ".zip" == name
        )
        expected_sha = package["archive_sha256"]
        expected_bytes = package["archive_bytes"]
        expected_members = package["archive_member_count"]
    raw = source_zip.read_bytes()
    assert digest(raw) == expected_sha and len(raw) == expected_bytes, name
    with zipfile.ZipFile(source_zip) as bundle:
        members = len(bundle.infolist())
    assert members == expected_members, name
    copied = ARTIFACT / name
    shutil.copyfile(source_zip, copied)
    assert file_digest(copied) == expected_sha and copied.stat().st_size == expected_bytes
    archives.append(
        {"name": name, "sha256": expected_sha, "bytes": expected_bytes, "members": members}
    )

SOURCE.mkdir()
member_counts = {"parent.zip": extract(ARTIFACT / "parent.zip", SOURCE)}
for package in r6_pins["package_gitlinks"]:
    name = Path(package["path"]).name + ".zip"
    member_counts[name] = extract(ARTIFACT / name, SOURCE / package["path"])

runner_rel = Path("source/tests/unit/test_load01_hundred_strategy_30min.py")
test_rel = Path("source/tests/unit/test_load01_rpc_telemetry_contract.py")
runner = SOURCE / runner_rel.relative_to("source")
test = SOURCE / test_rel.relative_to("source")
runner.parent.mkdir(parents=True, exist_ok=True)
shutil.copyfile(REPO / "tests/unit/test_load01_hundred_strategy_30min.py", runner)
shutil.copyfile(REPO / "tests/unit/test_load01_rpc_telemetry_contract.py", test)

base_commit = "ce1b678389456ed8e2b13a1bc710abeacb22605a"


def committed_pin(path: str) -> dict[str, object]:
    blob = subprocess.check_output(
        ["git", "-C", str(REPO), "rev-parse", f"{base_commit}:{path}"]
    ).decode().strip()
    raw = subprocess.check_output(["git", "-C", str(REPO), "show", f"{base_commit}:{path}"])
    return {"commit": base_commit, "git_blob": blob, "bytes": len(raw), "sha256": digest(raw)}


r6_root = Path(R6)
member_checks = []
for old_path, expected in r6_spec["source_sha256"].items():
    try:
        relative = Path(old_path).relative_to(r6_root)
    except ValueError:
        continue
    if not relative.parts or relative.parts[0] != "source":
        continue
    target = ARTIFACT / relative
    if relative.as_posix() == runner_rel.as_posix():
        continue
    assert target.is_file(), f"missing frozen member: {relative}"
    actual = file_digest(target)
    assert actual == expected, f"frozen member differs from R6 extraction: {relative}"
    member_checks.append({"path": relative.as_posix(), "sha256": actual})

manifest = {
    "schema": "iteration10-load01-rpc-telemetry-focused-source-v1",
    "evidence_level": "SOURCE_FAKE_RPC_TELEMETRY_CONTRACT_ONLY",
    "purpose": "Focused fake-source QA input only; no pilot node, Host, or load profile is selected.",
    "archive_source": str(R5),
    "materialization": "Fresh extraction from seven R5-frozen ZIPs; no Git worktree or R6 result tree copied.",
    "parent_commit": r6_pins["parent_commit"],
    "package_gitlinks": {row["path"]: row["commit"] for row in r6_pins["package_gitlinks"]},
    "r5_source_export_pins_sha256": r6_pins["r5_source_export_provenance"][
        "source_export_pins_sha256"
    ],
    "archives": archives,
    "extracted_file_counts": member_counts,
    "frozen_member_comparison": {
        "reference_export": str(R6 / "source"),
        "verified_member_count": len(member_checks),
        "all_compared_members_byte_identical": True,
        "runner_member": "Separately pinned candidate overlay; archive bytes remain unchanged.",
        "telemetry_test_member": "New focused test overlay based on committed ce1b678 source.",
    },
    "overlays": {
        "runner": {
            "path": runner_rel.as_posix(),
            "committed_base": committed_pin("tests/unit/test_load01_hundred_strategy_30min.py"),
            "candidate_sha256": file_digest(runner),
            "candidate_bytes": runner.stat().st_size,
            "source": str(REPO / "tests/unit/test_load01_hundred_strategy_30min.py"),
        },
        "telemetry_test": {
            "path": test_rel.as_posix(),
            "committed_base": committed_pin("tests/unit/test_load01_rpc_telemetry_contract.py"),
            "candidate_sha256": file_digest(test),
            "candidate_bytes": test.stat().st_size,
            "source": str(REPO / "tests/unit/test_load01_rpc_telemetry_contract.py"),
        },
    },
    "root_checkout_head_at_preparation": subprocess.check_output(
        ["git", "-C", str(REPO), "rev-parse", "HEAD"]
    ).decode().strip(),
    "scope_note": "Only the two listed files were overlaid into this non-Git export; other checkout WIP was excluded.",
}
MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

source_hashes = {
    str(REPO / ".codex-tmp/iteration10-focused-qa.py"): file_digest(
        REPO / ".codex-tmp/iteration10-focused-qa.py"
    ),
    str(MANIFEST): file_digest(MANIFEST),
}
for name in ARCHIVES:
    source_hashes[str(ARTIFACT / name)] = file_digest(ARTIFACT / name)
for old_path in r6_spec["source_sha256"]:
    try:
        relative = Path(old_path).relative_to(r6_root)
    except ValueError:
        continue
    if relative.parts and relative.parts[0] == "source":
        target = ARTIFACT / relative
        source_hashes[str(target)] = file_digest(target)
source_hashes[str(test)] = file_digest(test)

python = r"C:\anaconda3\python.exe"
pythonpath = ";".join(
    str(SOURCE / row["path"] / "src") for row in r6_pins["package_gitlinks"]
)
spec = {
    "schema": "iteration10-focused-qa-spec-v1",
    "artifact_id": "iteration10-load01-rpc-telemetry-focused-source-20261016-r1",
    "cwd": str(SOURCE),
    "python": python,
    "environment": {"PYTEST_DISABLE_PLUGIN_AUTOLOAD": "1", "PYTHONPATH": pythonpath},
    "unset_environment": [
        "BT_API_LOAD01_MODE", "BT_API_LOAD01_OUTPUT", "BT_API_LOAD01_EXPORT_PINS",
        "BT_API_LOAD01_SOURCE_ROOT", "BT_API_LOAD01_SOURCE_MANIFEST",
    ],
    "pytest_options": ["-q", "--noconftest", "-p", "no:cacheprovider", "-p", "no:asyncio"],
    "nodes": [
        "tests/unit/test_load01_rpc_telemetry_contract.py::test_hook_correlates_submit_cancel_boundaries_and_preserves_rpc_semantics",
        "tests/unit/test_load01_rpc_telemetry_contract.py::test_emergency_cleanup_drains_final_snapshot_before_terminate",
    ],
    "output": str(OUTPUT),
    "repositories": {},
    "source_sha256": dict(sorted(source_hashes.items())),
    "evidence_level": "SOURCE_FAKE_RPC_TELEMETRY_CONTRACT_ONLY",
    "source_resolution_policy": (
        "Direct extraction of the frozen R5 ZIPs plus exactly two individually pinned telemetry "
        "overlays. cwd and PYTHONPATH resolve imports from this non-Git export. Only narrow fake "
        "contract tests are selected; the sustained-load pilot node is excluded."
    ),
    "archive_and_overlay_manifest": str(MANIFEST),
}
SPEC_PATH.write_text(json.dumps(spec, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({
    "source_root": str(SOURCE),
    "manifest": str(MANIFEST),
    "manifest_sha256": file_digest(MANIFEST),
    "spec": str(SPEC_PATH),
    "spec_sha256": file_digest(SPEC_PATH),
    "source_pin_count": len(source_hashes),
    "runner_sha256": file_digest(runner),
    "runner_bytes": runner.stat().st_size,
    "test_sha256": file_digest(test),
    "test_bytes": test.stat().st_size,
    "archives": archives,
    "frozen_member_checks": len(member_checks),
    "qa_output_absent": not OUTPUT.exists(),
    "qa_executed": False,
}, ensure_ascii=False, indent=2))
