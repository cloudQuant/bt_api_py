# AFI10 service-v2 quote consumer R248

## Fixed partial candidate

Repository: `D:\source_code\ai-for-investor`, branch `dev`, HEAD `ad9c8dcc7ba6bef1d2cbd915551fe95932e92ee1` at snapshot. The candidate contains only four paths: the `QuoteService` service-v2 market consumer and its deployment adapter, focused tests, and one synthetic SDK ServiceHost/UI integration test. `candidate-partial-index.json` pins every exact candidate blob and SHA-256. The candidate is a copy of the tested workspace bytes; the four hashes match the prior author run's source pins.

Configured OKX ticker routes use the existing `sdk.market.event` envelope with nested `payload.key` and `payload.data`, and channel `tickers`. The projection maps to the existing QuoteService tick shape. A configured key that errors is returned as an error row without legacy fallback. Sources/symbols lacking an exact service-v2 binding retain the legacy path.

## Author evidence

The author invocation previously reported 11 passed, 0 failures/errors/skips, pytest exit 0 in 3.65 s for `tests/test_quote_service_market.py` and `tests/integration/test_quote_service_market_host_integration.py`. Ruff and `git diff --check` also reported success. This evidence level is `AUTHOR_LOCAL_SYNTHETIC_HOST_UI_ONLY`.

The original invocation was a console-only run; no raw stdout, JUnit file, or result JSON was found in the repository/temp evidence locations. This packet does not reconstruct raw stdout and does not repeat the accepted tests. The exact executed test/source hashes are preserved. Root QA and any later rerun remain separate evidence.

## Evidence boundary

The integration uses a synthetic provider that publishes on `GatewayMarketHub`'s owner thread, then exercises the SDK `ServiceMarketClient` and AFI quote HTTP/UI projection. It does not prove a production OKX WSS queue reaches the Hub. SDK R244 found no owner-thread drain hook; MIG01 is implementing a bounded owner-thread drain and OKX queue handle in a later SDK round. There is no cross-thread `publish` bridge in this AFI candidate.

The slice does not remove old AFI `GatewayRuntime` lifecycle or the legacy quote receiver/runtime path. Those remain active for unconfigured symbols and other existing consumers until a verified service-v2 replacement is available. No real provider/account, deployment install, service start, or formal AFI10 acceptance is claimed.