# Incremental static-review metadata — 2026-10-16

Provenance: Root forwarded the independent reviewer's incremental result from /root/resume_pass_audit_reg_risk_cfg; this note records that reported delta and is not a substitute for the original review artifact.

Decision: GO_STATIC for the exact current pins:
- src/bt_api_risk/portfolio_metrics_v1.py, 20,497 bytes, SHA-256 55a56d84fd314966f6e61fa6098bb7b5ae5cea27fac6df0ae01b562c3d4da23f.
- tests/test_portfolio_metrics_v1.py, 12,431 bytes, SHA-256 57517b596527b8831cbe4fd76aec28bdfc64a5e069042e2f9e7d4f4684d992ad.

Reviewed delta: a price return of exactly -1 yields zero stressed price and values below -1 are rejected; FX return remains strictly above -1 so the FX factor stays positive. SpotStressReportV1.as_of_utc echoes the already validated common cut. A two-row EUR-long / GBP-short hand example reconciles base 1200 and -150 (total 1050), stressed 1056 and -180 (total 876), and PnL -144 and -30 (total -174), by row and in aggregate. Exact position/shock mapping remains enforced.

The review did not run QA or Host and did not edit source. It is static-only; it does not establish FX provenance, account completeness, SDK service integration, or AFI04 acceptance.
