"""Scoped windowed-count threshold rules over durable monitor outbox events.

This module adds one minimal monitor rule type on top of the existing durable
outbox consumption (:class:`bt_api_monitor.durable.DurableOutboxConsumer`):

* a rule pins one exact ``outbox_scope`` plus one ``event_type`` (scoped
  configuration, no wildcards), a bounded observation window, and a count
  threshold;
* an alert fires when the number of observations inside the window first
  reaches ``threshold_count``; the rule then latches until the window drops
  below the threshold again and re-arms;
* duplicate suppression uses a monotonic per-rule sequence watermark that
  lives only inside one loop lifetime: a redelivered event carries the same
  ``event_id`` and sequence, never increments a count twice, and a pending
  alert is retried instead.  Across a consumer restart the durable checkpoint
  prevents re-delivery of acknowledged events, but a suffix replayed after a
  lost checkpoint is re-counted into a fresh window: the re-derived crossing
  alert can be anchored to a different triggering event when the checkpoint
  was lost at the crossing, and its ``alert_id`` (a deterministic digest over
  rule, scope, and triggering ``event_id``) can differ accordingly.
  Duplicate suppression covers same-anchor redeliveries within one loop
  lifetime, not a restart with lost rule state; alert sinks are at-least-once
  and cannot assume ``alert_id`` de-duplication across restarts.

The loop is deliberately inert outside its own read/checkpoint path: it never
appends to the outbox, never touches the control ledger, and performs no Risk
admission, order dispatch, or freeze action.  Alerting is observation-only
(告警不冒充硬风控); the evaluator stays internal to ``bt_api_monitor`` and adds
no new service role.  No network client, worker thread, or scheduler is
created: a deployment calls :meth:`ScopedThresholdRuleLoop.run_once` from its
own supervised loop.
"""

from __future__ import annotations

import hashlib
import json
import math
import re
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Callable, Optional

from .durable import (
    DurableOutbox,
    DurableOutboxConsumer,
    SequencedOutboxEvent,
)

THRESHOLD_ALERT_ID_PREFIX = "monitor-threshold-alert-v1:"
DEFAULT_RULE_CONSUMER_ID = "monitor.threshold-rules.v1"
MAX_RULE_WINDOW_SECONDS = 86_400.0
MAX_RULE_THRESHOLD_COUNT = 1_000_000
MAX_RUN_LIMIT = 1000
_ALERT_ID_DOMAIN = "bt-api-monitor.threshold-alert.v1"
_MAX_RULE_ID_BYTES = 128
_MAX_SCOPE_TEXT_BYTES = 256
_MAX_EVENT_TYPE_BYTES = 128
_RULE_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$")


class ThresholdRuleError(ValueError):
    """A rule, bounded run request, or scoped configuration is invalid."""


@dataclass(frozen=True)
class ThresholdRule:
    """One exact scope/event-type windowed count threshold."""

    rule_id: str
    outbox_scope: str
    event_type: str
    window_seconds: float
    threshold_count: int

    def __post_init__(self) -> None:
        if (
            type(self.rule_id) is not str
            or len(self.rule_id.encode("utf-8", "strict")) > _MAX_RULE_ID_BYTES
            or _RULE_ID_RE.fullmatch(self.rule_id) is None
        ):
            raise ThresholdRuleError("rule_id has an invalid format")
        _validate_scoped_text("outbox_scope", self.outbox_scope, _MAX_SCOPE_TEXT_BYTES)
        _validate_scoped_text("event_type", self.event_type, _MAX_EVENT_TYPE_BYTES)
        if isinstance(self.window_seconds, bool) or not isinstance(
            self.window_seconds, (int, float)
        ):
            raise ThresholdRuleError("window_seconds must be a finite duration")
        try:
            window_seconds = float(self.window_seconds)
        except OverflowError:
            raise ThresholdRuleError("window_seconds must be a finite duration") from None
        if not math.isfinite(window_seconds) or not 0.0 < window_seconds <= MAX_RULE_WINDOW_SECONDS:
            raise ThresholdRuleError("window_seconds is outside the bounded range")
        if (
            type(self.threshold_count) is not int
            or not 1 <= self.threshold_count <= MAX_RULE_THRESHOLD_COUNT
        ):
            raise ThresholdRuleError("threshold_count is outside the bounded range")


@dataclass(frozen=True)
class ThresholdAlert:
    """One deterministic windowed-count crossing; alerting is read-only."""

    alert_id: str
    rule_id: str
    outbox_scope: str
    event_type: str
    window_seconds: float
    threshold_count: int
    observed_count: int
    triggering_event_id: str
    triggering_sequence: int
    triggered_at: float


@dataclass(frozen=True)
class ThresholdRuleStatus:
    """Read-only snapshot of one rule's evaluation state."""

    rule_id: str
    window_count: int
    counted_events: int
    last_counted_sequence: int
    alerts_emitted: int
    armed: bool


@dataclass
class _RuleState:
    rule: ThresholdRule
    window: deque[tuple[float, str]] = field(default_factory=deque)
    counted_events: int = 0
    last_counted_sequence: int = 0
    alerts_emitted: int = 0
    armed: bool = True
    pending_alert: Optional[ThresholdAlert] = None  # noqa: UP045 -- Python 3.9 support.


AlertSink = Callable[[ThresholdAlert], None]


class ScopedThresholdRuleLoop:
    """Consume configured outbox scopes and evaluate windowed count rules.

    One :class:`~bt_api_monitor.durable.DurableOutboxConsumer` is used per
    configured scope with a stable consumer identity, so each scope keeps its
    own durable checkpoint.  Delivery failures propagate unchanged
    (:class:`OutboxDeliveryError`): the caller decides freeze/health policy
    while the durable cursor stays at the last acknowledgement.
    """

    def __init__(
        self,
        outbox: DurableOutbox,
        rules: tuple[ThresholdRule, ...],
        alert_sink: AlertSink,
        *,
        consumer_id: str = DEFAULT_RULE_CONSUMER_ID,
        clock: Optional[Callable[[], float]] = None,  # noqa: UP045 -- Python 3.9 support.
    ) -> None:
        if not isinstance(outbox, DurableOutbox) or outbox.is_read_only:
            raise ThresholdRuleError("outbox must be a writable DurableOutbox")
        if type(rules) is not tuple or not rules:
            raise ThresholdRuleError("rules must be a non-empty tuple")
        if any(type(rule) is not ThresholdRule for rule in rules):
            raise ThresholdRuleError("rules must contain ThresholdRule values")
        rule_ids = [rule.rule_id for rule in rules]
        if len(set(rule_ids)) != len(rule_ids):
            raise ThresholdRuleError("duplicate rule_id values are not allowed")
        _validate_scoped_text("consumer_id", consumer_id, _MAX_SCOPE_TEXT_BYTES)
        if not callable(alert_sink):
            raise ThresholdRuleError("alert_sink must be callable")

        scope_rules: dict[str, list[ThresholdRule]] = {}
        for rule in rules:
            scope_rules.setdefault(rule.outbox_scope, []).append(rule)
        self._outbox = outbox
        self._consumer_id = consumer_id
        self._alert_sink = alert_sink
        self._clock = clock or time.time
        self._states: dict[str, _RuleState] = {rule.rule_id: _RuleState(rule) for rule in rules}
        self._scope_states: dict[str, tuple[_RuleState, ...]] = {
            scope: tuple(
                self._states[rule.rule_id] for rule in sorted(group, key=lambda r: r.rule_id)
            )
            for scope, group in sorted(scope_rules.items())
        }

    @property
    def configured_scopes(self) -> tuple[str, ...]:
        """Return the exact outbox scopes this loop is allowed to consume."""

        return tuple(self._scope_states)

    def checkpoint(self, outbox_scope: str) -> int:
        """Return the durable consumer checkpoint for one configured scope."""

        if outbox_scope not in self._scope_states:
            raise ThresholdRuleError("outbox_scope is not configured")
        return self._outbox.checkpoint(self._consumer_id, outbox_scope)

    def rule_status(self, rule_id: str) -> ThresholdRuleStatus:
        """Return a read-only snapshot of one configured rule's state."""

        state = self._states.get(rule_id)
        if state is None:
            raise ThresholdRuleError("rule_id is not configured")
        return ThresholdRuleStatus(
            rule_id=rule_id,
            window_count=len(state.window),
            counted_events=state.counted_events,
            last_counted_sequence=state.last_counted_sequence,
            alerts_emitted=state.alerts_emitted,
            armed=state.armed,
        )

    def run_once(self, limit: int = 100) -> tuple[ThresholdAlert, ...]:
        """Consume every configured scope once and return delivered alerts.

        Scopes are processed in deterministic sorted order.  The first scope
        whose delivery or checkpoint fails raises and stops the pass; events
        already acknowledged in earlier scopes stay acknowledged.
        """

        if type(limit) is not int or not 1 <= limit <= MAX_RUN_LIMIT:
            raise ThresholdRuleError("limit is outside the bounded run range")
        emitted: list[ThresholdAlert] = []
        for scope in self._scope_states:
            consumer = DurableOutboxConsumer(
                self._outbox,
                self._consumer_id,
                scope,
                self._deliver_for_scope(scope, emitted),
            )
            consumer.consume(limit=limit)
        return tuple(emitted)

    def _deliver_for_scope(
        self, scope: str, emitted: list[ThresholdAlert]
    ) -> Callable[[SequencedOutboxEvent], None]:
        states = self._scope_states[scope]

        def deliver(item: SequencedOutboxEvent) -> None:
            for state in states:
                if item.event.event_type != state.rule.event_type:
                    continue
                alert = self._observe(state, item)
                if alert is not None:
                    emitted.append(alert)

        return deliver

    def _observe(self, state: _RuleState, item: SequencedOutboxEvent) -> Optional[ThresholdAlert]:  # noqa: UP045 -- Python 3.9 support.
        """Count one observation, suppressing duplicates by sequence.

        The outbox delivers strictly ascending sequences per scope; any
        delivery at or below the watermark is the same event (same
        ``event_id``) being redelivered after a failed checkpoint and never
        increments the window again.
        """

        now = float(self._clock())
        self._prune(state, now)
        if item.sequence <= state.last_counted_sequence:
            # Redelivery: retry a crossing whose sink call failed before.
            return self._retry_pending_alert(state)
        state.window.append((now, item.event.event_id))
        state.counted_events += 1
        state.last_counted_sequence = item.sequence
        if state.armed and len(state.window) >= state.rule.threshold_count:
            state.armed = False
            alert = ThresholdAlert(
                alert_id=_alert_id(state.rule, item.event.event_id),
                rule_id=state.rule.rule_id,
                outbox_scope=state.rule.outbox_scope,
                event_type=state.rule.event_type,
                window_seconds=state.rule.window_seconds,
                threshold_count=state.rule.threshold_count,
                observed_count=len(state.window),
                triggering_event_id=item.event.event_id,
                triggering_sequence=item.sequence,
                triggered_at=now,
            )
            state.pending_alert = alert
            self._alert_sink(alert)
            state.pending_alert = None
            state.alerts_emitted += 1
            return alert
        return None

    def _retry_pending_alert(self, state: _RuleState) -> Optional[ThresholdAlert]:  # noqa: UP045 -- Python 3.9 support.
        alert = state.pending_alert
        if alert is None:
            return None
        self._alert_sink(alert)
        state.pending_alert = None
        state.alerts_emitted += 1
        return alert

    def _prune(self, state: _RuleState, now: float) -> None:
        cutoff = now - state.rule.window_seconds
        window = state.window
        while window and window[0][0] < cutoff:
            window.popleft()
        if len(window) < state.rule.threshold_count:
            state.armed = True


def _alert_id(rule: ThresholdRule, triggering_event_id: str) -> str:
    digest = hashlib.sha256(
        json.dumps(
            {
                "domain": _ALERT_ID_DOMAIN,
                "event_id": triggering_event_id,
                "outbox_scope": rule.outbox_scope,
                "rule_id": rule.rule_id,
            },
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    ).hexdigest()
    return THRESHOLD_ALERT_ID_PREFIX + digest


def _validate_scoped_text(name: str, value: object, max_bytes: int) -> None:
    if type(value) is not str or not value or value != value.strip():
        raise ThresholdRuleError(name + " is required and must be trimmed text")
    try:
        encoded = value.encode("utf-8", "strict")
    except UnicodeError:
        raise ThresholdRuleError(name + " is not valid UTF-8") from None
    if len(encoded) > max_bytes or any(
        ord(character) < 32 or ord(character) == 127 for character in value
    ):
        raise ThresholdRuleError(name + " is outside the bounded text range")
    if "*" in value:
        raise ThresholdRuleError(name + " must not contain wildcards")


__all__ = [
    "DEFAULT_RULE_CONSUMER_ID",
    "MAX_RULE_THRESHOLD_COUNT",
    "MAX_RULE_WINDOW_SECONDS",
    "MAX_RUN_LIMIT",
    "THRESHOLD_ALERT_ID_PREFIX",
    "ScopedThresholdRuleLoop",
    "ThresholdAlert",
    "ThresholdRule",
    "ThresholdRuleError",
    "ThresholdRuleStatus",
]
